import { useState, useEffect, useCallback, useRef } from "react";
import {
  ChevronDown, ChevronRight, Swords, Users, MapPin, Crown,
  Scroll, Clock, Star, BookOpen, Dice6,
  Target, Heart, CheckCircle, Circle, ArrowRight, Plus,
  Compass, Mountain, Castle, Skull, Flag, TrendingUp, TrendingDown, Minus,
  SkipForward, Search, Bell, Settings, X, Edit3, Trash2, Eye, EyeOff,
  Globe, Layers, Activity, Upload, Download, FileText, Save, Copy,
  Calendar, Lock, Unlock, ToggleLeft, ToggleRight, AlertTriangle,
  Package, Shield, Wand2, Map as MapIcon, Link, RefreshCw, ChevronUp,
  MoreVertical, Check, Image, Bold, Italic, List, Type, Heading
} from "lucide-react";

/* ═══════════════════════════════════════════════════════════════════════════
   PHMURT STUDIOS — CAMPAIGN MANAGER
   Tokens & patterns matched 1:1 to style.css + campaigns.html
   ═══════════════════════════════════════════════════════════════════════════ */

/* Design tokens wired to CSS custom properties from style.css.
   Dark/light toggle is handled by html.light-mode — these vars
   resolve automatically so the campaign manager follows the site theme. */
const T = {
  bg:            "var(--bg)",
  bgNav:         "var(--bg-nav)",
  bgCard:        "var(--bg-card)",
  bgHover:       "var(--bg-hover)",
  bgMid:         "var(--bg-mid)",
  bgInput:       "var(--bg-input)",
  text:          "var(--text)",
  textDim:       "var(--text-dim)",
  textMuted:     "var(--text-muted)",
  textFaint:     "var(--text-faint)",
  crimson:       "var(--crimson)",
  crimsonDim:    "var(--crimson-dim)",
  crimsonSoft:   "var(--crimson-soft)",
  crimsonBorder: "var(--crimson-border)",
  border:        "var(--border)",
  borderMid:     "var(--border-mid)",
  ui:            "'Cinzel', serif",
  body:          "'Spectral', Georgia, serif",
};

/* Read a computed CSS variable value — needed for <canvas> fillStyle/strokeStyle
   which cannot interpret var() references. */
const cssVar = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();

// ─── BLANK CAMPAIGN TEMPLATE ────────────────────────────────────────────────

const NEW_CAMPAIGN = () => ({
  name: "Untitled Campaign", status: "active", startDate: new Date().toISOString().slice(0,10),
  nextSession: "", sessionsPlayed: 0,
  sessionSchedule: { dayOfWeek: 6, hour: 19, minute: 0, frequency: "weekly", timezone: "EST" },
  modules: {
    timeline: true, worldState: true, playMode: true, scheduler: true,
    questTracker: true, factionTracker: true, npcTracker: true,
    playerUploads: true, notesEditor: true,
  },
  party: [], quests: [], factions: [], regions: [], npcs: [],
  timeline: [], campaignNotes: [],
  activity: [{ time: "Just now", text: "Campaign created" }],
});

// ─── EXAMPLE CAMPAIGN (saved to account) ────────────────────────────────────

const EXAMPLE_CAMPAIGN = {
  name: "The Shattered Crown", status: "active", startDate: "2025-09-14",
  nextSession: "2026-04-02T19:00:00", sessionsPlayed: 24,
  sessionSchedule: { dayOfWeek: 3, hour: 19, minute: 0, frequency: "weekly", timezone: "EST" },
  modules: {
    timeline: true, worldState: true, playMode: true, scheduler: true,
    questTracker: true, factionTracker: true, npcTracker: true,
    playerUploads: true, notesEditor: true,
  },
  party: [
    { id:1, name:"Kael Stormwind",   cls:"Paladin", lv:9, hp:78, maxHp:85, ac:20, player:"Marcus", status:"healthy", sheetUrl:null, sheetName:null, race:"Human", bio:"Former soldier turned holy warrior." },
    { id:2, name:"Lyra Nightbloom",  cls:"Wizard",  lv:9, hp:42, maxHp:48, ac:15, player:"Sarah",  status:"healthy", sheetUrl:null, sheetName:null, race:"Half-Elf", bio:"Arcane scholar from the Moonspire Academy." },
    { id:3, name:"Thorne Ashwick",   cls:"Rogue",   lv:9, hp:55, maxHp:62, ac:17, player:"Jake",   status:"poisoned", sheetUrl:null, sheetName:null, race:"Halfling", bio:"Charming thief with a heart of gold." },
    { id:4, name:"Bronwyn Ironfist", cls:"Cleric",  lv:9, hp:68, maxHp:70, ac:18, player:"Emma",   status:"healthy", sheetUrl:null, sheetName:null, race:"Dwarf", bio:"Devoted healer and keeper of old rites." },
    { id:5, name:"Fenris Darkmoor",  cls:"Ranger",  lv:9, hp:30, maxHp:58, ac:16, player:"Alex",   status:"wounded", sheetUrl:null, sheetName:null, race:"Human", bio:"Lone tracker haunted by a dark past." },
  ],
  quests: [
    { id:1, title:"Retrieve the Crown of Aldenmire",  type:"main", status:"active", urgency:"high",     faction:"The Silver Accord", region:"Aldenmire Ruins" },
    { id:2, title:"Investigate the Blighted Marsh",    type:"side", status:"active", urgency:"medium",   faction:"Marsh Wardens",     region:"Greymoor Marshes" },
    { id:3, title:"Escort the Merchant Caravan",       type:"side", status:"completed", urgency:"low",   faction:"Merchant Guild",    region:"King's Road" },
    { id:4, title:"Destroy the Shadow Obelisk",        type:"main", status:"active", urgency:"critical", faction:"The Hollow",        region:"Shadowfen" },
    { id:5, title:"Win the Tournament of Blades",      type:"side", status:"upcoming", urgency:"low",    faction:"Kingdom of Valdris",region:"Valdris Capital" },
  ],
  factions: [
    { id:1, name:"The Silver Accord",  attitude:"allied",   power:72, trend:"rising",    desc:"Coalition of free cities opposing the Hollow",      color:"#a4b5cc" },
    { id:2, name:"The Hollow",         attitude:"hostile",  power:88, trend:"rising",    desc:"Shadow cult seeking the Shattered Crown",            color:"#8b50f0" },
    { id:3, name:"Kingdom of Valdris", attitude:"neutral",  power:65, trend:"declining", desc:"Once-mighty kingdom weakened by civil war",          color:"#e8940a" },
    { id:4, name:"Marsh Wardens",      attitude:"friendly", power:30, trend:"stable",   desc:"Druidic guardians of the Greymoor Marshes",          color:"#2e8b57" },
    { id:5, name:"Merchant Guild",     attitude:"friendly", power:55, trend:"rising",    desc:"Trade consortium with vast information networks",    color:"#d4433a" },
  ],
  regions: [
    { id:1, name:"Valdris Capital",  type:"city",       ctrl:"Kingdom of Valdris", threat:"low",     state:"tense",      visited:true },
    { id:2, name:"Greymoor Marshes", type:"wilderness",  ctrl:"Marsh Wardens",     threat:"medium",  state:"corrupted",  visited:true },
    { id:3, name:"Aldenmire Ruins",  type:"dungeon",     ctrl:"The Hollow",        threat:"extreme", state:"dangerous",  visited:false },
    { id:4, name:"Thornhaven",       type:"town",        ctrl:"The Silver Accord", threat:"low",     state:"rebuilding", visited:true },
    { id:5, name:"Shadowfen",        type:"wilderness",  ctrl:"The Hollow",        threat:"high",    state:"blighted",   visited:true },
    { id:6, name:"King's Road",      type:"route",       ctrl:"Kingdom of Valdris",threat:"medium",  state:"patrolled",  visited:true },
  ],
  npcs: [
    { id:1, name:"Commander Elara Voss", faction:"The Silver Accord", loc:"Thornhaven",       attitude:"allied",   role:"quest giver", alive:true },
    { id:2, name:"The Whisper King",     faction:"The Hollow",        loc:"Unknown",           attitude:"hostile",  role:"antagonist",  alive:true },
    { id:3, name:"Barkeep Milo",         faction:null,                loc:"Thornhaven",       attitude:"friendly", role:"informant",   alive:true },
    { id:4, name:"Warden Thistle",       faction:"Marsh Wardens",     loc:"Greymoor Marshes", attitude:"cautious", role:"ally",        alive:true },
    { id:5, name:"Lord Aldric Valdris",  faction:"Kingdom of Valdris",loc:"Valdris Capital",  attitude:"neutral",  role:"political",   alive:true },
    { id:6, name:"Seraphine the Lost",   faction:"The Hollow",        loc:"Shadowfen",        attitude:"hostile",  role:"lieutenant",  alive:false },
  ],
  timeline: [
    { id:24, n:24, title:"Into the Shadowfen", date:"2026-03-26",
      summary:"The party ventured into the Shadowfen seeking the Shadow Obelisk. They fought corrupted beasts and discovered Seraphine the Lost guarding a ritual site. After a fierce battle, Seraphine was defeated but the obelisk remains active.",
      events:[
        { id:"e1", type:"encounter",    text:"Ambush by 6 Blighted Wolves in the outer marshes",  outcome:"Victory — Fenris badly wounded", dmOnly:false },
        { id:"e2", type:"discovery",    text:"Found Seraphine's journal revealing the Crown's true location", outcome:"New quest lead unlocked", dmOnly:true },
        { id:"e3", type:"encounter",    text:"Boss fight: Seraphine the Lost (CR 11 Shadow Mage)", outcome:"Seraphine slain, obelisk still active", dmOnly:false },
        { id:"e4", type:"world_change", text:"The Hollow's grip on Shadowfen weakens slightly", outcome:"Faction power shift", dmOnly:false },
        { id:"e5", type:"loot",         text:"Acquired Seraphine's Shadow Staff and encoded map", outcome:"Key item obtained", dmOnly:false },
      ],
      changes:["Seraphine the Lost killed","Hollow power reduced","Aldenmire path revealed"], notes:"Party handled the encounter well. Fenris nearly went down twice.", dmOnly:false },
    { id:23, n:23, title:"The Warden's Warning", date:"2026-03-19",
      summary:"Warden Thistle warned the party about growing darkness in the marshes. The party helped defend a druidic shrine and earned the Marsh Wardens' trust.",
      events:[
        { id:"e6", type:"roleplay",     text:"Extended negotiation with Warden Thistle for safe passage", outcome:"Alliance formed", dmOnly:false },
        { id:"e7", type:"encounter",    text:"Defense of the Moonwell Shrine against shadow creatures", outcome:"Shrine protected", dmOnly:false },
        { id:"e8", type:"world_change", text:"Marsh Wardens formally allied with the party", outcome:"Faction relationship upgrade", dmOnly:false },
      ],
      changes:["Marsh Wardens now allied","Moonwell Shrine protected"], notes:"", dmOnly:false },
    { id:22, n:22, title:"Crossroads at King's Road", date:"2026-03-12",
      summary:"Completed the merchant escort quest. Encountered Hollow agents on the road. Learned about political tensions in Valdris.",
      events:[
        { id:"e9", type:"encounter",      text:"Hollow ambush on the merchant caravan", outcome:"Repelled, captured one agent", dmOnly:false },
        { id:"e10", type:"roleplay",       text:"Interrogation of captured Hollow agent", outcome:"Learned of Aldenmire excavation", dmOnly:true },
        { id:"e11", type:"quest_complete", text:"Merchant caravan delivered safely to Thornhaven", outcome:"Gold + merchant guild favor", dmOnly:false },
      ],
      changes:["Merchant Guild favor increased","Intel on Hollow gained"], notes:"", dmOnly:false },
    { id:21, n:21, title:"The Gathering Storm", date:"2026-03-05",
      summary:"Party arrived in Thornhaven. Met Commander Voss, learned about the Shattered Crown's history and the Silver Accord's formation.",
      events:[
        { id:"e12", type:"roleplay",  text:"Council meeting with Silver Accord leadership", outcome:"Main quest briefing received", dmOnly:false },
        { id:"e13", type:"discovery", text:"Ancient texts in Thornhaven library hint at Crown's power", outcome:"Lore unlocked", dmOnly:false },
      ],
      changes:["Silver Accord quest line activated"], notes:"", dmOnly:false },
  ],
  campaignNotes: [],
  activity: [
    { time:"2h ago", text:"Added session 24 notes and loot distribution" },
    { time:"5h ago", text:"Updated Fenris HP after healing rest" },
    { time:"1d ago", text:"Marked Seraphine the Lost as deceased" },
    { time:"1d ago", text:"Updated Hollow faction power (−5)" },
    { time:"2d ago", text:"Added encoded map to party inventory" },
    { time:"3d ago", text:"Scheduled next session: April 2nd" },
  ],
};

// ─── PRIMITIVES ─────────────────────────────────────────────────────────────

const Tag = ({ children, variant = "default" }) => {
  const m = {
    default:  { bg: T.crimsonSoft, c: T.crimson,  b: T.crimsonBorder },
    danger:   { bg: "rgba(212,67,58,0.16)", c: "#f06858", b: "rgba(212,67,58,0.42)" },
    success:  { bg: "rgba(52,168,83,0.14)", c: "#5ee09a", b: "rgba(52,168,83,0.32)" },
    warning:  { bg: "rgba(234,138,16,0.12)", c: "#f5c45c", b: "rgba(234,138,16,0.28)" },
    info:     { bg: "rgba(148,175,210,0.12)", c: "#b0c8e4", b: "rgba(148,175,210,0.28)" },
    critical: { bg: "rgba(212,67,58,0.22)", c: "#ff6b6b", b: "rgba(212,67,58,0.50)" },
    muted:    { bg: T.bgInput, c: T.textMuted, b: T.border },
  };
  const s = m[variant] || m.default;
  return (
    <span style={{
      display:"inline-block", background:s.bg, color:s.c, border:`1px solid ${s.b}`,
      fontFamily:T.ui, fontSize:"8px", letterSpacing:"1px", textTransform:"uppercase",
      padding:"3px 8px", borderRadius:"2px", fontWeight:500, whiteSpace:"nowrap",
    }}>{children}</span>
  );
};

const HpBar = ({ val, max, color }) => (
  <div style={{ width:"100%", height:6, background:T.bgInput, border:`1px solid ${T.border}`, borderRadius:"2px", overflow:"hidden" }}>
    <div style={{ width:`${Math.round(val/max*100)}%`, height:"100%", background:color||T.crimson, transition:"width 0.3s ease" }} />
  </div>
);

const PowerBar = ({ val, max, color }) => (
  <div style={{ width:"100%", height:4, background:T.bgInput, borderRadius:"2px", overflow:"hidden" }}>
    <div style={{ width:`${Math.round(val/max*100)}%`, height:"100%", background:color||T.crimson, transition:"width 0.3s ease" }} />
  </div>
);

const SectionTitle = ({ icon:Icon, children, count, action }) => (
  <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16 }}>
    <div style={{ display:"flex", alignItems:"center", gap:8 }}>
      {Icon && <Icon size={14} color={T.crimson} />}
      <span style={{ fontFamily:T.ui, fontSize:"11px", letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", fontWeight:500 }}>{children}</span>
      {count != null && <span style={{ fontFamily:T.ui, fontSize:"9px", color:T.textMuted, letterSpacing:"1px" }}>({count})</span>}
    </div>
    {action}
  </div>
);

const LinkBtn = ({ children, onClick }) => (
  <button onClick={onClick} style={{
    background:"none", border:"none", cursor:"pointer", padding:0,
    fontFamily:T.ui, fontSize:"9px", letterSpacing:"2px", color:T.textMuted, textTransform:"uppercase",
    fontWeight:500, display:"flex", alignItems:"center", gap:4, transition:"color 0.2s",
  }}>{children}</button>
);

const CrimsonBtn = ({ children, onClick, secondary, small, disabled, style:sx }) => (
  <button onClick={disabled?undefined:onClick} style={{
    padding: small ? "6px 14px" : "10px 24px",
    border: secondary ? `1px solid ${T.border}` : "none",
    background: disabled ? T.bgMid : secondary ? "transparent" : T.crimson,
    color: disabled ? T.textFaint : secondary ? T.textMuted : T.text,
    fontFamily:T.ui, fontSize: small ? "8px" : "9px", letterSpacing:"2px", textTransform:"uppercase",
    cursor: disabled ? "default" : "pointer", borderRadius:"2px", fontWeight:500, transition:"all 0.2s",
    display:"inline-flex", alignItems:"center", gap:8, opacity: disabled ? 0.5 : 1, ...sx,
  }}>{children}</button>
);

const Section = ({ children, style }) => (
  <div style={{
    background:T.bgCard, border:`1px solid ${T.crimsonBorder}`, borderRadius:"4px",
    padding:28, boxShadow:"0 2px 8px rgba(0,0,0,0.08)", ...style,
  }}>{children}</div>
);

const Input = ({ value, onChange, placeholder, style:sx, type="text", ...rest }) => (
  <input type={type} value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} {...rest}
    style={{ padding:"8px 12px", border:`1px solid ${T.border}`, borderRadius:"2px", background:T.bgInput,
      fontSize:13, fontFamily:T.body, color:T.text, outline:"none", width:"100%", ...sx }} />
);

const Select = ({ value, onChange, children, style:sx }) => (
  <select value={value} onChange={e=>onChange(e.target.value)}
    style={{ padding:"8px 12px", border:`1px solid ${T.border}`, borderRadius:"2px", background:T.bgCard,
      fontSize:13, fontFamily:T.body, color:T.text, outline:"none", cursor:"pointer", ...sx }}>
    {children}
  </select>
);

const Textarea = ({ value, onChange, placeholder, rows=4, style:sx }) => (
  <textarea value={value} onChange={e=>onChange(e.target.value)} placeholder={placeholder} rows={rows}
    style={{ padding:"10px 12px", border:`1px solid ${T.border}`, borderRadius:"2px", background:T.bgInput,
      fontSize:13, fontFamily:T.body, color:T.text, outline:"none", width:"100%", resize:"vertical",
      lineHeight:1.7, ...sx }} />
);

const Modal = ({ open, onClose, title, children, wide }) => {
  if (!open) return null;
  return (
    <div style={{ position:"fixed", inset:0, background:"rgba(0,0,6,0.70)", zIndex:1000, display:"flex", alignItems:"center", justifyContent:"center", padding:32 }}
      onClick={onClose}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:T.bgCard, border:`1px solid ${T.crimsonBorder}`, borderRadius:"4px",
        width: wide ? 740 : 520, maxHeight:"85vh", overflow:"hidden", display:"flex", flexDirection:"column",
        boxShadow:"0 12px 40px rgba(0,0,6,0.50)",
      }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"18px 24px", borderBottom:`1px solid ${T.border}` }}>
          <span style={{ fontFamily:T.ui, fontSize:11, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", fontWeight:500 }}>{title}</span>
          <button onClick={onClose} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:4 }}><X size={16}/></button>
        </div>
        <div style={{ padding:24, overflowY:"auto", flex:1 }}>{children}</div>
      </div>
    </div>
  );
};

const ToggleSwitch = ({ on, onToggle, label }) => (
  <div onClick={onToggle} style={{ display:"flex", alignItems:"center", gap:12, cursor:"pointer", padding:"8px 0" }}>
    {on ? <ToggleRight size={22} color={T.crimson}/> : <ToggleLeft size={22} color={T.textFaint}/>}
    <span style={{ fontSize:13, fontFamily:T.body, color: on ? T.text : T.textMuted, fontWeight:300 }}>{label}</span>
  </div>
);

function useCountdown(target) {
  const [s,setS] = useState("");
  useEffect(() => {
    const tick = () => {
      const d = new Date(target) - new Date();
      if (d<=0) { setS("Now"); return; }
      const days=Math.floor(d/864e5), hrs=Math.floor((d%864e5)/36e5), min=Math.floor((d%36e5)/6e4);
      setS(days>0 ? `${days}d ${hrs}h` : `${hrs}h ${min}m`);
    };
    tick(); const id=setInterval(tick,60000); return ()=>clearInterval(id);
  }, [target]);
  return s;
}

let _eid = 100;
const eid = () => `e${_eid++}`;
let _id = 100;
const uid = () => _id++;

// ─── FANTASY MAP ICONS (hand-drawn cartography style) ───────────────────────

const MapIconMountain = ({ size=32, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Main peak — organic, slightly asymmetric */}
    <path d="M24 6 C23 6, 14 22, 10 32 Q9.5 33, 10 33.5 L17 33 Q18 28, 20 24 C21 22, 22.5 18, 24 14 C25.5 18, 27 22, 28 24 Q30 28, 31 33 L38 33.5 Q38.5 33, 38 32 C34 22, 25 6, 24 6Z" fill={color} opacity="0.12"/>
    <path d="M24 6 C23 6, 14 22, 10 32 Q9.5 33, 10 33.5 L17 33 Q18 28, 20 24 C21 22, 22.5 18, 24 14 C25.5 18, 27 22, 28 24 Q30 28, 31 33 L38 33.5 Q38.5 33, 38 32 C34 22, 25 6, 24 6Z" stroke={color} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Snow cap — jagged */}
    <path d="M24 6 C23.2 6, 20 13, 18.5 17 L21 15.5 L22 17 L24 12 L26 17 L27 15.5 L29.5 17 C28 13, 24.8 6, 24 6Z" fill={color} opacity="0.25"/>
    {/* Left secondary peak */}
    <path d="M12 33 C11 33, 7 26, 5 22 Q4 20.5, 4 22 C3 27, 2 33, 3 34 Q3.5 34.5, 4 34 L12 34Z" fill={color} opacity="0.08"/>
    <path d="M5 22 Q4 20.5, 4 22 C3 27, 2 33, 3 34 L12 34 L12 33 C11 33, 7 26, 5 22Z" stroke={color} strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.6"/>
    {/* Right secondary peak */}
    <path d="M36 33 C37 33, 41 27, 43 23 Q44 21.5, 44 23 C45 28, 46 33, 45 34 Q44.5 34.5, 44 34 L36 34Z" fill={color} opacity="0.08"/>
    <path d="M43 23 Q44 21.5, 44 23 C45 28, 46 33, 45 34 L36 34 L36 33 C37 33, 41 27, 43 23Z" stroke={color} strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.6"/>
    {/* Ridgelines for texture */}
    <path d="M19 25 Q21 21, 24 14" stroke={color} strokeWidth="0.7" strokeLinecap="round" opacity="0.3" fill="none"/>
    <path d="M29 25 Q27 21, 24 14" stroke={color} strokeWidth="0.7" strokeLinecap="round" opacity="0.3" fill="none"/>
    {/* Ground line */}
    <path d="M1 34 Q12 33, 24 34 Q36 35, 47 34" stroke={color} strokeWidth="1.2" strokeLinecap="round" fill="none" opacity="0.4"/>
  </svg>
);

const MapIconMountainSmall = ({ size=24, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M16 5 C15 5, 8 17, 5 23 Q4.5 24, 5 24 L27 24 Q27.5 24, 27 23 C24 17, 17 5, 16 5Z" fill={color} opacity="0.1"/>
    <path d="M16 5 C15 5, 8 17, 5 23 L27 23 C24 17, 17 5, 16 5Z" stroke={color} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    <path d="M16 5 C15.5 5, 13 10, 12 13 L14 11.5 L16 8 L18 11.5 L20 13 C19 10, 16.5 5, 16 5Z" fill={color} opacity="0.2"/>
    <path d="M11 18 Q13 14, 16 8" stroke={color} strokeWidth="0.6" opacity="0.25" fill="none"/>
    <path d="M2 24 Q16 23, 30 24" stroke={color} strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.35"/>
  </svg>
);

const MapIconTree = ({ size=28, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 32 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Organic deciduous tree with layered canopy */}
    <path d="M16 30 L16 20" stroke={color} strokeWidth="1.8" strokeLinecap="round"/>
    <path d="M14.5 24 Q12 25, 11 24" stroke={color} strokeWidth="1" strokeLinecap="round" opacity="0.5"/>
    <path d="M17.5 22 Q19 23, 20 22" stroke={color} strokeWidth="1" strokeLinecap="round" opacity="0.5"/>
    {/* Canopy — multiple organic blobs */}
    <path d="M16 4 C10 4, 5 9, 6 14 C4 15, 4 19, 7 20 C6 22, 9 25, 13 24 C14 26, 18 26, 19 24 C23 25, 26 22, 25 20 C28 19, 28 15, 26 14 C27 9, 22 4, 16 4Z" fill={color} opacity="0.15"/>
    <path d="M16 4 C10 4, 5 9, 6 14 C4 15, 4 19, 7 20 C6 22, 9 25, 13 24 C14 26, 18 26, 19 24 C23 25, 26 22, 25 20 C28 19, 28 15, 26 14 C27 9, 22 4, 16 4Z" stroke={color} strokeWidth="1.2" strokeLinecap="round" fill="none"/>
    {/* Inner texture */}
    <path d="M10 14 Q13 11, 16 12 Q19 11, 22 14" stroke={color} strokeWidth="0.6" opacity="0.2" fill="none"/>
    <path d="M8 19 Q12 17, 16 18 Q20 17, 24 19" stroke={color} strokeWidth="0.6" opacity="0.2" fill="none"/>
  </svg>
);

const MapIconForest = ({ size=32, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 48 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Cluster of 3 trees with varying sizes */}
    {/* Back tree (left) */}
    <path d="M14 28 L14 21" stroke={color} strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M14 8 C9 8, 5 12, 6 16 C4 17, 5 21, 8 21 C8 23, 12 24, 14 22 C16 24, 20 23, 20 21 C23 21, 24 17, 22 16 C23 12, 19 8, 14 8Z" fill={color} opacity="0.12"/>
    <path d="M14 8 C9 8, 5 12, 6 16 C4 17, 5 21, 8 21 C8 23, 12 24, 14 22 C16 24, 20 23, 20 21 C23 21, 24 17, 22 16 C23 12, 19 8, 14 8Z" stroke={color} strokeWidth="1.1" strokeLinecap="round" fill="none"/>
    {/* Front tree (right, slightly larger) */}
    <path d="M32 30 L32 22" stroke={color} strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M32 7 C26 7, 22 12, 23 16 C21 17, 21 21, 24 22 C23 24, 27 26, 30 24 C31 26, 35 26, 36 24 C39 25, 42 22, 41 20 C44 19, 44 15, 41 14 C43 10, 38 7, 32 7Z" fill={color} opacity="0.12"/>
    <path d="M32 7 C26 7, 22 12, 23 16 C21 17, 21 21, 24 22 C23 24, 27 26, 30 24 C31 26, 35 26, 36 24 C39 25, 42 22, 41 20 C44 19, 44 15, 41 14 C43 10, 38 7, 32 7Z" stroke={color} strokeWidth="1.1" strokeLinecap="round" fill="none"/>
    {/* Middle small tree */}
    <path d="M22 29 L22 24" stroke={color} strokeWidth="1.2" strokeLinecap="round"/>
    <path d="M22 14 C19 14, 16 17, 17 19 C16 20, 17 22, 19 22 C19 24, 22 25, 24 23 C26 24, 28 22, 27 20 C29 19, 28 16, 26 16 C27 14, 25 12, 22 14Z" fill={color} opacity="0.1"/>
    <path d="M22 14 C19 14, 16 17, 17 19 C16 20, 17 22, 19 22 C19 24, 22 25, 24 23 C26 24, 28 22, 27 20 C29 19, 28 16, 26 16 C27 14, 25 12, 22 14Z" stroke={color} strokeWidth="0.9" strokeLinecap="round" fill="none" opacity="0.7"/>
    {/* Ground line */}
    <path d="M2 30 Q16 29, 30 30 Q40 31, 46 30" stroke={color} strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.3"/>
  </svg>
);

const MapIconCity = ({ size=32, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Walled city with towers and central keep */}
    {/* Wall base */}
    <rect x="6" y="22" width="28" height="12" rx="1" fill={color} opacity="0.08"/>
    <path d="M6 22 L6 34 L34 34 L34 22" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    {/* Wall battlements */}
    <path d="M6 22 L6 20 L9 20 L9 22 L11 22 L11 20 L14 20 L14 22 L16 22 L16 20 L19 20 L19 22 L21 22 L21 20 L24 20 L24 22 L26 22 L26 20 L29 20 L29 22 L31 22 L31 20 L34 20 L34 22" stroke={color} strokeWidth="1.1" fill="none"/>
    {/* Gate */}
    <path d="M17 34 L17 27 Q20 24, 23 27 L23 34" stroke={color} strokeWidth="1.2" fill="none"/>
    <line x1="20" y1="27" x2="20" y2="34" stroke={color} strokeWidth="0.6" opacity="0.4"/>
    {/* Central keep tower */}
    <rect x="17" y="10" width="6" height="12" fill={color} opacity="0.1"/>
    <path d="M17 22 L17 10 L23 10 L23 22" stroke={color} strokeWidth="1.2" fill="none"/>
    <path d="M16 10 L20 5 L24 10" stroke={color} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Flag on keep */}
    <line x1="20" y1="5" x2="20" y2="2" stroke={color} strokeWidth="0.8"/>
    <path d="M20 2 L24 3.5 L20 5" fill={color} opacity="0.3"/>
    <path d="M20 2 L24 3.5 L20 5" stroke={color} strokeWidth="0.7" fill="none"/>
    {/* Left tower */}
    <rect x="4" y="15" width="5" height="7" fill={color} opacity="0.08"/>
    <path d="M4 22 L4 15 L9 15 L9 22" stroke={color} strokeWidth="1.1" fill="none"/>
    <path d="M3 15 L6.5 11 L10 15" stroke={color} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Right tower */}
    <rect x="31" y="15" width="5" height="7" fill={color} opacity="0.08"/>
    <path d="M31 22 L31 15 L36 15 L36 22" stroke={color} strokeWidth="1.1" fill="none"/>
    <path d="M30 15 L33.5 11 L37 15" stroke={color} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Windows */}
    <circle cx="6.5" cy="18" r="0.8" fill={color} opacity="0.4"/>
    <circle cx="33.5" cy="18" r="0.8" fill={color} opacity="0.4"/>
    <circle cx="20" cy="14" r="1" fill={color} opacity="0.4"/>
  </svg>
);

const MapIconTown = ({ size=28, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Small town — cluster of buildings with a church spire */}
    {/* Main building left */}
    <rect x="6" y="20" width="8" height="10" fill={color} opacity="0.08"/>
    <path d="M6 30 L6 20 L14 20 L14 30" stroke={color} strokeWidth="1.2" fill="none"/>
    <path d="M5 20 L10 15 L15 20" stroke={color} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Church/tall building center */}
    <rect x="14" y="16" width="7" height="14" fill={color} opacity="0.08"/>
    <path d="M14 30 L14 16 L21 16 L21 30" stroke={color} strokeWidth="1.2" fill="none"/>
    <path d="M13 16 L17.5 9 L22 16" stroke={color} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    <line x1="17.5" y1="9" x2="17.5" y2="6" stroke={color} strokeWidth="0.8"/>
    <circle cx="17.5" cy="5.5" r="1" stroke={color} strokeWidth="0.7" fill="none"/>
    {/* Small building right */}
    <rect x="21" y="22" width="7" height="8" fill={color} opacity="0.08"/>
    <path d="M21 30 L21 22 L28 22 L28 30" stroke={color} strokeWidth="1.2" fill="none"/>
    <path d="M20 22 L24.5 18 L29 22" stroke={color} strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Windows */}
    <rect x="8" y="23" width="2" height="2.5" rx="0.3" stroke={color} strokeWidth="0.6" fill="none" opacity="0.5"/>
    <rect x="16" y="20" width="2" height="2.5" rx="0.3" stroke={color} strokeWidth="0.6" fill="none" opacity="0.5"/>
    <rect x="23" y="25" width="2" height="2" rx="0.3" stroke={color} strokeWidth="0.6" fill="none" opacity="0.5"/>
    {/* Ground */}
    <path d="M2 30 Q18 29, 34 30" stroke={color} strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.35"/>
  </svg>
);

const MapIconHamlet = ({ size=24, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Tiny village — 2 small houses */}
    <rect x="4" y="16" width="7" height="7" fill={color} opacity="0.08"/>
    <path d="M4 23 L4 16 L11 16 L11 23" stroke={color} strokeWidth="1.1" fill="none"/>
    <path d="M3 16 L7.5 12 L12 16" stroke={color} strokeWidth="1.1" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    <rect x="14" y="18" width="6" height="5" fill={color} opacity="0.06"/>
    <path d="M14 23 L14 18 L20 18 L20 23" stroke={color} strokeWidth="1" fill="none"/>
    <path d="M13 18 L17 15 L21 18" stroke={color} strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    {/* Smoke wisps */}
    <path d="M7.5 12 Q7 10, 8 8 Q7.5 6, 8.5 5" stroke={color} strokeWidth="0.6" strokeLinecap="round" fill="none" opacity="0.3"/>
    {/* Ground */}
    <path d="M1 23 Q14 22, 27 23" stroke={color} strokeWidth="0.8" strokeLinecap="round" fill="none" opacity="0.3"/>
  </svg>
);

const MapIconKingdom = ({ size=36, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Grand capital — large castle with crown motif */}
    {/* Base wall */}
    <rect x="5" y="25" width="34" height="12" rx="1" fill={color} opacity="0.08"/>
    <path d="M5 25 L5 37 L39 37 L39 25" stroke={color} strokeWidth="1.3" fill="none"/>
    {/* Battlements */}
    <path d="M5 25 L5 23 L8 23 L8 25 L10 25 L10 23 L13 23 L13 25 L15 25 L15 23 L18 23 L18 25 L20 25 L20 23 L24 23 L24 25 L26 25 L26 23 L29 23 L29 25 L31 25 L31 23 L34 23 L34 25 L36 25 L36 23 L39 23 L39 25" stroke={color} strokeWidth="1" fill="none"/>
    {/* Grand gate with arch */}
    <path d="M18 37 L18 29 Q22 24, 26 29 L26 37" stroke={color} strokeWidth="1.3" fill="none"/>
    {/* Central grand tower */}
    <rect x="18" y="12" width="8" height="13" fill={color} opacity="0.1"/>
    <path d="M18 25 L18 12 L26 12 L26 25" stroke={color} strokeWidth="1.2" fill="none"/>
    {/* Crown-shaped top on central tower */}
    <path d="M17 12 L18 8 L20 11 L22 6 L24 11 L26 8 L27 12" stroke={color} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
    <circle cx="22" cy="5" r="1.2" fill={color} opacity="0.3"/>
    <circle cx="22" cy="5" r="1.2" stroke={color} strokeWidth="0.7" fill="none"/>
    {/* Left tower */}
    <rect x="3" y="17" width="6" height="8" fill={color} opacity="0.08"/>
    <path d="M3 25 L3 17 L9 17 L9 25" stroke={color} strokeWidth="1.1" fill="none"/>
    <path d="M2 17 L6 12 L10 17" stroke={color} strokeWidth="1.1" strokeLinecap="round" fill="none"/>
    <line x1="6" y1="12" x2="6" y2="9" stroke={color} strokeWidth="0.8"/>
    <path d="M6 9 L9 10.5 L6 12" fill={color} opacity="0.25"/>
    {/* Right tower */}
    <rect x="35" y="17" width="6" height="8" fill={color} opacity="0.08"/>
    <path d="M35 25 L35 17 L41 17 L41 25" stroke={color} strokeWidth="1.1" fill="none"/>
    <path d="M34 17 L38 12 L42 17" stroke={color} strokeWidth="1.1" strokeLinecap="round" fill="none"/>
    <line x1="38" y1="12" x2="38" y2="9" stroke={color} strokeWidth="0.8"/>
    <path d="M38 9 L41 10.5 L38 12" fill={color} opacity="0.25"/>
    {/* Windows */}
    <circle cx="6" cy="20" r="0.8" fill={color} opacity="0.4"/>
    <circle cx="38" cy="20" r="0.8" fill={color} opacity="0.4"/>
    <circle cx="22" cy="16" r="1.2" fill={color} opacity="0.35"/>
    <rect x="20" y="19" width="4" height="3" rx="0.3" stroke={color} strokeWidth="0.5" fill="none" opacity="0.3"/>
  </svg>
);

const MapIconRuins = ({ size=28, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Crumbling ruins — broken walls and pillars */}
    {/* Left broken pillar */}
    <path d="M8 30 L8 14 Q8 12, 9 13 L10 16 L10 30" stroke={color} strokeWidth="1.2" fill="none"/>
    <path d="M7 14 L11 12 L11 14" stroke={color} strokeWidth="0.8" fill="none" opacity="0.6"/>
    {/* Center broken wall */}
    <path d="M14 30 L14 18 L16 16 L18 19 L19 17 L21 20 L22 18 L23 30" stroke={color} strokeWidth="1.2" fill="none"/>
    <path d="M14 18 L14 30 L23 30 L23 18" fill={color} opacity="0.06"/>
    {/* Right tall broken pillar */}
    <path d="M27 30 L27 10 L29 10 L29 30" stroke={color} strokeWidth="1.1" fill="none"/>
    <path d="M26 10 L28 7 L30 10" stroke={color} strokeWidth="0.9" strokeLinecap="round" fill="none"/>
    {/* Scattered rubble */}
    <circle cx="12" cy="29" r="1.2" stroke={color} strokeWidth="0.7" fill={color} opacity="0.15"/>
    <circle cx="25" cy="29.5" r="0.8" stroke={color} strokeWidth="0.6" fill={color} opacity="0.12"/>
    <rect x="16" y="28" width="2" height="1.5" rx="0.3" stroke={color} strokeWidth="0.5" fill="none" opacity="0.4" transform="rotate(-12 17 28.5)"/>
    {/* Cracks in wall */}
    <path d="M17 22 L18 25 L16 27" stroke={color} strokeWidth="0.5" opacity="0.3" fill="none"/>
    <path d="M20 21 L19 24" stroke={color} strokeWidth="0.5" opacity="0.3" fill="none"/>
    {/* Ground */}
    <path d="M3 30 Q18 29, 33 30" stroke={color} strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.35"/>
    {/* Overgrown vine */}
    <path d="M27 20 Q30 18, 31 20 Q32 22, 30 23" stroke={color} strokeWidth="0.6" opacity="0.3" fill="none"/>
  </svg>
);

const MapIconDungeon = ({ size=28, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Cave/dungeon entrance in hillside */}
    {/* Hill mound */}
    <path d="M2 30 Q6 18, 18 14 Q30 18, 34 30" fill={color} opacity="0.08"/>
    <path d="M2 30 Q6 18, 18 14 Q30 18, 34 30" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    {/* Dark cave opening */}
    <path d="M12 30 Q12 22, 18 20 Q24 22, 24 30" fill={color} opacity="0.25"/>
    <path d="M12 30 Q12 22, 18 20 Q24 22, 24 30" stroke={color} strokeWidth="1.3" strokeLinecap="round" fill="none"/>
    {/* Stalactites */}
    <path d="M14 22 L14.5 25" stroke={color} strokeWidth="0.7" strokeLinecap="round" opacity="0.5"/>
    <path d="M17 20.5 L17 24" stroke={color} strokeWidth="0.7" strokeLinecap="round" opacity="0.5"/>
    <path d="M21 21 L20.5 24" stroke={color} strokeWidth="0.7" strokeLinecap="round" opacity="0.5"/>
    {/* Skull warning */}
    <circle cx="18" cy="27" r="2" stroke={color} strokeWidth="0.8" fill="none" opacity="0.4"/>
    <circle cx="17" cy="26.5" r="0.5" fill={color} opacity="0.4"/>
    <circle cx="19" cy="26.5" r="0.5" fill={color} opacity="0.4"/>
    {/* Rocks */}
    <circle cx="10" cy="28" r="1.5" stroke={color} strokeWidth="0.7" fill="none" opacity="0.3"/>
    <circle cx="26" cy="28" r="1" stroke={color} strokeWidth="0.6" fill="none" opacity="0.3"/>
    {/* Ground */}
    <path d="M1 30 Q18 29, 35 30" stroke={color} strokeWidth="1" strokeLinecap="round" fill="none" opacity="0.35"/>
  </svg>
);

const MapIconRoute = ({ size=24, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Winding road with signpost */}
    <path d="M6 28 Q10 22, 16 20 Q22 18, 20 12 Q18 8, 22 4" stroke={color} strokeWidth="1.8" strokeLinecap="round" strokeDasharray="4 3" fill="none" opacity="0.5"/>
    {/* Signpost */}
    <line x1="16" y1="14" x2="16" y2="22" stroke={color} strokeWidth="1.3" strokeLinecap="round"/>
    <path d="M16 14 L22 13 L22 16 L16 17" stroke={color} strokeWidth="1" fill={color} opacity="0.12"/>
    <path d="M16 14 L22 13 L22 16 L16 17" stroke={color} strokeWidth="1" fill="none"/>
    <path d="M16 16 L11 15.5 L11 18 L16 18.5" stroke={color} strokeWidth="0.9" fill={color} opacity="0.08"/>
    <path d="M16 16 L11 15.5 L11 18 L16 18.5" stroke={color} strokeWidth="0.9" fill="none" opacity="0.7"/>
  </svg>
);

const MapIconCastle = ({ size=28, color="currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 36 36" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Fortified castle on a hill */}
    {/* Hill */}
    <path d="M3 32 Q10 26, 18 25 Q26 26, 33 32" fill={color} opacity="0.06"/>
    <path d="M3 32 Q10 26, 18 25 Q26 26, 33 32" stroke={color} strokeWidth="1" fill="none" opacity="0.4"/>
    {/* Main wall */}
    <path d="M8 25 L8 17 L28 17 L28 25" stroke={color} strokeWidth="1.2" fill="none"/>
    <rect x="8" y="17" width="20" height="8" fill={color} opacity="0.08"/>
    {/* Battlements */}
    <path d="M8 17 L8 15.5 L10 15.5 L10 17 L12 17 L12 15.5 L14 15.5 L14 17 L16 17 L16 15.5 L20 15.5 L20 17 L22 17 L22 15.5 L24 15.5 L24 17 L26 17 L26 15.5 L28 15.5 L28 17" stroke={color} strokeWidth="0.9" fill="none"/>
    {/* Central tower */}
    <path d="M15 17 L15 9 L21 9 L21 17" stroke={color} strokeWidth="1.1" fill="none"/>
    <rect x="15" y="9" width="6" height="8" fill={color} opacity="0.08"/>
    <path d="M14 9 L18 5 L22 9" stroke={color} strokeWidth="1.1" strokeLinecap="round" fill="none"/>
    {/* Flag */}
    <line x1="18" y1="5" x2="18" y2="2" stroke={color} strokeWidth="0.7"/>
    <path d="M18 2 L21 3 L18 4" fill={color} opacity="0.3"/>
    {/* Gate */}
    <path d="M16 25 L16 21 Q18 19, 20 21 L20 25" stroke={color} strokeWidth="1" fill="none"/>
  </svg>
);

/* Map of region type → fantasy icon component */
const FANTASY_ICONS = {
  city: MapIconCity,
  town: MapIconTown,
  hamlet: MapIconHamlet,
  kingdom: MapIconKingdom,
  capital: MapIconKingdom,
  wilderness: MapIconMountain,
  mountain: MapIconMountain,
  forest: MapIconForest,
  dungeon: MapIconDungeon,
  ruins: MapIconRuins,
  castle: MapIconCastle,
  route: MapIconRoute,
  cave: MapIconDungeon,
  shrine: MapIconRuins,
  tower: MapIconCastle,
  grove: MapIconForest,
  monolith: MapIconRuins,
};

const getFantasyIcon = (type) => FANTASY_ICONS[type] || MapIconRoute;

// ─── DICE ROLLER ────────────────────────────────────────────────────────────

function DiceRoller() {
  const [results,setResults] = useState([]);
  const [die,setDie] = useState(20);
  const [mod,setMod] = useState(0);
  const [count,setCount] = useState(1);
  const [rolling,setRolling] = useState(false);
  const dice = [4,6,8,10,12,20,100];

  const roll = useCallback(() => {
    setRolling(true);
    setTimeout(() => {
      const rolls = Array.from({length:count}, ()=> Math.floor(Math.random()*die)+1);
      const total = rolls.reduce((a,b)=>a+b,0) + mod;
      const hasCrit = die===20 && rolls.some(r=>r===20);
      const hasFumble = die===20 && rolls.some(r=>r===1);
      setResults(p => [{ die, rolls, count, mod, total, crit:hasCrit, fumble:hasFumble, t:Date.now() }, ...p].slice(0,20));
      setRolling(false);
    }, 250);
  }, [die,mod,count]);

  return (
    <div>
      <div style={{ display:"flex", gap:4, marginBottom:12, flexWrap:"wrap" }}>
        {dice.map(d => (
          <button key={d} onClick={()=>setDie(d)} style={{
            padding:"5px 8px", background: d===die ? T.crimson : "transparent",
            border:`1px solid ${d===die ? T.crimson : T.border}`,
            color: d===die ? T.text : T.textMuted,
            fontFamily:T.ui, fontSize:"10px", cursor:"pointer", borderRadius:"2px",
            fontWeight:500, transition:"all 0.15s",
          }}>d{d}</button>
        ))}
      </div>
      <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:16, marginBottom:12 }}>
        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
          <span style={{ fontFamily:T.ui, fontSize:8, color:T.textMuted, letterSpacing:"1px" }}>COUNT</span>
          <button onClick={()=>setCount(c=>Math.max(1,c-1))} style={{ width:24, height:24, background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontSize:14, cursor:"pointer", borderRadius:"2px", display:"flex", alignItems:"center", justifyContent:"center" }}>−</button>
          <span style={{ fontFamily:T.ui, fontSize:14, color:T.text, fontWeight:500, minWidth:20, textAlign:"center" }}>{count}</span>
          <button onClick={()=>setCount(c=>Math.min(10,c+1))} style={{ width:24, height:24, background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontSize:14, cursor:"pointer", borderRadius:"2px", display:"flex", alignItems:"center", justifyContent:"center" }}>+</button>
        </div>
        <div style={{ width:1, height:20, background:T.border }}/>
        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
          <span style={{ fontFamily:T.ui, fontSize:8, color:T.textMuted, letterSpacing:"1px" }}>MOD</span>
          <button onClick={()=>setMod(m=>m-1)} style={{ width:24, height:24, background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontSize:14, cursor:"pointer", borderRadius:"2px", display:"flex", alignItems:"center", justifyContent:"center" }}>−</button>
          <span style={{ fontFamily:T.ui, fontSize:14, color:T.text, fontWeight:500, minWidth:30, textAlign:"center" }}>{mod>=0?`+${mod}`:mod}</span>
          <button onClick={()=>setMod(m=>m+1)} style={{ width:24, height:24, background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontSize:14, cursor:"pointer", borderRadius:"2px", display:"flex", alignItems:"center", justifyContent:"center" }}>+</button>
        </div>
      </div>
      <button onClick={roll} disabled={rolling} style={{
        width:"100%", padding:10, background:rolling?T.crimsonDim:T.crimson, border:"none",
        color:T.text, fontFamily:T.ui, fontSize:"10px", letterSpacing:"2px", textTransform:"uppercase",
        cursor:rolling?"default":"pointer", borderRadius:"2px", fontWeight:500, marginBottom:8, transition:"all 0.2s",
      }}>{rolling ? "Rolling..." : `Roll ${count}d${die}${mod?mod>0?`+${mod}`:mod:""}`}</button>
      {results.length > 0 && (
        <div style={{ borderTop:`1px solid ${T.border}`, marginTop:8, paddingTop:8 }}>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:6 }}>
            <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1px" }}>HISTORY</span>
            <button onClick={()=>setResults([])} style={{ background:"none", border:"none", cursor:"pointer", fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1px" }}>CLEAR</button>
          </div>
          {results.map((r,i) => (
            <div key={r.t} style={{ display:"flex", justifyContent:"space-between", padding:"4px 0", fontSize:12, color:T.textDim, opacity:i===0?1:Math.max(0.35,1-i*0.08) }}>
              <span style={{ fontFamily:T.ui, fontSize:10, color:T.textMuted }}>
                {r.count>1?`${r.count}`:""}{r.die===100?"d%":`d${r.die}`}{r.mod!==0?(r.mod>0?`+${r.mod}`:r.mod):""}
                {r.count>1 && <span style={{ color:T.textFaint, marginLeft:4 }}>[{r.rolls.join(", ")}]</span>}
              </span>
              <span style={{ fontWeight:500, color: r.crit?"#f5d020":r.fumble?"#ef5350":T.text, textShadow: r.crit?"0 0 12px rgba(245,208,32,0.6)":r.fumble?"0 0 12px rgba(239,83,80,0.6)":"none" }}>
                {r.total} {r.crit?"NAT 20!":r.fumble?"NAT 1":""}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ─── INITIATIVE TRACKER ─────────────────────────────────────────────────────

function InitiativeTracker({ party }) {
  const [combatants,setCombatants] = useState([]);
  const [turn,setTurn] = useState(0);
  const [round,setRound] = useState(1);
  const [live,setLive] = useState(false);
  const [name,setName] = useState("");
  const [init,setInit] = useState("");
  const [hpVal,setHpVal] = useState("");
  const [acVal,setAcVal] = useState("");
  const [conditions,setConditions] = useState({});

  const start = () => {
    const pcs = party.map(p => ({ id:`pc-${p.id}`, name:p.name, init:Math.floor(Math.random()*20)+1, hp:p.hp, maxHp:p.maxHp, ac:p.ac, type:"pc" }));
    setCombatants(pcs.sort((a,b)=>b.init-a.init));
    setTurn(0); setRound(1); setLive(true); setConditions({});
  };
  const next = () => {
    let nextIdx = turn + 1;
    while (nextIdx < combatants.length && combatants[nextIdx].hp <= 0) nextIdx++;
    if (nextIdx >= combatants.length) {
      setRound(r=>r+1);
      let first = 0;
      while (first < combatants.length && combatants[first].hp <= 0) first++;
      setTurn(first);
    } else setTurn(nextIdx);
  };
  const prev = () => {
    if (turn === 0 && round === 1) return;
    let prevIdx = turn - 1;
    if (prevIdx < 0) { setRound(r=>Math.max(1,r-1)); prevIdx = combatants.length - 1; }
    while (prevIdx >= 0 && combatants[prevIdx].hp <= 0) prevIdx--;
    if (prevIdx >= 0) setTurn(prevIdx);
  };
  const adjHp = (id,d) => setCombatants(p=>p.map(c=>c.id===id?{...c,hp:Math.max(0,Math.min(c.maxHp,c.hp+d))}:c));
  const remove = (id) => { setCombatants(p=>p.filter(c=>c.id!==id)); if(turn >= combatants.length-1) setTurn(t=>Math.max(0,t-1)); };
  const addCondition = (id, cond) => { if(!cond) return; setConditions(p=>({...p, [id]: [...(p[id]||[]), cond]})); };
  const removeCondition = (id, idx) => { setConditions(p=>({...p, [id]: (p[id]||[]).filter((_,i)=>i!==idx)})); };
  const add = () => {
    if(!name.trim()||!init) return;
    const newC = {id:`c-${Date.now()}`,name,init:parseInt(init),hp:parseInt(hpVal)||30,maxHp:parseInt(hpVal)||30,ac:parseInt(acVal)||12,type:"enemy"};
    setCombatants(p=>[...p,newC].sort((a,b)=>b.init-a.init));
    setName(""); setInit(""); setHpVal(""); setAcVal("");
  };

  const conditionsList = ["Blinded","Charmed","Deafened","Frightened","Grappled","Incapacitated","Invisible","Paralyzed","Petrified","Poisoned","Prone","Restrained","Stunned","Unconscious","Concentrating"];

  if(!live) return (
    <div style={{ textAlign:"center", padding:"28px 0" }}>
      <Swords size={28} color={T.textFaint} style={{ marginBottom:10 }} />
      <p style={{ fontFamily:T.body, fontSize:14, color:T.textMuted, fontStyle:"italic", fontWeight:300, marginBottom:18 }}>No active encounter</p>
      <CrimsonBtn onClick={start}><Swords size={13}/> Start Encounter</CrimsonBtn>
    </div>
  );

  return (
    <div>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:14 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <Tag variant="danger">Round {round}</Tag>
          <span style={{ fontFamily:T.ui, fontSize:9, color:T.textFaint, letterSpacing:"1px" }}>{turn+1}/{combatants.length}</span>
        </div>
        <div style={{ display:"flex", gap:6 }}>
          <CrimsonBtn onClick={prev} secondary small><ChevronUp size={11}/></CrimsonBtn>
          <CrimsonBtn onClick={next} secondary small><SkipForward size={11}/> Next</CrimsonBtn>
          <CrimsonBtn onClick={()=>{setLive(false);setCombatants([]);}} secondary small>End</CrimsonBtn>
        </div>
      </div>
      <div style={{ display:"flex", flexDirection:"column", gap:2, maxHeight:320, overflowY:"auto" }}>
        {combatants.map((c,i) => (
          <div key={c.id} style={{
            padding:"8px 10px", background: i===turn ? T.crimsonSoft : "transparent",
            borderRadius:"2px", borderLeft: i===turn ? `3px solid ${T.crimson}` : "3px solid transparent",
            opacity: c.hp<=0 ? 0.3 : 1, transition:"all 0.15s",
          }}>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <span style={{ fontSize:12, fontFamily:T.body, fontWeight:500, color:T.textFaint, minWidth:20 }}>{c.init}</span>
              <span style={{ width:5, height:5, borderRadius:"50%", flexShrink:0, background:c.type==="pc"?"#5ee09a":T.crimson }} />
              <span style={{ flex:1, fontSize:13, fontFamily:T.body, fontWeight:400, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{c.name}</span>
              <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1px" }}>AC {c.ac}</span>
              <div style={{ display:"flex", alignItems:"center", gap:2 }}>
                <button onClick={()=>adjHp(c.id,-5)} style={{ background:"none", border:"none", cursor:"pointer", color:T.crimson, fontSize:14, padding:"2px 4px" }}>−</button>
                <span style={{ fontSize:11, fontFamily:T.body, fontWeight:500, minWidth:42, textAlign:"center", color:c.hp<=c.maxHp*0.25?T.crimson:c.hp<=c.maxHp*0.5?"#e8940a":T.textDim }}>{c.hp}/{c.maxHp}</span>
                <button onClick={()=>adjHp(c.id,5)} style={{ background:"none", border:"none", cursor:"pointer", color:"#5ee09a", fontSize:14, padding:"2px 4px" }}>+</button>
              </div>
              {c.type==="enemy" && <button onClick={()=>remove(c.id)} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:"2px" }}><X size={10}/></button>}
            </div>
            {(conditions[c.id]||[]).length > 0 && (
              <div style={{ display:"flex", gap:4, flexWrap:"wrap", marginTop:4, paddingLeft:28 }}>
                {(conditions[c.id]||[]).map((cond,ci) => (
                  <span key={ci} onClick={()=>removeCondition(c.id,ci)} style={{
                    display:"inline-flex", alignItems:"center", gap:3, background:T.crimsonSoft, border:`1px solid ${T.crimsonBorder}`,
                    padding:"1px 6px", borderRadius:"2px", fontSize:8, fontFamily:T.ui, letterSpacing:"0.5px", color:T.crimson, cursor:"pointer", textTransform:"uppercase",
                  }}>{cond} <X size={7}/></span>
                ))}
              </div>
            )}
            {i === turn && c.hp > 0 && (
              <div style={{ paddingLeft:28, marginTop:4 }}>
                <select onChange={e=>{addCondition(c.id,e.target.value);e.target.value="";}} value=""
                  style={{ padding:"3px 6px", fontSize:10, fontFamily:T.ui, background:T.bgInput, border:`1px solid ${T.border}`, color:T.textMuted, borderRadius:"2px", cursor:"pointer" }}>
                  <option value="">+ Condition</option>
                  {conditionsList.map(co=><option key={co} value={co}>{co}</option>)}
                </select>
              </div>
            )}
          </div>
        ))}
      </div>
      <div style={{ display:"flex", gap:6, marginTop:12, paddingTop:12, borderTop:`1px solid ${T.borderMid}` }}>
        <Input value={name} onChange={setName} placeholder="Name" style={{ flex:1 }} />
        <Input value={init} onChange={setInit} placeholder="Init" type="number" style={{ width:48, textAlign:"center" }} />
        <Input value={hpVal} onChange={setHpVal} placeholder="HP" type="number" style={{ width:48, textAlign:"center" }} />
        <Input value={acVal} onChange={setAcVal} placeholder="AC" type="number" style={{ width:48, textAlign:"center" }} />
        <CrimsonBtn onClick={add} secondary small><Plus size={12}/></CrimsonBtn>
      </div>
    </div>
  );
}

// ─── SESSION SCHEDULER (inline, no wrapper) ────────────────────────────────

function SessionSchedulerInline({ data, setData }) {
  const sched = data.sessionSchedule;
  const dayNames = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  const [customDate, setCustomDate] = useState("");
  const [customTime, setCustomTime] = useState("19:00");

  const updateSchedule = (key, val) => {
    setData(d => ({ ...d, sessionSchedule: { ...d.sessionSchedule, [key]: val } }));
  };

  const calculateNextSession = () => {
    const now = new Date();
    let next = new Date(now);
    const targetDay = sched.dayOfWeek;
    const diff = (targetDay - now.getDay() + 7) % 7;
    next.setDate(now.getDate() + (diff === 0 && now.getHours() >= sched.hour ? 7 : diff));
    next.setHours(sched.hour, sched.minute, 0, 0);
    if (sched.frequency === "biweekly") next.setDate(next.getDate() + 7);
    return next.toISOString();
  };

  const applySchedule = () => {
    const nextISO = calculateNextSession();
    setData(d => ({ ...d, nextSession: nextISO,
      activity: [{ time: "Just now", text: `Updated session schedule: ${dayNames[sched.dayOfWeek]}s at ${sched.hour}:${String(sched.minute).padStart(2,"0")}` }, ...d.activity].slice(0,20)
    }));
  };

  const scheduleCustom = () => {
    if (!customDate) return;
    const dt = new Date(`${customDate}T${customTime}:00`);
    setData(d => ({ ...d, nextSession: dt.toISOString(),
      activity: [{ time: "Just now", text: `Scheduled session for ${dt.toLocaleDateString("en-US",{weekday:"long",month:"long",day:"numeric"})} at ${customTime}` }, ...d.activity].slice(0,20)
    }));
    setCustomDate(""); setCustomTime("19:00");
  };

  const cancelNext = () => {
    const after = calculateNextSession();
    const skip = new Date(new Date(after).getTime() + 7*864e5);
    setData(d => ({ ...d, nextSession: skip.toISOString(),
      activity: [{ time: "Just now", text: "Cancelled next session, pushed to following week" }, ...d.activity].slice(0,20)
    }));
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Day</span>
          <Select value={sched.dayOfWeek} onChange={v=>updateSchedule("dayOfWeek",parseInt(v))} style={{ width:"100%" }}>
            {dayNames.map((d,i) => <option key={i} value={i}>{d}</option>)}
          </Select>
        </div>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Frequency</span>
          <Select value={sched.frequency} onChange={v=>updateSchedule("frequency",v)} style={{ width:"100%" }}>
            <option value="weekly">Weekly</option>
            <option value="biweekly">Biweekly</option>
            <option value="monthly">Monthly</option>
          </Select>
        </div>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Hour</span>
          <Input type="number" value={sched.hour} onChange={v=>updateSchedule("hour",Math.max(0,Math.min(23,parseInt(v)||0)))} />
        </div>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Minute</span>
          <Input type="number" value={sched.minute} onChange={v=>updateSchedule("minute",Math.max(0,Math.min(59,parseInt(v)||0)))} />
        </div>
      </div>
      <div style={{ display:"flex", gap:8 }}>
        <CrimsonBtn onClick={applySchedule} small><Check size={12}/> Apply Schedule</CrimsonBtn>
        <CrimsonBtn onClick={cancelNext} secondary small><X size={12}/> Skip Next</CrimsonBtn>
      </div>
      <div style={{ borderTop:`1px solid ${T.border}`, paddingTop:16 }}>
        <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:10 }}>One-Off Session</span>
        <div style={{ display:"flex", gap:8 }}>
          <Input type="date" value={customDate} onChange={setCustomDate} style={{ flex:1 }} />
          <Input type="time" value={customTime} onChange={setCustomTime} style={{ width:100 }} />
          <CrimsonBtn onClick={scheduleCustom} secondary small><Calendar size={12}/> Set</CrimsonBtn>
        </div>
      </div>
    </div>
  );
}

// ─── PLAYER CHARACTER FORM (self-service for players) ───────────────────────

function PlayerCharacterForm({ onSubmit, existing, onCancel }) {
  const [form, setForm] = useState(existing || {
    name:"", cls:"", lv:1, hp:10, maxHp:10, ac:10, player:"", status:"healthy",
    race:"", bio:"", sheetUrl:null, sheetName:null,
  });
  const fileRef = useRef(null);

  const handleSheet = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    setForm(p => ({...p, sheetUrl: url, sheetName: file.name}));
  };

  const submit = () => {
    if (!form.name.trim() || !form.player.trim()) return;
    onSubmit(form);
  };

  const classes = ["Barbarian","Bard","Cleric","Druid","Fighter","Monk","Paladin","Ranger","Rogue","Sorcerer","Warlock","Wizard","Artificer","Blood Hunter"];
  const races = ["Human","Elf","Half-Elf","Dwarf","Halfling","Gnome","Half-Orc","Tiefling","Dragonborn","Aasimar","Goliath","Tabaxi","Kenku","Firbolg","Genasi","Changeling","Warforged"];

  return (
    <div style={{ display:"flex", flexDirection:"column", gap:14 }}>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Player Name</span>
          <Input value={form.player} onChange={v=>setForm(p=>({...p,player:v}))} placeholder="Your name" />
        </div>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Character Name</span>
          <Input value={form.name} onChange={v=>setForm(p=>({...p,name:v}))} placeholder="Character name" />
        </div>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Race</span>
          <Select value={form.race} onChange={v=>setForm(p=>({...p,race:v}))} style={{ width:"100%" }}>
            <option value="">Select...</option>
            {races.map(r=><option key={r} value={r}>{r}</option>)}
          </Select>
        </div>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Class</span>
          <Select value={form.cls} onChange={v=>setForm(p=>({...p,cls:v}))} style={{ width:"100%" }}>
            <option value="">Select...</option>
            {classes.map(c=><option key={c} value={c}>{c}</option>)}
          </Select>
        </div>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Level</span>
          <Input type="number" value={form.lv} onChange={v=>setForm(p=>({...p,lv:Math.max(1,Math.min(20,parseInt(v)||1))}))} />
        </div>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:12 }}>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>HP</span>
          <Input type="number" value={form.hp} onChange={v=>setForm(p=>({...p,hp:parseInt(v)||1,maxHp:Math.max(p.maxHp,parseInt(v)||1)}))} />
        </div>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Max HP</span>
          <Input type="number" value={form.maxHp} onChange={v=>setForm(p=>({...p,maxHp:parseInt(v)||1}))} />
        </div>
        <div>
          <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>AC</span>
          <Input type="number" value={form.ac} onChange={v=>setForm(p=>({...p,ac:parseInt(v)||10}))} />
        </div>
      </div>
      <div>
        <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Backstory / Notes</span>
        <Textarea value={form.bio||""} onChange={v=>setForm(p=>({...p,bio:v}))} placeholder="A brief backstory or notes about your character..." rows={3} />
      </div>
      <div>
        <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Character Sheet</span>
        <input type="file" ref={fileRef} style={{display:"none"}} accept=".pdf,.png,.jpg,.jpeg,.json" onChange={handleSheet} />
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          <CrimsonBtn onClick={()=>fileRef.current?.click()} secondary small><Upload size={11}/> {form.sheetName ? "Replace" : "Upload Sheet"}</CrimsonBtn>
          {form.sheetName && <span style={{ fontSize:11, color:T.textDim, fontStyle:"italic" }}>{form.sheetName}</span>}
        </div>
      </div>
      <div style={{ display:"flex", gap:8, paddingTop:8, borderTop:`1px solid ${T.border}` }}>
        <CrimsonBtn onClick={submit}><Check size={12}/> {existing ? "Save Changes" : "Join Campaign"}</CrimsonBtn>
        {onCancel && <CrimsonBtn onClick={onCancel} secondary>Cancel</CrimsonBtn>}
      </div>
    </div>
  );
}

// ─── PLAYER CHARACTER CARD (compact display after joining) ──────────────────

function PlayerCard({ member, onEdit, onUploadSheet, isDm }) {
  const [expanded, setExpanded] = useState(false);
  const fileRef = useRef(null);

  const handleSheet = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    onUploadSheet(member.id, file);
  };

  return (
    <div style={{
      background:T.bgCard, border:`1px solid ${T.border}`, borderRadius:"4px",
      boxShadow:"0 2px 8px rgba(0,0,0,0.08)", transition:"all 0.2s", overflow:"hidden",
    }}>
      <input type="file" ref={fileRef} style={{display:"none"}} accept=".pdf,.png,.jpg,.jpeg,.json" onChange={handleSheet} />
      {/* Compact header — always visible */}
      <div onClick={()=>setExpanded(!expanded)} style={{ padding:"16px 20px", cursor:"pointer", display:"flex", alignItems:"center", gap:12 }}>
        <div style={{ width:36, height:36, borderRadius:"50%", background:T.crimsonSoft, border:`1px solid ${T.crimsonBorder}`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
          <span style={{ fontFamily:T.ui, fontSize:12, color:T.crimson, fontWeight:500 }}>{member.name.charAt(0)}</span>
        </div>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ display:"flex", alignItems:"center", gap:8 }}>
            <span style={{ fontSize:15, color:T.text, fontWeight:300 }}>{member.name}</span>
            <Tag variant="muted">Lv{member.lv} {member.cls}</Tag>
          </div>
          <div style={{ fontSize:11, color:T.textFaint, fontWeight:300, marginTop:2 }}>
            {member.player}{member.race ? ` — ${member.race}` : ""}
          </div>
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:10, flexShrink:0 }}>
          {member.status!=="healthy" && <Tag variant={member.status==="wounded"||member.status==="dead"?"danger":"warning"}>{member.status}</Tag>}
          <div style={{ textAlign:"right" }}>
            <div style={{ fontSize:11, color:member.hp<=member.maxHp*0.3?T.crimson:member.hp<=member.maxHp*0.5?"#e8940a":T.textDim, fontWeight:500 }}>{member.hp}/{member.maxHp}</div>
            <div style={{ width:60 }}><HpBar val={member.hp} max={member.maxHp} color={member.hp<member.maxHp*0.3?T.crimson:member.hp<member.maxHp*0.6?"#e8940a":"#2e8b57"}/></div>
          </div>
          <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1px" }}>AC {member.ac}</span>
          {expanded ? <ChevronUp size={14} color={T.textFaint}/> : <ChevronDown size={14} color={T.textFaint}/>}
        </div>
      </div>

      {/* Expanded detail */}
      {expanded && (
        <div style={{ padding:"0 20px 20px", borderTop:`1px solid ${T.borderMid}` }}>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1fr", gap:12, paddingTop:16, marginBottom:12 }}>
            {[{l:"HP",v:`${member.hp}/${member.maxHp}`},{l:"AC",v:member.ac},{l:"Level",v:member.lv},{l:"Class",v:member.cls}].map(s=>(
              <div key={s.l} style={{ textAlign:"center", background:T.bg, padding:"10px 8px", borderRadius:"2px", border:`1px solid ${T.border}` }}>
                <span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1.5px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:4 }}>{s.l}</span>
                <span style={{ fontSize:14, color:T.crimson, fontWeight:300 }}>{s.v}</span>
              </div>
            ))}
          </div>
          {member.bio && <p style={{ fontSize:13, color:T.textDim, fontStyle:"italic", fontWeight:300, lineHeight:1.7, margin:"0 0 12px" }}>{member.bio}</p>}
          {member.sheetName && (
            <div style={{ display:"flex", alignItems:"center", gap:6, marginBottom:12 }}>
              <FileText size={11} color={T.textFaint}/>
              <a href={member.sheetUrl} target="_blank" rel="noreferrer" style={{ fontSize:11, color:T.crimson, textDecoration:"none" }}>{member.sheetName}</a>
            </div>
          )}
          <div style={{ display:"flex", gap:6 }}>
            <CrimsonBtn onClick={()=>onEdit(member)} secondary small><Edit3 size={10}/> Edit Character</CrimsonBtn>
            <CrimsonBtn onClick={()=>fileRef.current?.click()} secondary small><Upload size={10}/> {member.sheetName?"Replace":"Upload"} Sheet</CrimsonBtn>
            {isDm && (
              <CrimsonBtn onClick={()=>onEdit({...member, _remove:true})} secondary small><Trash2 size={10}/> Remove</CrimsonBtn>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CAMPAIGN SELECTOR
// ═══════════════════════════════════════════════════════════════════════════

function CampaignSelector({ campaigns, activeCampaignId, onSelect, onCreate, onDelete }) {
  const [showList, setShowList] = useState(false);

  return (
    <div style={{ position:"relative" }}>
      <button onClick={()=>setShowList(!showList)} style={{
        display:"flex", alignItems:"center", gap:8, background:"transparent", border:`1px solid ${T.border}`,
        padding:"6px 14px", borderRadius:"2px", cursor:"pointer", transition:"all 0.2s",
      }}>
        <span style={{ fontSize:12, color:T.textDim, fontWeight:300 }}>{campaigns.find(c=>c.id===activeCampaignId)?.data.name || "Select Campaign"}</span>
        <ChevronDown size={12} color={T.textFaint}/>
      </button>
      {showList && (
        <div style={{
          position:"absolute", top:"100%", right:0, marginTop:4, width:280,
          background:T.bgCard, border:`1px solid ${T.crimsonBorder}`, borderRadius:"4px",
          boxShadow:"0 8px 24px rgba(0,0,6,0.45)", zIndex:300, overflow:"hidden",
        }}>
          <div style={{ padding:"12px 16px", borderBottom:`1px solid ${T.border}` }}>
            <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase" }}>Your Campaigns</span>
          </div>
          <div style={{ maxHeight:240, overflowY:"auto" }}>
            {campaigns.map(c => (
              <div key={c.id} onClick={()=>{onSelect(c.id);setShowList(false);}} style={{
                padding:"10px 16px", cursor:"pointer", display:"flex", justifyContent:"space-between", alignItems:"center",
                background: c.id===activeCampaignId ? T.crimsonSoft : "transparent",
                borderBottom:`1px solid ${T.borderMid}`, transition:"background 0.15s",
              }}>
                <div>
                  <div style={{ fontSize:13, color:T.text, fontWeight:300 }}>{c.data.name}</div>
                  <div style={{ fontSize:10, color:T.textFaint, fontStyle:"italic" }}>
                    {c.data.party.length} players · {c.data.sessionsPlayed} sessions
                    {c.isExample && " · Example"}
                  </div>
                </div>
                {!c.isExample && c.id !== activeCampaignId && (
                  <button onClick={e=>{e.stopPropagation();onDelete(c.id);}} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:4 }}><Trash2 size={11}/></button>
                )}
              </div>
            ))}
          </div>
          <div onClick={()=>{onCreate();setShowList(false);}} style={{
            padding:"12px 16px", cursor:"pointer", borderTop:`1px solid ${T.border}`,
            display:"flex", alignItems:"center", gap:8, transition:"background 0.15s",
          }}>
            <Plus size={14} color={T.crimson}/>
            <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase" }}>New Campaign</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════════════════════════════════

function DashboardView({ data, setData, onNav }) {
  const countdown = useCountdown(data.nextSession);
  const active = data.quests.filter(q=>q.status==="active");
  const urgVar = { critical:"critical", high:"danger", medium:"warning", low:"muted" };
  const [joiningParty, setJoiningParty] = useState(false);
  const [editingMember, setEditingMember] = useState(null);
  const [addingQuest, setAddingQuest] = useState(false);
  const [schedOpen, setSchedOpen] = useState(false);
  const [newQuest, setNewQuest] = useState({ title:"", type:"side", status:"active", urgency:"medium", faction:"", region:"" });

  const handlePlayerSubmit = (formData) => {
    if (editingMember) {
      if (formData._remove) {
        setData(d=>({...d, party: d.party.filter(p=>p.id!==editingMember.id),
          activity:[{time:"Just now", text:`Removed ${editingMember.name} from party`},...d.activity].slice(0,20)}));
      } else {
        setData(d=>({...d, party: d.party.map(p=>p.id===editingMember.id?{...p,...formData}:p),
          activity:[{time:"Just now", text:`${formData.name} updated their character`},...d.activity].slice(0,20)}));
      }
      setEditingMember(null);
    } else {
      setData(d=>({...d, party: [...d.party, { ...formData, id:uid() }],
        activity:[{time:"Just now", text:`${formData.name} (${formData.player}) joined the party`},...d.activity].slice(0,20)}));
      setJoiningParty(false);
    }
  };
  const handleEdit = (member) => setEditingMember(member);
  const handleSheetUpload = (id) => {
    const url = prompt("Paste the Google Sheets / D&D Beyond URL:");
    if(url) setData(d=>({...d, party:d.party.map(p=>p.id===id?{...p,sheetUrl:url,sheetName:url.includes("dndbeyond")?"D&D Beyond":"Google Sheet"}:p)}));
  };
  const addQuest = () => {
    if(!newQuest.title) return;
    setData(d=>({...d, quests:[...d.quests,{...newQuest,id:uid()}],
      activity:[{time:"Just now",text:`New quest: ${newQuest.title}`},...d.activity].slice(0,20)}));
    setNewQuest({ title:"", type:"side", status:"active", urgency:"medium", faction:"", region:"" });
    setAddingQuest(false);
  };
  const nextN = data.sessionsPlayed + 1;
  const steps = [
    { done:data.party.length>0, text:"Add party members" },
    { done:data.sessionsPlayed>0, text:"Log your first session" },
    { done:data.regions.length>0, text:"Establish world regions" },
    { done:data.factions.length>0, text:"Create factions" },
    { done:data.npcs.length>0, text:"Add NPCs to the world" },
    { done:data.nextSession, text:"Schedule your next session" },
  ];

  return (
    <div style={{ display:"grid", gridTemplateColumns:"1fr 340px", gap:24, padding:"32px 56px" }}>
      <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
        {/* Stats Row */}
        <div style={{ display:"flex", gap:20 }}>
          {[
            { label:"Sessions", val:data.sessionsPlayed, icon:BookOpen },
            { label:"Quests", val:data.quests.length, icon:Scroll },
            { label:"Party", val:data.party.length, icon:Users },
            { label:"Regions", val:data.regions.length, icon:MapPin },
          ].map((s,i) => (
            <div key={i} style={{ flex:1, padding:"20px 24px", background:T.bgCard, border:`1px solid ${T.border}`, borderRadius:"4px" }}>
              <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                <s.icon size={14} color={T.crimson}/>
                <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1.5px", color:T.textMuted, textTransform:"uppercase" }}>{s.label}</span>
              </div>
              <span style={{ fontSize:28, color:T.text, fontWeight:300 }}>{s.val}</span>
            </div>
          ))}
        </div>

        {/* Next Session + inline scheduler */}
        <Section>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
            <div>
              <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.textMuted, textTransform:"uppercase" }}>Next Session</span>
              <div style={{ fontSize:32, color:T.text, fontWeight:300, margin:"8px 0 4px" }}>
                {data.nextSession ? new Date(data.nextSession).toLocaleDateString("en-US",{weekday:"long",month:"short",day:"numeric"}) : "Not Scheduled"}
              </div>
              {countdown && countdown !== "Now" && (
                <div style={{ fontFamily:T.ui, fontSize:11, letterSpacing:"1px", color:T.crimson }}>{countdown} remaining</div>
              )}
            </div>
            <div style={{ textAlign:"right" }}>
              {!schedOpen ? (
                <LinkBtn onClick={()=>setSchedOpen(true)}><Settings size={10}/> Configure</LinkBtn>
              ) : (
                <LinkBtn onClick={()=>setSchedOpen(false)}><X size={10}/> Close</LinkBtn>
              )}
            </div>
          </div>
          {schedOpen && (
            <div style={{ marginTop:20, paddingTop:20, borderTop:`1px solid ${T.border}` }}>
              <SessionSchedulerInline data={data} setData={setData} />
            </div>
          )}
        </Section>

        {/* Party */}
        <div>
          <SectionTitle icon={Users} count={data.party.length} action={
            <LinkBtn onClick={()=>setJoiningParty(true)}><Plus size={10}/> Join Party</LinkBtn>
          }>The Party</SectionTitle>

          {data.party.length === 0 && (
            <Section style={{ textAlign:"center", padding:40 }}>
              <Users size={32} color={T.textFaint} style={{ marginBottom:16 }}/>
              <p style={{ fontSize:14, color:T.textMuted, fontWeight:300, margin:"0 0 16px" }}>No adventurers yet.</p>
              <CrimsonBtn onClick={()=>setJoiningParty(true)}><Plus size={12}/> Add First Character</CrimsonBtn>
            </Section>
          )}

          <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
            {data.party.map(p => (
              <PlayerCard key={p.id} member={p} onEdit={handleEdit} onUploadSheet={handleSheetUpload} isDm={true} />
            ))}
          </div>
        </div>

        {/* Join Party / Edit Character Modal */}
        <Modal open={joiningParty || editingMember !== null} onClose={()=>{setJoiningParty(false);setEditingMember(null);}} title={editingMember ? "Edit Character" : "Join the Party"} wide>
          <PlayerCharacterForm
            existing={editingMember}
            onSubmit={handlePlayerSubmit}
            onCancel={()=>{setJoiningParty(false);setEditingMember(null);}}
          />
        </Modal>

        {/* Quests */}
        {data.modules.questTracker && (
          <div>
            <SectionTitle icon={Scroll} action={<LinkBtn onClick={()=>setAddingQuest(true)}><Plus size={10}/> Add Quest</LinkBtn>}>Active Quests</SectionTitle>
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              {active.map(q => (
                <div key={q.id} style={{ display:"flex", alignItems:"center", gap:12, padding:"14px 20px", background:T.bgCard, border:`1px solid ${T.border}`, borderRadius:"4px", borderLeft:`3px solid ${q.type==="main"?T.crimson:T.textFaint}` }}>
                  <div style={{ flex:1 }}>
                    <span style={{ fontSize:14, fontWeight:300, color:T.text }}>{q.title}</span>
                    <div style={{ display:"flex", gap:6, marginTop:6 }}>
                      <Tag variant={urgVar[q.urgency]}>{q.urgency}</Tag>
                      <Tag variant={q.type==="main"?"default":"muted"}>{q.type}</Tag>
                      {q.region && <Tag variant="info">{q.region}</Tag>}
                    </div>
                  </div>
                  <Select value={q.status} onChange={v=>setData(d=>({...d,quests:d.quests.map(qq=>qq.id===q.id?{...qq,status:v}:qq)}))} style={{width:120}}>
                    {["active","completed","upcoming","failed"].map(s=><option key={s} value={s}>{s}</option>)}
                  </Select>
                </div>
              ))}
              {active.length===0 && <p style={{ fontSize:13, color:T.textFaint, fontStyle:"italic", padding:16, fontWeight:300 }}>No active quests.</p>}
            </div>
          </div>
        )}

        {/* Add Quest Modal */}
        <Modal open={addingQuest} onClose={()=>setAddingQuest(false)} title="Add Quest">
          <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
            <Input value={newQuest.title} onChange={v=>setNewQuest(p=>({...p,title:v}))} placeholder="Quest title" />
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
              <Select value={newQuest.type} onChange={v=>setNewQuest(p=>({...p,type:v}))} style={{ width:"100%" }}>
                <option value="main">Main Quest</option>
                <option value="side">Side Quest</option>
              </Select>
              <Select value={newQuest.urgency} onChange={v=>setNewQuest(p=>({...p,urgency:v}))} style={{ width:"100%" }}>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="critical">Critical</option>
              </Select>
            </div>
            <Input value={newQuest.region} onChange={v=>setNewQuest(p=>({...p,region:v}))} placeholder="Region" />
            <Input value={newQuest.faction} onChange={v=>setNewQuest(p=>({...p,faction:v}))} placeholder="Faction" />
            <CrimsonBtn onClick={addQuest}><Plus size={12}/> Add Quest</CrimsonBtn>
          </div>
        </Modal>

        {/* Factions */}
        {data.modules.factionTracker && (
          <div>
            <SectionTitle icon={Globe} action={<LinkBtn onClick={()=>onNav("world")}>World State <ArrowRight size={10}/></LinkBtn>}>Factions</SectionTitle>
            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
              {data.factions.map(f => (
                <div key={f.id} style={{ padding:16, background:T.bgCard, border:`1px solid ${T.border}`, borderRadius:"4px", borderLeft:`4px solid ${f.color}` }}>
                  <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:8 }}>
                    <span style={{ fontSize:14, fontWeight:300, color:T.text }}>{f.name}</span>
                    <Tag variant={f.attitude==="allied"||f.attitude==="friendly"?"success":f.attitude==="hostile"?"danger":"muted"}>{f.attitude}</Tag>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <div style={{flex:1}}><PowerBar val={f.power} max={100} color={f.color}/></div>
                    <span style={{ fontSize:11, color:T.textMuted }}>{f.power}</span>
                    {f.trend==="rising"?<TrendingUp size={10} color={T.crimson}/>:f.trend==="declining"?<TrendingDown size={10} color="#5ee09a"/>:<Minus size={10} color={T.textFaint}/>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* RIGHT SIDEBAR */}
      <div style={{ display:"flex", flexDirection:"column", gap:24 }}>
        <Section>
          <SectionTitle icon={Compass}>What's Next</SectionTitle>
          <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
            {steps.map((s,i) => (
              <div key={i} style={{ display:"flex", alignItems:"start", gap:10, opacity:s.done?0.4:1 }}>
                {s.done ? <CheckCircle size={14} color="#5ee09a" style={{marginTop:2,flexShrink:0}}/> : <Circle size={14} color={T.crimson} style={{marginTop:2,flexShrink:0}}/>}
                <span style={{ fontSize:13, fontFamily:T.body, fontWeight:300, color:s.done?T.textFaint:T.textDim, textDecoration:s.done?"line-through":"none" }}>{s.text}</span>
              </div>
            ))}
          </div>
        </Section>

        {data.modules.timeline && (
          <Section>
            <SectionTitle icon={BookOpen}>Latest Session</SectionTitle>
            {data.timeline.length > 0 ? <>
              <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"1px", color:T.crimson, fontWeight:500 }}>#{data.timeline[0].n}</span>
              <div style={{ fontSize:18, color:T.text, fontWeight:300, margin:"6px 0 4px" }}>{data.timeline[0].title}</div>
              <div style={{ fontSize:12, color:T.textMuted, fontStyle:"italic", marginBottom:12, fontWeight:300 }}>{data.timeline[0].date}</div>
              <p style={{ fontSize:13, color:T.textDim, lineHeight:1.7, margin:"0 0 12px", fontWeight:300 }}>{data.timeline[0].summary}</p>
              <button onClick={()=>onNav("timeline")} style={{
                width:"100%", padding:10, background:T.crimsonSoft, border:`1px solid ${T.crimsonBorder}`,
                borderRadius:"2px", cursor:"pointer", fontFamily:T.ui, fontSize:"9px", letterSpacing:"2px",
                color:T.crimson, textTransform:"uppercase", fontWeight:500, display:"flex", alignItems:"center", justifyContent:"center", gap:8,
              }}>View Timeline <ArrowRight size={10}/></button>
            </> : <p style={{ fontSize:13, color:T.textFaint, fontStyle:"italic" }}>No sessions logged yet.</p>}
          </Section>
        )}

        <Section>
          <SectionTitle icon={Activity}>Recent Activity</SectionTitle>
          {data.activity.slice(0,6).map((a,i) => (
            <div key={i} style={{ padding:"10px 0", borderBottom:i<5?`1px solid ${T.borderMid}`:"none" }}>
              <span style={{ fontSize:12, fontFamily:T.body, color:T.textDim, lineHeight:1.5, fontWeight:300 }}>{a.text}</span>
              <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, marginTop:2, display:"block" }}>{a.time}</span>
            </div>
          ))}
        </Section>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// TIMELINE
// ═══════════════════════════════════════════════════════════════════════════

function TimelineView({ data, setData }) {
  const [open,setOpen] = useState(new Set([data.timeline[0]?.id]));
  const [dmView,setDmView] = useState(true);
  const [addingSession, setAddingSession] = useState(false);
  const [addingEvent, setAddingEvent] = useState(null);
  const [newSession, setNewSession] = useState({ title:"", date:new Date().toISOString().split('T')[0], summary:"", dmOnly:false });
  const [newEvent, setNewEvent] = useState({ type:"encounter", text:"", outcome:"", dmOnly:false });
  const [editNotes, setEditNotes] = useState({});

  const evIcons = { encounter:Swords, discovery:Search, roleplay:Users, world_change:Globe, loot:Star, quest_complete:CheckCircle };
  const evCols = { encounter:"#a31515", discovery:"#1e8b4a", roleplay:"#9a8520", world_change:"#2e5a80", loot:"#9a8520", quest_complete:"#4a7028" };
  const toggle = id => setOpen(s => { const n=new Set(s); n.has(id)?n.delete(id):n.add(id); return n; });

  const addSession = () => {
    if(!newSession.title) return;
    const n = data.sessionsPlayed + 1;
    setData(d=>({...d, sessionsPlayed:n, timeline:[{id:uid(),n,title:newSession.title,date:newSession.date,summary:newSession.summary,events:[],changes:[],notes:"",dmOnly:newSession.dmOnly},...d.timeline],
      activity:[{time:"Just now",text:`Session ${n}: ${newSession.title}`},...d.activity].slice(0,20)}));
    setNewSession({ title:"", date:new Date().toISOString().split('T')[0], summary:"", dmOnly:false });
    setAddingSession(false);
  };
  const addEvent = (sessionId) => {
    if(!newEvent.text) return;
    setData(d=>({...d,timeline:d.timeline.map(s=>s.id===sessionId?{...s,events:[...s.events,{id:eid(),...newEvent}]}:s)}));
    setNewEvent({ type:"encounter", text:"", outcome:"", dmOnly:false });
    setAddingEvent(null);
  };
  const saveNotes = (sessionId, notes) => {
    setData(d=>({...d,timeline:d.timeline.map(s=>s.id===sessionId?{...s,notes}:s)}));
  };

  return (
    <div style={{ padding:"32px 56px", maxWidth:900, margin:"0 auto" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:32 }}>
        <div>
          <div style={{ fontSize:28, color:T.text, fontWeight:300 }}>Campaign Timeline</div>
          <p style={{ fontSize:13, color:T.textMuted, fontStyle:"italic", margin:"4px 0 0", fontWeight:300 }}>{data.timeline.length} sessions logged</p>
        </div>
        <div style={{ display:"flex", gap:12 }}>
          <ToggleSwitch on={dmView} onToggle={()=>setDmView(!dmView)} label="DM View" />
          <CrimsonBtn onClick={()=>setAddingSession(true)}><Plus size={12}/> New Session</CrimsonBtn>
        </div>
      </div>

      {/* Add Session Modal */}
      <Modal open={addingSession} onClose={()=>setAddingSession(false)} title="Log New Session">
        <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
          <Input value={newSession.title} onChange={v=>setNewSession(p=>({...p,title:v}))} placeholder="Session title" />
          <Input value={newSession.date} onChange={v=>setNewSession(p=>({...p,date:v}))} type="date" />
          <Textarea value={newSession.summary} onChange={v=>setNewSession(p=>({...p,summary:v}))} placeholder="Session summary..." rows={4} />
          <ToggleSwitch on={newSession.dmOnly} onToggle={()=>setNewSession(p=>({...p,dmOnly:!p.dmOnly}))} label="DM Only" />
          <CrimsonBtn onClick={addSession}><Plus size={12}/> Log Session</CrimsonBtn>
        </div>
      </Modal>

      {data.timeline.length === 0 && (
        <Section style={{ textAlign:"center", padding:48 }}>
          <Clock size={32} color={T.textFaint} style={{ marginBottom:16 }}/>
          <p style={{ fontSize:14, color:T.textMuted, fontWeight:300, margin:"0 0 16px" }}>No sessions logged yet.</p>
          <CrimsonBtn onClick={()=>setAddingSession(true)}><Plus size={12}/> Log First Session</CrimsonBtn>
        </Section>
      )}

      <div style={{ position:"relative", paddingLeft:32 }}>
        {/* Timeline spine */}
        <div style={{ position:"absolute", left:7, top:0, bottom:0, width:2, background:T.crimsonBorder }}/>

        {data.timeline.map((s,idx) => {
          const isOpen = open.has(s.id);
          if(s.dmOnly && !dmView) return null;
          return (
            <div key={s.id} style={{ marginBottom:24, position:"relative" }}>
              {/* Timeline dot */}
              <div style={{ position:"absolute", left:-32, top:18, width:16, height:16, borderRadius:"50%",
                background:idx===0?T.crimson:T.bgCard, border:`2px solid ${idx===0?T.crimson:T.crimsonBorder}` }}/>

              <Section style={{ cursor:"pointer", transition:"all 0.2s" }} onClick={()=>toggle(s.id)}>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
                  <div style={{ flex:1 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:6 }}>
                      <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"1px", color:T.crimson, fontWeight:500 }}>Session {s.n}</span>
                      {s.dmOnly && <Tag variant="muted"><Lock size={8}/> DM</Tag>}
                    </div>
                    <div style={{ fontSize:18, color:T.text, fontWeight:300, marginBottom:4 }}>{s.title}</div>
                    <div style={{ fontSize:12, color:T.textMuted, fontStyle:"italic", fontWeight:300 }}>{s.date}</div>
                  </div>
                  <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                    <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint }}>{s.events?.length||0} events</span>
                    {isOpen ? <ChevronUp size={14} color={T.textFaint}/> : <ChevronDown size={14} color={T.textFaint}/>}
                  </div>
                </div>

                {isOpen && <>
                  <p style={{ fontSize:13, color:T.textDim, lineHeight:1.7, margin:"16px 0", fontWeight:300, borderTop:`1px solid ${T.border}`, paddingTop:16 }}>{s.summary}</p>

                  {/* Events */}
                  {s.events?.length > 0 && (
                    <div style={{ display:"flex", flexDirection:"column", gap:8, marginBottom:16 }}>
                      {s.events.map(ev => {
                        if(ev.dmOnly && !dmView) return null;
                        const EvIcon = evIcons[ev.type] || Circle;
                        return (
                          <div key={ev.id} style={{ display:"flex", gap:12, padding:"12px 16px", background:T.bg, borderRadius:"2px", borderLeft:`3px solid ${evCols[ev.type]||T.textFaint}`, opacity:ev.dmOnly?0.6:1 }}>
                            <EvIcon size={14} color={evCols[ev.type]||T.textFaint} style={{ marginTop:2, flexShrink:0 }}/>
                            <div style={{ flex:1 }}>
                              <span style={{ fontSize:13, color:T.text, fontWeight:300 }}>{ev.text}</span>
                              {ev.outcome && <div style={{ fontSize:11, color:T.textMuted, fontStyle:"italic", marginTop:4, fontWeight:300 }}>{ev.outcome}</div>}
                            </div>
                            {ev.dmOnly && <Lock size={10} color={T.textFaint}/>}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* World Changes */}
                  {s.changes?.length > 0 && (
                    <div style={{ padding:12, background:T.crimsonSoft, border:`1px solid ${T.crimsonBorder}`, borderRadius:"2px", marginBottom:16 }}>
                      <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1.5px", color:T.crimson, textTransform:"uppercase", display:"block", marginBottom:6 }}>World Changes</span>
                      {s.changes.map((c,ci) => <div key={ci} style={{ fontSize:12, color:T.textDim, fontWeight:300, padding:"2px 0" }}>• {c}</div>)}
                    </div>
                  )}

                  {/* DM Notes */}
                  {dmView && (
                    <div style={{ marginTop:12 }}>
                      <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase" }}>DM Notes</span>
                      <Textarea value={editNotes[s.id]!=null?editNotes[s.id]:(s.notes||"")} onChange={v=>setEditNotes(p=>({...p,[s.id]:v}))} rows={2} style={{ marginTop:6 }} placeholder="Private notes..." />
                      {editNotes[s.id]!=null && editNotes[s.id]!==(s.notes||"") && (
                        <CrimsonBtn small onClick={()=>{saveNotes(s.id,editNotes[s.id]);setEditNotes(p=>{const n={...p};delete n[s.id];return n;});}} style={{marginTop:6}}><Save size={10}/> Save</CrimsonBtn>
                      )}
                    </div>
                  )}

                  {/* Add event button */}
                  <div style={{ marginTop:12, paddingTop:12, borderTop:`1px solid ${T.border}` }}>
                    {addingEvent===s.id ? (
                      <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
                        <Select value={newEvent.type} onChange={v=>setNewEvent(p=>({...p,type:v}))} style={{width:"100%"}}>
                          <option value="encounter">Encounter</option>
                          <option value="discovery">Discovery</option>
                          <option value="roleplay">Roleplay</option>
                          <option value="world_change">World Change</option>
                          <option value="loot">Loot</option>
                          <option value="quest_complete">Quest Complete</option>
                        </Select>
                        <Input value={newEvent.text} onChange={v=>setNewEvent(p=>({...p,text:v}))} placeholder="What happened?" />
                        <Input value={newEvent.outcome} onChange={v=>setNewEvent(p=>({...p,outcome:v}))} placeholder="Outcome (optional)" />
                        <div style={{ display:"flex", gap:8 }}>
                          <CrimsonBtn small onClick={()=>addEvent(s.id)}><Plus size={10}/> Add</CrimsonBtn>
                          <CrimsonBtn small secondary onClick={()=>setAddingEvent(null)}><X size={10}/> Cancel</CrimsonBtn>
                        </div>
                      </div>
                    ) : (
                      <LinkBtn onClick={()=>setAddingEvent(s.id)}><Plus size={10}/> Add Event</LinkBtn>
                    )}
                  </div>
                </>}
              </Section>
            </div>
          );
        })}
      </div>
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════
// WORLD STATE
// ═══════════════════════════════════════════════════════════════════════════

function WorldView({ data, setData }) {
  const [sel,setSel] = useState(null);
  const [selType,setSelType] = useState(null);
  const [tab,setTab] = useState("map");
  const [editing,setEditing] = useState(false);
  const [addingEntity,setAddingEntity] = useState(false);

  // ── Map state — starts zoomed out to see the whole continent ──
  const [mapZoom, setMapZoom] = useState(0.25);
  const [mapPan, setMapPan] = useState({ x: 60, y: 30 });
  const [dragging, setDragging] = useState(null);
  const mapRef = useRef(null);
  const [zoomLevel, setZoomLevel] = useState("continent"); // continent | kingdom | local | detail

  // Update zoom level label
  useEffect(() => {
    if (mapZoom < 0.6) setZoomLevel("continent");
    else if (mapZoom < 1.5) setZoomLevel("kingdom");
    else if (mapZoom < 3.0) setZoomLevel("local");
    else setZoomLevel("detail");
  }, [mapZoom]);


  const conns = (type,ent) => {
    const c=[];
    if(type==="region"){ const f=data.factions.find(f=>f.name===ent.ctrl); if(f) c.push({type:"faction",e:f,label:"Controlled by"}); data.npcs.filter(n=>n.loc===ent.name).forEach(n=>c.push({type:"npc",e:n,label:"Located here"})); data.quests.filter(q=>q.region===ent.name).forEach(q=>c.push({type:"quest",e:q,label:"Active quest"})); }
    else if(type==="faction"){ data.regions.filter(r=>r.ctrl===ent.name).forEach(r=>c.push({type:"region",e:r,label:"Controls"})); data.npcs.filter(n=>n.faction===ent.name).forEach(n=>c.push({type:"npc",e:n,label:"Member"})); data.quests.filter(q=>q.faction===ent.name).forEach(q=>c.push({type:"quest",e:q,label:"Related quest"})); }
    else if(type==="npc"){ if(ent.faction){const f=data.factions.find(f=>f.name===ent.faction); if(f) c.push({type:"faction",e:f,label:"Member of"});} const r=data.regions.find(r=>r.name===ent.loc); if(r) c.push({type:"region",e:r,label:"Located in"}); }
    return c;
  };
  const tCols = { low:"#5ee09a", medium:"#e8ba40", high:"#e8940a", extreme:T.crimson };

  // ── Continental map — 6000×4500 world ──
  const MAP_W = 6000, MAP_H = 4500;

  // Deterministic hash seed
  const seed = useCallback((s) => { let h=0; for(let i=0;i<s.length;i++){h=((h<<5)-h)+s.charCodeAt(i);h|=0;} return h; }, []);
  const seedF = useCallback((x,y,i) => { const v = Math.sin(x*12.9898+y*78.233+i*43758.5453)*43758.5453; return v - Math.floor(v); }, []);

  // ── Region map positions — spread across the continent ──
  const regionPositions = useCallback(() => {
    const pad=400;
    return data.regions.map((r,i) => {
      const s = seed(r.name+r.id);
      const angle = (i / Math.max(data.regions.length,1)) * Math.PI * 2 + (s%100)/200;
      const dist = 0.2 + (Math.abs(s%400)/700);
      // Kingdoms/capitals get more central placement, hamlets/dungeons get pushed outward
      const centralBias = (r.type==="kingdom"||r.type==="capital"||r.type==="city") ? 0.6 : 1.0;
      const x = Math.round(MAP_W/2 + Math.cos(angle) * (MAP_W/2 - pad) * dist * centralBias);
      const y = Math.round(MAP_H/2 + Math.sin(angle) * (MAP_H/2 - pad) * dist * centralBias);
      return { ...r, mx: Math.max(pad, Math.min(MAP_W-pad, x)), my: Math.max(pad, Math.min(MAP_H-pad, y)) };
    });
  }, [data.regions, seed]);

  const mapRegions = regionPositions();

  // ── Procedural POIs (dungeons, ruins, shrines, caves scattered across the world) ──
  const worldPOIs = useCallback(() => {
    const pois = [];
    const types = ["dungeon","ruins","dungeon","ruins","cave","shrine","cave","tower","grove","monolith"];
    const names = ["Darkhollow Crypt","Shattered Pillar","The Sunken Vault","Serpent's Den","Whispering Grotto",
      "Moonlit Shrine","Dragon's Maw Cave","Old Watchtower","The Twisted Grove","The Standing Stone",
      "Tomb of the Forgotten","Crumbling Bastion","The Bone Pit","Iron Gate Ruins","Crystalvein Cavern",
      "Stormbreak Spire","The Withered Oak","Ancestor's Cairn","Wraithwood Hollow","The Ember Forge",
      "Tidal Caves","Blightmoor Ruins","Gnarled Root Temple","Shadowpeak Mine","The Silent Obelisk",
      "Windscour Heights","Blackwater Grotto","Duskfall Sanctum","The Petrified Circle","Ironmaw Depths",
      "Thornkeep Ruins","Mistwalker's Shrine","The Frozen Barrow","Starfall Crater","Ashveil Catacombs"];
    for (let i=0; i<35; i++) {
      const a = seedF(i,7,3)*Math.PI*2;
      const d = 600 + seedF(i,11,5)*1800;
      const x = Math.round(MAP_W/2 + Math.cos(a)*d + seedF(i,3,1)*400-200);
      const y = Math.round(MAP_H/2 + Math.sin(a)*d*0.75 + seedF(i,5,2)*300-150);
      if(x>200 && x<MAP_W-200 && y>200 && y<MAP_H-200) {
        const threat = ["low","medium","high","extreme"][Math.floor(seedF(i,9,4)*4)];
        pois.push({ id:`poi-${i}`, name:names[i%names.length], type:types[i%types.length], x:Math.max(300,Math.min(MAP_W-300,x)), y:Math.max(300,Math.min(MAP_H-300,y)), threat });
      }
    }
    return pois;
  }, [seedF]);

  const pois = worldPOIs();

  // ── Weather zones — procedural weather system ──

  // ── Travel distance calculator ──

  // ── Encounter zone generation ──

  // ── Roads: connect regions by faction, proximity, and type — with major/minor classifications ──
  const roads = useCallback(() => {
    const rs = [];
    const mr = mapRegions;
    for (let i=0; i<mr.length; i++) {
      for (let j=i+1; j<mr.length; j++) {
        const a = mr[i], b = mr[j];
        const shareCtrl = a.ctrl && b.ctrl && a.ctrl === b.ctrl;
        const questLink = data.quests.some(q => (q.region===a.name && data.factions.some(f=>f.name===q.faction && data.regions.some(r2=>r2.ctrl===f.name && r2.name===b.name))) || (q.region===b.name && data.factions.some(f=>f.name===q.faction && data.regions.some(r2=>r2.ctrl===f.name && r2.name===a.name))));
        const isRoute = a.type==="route" || b.type==="route";
        const dist = Math.hypot(a.mx-b.mx, a.my-b.my);
        const isMajor = (a.type==="city"||a.type==="kingdom"||a.type==="capital") && (b.type==="city"||b.type==="kingdom"||b.type==="capital");
        if (shareCtrl || questLink || isRoute || dist < 1200) {
          // Multi-segment organic curved path for longer roads
          const segs = dist > 800 ? 3 : dist > 400 ? 2 : 1;
          let path = `M${a.mx},${a.my}`;
          for (let s=0; s<segs; s++) {
            const t1 = (s+0.5)/segs, t2 = (s+1)/segs;
            const cx = a.mx + (b.mx-a.mx)*t1 + Math.sin(a.mx*0.007+b.my*0.011+s*2)*80*(dist/800);
            const cy = a.my + (b.my-a.my)*t1 + Math.cos(a.my*0.009+b.mx*0.013+s*3)*60*(dist/800);
            const ex = a.mx + (b.mx-a.mx)*t2;
            const ey = a.my + (b.my-a.my)*t2;
            path += ` Q${Math.round(cx)},${Math.round(cy)} ${Math.round(ex)},${Math.round(ey)}`;
          }
          rs.push({ from:a, to:b, path, dist, major:isMajor||shareCtrl });
        }
      }
    }
    return rs;
  }, [mapRegions, data.quests, data.factions, data.regions]);

  // ── Zoom / Pan handlers — wider range for continental zoom (0.15x to 8x) ──
  const handleWheel = useCallback((e) => {
    e.preventDefault();
    const rect = mapRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mx = e.clientX - rect.left, my = e.clientY - rect.top;
    // Proportional zoom speed — faster at high zoom, slower at low zoom
    const factor = e.deltaY > 0 ? 0.88 : 1.14;
    const newZoom = Math.max(0.12, Math.min(8, mapZoom * factor));
    const ratio = newZoom / mapZoom;
    setMapPan(p => ({ x: mx - (mx - p.x) * ratio, y: my - (my - p.y) * ratio }));
    setMapZoom(newZoom);
  }, [mapZoom]);

  const handleMouseDown = useCallback((e) => {
    if (e.button !== 0) return;
    setDragging({ startX: e.clientX, startY: e.clientY, panX: mapPan.x, panY: mapPan.y });
  }, [mapPan]);

  const handleMouseMove = useCallback((e) => {
    if (!dragging) return;
    setMapPan({ x: dragging.panX + (e.clientX - dragging.startX), y: dragging.panY + (e.clientY - dragging.startY) });
  }, [dragging]);

  const handleMouseUp = useCallback(() => setDragging(null), []);

  const selectRegion = (r) => { setSel(r); setSelType("region"); setEditing(false); };

  // ── Continental terrain generation — mountain ranges, forests, hills ──
  const terrainFeatures = useCallback(() => {
    const features = [];
    // Large mountain ranges spanning the continent
    const mtRanges = [
      { cx:800, cy:600, spread:500, count:22, dir:0.3 },
      { cx:4200, cy:900, spread:450, count:20, dir:-0.4 },
      { cx:2800, cy:400, spread:600, count:28, dir:0.1 },
      { cx:1200, cy:3200, spread:400, count:16, dir:0.6 },
      { cx:4800, cy:2800, spread:350, count:14, dir:-0.2 },
      { cx:3000, cy:2200, spread:300, count:12, dir:0.5 },
      { cx:5200, cy:1600, spread:280, count:10, dir:-0.1 },
      { cx:600, cy:2000, spread:250, count:9, dir:0.8 },
    ];
    mtRanges.forEach((range,ri) => {
      for(let i=0;i<range.count;i++){
        // Elongated ranges — mountains follow a directional line
        const t = (i/range.count - 0.5) * 2;
        const baseX = range.cx + Math.cos(range.dir)*t*range.spread;
        const baseY = range.cy + Math.sin(range.dir)*t*range.spread*0.6;
        const x = baseX + seedF(ri,i,1)*100-50;
        const y = baseY + seedF(ri,i,2)*70-35;
        const s = 0.7 + seedF(ri,i,3)*1.0;
        features.push({ type:"mountain", x, y, scale:s, key:`mt-${ri}-${i}` });
      }
    });
    // Dense forest clusters
    const forests = [
      { cx:1800, cy:1600, spread:400, count:28 },
      { cx:600, cy:1500, spread:300, count:20 },
      { cx:3800, cy:2400, spread:350, count:24 },
      { cx:3200, cy:1000, spread:250, count:16 },
      { cx:1000, cy:800, spread:280, count:18 },
      { cx:5000, cy:800, spread:220, count:14 },
      { cx:2200, cy:3400, spread:300, count:20 },
      { cx:4400, cy:3600, spread:260, count:16 },
      { cx:1400, cy:2600, spread:200, count:12 },
      { cx:3600, cy:600, spread:180, count:10 },
      { cx:5400, cy:2200, spread:200, count:12 },
      { cx:800, cy:3800, spread:240, count:15 },
    ];
    forests.forEach((f,fi) => {
      for(let i=0;i<f.count;i++){
        const a = (i/f.count)*Math.PI*2 + seedF(fi,i,5)*0.6;
        const d = f.spread * (0.15 + seedF(fi,i,4)*0.85);
        const x = f.cx + Math.cos(a)*d + seedF(fi,i,6)*60-30;
        const y = f.cy + Math.sin(a)*d + seedF(fi,i,7)*50-25;
        const s = 0.5 + seedF(fi,i,8)*0.7;
        features.push({ type:"tree", x, y, scale:s, key:`tr-${fi}-${i}` });
      }
    });
    // Scattered small hills (visible at medium zoom)
    for(let i=0;i<60;i++){
      const x = 400 + seedF(i,20,1)*(MAP_W-800);
      const y = 400 + seedF(i,20,2)*(MAP_H-800);
      features.push({ type:"hill", x, y, scale:0.4+seedF(i,20,3)*0.4, key:`hill-${i}` });
    }
    return features;
  }, [seedF]);

  const terrain = terrainFeatures();

  // ── Kingdom territory polygons (convex hulls of faction-controlled regions) ──
  const territories = useCallback(() => {
    const factionRegions = {};
    mapRegions.forEach(r => {
      if(r.ctrl) {
        if(!factionRegions[r.ctrl]) factionRegions[r.ctrl] = [];
        factionRegions[r.ctrl].push(r);
      }
    });
    const results = [];
    Object.entries(factionRegions).forEach(([fName, regs]) => {
      if(regs.length < 2) return;
      const faction = data.factions.find(f=>f.name===fName);
      if(!faction) return;
      // Simple convex hull approximation: sort by angle from centroid
      const cx = regs.reduce((s,r)=>s+r.mx,0)/regs.length;
      const cy = regs.reduce((s,r)=>s+r.my,0)/regs.length;
      const sorted = [...regs].sort((a,b) => Math.atan2(a.my-cy,a.mx-cx) - Math.atan2(b.my-cy,b.mx-cx));
      // Expand outward for territory border
      const points = sorted.map(r => {
        const dx = r.mx-cx, dy = r.my-cy;
        const d = Math.hypot(dx,dy) || 1;
        return { x: r.mx + (dx/d)*180, y: r.my + (dy/d)*140 };
      });
      const path = points.map((p,i) => {
        if(i===0) return `M${Math.round(p.x)},${Math.round(p.y)}`;
        const prev = points[(i-1+points.length)%points.length];
        const cpx = (prev.x+p.x)/2 + (Math.sin(i*1.5)*40);
        const cpy = (prev.y+p.y)/2 + (Math.cos(i*1.7)*30);
        return `Q${Math.round(cpx)},${Math.round(cpy)} ${Math.round(p.x)},${Math.round(p.y)}`;
      }).join(" ") + "Z";
      results.push({ faction:fName, color:faction.color, path });
    });
    return results;
  }, [mapRegions, data.factions]);

  const updateFaction = (id, updates) => {
    setData(d=>({...d, factions:d.factions.map(f=>f.id===id?{...f,...updates}:f)}));
    if(sel?.id===id && selType==="faction") setSel(p=>({...p,...updates}));
  };
  const updateRegion = (id, updates) => {
    setData(d=>({...d, regions:d.regions.map(r=>r.id===id?{...r,...updates}:r)}));
    if(sel?.id===id && selType==="region") setSel(p=>({...p,...updates}));
  };
  const updateNpc = (id, updates) => {
    setData(d=>({...d, npcs:d.npcs.map(n=>n.id===id?{...n,...updates}:n)}));
    if(sel?.id===id && selType==="npc") setSel(p=>({...p,...updates}));
  };
  const addEntity = (type, entity) => {
    const newE = { ...entity, id:uid() };
    if(type==="region") setData(d=>({...d,regions:[...d.regions,newE]}));
    if(type==="faction") setData(d=>({...d,factions:[...d.factions,newE]}));
    if(type==="npc") setData(d=>({...d,npcs:[...d.npcs,newE]}));
    setAddingEntity(false);
  };

  // ── Inline SVG terrain renderers for the map ──
  const MtnSvg = ({ x, y, s }) => (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <path d="M0,0 L-18,-35 Q-15,-42,-8,-40 L0,-50 L8,-40 Q15,-42,18,-35 L0,0Z" fill="var(--text-faint)" opacity="0.12" stroke="var(--text-faint)" strokeWidth="1.2"/>
      <path d="M0,-50 L-5,-38 L-2,-40 L0,-45 L2,-40 L5,-38 L0,-50Z" fill="var(--text-muted)" opacity="0.18"/>
      <path d="M-6,-30 Q-3,-36,0,-50" stroke="var(--text-faint)" strokeWidth="0.5" opacity="0.2" fill="none"/>
    </g>
  );
  const TreeSvg = ({ x, y, s }) => (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <line x1="0" y1="0" x2="0" y2="-12" stroke="var(--text-faint)" strokeWidth="1.5" opacity="0.5"/>
      <path d="M0,-30 C-8,-30,-14,-24,-13,-18 C-16,-17,-15,-12,-12,-11 C-13,-8,-9,-5,-5,-6 C-4,-3,4,-3,5,-6 C9,-5,13,-8,12,-11 C15,-12,16,-17,13,-18 C14,-24,8,-30,0,-30Z" fill="var(--text-faint)" opacity="0.1" stroke="var(--text-faint)" strokeWidth="0.9"/>
    </g>
  );
  const HillSvg = ({ x, y, s }) => (
    <g transform={`translate(${x},${y}) scale(${s})`}>
      <path d="M-20,0 Q-10,-18 0,-22 Q10,-18 20,0Z" fill="var(--text-faint)" opacity="0.06" stroke="var(--text-faint)" strokeWidth="0.6" opacity="0.12"/>
    </g>
  );
  // POI icon renderer for scattered world POIs
  const POISvg = ({ poi, zoom: z }) => {
    const iconSize = z > 3 ? 28 : 22;
    const FI = FANTASY_ICONS[poi.type] || MapIconRuins;
    const threatCol = tCols[poi.threat] || "var(--text-muted)";
    return (
      <g style={{ cursor:"pointer" }} onClick={(e)=>{e.stopPropagation();setSel({...poi,id:poi.id});setSelType("poi");}}>
        <g transform={`translate(${poi.x - iconSize/2},${poi.y - iconSize/2})`}>
          <FI size={iconSize} color={threatCol} />
        </g>
        {z > 2.5 && <text x={poi.x} y={poi.y+18} textAnchor="middle" fill="var(--text-muted)" fontFamily="'Spectral', serif" fontSize="8" fontStyle="italic" opacity="0.7" style={{pointerEvents:"none"}}>{poi.name}</text>}
      </g>
    );
  };

  const roadList = roads();

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"calc(100vh - 56px)", overflow:"hidden" }}>
      {/* Top bar */}
      <div style={{ display:"flex", alignItems:"center", gap:0, padding:"0 24px", borderBottom:`1px solid ${T.border}`, flexShrink:0, background:T.bgNav }}>
        {["map","regions","factions","npcs"].map(t => (
          <button key={t} onClick={()=>{setTab(t);if(t!=="map"){setSel(null);setEditing(false);}}} style={{
            padding:"14px 24px", background:"transparent", border:"none", cursor:"pointer",
            fontFamily:T.ui, fontSize:9, letterSpacing:"2px", textTransform:"uppercase", fontWeight:500,
            color:tab===t?T.crimson:T.textMuted, transition:"all 0.3s",
            borderBottom:tab===t?`2px solid ${T.crimson}`:"2px solid transparent",
          }}>{t==="map"?"Fantasy Map":t}</button>
        ))}
        <div style={{ marginLeft:"auto", display:"flex", gap:8, alignItems:"center" }}>
          {tab==="map" && <>
            <span style={{ fontFamily:T.ui, fontSize:8, color:T.crimson, letterSpacing:"1px", fontWeight:500 }}>{zoomLevel.toUpperCase()}</span>
            <span style={{ fontFamily:T.ui, fontSize:8, color:T.textMuted, letterSpacing:"1px" }}>{Math.round(mapZoom*100)}%</span>
            <button onClick={()=>setMapZoom(z=>Math.min(8,z*1.3))} style={{ padding:"4px 8px", background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontSize:13, cursor:"pointer", borderRadius:"2px" }}>+</button>
            <button onClick={()=>setMapZoom(z=>Math.max(0.12,z*0.77))} style={{ padding:"4px 8px", background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontSize:13, cursor:"pointer", borderRadius:"2px" }}>−</button>
            <button onClick={()=>{setMapZoom(0.25);setMapPan({x:60,y:30});}} style={{ padding:"4px 10px", background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontFamily:T.ui, fontSize:8, letterSpacing:"1px", textTransform:"uppercase", cursor:"pointer", borderRadius:"2px" }}>Continent</button>
            <button onClick={()=>{setMapZoom(1);setMapPan({x:-1200,y:-800});}} style={{ padding:"4px 10px", background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontFamily:T.ui, fontSize:8, letterSpacing:"1px", textTransform:"uppercase", cursor:"pointer", borderRadius:"2px" }}>Kingdom</button>
            <button onClick={()=>{setMapZoom(2.5);setMapPan({x:-4500,y:-3200});}} style={{ padding:"4px 10px", background:"transparent", border:`1px solid ${T.border}`, color:T.textMuted, fontFamily:T.ui, fontSize:8, letterSpacing:"1px", textTransform:"uppercase", cursor:"pointer", borderRadius:"2px" }}>Local</button>
            {tab==="map" && <div style={{ position:"relative" }}>
              
              <Search size={11} color={T.textFaint} style={{ position:"absolute", left:8, top:"50%", transform:"translateY(-50%)" }}/>
            </div>}
          </>}
          <CrimsonBtn onClick={()=>setAddingEntity(true)} small><Plus size={11}/> Add</CrimsonBtn>
        </div>
      </div>

      <div style={{ display:"flex", flex:1, overflow:"hidden" }}>
        {/* ══════════ FANTASY MAP TAB — Multi-scale continental map ══════════ */}
        {tab==="map" && (
          <div ref={mapRef} style={{ flex:1, overflow:"hidden", cursor:dragging?"grabbing":"grab", position:"relative", background:T.bg }}
            onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} onMouseLeave={handleMouseUp}
            onWheel={handleWheel}>
            <svg width="100%" height="100%" style={{ display:"block" }}>
              <defs>
                {/* Parchment texture filter */}
                <filter id="parchment">
                  <feTurbulence type="fractalNoise" baseFrequency="0.02" numOctaves="5" result="noise"/>
                  <feDiffuseLighting in="noise" lightingColor="var(--bg-card)" surfaceScale="1.2" result="lit"><feDistantLight azimuth="45" elevation="55"/></feDiffuseLighting>
                  <feComposite in="SourceGraphic" in2="lit" operator="arithmetic" k1="0.7" k2="0.35" k3="0" k4="0"/>
                </filter>
                {/* Water pattern */}
                <pattern id="waterPat" x="0" y="0" width="80" height="80" patternUnits="userSpaceOnUse">
                  <path d="M0,40 Q20,35 40,40 Q60,45 80,40" stroke="var(--crimson-border)" strokeWidth="0.5" fill="none" opacity="0.25"/>
                  <path d="M0,55 Q20,50 40,55 Q60,60 80,55" stroke="var(--crimson-border)" strokeWidth="0.3" fill="none" opacity="0.15"/>
                  <path d="M0,25 Q20,20 40,25 Q60,30 80,25" stroke="var(--crimson-border)" strokeWidth="0.3" fill="none" opacity="0.12"/>
                </pattern>
                {/* Glow for cities */}
                <filter id="cityGlow">
                  <feGaussianBlur stdDeviation="4" result="blur"/>
                  <feComposite in="SourceGraphic" in2="blur" operator="over"/>
                </filter>
              </defs>

              <g transform={`translate(${mapPan.x},${mapPan.y}) scale(${mapZoom})`}>
                {/* ═══ LAYER 0: Base map — always visible ═══ */}
                <rect x="0" y="0" width={MAP_W} height={MAP_H} rx="12" fill="var(--bg-card)" stroke="var(--crimson-border)" strokeWidth="3" filter="url(#parchment)"/>

                {/* ═══ LAYER 1: Continental geography — ocean, coastlines, major water ═══ */}
                {/* Western ocean */}
                <path d="M0,0 L0,4500 Q300,4200 250,3600 Q180,3000 320,2400 Q250,1800 200,1200 Q300,600 180,0 Z" fill="var(--crimson-soft)" opacity="0.25"/>
                <path d="M0,0 L0,4500 Q300,4200 250,3600 Q180,3000 320,2400 Q250,1800 200,1200 Q300,600 180,0 Z" fill="url(#waterPat)"/>
                {/* Eastern ocean */}
                <path d="M6000,0 L6000,4500 Q5700,4100 5750,3400 Q5800,2700 5680,2000 Q5750,1300 5800,600 Q5700,200 5750,0 Z" fill="var(--crimson-soft)" opacity="0.2"/>
                <path d="M6000,0 L6000,4500 Q5700,4100 5750,3400 Q5800,2700 5680,2000 Q5750,1300 5800,600 Q5700,200 5750,0 Z" fill="url(#waterPat)"/>
                {/* Northern sea */}
                <path d="M0,0 L6000,0 L6000,200 Q5000,350 4000,250 Q3000,400 2000,300 Q1000,380 0,250 Z" fill="var(--crimson-soft)" opacity="0.2"/>
                <path d="M0,0 L6000,0 L6000,200 Q5000,350 4000,250 Q3000,400 2000,300 Q1000,380 0,250 Z" fill="url(#waterPat)"/>
                {/* Southern sea */}
                <path d="M0,4500 L6000,4500 L6000,4250 Q5000,4100 4000,4200 Q3000,4080 2000,4180 Q1000,4100 0,4220 Z" fill="var(--crimson-soft)" opacity="0.2"/>
                <path d="M0,4500 L6000,4500 L6000,4250 Q5000,4100 4000,4200 Q3000,4080 2000,4180 Q1000,4100 0,4220 Z" fill="url(#waterPat)"/>
                {/* Inland sea */}
                <ellipse cx="3000" cy="2000" rx="400" ry="250" fill="var(--crimson-soft)" opacity="0.18"/>
                <ellipse cx="3000" cy="2000" rx="400" ry="250" fill="url(#waterPat)"/>
                {/* Large lake */}
                <ellipse cx="1600" cy="3200" rx="200" ry="140" fill="var(--crimson-soft)" opacity="0.15"/>
                <ellipse cx="1600" cy="3200" rx="200" ry="140" fill="url(#waterPat)"/>
                {/* Bay */}
                <path d="M4800,4500 Q4600,4000 4900,3800 Q5200,3700 5400,4000 Q5600,4300 5500,4500 Z" fill="var(--crimson-soft)" opacity="0.15"/>
                <path d="M4800,4500 Q4600,4000 4900,3800 Q5200,3700 5400,4000 Q5600,4300 5500,4500 Z" fill="url(#waterPat)"/>

                {/* Major rivers */}
                <path d="M1800,300 Q1850,600 1700,1000 Q1600,1400 1650,1800 Q1700,2200 1600,2600 Q1550,3000 1600,3200" stroke="var(--crimson-border)" strokeWidth="3" fill="none" opacity="0.3" strokeLinecap="round"/>
                <path d="M3200,400 Q3100,800 3150,1200 Q3050,1600 3000,2000" stroke="var(--crimson-border)" strokeWidth="2.5" fill="none" opacity="0.25" strokeLinecap="round"/>
                <path d="M4500,600 Q4400,1000 4500,1400 Q4550,1800 4400,2200 Q4350,2600 4500,3000 Q4600,3400 4500,3800" stroke="var(--crimson-border)" strokeWidth="2.5" fill="none" opacity="0.25" strokeLinecap="round"/>
                {/* Tributary rivers — visible at kingdom zoom */}
                {mapZoom > 0.5 && <>
                  <path d="M1200,1200 Q1400,1300 1650,1400" stroke="var(--crimson-border)" strokeWidth="1.5" fill="none" opacity="0.2" strokeLinecap="round"/>
                  <path d="M2200,1800 Q2500,1900 3000,2000" stroke="var(--crimson-border)" strokeWidth="1.5" fill="none" opacity="0.18" strokeLinecap="round"/>
                  <path d="M3800,1200 Q3600,1400 3150,1600" stroke="var(--crimson-border)" strokeWidth="1.2" fill="none" opacity="0.15" strokeLinecap="round"/>
                  <path d="M5200,2000 Q4900,2100 4500,2200" stroke="var(--crimson-border)" strokeWidth="1.2" fill="none" opacity="0.15" strokeLinecap="round"/>
                </>}

                {/* ═══ LAYER 2: Kingdom territories — visible at continent/kingdom zoom ═══ */}
                {mapZoom < 2.5 && territories().map((t,i) => (
                  <path key={`terr-${i}`} d={t.path} fill={t.color} opacity={0.06 + (mapZoom > 0.5 ? 0.04 : 0)} stroke={t.color} strokeWidth={mapZoom > 0.6 ? 1.5 : 2.5} strokeDasharray="12,8" strokeOpacity="0.3"/>
                ))}

                {/* ═══ LAYER 3: Terrain features — scale-dependent ═══ */}
                {/* Mountains — always visible (they define the landscape) */}
                {terrain.filter(t=>t.type==="mountain").map(t => <MtnSvg key={t.key} x={t.x} y={t.y} s={t.scale}/>)}
                {/* Hills — visible at kingdom zoom and closer */}
                {mapZoom > 0.5 && terrain.filter(t=>t.type==="hill").map(t => <HillSvg key={t.key} x={t.x} y={t.y} s={t.scale}/>)}
                {/* Forests — visible from kingdom zoom */}
                {mapZoom > 0.4 && terrain.filter(t=>t.type==="tree").map(t => <TreeSvg key={t.key} x={t.x} y={t.y} s={t.scale}/>)}

                {/* ═══ LAYER 4: Roads — major roads at kingdom zoom, minor at local ═══ */}
                {<g opacity={mapZoom > 0.5 ? Math.min(1, (mapZoom-0.5)*1.5) : 0} style={{ transition:"opacity 0.3s" }}>
                  {roadList.filter(rd=>rd.major).map((rd,i) => (
                    <path key={`mroad-${i}`} d={rd.path} stroke="var(--text-faint)" strokeWidth={mapZoom > 1.5 ? 1.5 : 3} fill="none" strokeDasharray={mapZoom > 2 ? "10,8" : "16,12"} opacity="0.5" strokeLinecap="round"/>
                  ))}
                </g>}
                {mapZoom > 0.8 && <g opacity={Math.min(1, (mapZoom-0.8)*2)} style={{ transition:"opacity 0.3s" }}>
                  {roadList.filter(rd=>!rd.major).map((rd,i) => (
                    <path key={`road-${i}`} d={rd.path} stroke="var(--text-faint)" strokeWidth={mapZoom > 2 ? 0.8 : 1.5} fill="none" strokeDasharray="6,6" opacity="0.35" strokeLinecap="round"/>
                  ))}
                </g>}

                {/* ═══ LAYER 5: Region markers — scale-dependent icon/label sizing ═══ */}
                {mapRegions.map(r => {
                  const active = sel?.id===r.id && selType==="region";
                  const threatCol = tCols[r.threat] || "var(--text-muted)";
                  const isBig = r.type==="city"||r.type==="kingdom"||r.type==="capital";
                  const isSmall = r.type==="hamlet"||r.type==="ruins"||r.type==="dungeon";
                  // Hide small settlements at continent zoom
                  if(isSmall && mapZoom < 0.5) return null;
                  // Scale icons inversely with zoom for readability at all levels
                  const baseSize = isBig ? 60 : isSmall ? 30 : 42;
                  const iconSize = Math.max(18, Math.min(baseSize, baseSize / Math.max(mapZoom*0.8, 0.5)));
                  const fontSize = isBig ? Math.max(8, 16/Math.max(mapZoom*0.7,0.4)) : Math.max(6, 12/Math.max(mapZoom*0.7,0.4));
                  return (
                    <g key={r.id} onClick={(e)=>{e.stopPropagation(); selectRegion(r);}} style={{ cursor:"pointer" }}>
                      {/* Glow ring on selection */}
                      {active && <circle cx={r.mx} cy={r.my} r={isBig?50:35} fill="none" stroke="var(--crimson)" strokeWidth="2.5" opacity="0.5" strokeDasharray="8,5">
                        <animate attributeName="stroke-dashoffset" from="0" to="26" dur="2s" repeatCount="indefinite"/>
                      </circle>}
                      {/* City glow at continental zoom */}
                      {isBig && mapZoom < 0.6 && <circle cx={r.mx} cy={r.my} r="30" fill={threatCol} opacity="0.08"/>}
                      {/* Icon */}
                      <g transform={`translate(${r.mx - iconSize/2},${r.my - iconSize/2})`}>
                        {(() => { const FI = getFantasyIcon(r.type); return <FI size={iconSize} color={threatCol} />; })()}
                      </g>
                      {/* Label — always show for kingdoms/cities, show others when zoomed */}
                      {(isBig || mapZoom > 0.4) && (
                        <text x={r.mx} y={r.my + (isBig?40:28)} textAnchor="middle" fill="var(--text)" fontFamily="'Cinzel', serif" fontSize={fontSize} fontWeight={isBig?"600":"500"} letterSpacing={isBig?"2.5":"1.5"} opacity={active?1:0.85} style={{ textTransform:"uppercase", pointerEvents:"none" }}>
                          {r.name}
                        </text>
                      )}
                      {/* Faction/state subtitle — kingdom zoom+ */}
                      {mapZoom > 0.8 && (
                        <text x={r.mx} y={r.my + (isBig?54:40)} textAnchor="middle" fill="var(--text-muted)" fontFamily="'Spectral', serif" fontSize={Math.max(6,10/Math.max(mapZoom*0.7,0.5))} fontStyle="italic" fontWeight="300" opacity="0.65" style={{ pointerEvents:"none" }}>
                          {r.ctrl ? r.ctrl : r.type} — {r.state}
                        </text>
                      )}
                      {/* Threat pip — local zoom+ */}
                      {mapZoom > 1.0 && (
                        <circle cx={r.mx + (isBig?28:20)} cy={r.my - (isBig?24:16)} r="5" fill={threatCol} opacity="0.7"/>
                      )}
                      {/* Visited marker — local zoom+ */}
                      {r.visited && mapZoom > 1.2 && (
                        <g transform={`translate(${r.mx-(isBig?28:20)},${r.my-(isBig?26:18)})`}>
                          <circle r="6" fill="var(--bg-card)" stroke="var(--text-muted)" strokeWidth="0.7"/>
                          <path d="M-2.5,0 L-0.5,2.5 L3,-2.5" stroke="#5ee09a" strokeWidth="1.4" fill="none" strokeLinecap="round"/>
                        </g>
                      )}
                      {/* Building cluster hint at detail zoom for towns/cities */}
                      {mapZoom > 3 && (isBig || r.type==="town") && (
                        <g opacity="0.2">
                          {[0,1,2,3,4].map(bi => {
                            const bx = r.mx + Math.cos(bi*1.3)*35 + seedF(bi,r.mx,1)*20-10;
                            const by = r.my + Math.sin(bi*1.3)*30 + seedF(bi,r.my,2)*15-8;
                            return <rect key={`b-${bi}`} x={bx-4} y={by-4} width={8+seedF(bi,3,3)*6} height={7+seedF(bi,4,4)*5} fill="var(--text-faint)" rx="1"/>;
                          })}
                        </g>
                      )}
                    </g>
                  );
                })}

                {/* ═══ LAYER 6: World POIs — visible at local zoom+ ═══ */}
                {mapZoom > 1.5 && pois.map(p => <POISvg key={p.id} poi={p} zoom={mapZoom}/>)}

                {/* ═══ LAYER 7: Weather overlay ═══ */}
                {mapZoom > 0.4 && data.factions.map(wz => (
                  <g key={wz.key} opacity={0.12 + (mapZoom > 1 ? 0.08 : 0)}>
                    {wz.type==="rain" && <><circle cx={wz.x} cy={wz.y} r={wz.r} fill="rgba(110,160,250,0.08)" stroke="rgba(110,160,250,0.15)" strokeWidth="1" strokeDasharray="8,6"/>
                      {mapZoom > 1 && [0,1,2,3,4,5].map(ri => <line key={`r-${ri}`} x1={wz.x-wz.r*0.6+ri*(wz.r*0.24)} y1={wz.y-20} x2={wz.x-wz.r*0.6+ri*(wz.r*0.24)-8} y2={wz.y+20} stroke="rgba(110,160,250,0.2)" strokeWidth="1" strokeLinecap="round"/>)}</>}
                    {wz.type==="storm" && <><circle cx={wz.x} cy={wz.y} r={wz.r} fill="rgba(90,15,150,0.06)" stroke="rgba(90,15,150,0.15)" strokeWidth="1.5" strokeDasharray="4,4"/>
                      {mapZoom > 1 && <path d={`M${wz.x-10},${wz.y-15} L${wz.x+5},${wz.y-2} L${wz.x-5},${wz.y-2} L${wz.x+10},${wz.y+15}`} stroke="rgba(255,220,30,0.3)" strokeWidth="1.5" fill="none"/>}</>}
                    {wz.type==="snow" && <circle cx={wz.x} cy={wz.y} r={wz.r} fill="rgba(210,228,255,0.06)" stroke="rgba(210,228,255,0.15)" strokeWidth="1" strokeDasharray="3,6"/>}
                    {wz.type==="fog" && <ellipse cx={wz.x} cy={wz.y} rx={wz.r*1.3} ry={wz.r*0.6} fill="rgba(190,190,200,0.06)" stroke="rgba(190,190,200,0.1)" strokeWidth="1"/>}
                    {wz.type==="wind" && mapZoom > 0.8 && <path d={`M${wz.x-wz.r*0.8},${wz.y} Q${wz.x},${wz.y-30} ${wz.x+wz.r*0.8},${wz.y}`} stroke="rgba(190,190,200,0.15)" strokeWidth="1.5" fill="none" strokeLinecap="round"/>}
                    {mapZoom > 1.2 && <text x={wz.x} y={wz.y} textAnchor="middle" fill="var(--text-faint)" fontFamily="'Spectral', serif" fontSize="9" fontStyle="italic" opacity="0.5">{wz.type}</text>}
                  </g>
                ))}

                {/* ═══ LAYER 8: Encounter zones — visible at local zoom+ ═══ */}
                {mapZoom > 1.8 && [].map(ez => (
                  <g key={ez.key} opacity="0.25" style={{cursor:"pointer"}} onClick={(e)=>{e.stopPropagation();setSel({...ez,id:ez.id});setSelType("encounter");}}>
                    <circle cx={ez.x} cy={ez.y} r={ez.r} fill="rgba(212,67,58,0.04)" stroke="rgba(212,67,58,0.2)" strokeWidth="1" strokeDasharray="6,4"/>
                    {mapZoom > 2.5 && <>
                      <text x={ez.x} y={ez.y-8} textAnchor="middle" fill="var(--crimson)" fontFamily="'Cinzel', serif" fontSize="7" letterSpacing="1" opacity="0.6" style={{textTransform:"uppercase"}}>{ez.type}</text>
                      <text x={ez.x} y={ez.y+6} textAnchor="middle" fill="var(--text-muted)" fontFamily="'Spectral', serif" fontSize="8" fontStyle="italic" opacity="0.5">CR {ez.cr}</text>
                    </>}
                    {mapZoom > 3 && <text x={ez.x} y={ez.y+18} textAnchor="middle" fill="var(--text-faint)" fontFamily="'Spectral', serif" fontSize="7" opacity="0.4">{ez.name}</text>}
                  </g>
                ))}

                {/* ═══ LAYER 9: Travel route overlay (removed) ═══ */}

                {/* ═══ LAYER 10: Compass rose ═══ */}
                <g transform={`translate(${MAP_W-200},${MAP_H-200})`} opacity="0.3">
                  <line x1="0" y1="-55" x2="0" y2="55" stroke="var(--text-faint)" strokeWidth="2"/>
                  <line x1="-55" y1="0" x2="55" y2="0" stroke="var(--text-faint)" strokeWidth="2"/>
                  <line x1="-35" y1="-35" x2="35" y2="35" stroke="var(--text-faint)" strokeWidth="0.8"/>
                  <line x1="35" y1="-35" x2="-35" y2="35" stroke="var(--text-faint)" strokeWidth="0.8"/>
                  <polygon points="0,-60 -7,-40 7,-40" fill="var(--crimson)"/>
                  <polygon points="0,60 -5,42 5,42" fill="var(--text-faint)"/>
                  <text x="0" y="-68" textAnchor="middle" fill="var(--text-muted)" fontFamily="'Cinzel', serif" fontSize="14" fontWeight="600">N</text>
                  <text x="68" y="5" textAnchor="middle" fill="var(--text-faint)" fontFamily="'Cinzel', serif" fontSize="10">E</text>
                  <text x="-68" y="5" textAnchor="middle" fill="var(--text-faint)" fontFamily="'Cinzel', serif" fontSize="10">W</text>
                  <text x="0" y="80" textAnchor="middle" fill="var(--text-faint)" fontFamily="'Cinzel', serif" fontSize="10">S</text>
                </g>

                {/* Map title cartouche */}
                <g transform="translate(300,130)">
                  <rect x="-140" y="-35" width="280" height="55" rx="4" fill="var(--bg-card)" stroke="var(--crimson-border)" strokeWidth="1.5" opacity="0.92"/>
                  <line x1="-120" y1="-15" x2="120" y2="-15" stroke="var(--crimson-border)" strokeWidth="0.5" opacity="0.4"/>
                  <text x="0" y="-2" textAnchor="middle" fill="var(--crimson)" fontFamily="'Cinzel', serif" fontSize="15" fontWeight="600" letterSpacing="4" style={{ textTransform:"uppercase" }}>
                    {data.name || "The Realm"}
                  </text>
                  <line x1="-120" y1="8" x2="120" y2="8" stroke="var(--crimson-border)" strokeWidth="0.5" opacity="0.4"/>
                </g>

                {/* Scale bar — visible at kingdom zoom+ */}
                {mapZoom > 0.5 && (
                  <g transform={`translate(${MAP_W-500},${MAP_H-80})`} opacity="0.3">
                    <line x1="0" y1="0" x2="200" y2="0" stroke="var(--text-faint)" strokeWidth="2"/>
                    <line x1="0" y1="-6" x2="0" y2="6" stroke="var(--text-faint)" strokeWidth="1.5"/>
                    <line x1="200" y1="-6" x2="200" y2="6" stroke="var(--text-faint)" strokeWidth="1.5"/>
                    <line x1="100" y1="-4" x2="100" y2="4" stroke="var(--text-faint)" strokeWidth="1"/>
                    <text x="100" y="18" textAnchor="middle" fill="var(--text-faint)" fontFamily="'Spectral', serif" fontSize="10">100 leagues</text>
                  </g>
                )}
              </g>
            </svg>

            {/* Zoom level indicator */}
            <div style={{ position:"absolute", top:12, right:12, display:"flex", flexDirection:"column", alignItems:"flex-end", gap:6, pointerEvents:"none" }}>
              <div style={{ padding:"6px 14px", background:T.bgCard, border:`1px solid ${T.crimsonBorder}`, borderRadius:"3px", fontFamily:T.ui, fontSize:8, color:T.crimson, letterSpacing:"2px", textTransform:"uppercase", opacity:0.85 }}>
                {zoomLevel} view
              </div>
              {mapZoom > 1.5 && <div style={{ padding:"4px 10px", background:T.bgCard, border:`1px solid ${T.border}`, borderRadius:"2px", fontFamily:T.body, fontSize:9, color:T.textMuted, fontStyle:"italic", opacity:0.7 }}>
                {pois.length} points of interest
              </div>}
            </div>

            {/* Minimap overlay — always visible when zoomed past continent */}
            {mapZoom > 0.5 && (
              <div style={{ position:"absolute", bottom:12, left:12, width:200, height:150, background:T.bgCard, border:`1px solid ${T.crimsonBorder}`, borderRadius:"3px", overflow:"hidden", opacity:0.88 }}>
                <svg width="200" height="150" viewBox={`0 0 ${MAP_W} ${MAP_H}`}>
                  <rect width={MAP_W} height={MAP_H} fill="var(--bg-card)" opacity="0.5"/>
                  {/* Territory fills */}
                  {territories().map((t,i) => <path key={`mt-${i}`} d={t.path} fill={t.color} opacity="0.12"/>)}
                  {/* Region dots */}
                  {mapRegions.map(r => <circle key={r.id} cx={r.mx} cy={r.my} r={(r.type==="city"||r.type==="kingdom")?30:18} fill={tCols[r.threat]||"var(--text-muted)"} opacity="0.5"/>)}
                  {/* Viewport indicator */}
                  {(() => {
                    const rect = mapRef.current?.getBoundingClientRect();
                    if(!rect) return null;
                    const vx = -mapPan.x / mapZoom, vy = -mapPan.y / mapZoom;
                    const vw = rect.width / mapZoom, vh = rect.height / mapZoom;
                    return <rect x={vx} y={vy} width={vw} height={vh} fill="none" stroke="var(--crimson)" strokeWidth="8" opacity="0.65" rx="4"/>;
                  })()}
                </svg>
              </div>
            )}

            {/* Travel info panel */}</div>
        )}

        {/* ══════════ LIST TABS (regions / factions / npcs) ══════════ */}
        {tab!=="map" && (
          <div style={{ flex:1, overflowY:"auto", padding:"24px 48px" }}>
            {tab==="regions" && (
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
                {data.regions.map(r => {
                  const FantasyIcon = getFantasyIcon(r.type);
                  const active=sel?.id===r.id&&selType==="region";
                  return (
                    <div key={r.id} onClick={()=>{setSel(r);setSelType("region");setEditing(false);}} style={{
                      background:active?T.bgHover:T.bgCard, padding:20, cursor:"pointer",
                      border:`1px solid ${active?T.crimsonBorder:T.border}`, borderRadius:"4px",
                      boxShadow:"0 2px 8px rgba(0,0,0,0.08)", transition:"all 0.2s",
                    }}>
                      <div style={{ display:"flex", alignItems:"start", gap:14 }}>
                        <div style={{ flexShrink:0, marginTop:-2, opacity:0.85 }}>
                          <FantasyIcon size={r.type==="city"||r.type==="kingdom"||r.type==="capital"?36:28} color={tCols[r.threat]} />
                        </div>
                        <div style={{ flex:1 }}>
                          <div style={{ fontSize:15, fontWeight:300, color:T.text, marginBottom:8 }}>{r.name}</div>
                          <div style={{ display:"flex", gap:6, flexWrap:"wrap", marginBottom:8 }}>
                            <Tag variant={r.threat==="extreme"?"critical":r.threat==="high"?"danger":r.threat==="medium"?"warning":"success"}>{r.threat}</Tag>
                            <Tag variant="muted">{r.type}</Tag>
                            {r.visited && <Tag variant="info">visited</Tag>}
                          </div>
                          <div style={{ fontSize:12, color:T.textMuted, fontWeight:300 }}>{r.ctrl} — <span style={{fontStyle:"italic"}}>{r.state}</span></div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {tab==="factions" && (
              <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
                {data.factions.map(f => {
                  const active=sel?.id===f.id&&selType==="faction";
                  return (
                    <div key={f.id} onClick={()=>{setSel(f);setSelType("faction");setEditing(false);}} style={{
                      background:active?T.bgHover:T.bgCard, padding:24, cursor:"pointer",
                      border:`1px solid ${active?T.crimsonBorder:T.border}`, borderRadius:"4px",
                      borderLeft:`4px solid ${f.color}`, boxShadow:"0 2px 8px rgba(0,0,0,0.08)", transition:"all 0.2s",
                    }}>
                      <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8 }}>
                        <span style={{ fontSize:18, fontWeight:300, color:T.text }}>{f.name}</span>
                        <Tag variant={f.attitude==="allied"||f.attitude==="friendly"?"success":f.attitude==="hostile"?"danger":"muted"}>{f.attitude}</Tag>
                        {f.trend==="rising"?<TrendingUp size={12} color={T.crimson}/>:f.trend==="declining"?<TrendingDown size={12} color="#5ee09a"/>:<Minus size={12} color={T.textFaint}/>}
                      </div>
                      <p style={{ fontSize:13, color:T.textDim, margin:"0 0 10px", fontWeight:300, fontStyle:"italic" }}>{f.desc}</p>
                      <div style={{ display:"flex", alignItems:"center", gap:10, maxWidth:300 }}>
                        <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1.5px" }}>PWR</span>
                        <div style={{flex:1}}><PowerBar val={f.power} max={100} color={f.color}/></div>
                        <span style={{ fontSize:12, color:T.textMuted }}>{f.power}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {tab==="npcs" && (
              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16 }}>
                {data.npcs.map(n => {
                  const active=sel?.id===n.id&&selType==="npc";
                  return (
                    <div key={n.id} onClick={()=>{setSel(n);setSelType("npc");setEditing(false);}} style={{
                      background:active?T.bgHover:T.bgCard, padding:20, cursor:"pointer", opacity:n.alive?1:0.45,
                      border:`1px solid ${active?T.crimsonBorder:T.border}`, borderRadius:"4px",
                      boxShadow:"0 2px 8px rgba(0,0,0,0.08)", transition:"all 0.2s",
                    }}>
                      <div style={{ display:"flex", alignItems:"start", gap:10 }}>
                        {n.alive?<Users size={14} color={T.textFaint}/>:<Skull size={14} color={T.crimson}/>}
                        <div>
                          <div style={{ fontSize:15, fontWeight:300, color:T.text, marginBottom:4 }}>{n.name}</div>
                          <div style={{ fontSize:12, color:T.textFaint, marginBottom:8, fontStyle:"italic", fontWeight:300 }}>{n.role} — {n.loc}</div>
                          <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
                            <Tag variant={n.attitude==="allied"||n.attitude==="friendly"?"success":n.attitude==="hostile"?"danger":n.attitude==="cautious"?"warning":"muted"}>{n.attitude}</Tag>
                            {n.faction && <Tag variant="muted">{n.faction}</Tag>}
                            {!n.alive && <Tag variant="danger">deceased</Tag>}
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ══════════ DETAIL PANEL (right side) ══════════ */}
        <div style={{ width:sel?360:0, overflowY:"auto", overflowX:"hidden", transition:"width 0.25s ease", flexShrink:0, borderLeft:sel?`1px solid ${T.border}`:"none" }}>
          {sel && (
            <div style={{ padding:24, width:360 }}>
              <Section>
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                    {selType==="region" && (() => { const FI = getFantasyIcon(sel.type); return <FI size={28} color={T.crimson} />; })()}
                    <div style={{ fontSize:18, color:T.text, fontWeight:300 }}>{sel.name}</div>
                  </div>
                  <div style={{ display:"flex", gap:6 }}>
                    <button onClick={()=>setEditing(!editing)} style={{ background:"none", border:"none", cursor:"pointer", color:editing?T.crimson:T.textFaint }}><Edit3 size={14}/></button>
                    <button onClick={()=>setSel(null)} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint }}><X size={14}/></button>
                  </div>
                </div>

                {editing ? (
                  <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:20 }}>
                    {selType==="faction" && <>
                      <Select value={sel.attitude} onChange={v=>{updateFaction(sel.id,{attitude:v});setSel(p=>({...p,attitude:v}));}} style={{ width:"100%" }}>
                        {["allied","friendly","neutral","cautious","hostile"].map(a=><option key={a} value={a}>{a}</option>)}
                      </Select>
                      <div>
                        <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1px" }}>POWER: {sel.power}</span>
                        <input type="range" min="0" max="100" value={sel.power} onChange={e=>{const v=parseInt(e.target.value);updateFaction(sel.id,{power:v});setSel(p=>({...p,power:v}));}} style={{ width:"100%" }} />
                      </div>
                      <Select value={sel.trend} onChange={v=>{updateFaction(sel.id,{trend:v});setSel(p=>({...p,trend:v}));}} style={{ width:"100%" }}>
                        {["rising","stable","declining"].map(t=><option key={t} value={t}>{t}</option>)}
                      </Select>
                    </>}
                    {selType==="region" && <>
                      <Select value={sel.type} onChange={v=>{updateRegion(sel.id,{type:v});setSel(p=>({...p,type:v}));}} style={{ width:"100%" }}>
                        {["city","town","hamlet","kingdom","castle","wilderness","forest","mountain","dungeon","ruins","route"].map(t=><option key={t} value={t}>{t}</option>)}
                      </Select>
                      <Select value={sel.threat} onChange={v=>{updateRegion(sel.id,{threat:v});setSel(p=>({...p,threat:v}));}} style={{ width:"100%" }}>
                        {["low","medium","high","extreme"].map(t=><option key={t} value={t}>{t}</option>)}
                      </Select>
                      <Input value={sel.state} onChange={v=>{updateRegion(sel.id,{state:v});setSel(p=>({...p,state:v}));}} placeholder="State" />
                      <ToggleSwitch on={sel.visited} onToggle={()=>{updateRegion(sel.id,{visited:!sel.visited});setSel(p=>({...p,visited:!p.visited}));}} label="Visited" />
                    </>}
                    {selType==="npc" && <>
                      <Select value={sel.attitude} onChange={v=>{updateNpc(sel.id,{attitude:v});setSel(p=>({...p,attitude:v}));}} style={{ width:"100%" }}>
                        {["allied","friendly","neutral","cautious","hostile"].map(a=><option key={a} value={a}>{a}</option>)}
                      </Select>
                      <Input value={sel.loc} onChange={v=>{updateNpc(sel.id,{loc:v});setSel(p=>({...p,loc:v}));}} placeholder="Location" />
                      <Input value={sel.role} onChange={v=>{updateNpc(sel.id,{role:v});setSel(p=>({...p,role:v}));}} placeholder="Role" />
                      <ToggleSwitch on={sel.alive} onToggle={()=>{updateNpc(sel.id,{alive:!sel.alive});setSel(p=>({...p,alive:!p.alive}));}} label="Alive" />
                    </>}
                  </div>
                ) : (
                  <div style={{ padding:14, background:T.bg, border:`1px solid ${T.crimsonBorder}`, borderRadius:"2px", marginBottom:20 }}>
                    {selType==="region" && <>
                      <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Type: <span style={{color:T.textDim}}>{sel.type}</span></div>
                      <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>State: <span style={{color:T.textDim,fontStyle:"italic"}}>{sel.state}</span></div>
                      <div style={{ fontSize:12, color:T.textMuted }}>Threat: <Tag variant={sel.threat==="extreme"?"critical":sel.threat==="high"?"danger":sel.threat==="medium"?"warning":"success"}>{sel.threat}</Tag></div>
                    </>}
                    {selType==="faction" && <>
                      <p style={{ fontSize:13, color:T.textDim, margin:"0 0 10px", fontWeight:300, fontStyle:"italic" }}>{sel.desc}</p>
                      <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Power: <span style={{color:T.textDim}}>{sel.power}/100</span></div>
                      <div style={{ fontSize:12, color:T.textMuted }}>Trend: <span style={{color:T.textDim}}>{sel.trend}</span></div>
                    </>}
                    {selType==="npc" && <>
                      <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Role: <span style={{color:T.textDim}}>{sel.role}</span></div>
                      <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Location: <span style={{color:T.textDim}}>{sel.loc}</span></div>
                      <div style={{ fontSize:12, color:T.textMuted }}>Status: <span style={{color:T.textDim}}>{sel.alive?"Alive":"Deceased"}</span></div>
                    </>}
                  </div>
                )}

                <SectionTitle icon={Layers}>Connections</SectionTitle>
                <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
                  {conns(selType,sel).map((c,i) => (
                    <div key={i} onClick={()=>{setSel(c.e);setSelType(c.type);setEditing(false);}} style={{
                      padding:"12px 14px", background:T.bg, cursor:"pointer", borderRadius:"2px",
                      border:`1px solid ${T.border}`, borderLeft:`3px solid ${c.type==="faction"?(c.e.color||T.crimson):T.textFaint}`,
                      transition:"all 0.15s",
                    }}>
                      <span style={{ fontFamily:T.ui, fontSize:7, color:T.textFaint, letterSpacing:"2px", textTransform:"uppercase", display:"block", marginBottom:3 }}>{c.label}</span>
                      <span style={{ fontSize:13, fontWeight:300, color:T.text }}>{c.e.name||c.e.title}</span>
                    </div>
                  ))}
                  {conns(selType,sel).length===0 && <p style={{ fontSize:12, color:T.textFaint, fontStyle:"italic", fontWeight:300 }}>No connections.</p>}
                </div>

                {/* POI details */}
                {selType==="poi" && !editing && (
                  <div style={{ padding:14, background:T.bg, border:`1px solid ${T.crimsonBorder}`, borderRadius:"2px", marginBottom:20 }}>
                    <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Type: <span style={{color:T.textDim}}>{sel.type}</span></div>
                    <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Threat: <Tag variant={sel.threat==="extreme"?"critical":sel.threat==="high"?"danger":sel.threat==="medium"?"warning":"success"}>{sel.threat}</Tag></div>
                    <div style={{ fontSize:12, color:T.textMuted, marginTop:10, fontStyle:"italic", fontWeight:300 }}>A mysterious point of interest awaiting exploration.</div>
                  </div>
                )}
                {/* Encounter zone details */}
                {selType==="encounter" && !editing && (
                  <div style={{ padding:14, background:T.bg, border:`1px solid ${T.crimsonBorder}`, borderRadius:"2px", marginBottom:20 }}>
                    <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Type: <span style={{color:T.textDim}}>{sel.type}</span></div>
                    <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Challenge: <Tag variant={sel.cr>10?"critical":sel.cr>7?"danger":sel.cr>3?"warning":"success"}>CR {sel.cr}</Tag></div>
                    <div style={{ fontSize:12, color:T.textMuted, marginBottom:6 }}>Name: <span style={{color:T.textDim,fontStyle:"italic"}}>{sel.name}</span></div>
                    <div style={{ fontSize:12, color:T.textMuted, marginTop:10, fontStyle:"italic", fontWeight:300 }}>An area known for dangerous encounters.</div>
                  </div>
                )}
              </Section>
            </div>
          )}
        </div>
      </div>

      {/* Add Entity Modal */}
      <AddEntityModal open={addingEntity} onClose={()=>setAddingEntity(false)} tab={tab==="map"?"regions":tab} onAdd={addEntity} data={data} />
    </div>
  );
}

function AddEntityModal({ open, onClose, tab, onAdd, data }) {
  const [form, setForm] = useState({});
  useEffect(() => {
    if (tab==="regions") setForm({ name:"", type:"town", ctrl:"", threat:"low", state:"stable", visited:false, terrain:"" });
    else if (tab==="factions") setForm({ name:"", attitude:"neutral", power:50, trend:"stable", desc:"", color:"#a4b5cc" });
    else setForm({ name:"", faction:null, loc:"", attitude:"neutral", role:"", alive:true });
  }, [tab, open]);

  return (
    <Modal open={open} onClose={onClose} title={`Add ${tab.slice(0,-1)}`}>
      <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
        <Input value={form.name||""} onChange={v=>setForm(p=>({...p,name:v}))} placeholder="Name" />
        {tab==="regions" && <>
          <Select value={form.type||"town"} onChange={v=>setForm(p=>({...p,type:v}))} style={{ width:"100%" }}>
            {["city","town","hamlet","kingdom","castle","wilderness","forest","mountain","dungeon","ruins","route"].map(t=><option key={t} value={t}>{t}</option>)}
          </Select>
          <Select value={form.ctrl||""} onChange={v=>setForm(p=>({...p,ctrl:v}))} style={{ width:"100%" }}>
            <option value="">No controller</option>
            {data.factions.map(f=><option key={f.id} value={f.name}>{f.name}</option>)}
          </Select>
          <Select value={form.threat||"low"} onChange={v=>setForm(p=>({...p,threat:v}))} style={{ width:"100%" }}>
            {["low","medium","high","extreme"].map(t=><option key={t} value={t}>{t}</option>)}
          </Select>
        </>}
        {tab==="factions" && <>
          <Textarea value={form.desc||""} onChange={v=>setForm(p=>({...p,desc:v}))} placeholder="Description..." rows={2} />
          <Select value={form.attitude||"neutral"} onChange={v=>setForm(p=>({...p,attitude:v}))} style={{ width:"100%" }}>
            {["allied","friendly","neutral","cautious","hostile"].map(a=><option key={a} value={a}>{a}</option>)}
          </Select>
        </>}
        {tab==="npcs" && <>
          <Input value={form.role||""} onChange={v=>setForm(p=>({...p,role:v}))} placeholder="Role (e.g., quest giver, ally)" />
          <Input value={form.loc||""} onChange={v=>setForm(p=>({...p,loc:v}))} placeholder="Location" />
          <Select value={form.faction||""} onChange={v=>setForm(p=>({...p,faction:v||null}))} style={{ width:"100%" }}>
            <option value="">No faction</option>
            {data.factions.map(f=><option key={f.id} value={f.name}>{f.name}</option>)}
          </Select>
          <Select value={form.attitude||"neutral"} onChange={v=>setForm(p=>({...p,attitude:v}))} style={{ width:"100%" }}>
            {["allied","friendly","neutral","cautious","hostile"].map(a=><option key={a} value={a}>{a}</option>)}
          </Select>
        </>}
        <CrimsonBtn onClick={()=>{if(form.name) onAdd(tab.slice(0,-1),form);}}><Plus size={12}/> Add</CrimsonBtn>
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// PLAY MODE
// ═══════════════════════════════════════════════════════════════════════════

// ─── BATTLEMAP (Canvas-based, Mode-driven, Phase 3 with Terrain & Dice Panel) ───────────────

// ── Dice expression parser ──
function parseDiceExpression(expr) {
  const trimmed = expr.trim().toLowerCase();
  const rolls = [];
  let total = 0;
  let modifier = 0;

  // Split on + or - but keep the sign
  const parts = trimmed.match(/[+-]?[^+-]+/g) || [];

  for (const part of parts) {
    const p = part.trim();

    // Match dice notation: XdY[kh/kl]Z
    const diceMatch = p.match(/^([+-])?(\d+)?d(\d+)(kh|kl)?(\d+)?$/);
    if (diceMatch) {
      const sign = diceMatch[1] === '-' ? -1 : 1;
      const count = parseInt(diceMatch[2] || 1);
      const sides = parseInt(diceMatch[3]);
      const keepOp = diceMatch[4];
      const keepNum = diceMatch[5] ? parseInt(diceMatch[5]) : count;

      const diceRolls = [];
      for (let i = 0; i < count; i++) {
        diceRolls.push(Math.floor(Math.random() * sides) + 1);
      }
      diceRolls.sort((a, b) => b - a);

      let diceTally = 0;
      if (keepOp === 'kh') {
        diceTally = diceRolls.slice(0, keepNum).reduce((a, b) => a + b, 0);
      } else if (keepOp === 'kl') {
        diceTally = diceRolls.slice(-keepNum).reduce((a, b) => a + b, 0);
      } else {
        diceTally = diceRolls.reduce((a, b) => a + b, 0);
      }

      diceTally *= sign;
      total += diceTally;
      rolls.push(...diceRolls.map(r => r * sign));
    } else {
      // Try to parse as modifier
      const num = parseInt(p);
      if (!isNaN(num)) {
        modifier += num;
        total += num;
      }
    }
  }

  return {
    rolls,
    modifier,
    total,
    expression: trimmed,
    details: rolls.length > 0 ? rolls.join(", ") : "no dice"
  };
}

// ── Terrain type definitions ──
const TERRAIN_TYPES = {
  difficult: { color: "rgba(255, 200, 20, 0.45)", label: "Difficult", cost: 2 },
  water: { color: "rgba(50, 160, 255, 0.42)", label: "Water", cost: 2 },
  lava: { color: "rgba(255, 75, 60, 0.45)", label: "Lava", cost: 2 },
  ice: { color: "rgba(185, 200, 215, 0.42)", label: "Ice", cost: 1 },
  pit: { color: "rgba(20, 20, 28, 0.65)", label: "Pit", cost: 999 }
};

// ── Phase 4: Multiplayer & Extensibility constants ──
const SYNC_KEY = 'phmurt-battlemap-sync';
const TEMPLATE_KEY = 'phmurt-encounter-templates';

function debounce(fn, ms) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), ms); };
}

// ── Line-of-sight helpers (outside component for performance) ──
function segmentsIntersect(ax, ay, bx, by, cx, cy, dx, dy) {
  const denom = (bx-ax)*(dy-cy) - (by-ay)*(dx-cx);
  if (Math.abs(denom) < 1e-10) return false;
  const t = ((cx-ax)*(dy-cy) - (cy-ay)*(dx-cx)) / denom;
  const u = ((cx-ax)*(by-ay) - (cy-ay)*(bx-ax)) / denom;
  return t > 0.001 && t < 0.999 && u > 0.001 && u < 0.999;
}

function hasLineOfSight(x1, y1, x2, y2, walls) {
  for (let i = 0; i < walls.length; i++) {
    const w = walls[i];
    if (segmentsIntersect(x1, y1, x2, y2, w.x1, w.y1, w.x2, w.y2)) return false;
  }
  return true;
}

function computeVisibleCells(tokens, walls, gridSize, mapW, mapH) {
  const visible = {};     // "gx,gy" -> "full" | "dim"
  const visionTokens = tokens.filter(t => t.vision > 0);
  if (visionTokens.length === 0) return null; // null = no vision system active
  const maxGX = Math.ceil(mapW / gridSize);
  const maxGY = Math.ceil(mapH / gridSize);
  for (const t of visionTokens) {
    const visionPx = t.vision * gridSize;
    const darkPx = (t.darkvision || 0) * gridSize;
    const maxR = Math.max(visionPx, darkPx);
    const startGX = Math.max(0, Math.floor((t.x - maxR) / gridSize));
    const startGY = Math.max(0, Math.floor((t.y - maxR) / gridSize));
    const endGX = Math.min(maxGX, Math.ceil((t.x + maxR) / gridSize));
    const endGY = Math.min(maxGY, Math.ceil((t.y + maxR) / gridSize));
    for (let gx = startGX; gx < endGX; gx++) {
      for (let gy = startGY; gy < endGY; gy++) {
        const key = gx + "," + gy;
        if (visible[key] === "full") continue;
        const cx = gx * gridSize + gridSize / 2;
        const cy = gy * gridSize + gridSize / 2;
        const dist = Math.hypot(cx - t.x, cy - t.y);
        if (dist > maxR) continue;
        if (!hasLineOfSight(t.x, t.y, cx, cy, walls)) continue;
        if (dist <= visionPx) {
          visible[key] = "full";
        } else if (dist <= darkPx && visible[key] !== "full") {
          visible[key] = "dim";
        }
      }
    }
  }
  return visible;
}

function Battlemap({ party, npcs, viewRole = "dm" }) {
  const canvasRef = useRef(null);
  const wrapRef = useRef(null);
  const fileRef = useRef(null);

  // ── Core map state ──
  const [gridSize, setGridSize] = useState(40);
  const [showGrid, setShowGrid] = useState(true);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({x:0,y:0});
  const [bgColor, setBgColor] = useState("#10101e");
  const [bgImage, setBgImage] = useState(null);
  const [tokens, setTokens] = useState([]);
  const [drawings, setDrawings] = useState([]);
  const [fogCells, setFogCells] = useState({});
  const [drawColor, setDrawColor] = useState("#dc143c");
  const [drawWidth, setDrawWidth] = useState(3);

  // ── Walls ──
  const [walls, setWalls] = useState([]);
  const [wallStart, setWallStart] = useState(null);
  const [wallPreview, setWallPreview] = useState(null);

  // ── Terrain system ──
  const [terrainCells, setTerrainCells] = useState({});
  const [selectedTerrain, setSelectedTerrain] = useState("difficult");

  // ── Interaction state ──
  const [dragState, setDragState] = useState(null);
  const [drawPoints, setDrawPoints] = useState([]);
  const [rulerStart, setRulerStart] = useState(null);
  const [rulerEnd, setRulerEnd] = useState(null);

  // ── Mode system ──
  const [mode, setMode] = useState("select"); // "select" | "draw" | "combat"
  const [drawTool, setDrawTool] = useState("draw"); // "draw" | "fog" | "wall" | "terrain" | "ruler" | "eraser"
  const [selectedTokenId, setSelectedTokenId] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);

  // ── Combat state ──
  const [combatants, setCombatants] = useState([]);
  const [turn, setTurn] = useState(0);
  const [round, setRound] = useState(1);
  const [combatLive, setCombatLive] = useState(false);
  const [conditions, setConditions] = useState({});
  const [addName, setAddName] = useState("");
  const [addInit, setAddInit] = useState("");
  const [addHp, setAddHp] = useState("");
  const [addAc, setAddAc] = useState("");

  // ── Movement system ──
  const [movementMode, setMovementMode] = useState(false);
  const [movementPath, setMovementPath] = useState([]);
  const [movementOrigin, setMovementOrigin] = useState(null);

  // ── Fog mode ──
  const [fogMode, setFogMode] = useState("manual"); // "manual" | "vision"

  // ── Dice roll display ──
  const [diceResult, setDiceResult] = useState(null);

  // ── Dice panel state ──
  const [showDicePanel, setShowDicePanel] = useState(false);
  const [diceInput, setDiceInput] = useState("");
  const [rollHistory, setRollHistory] = useState([]);

  // ── Phase 4: Multiplayer & Extensibility ──
  const [pings, setPings] = useState([]);
  const [pingMode, setPingMode] = useState(false);
  const [templates, setTemplates] = useState(() => {
    try { return JSON.parse(localStorage.getItem(TEMPLATE_KEY) || '[]'); } catch { return []; }
  });
  const [templateName, setTemplateName] = useState("");
  const [showTemplateInput, setShowTemplateInput] = useState(false);

  // ── Animation ──
  const animRef = useRef(0);

  const selectedToken = tokens.find(t => t.id === selectedTokenId);
  const activeCombatantId = combatLive && combatants[turn] ? combatants[turn].mapTokenId : null;

  const worldToCanvas = (wx, wy) => ({ x: wx * zoom + pan.x, y: wy * zoom + pan.y });
  const canvasToWorld = (cx, cy) => ({ x: (cx - pan.x) / zoom, y: (cy - pan.y) / zoom });

  const activeTool = mode === "draw" ? drawTool : "select";

  // ── Snap to nearest grid intersection (for walls) ──
  const snapToGridIntersection = (wx, wy) => ({
    x: Math.round(wx / gridSize) * gridSize,
    y: Math.round(wy / gridSize) * gridSize,
  });

  // ── Snap to grid center (for tokens) ──
  const snapToGridCenter = (wx, wy) => ({
    x: Math.floor(wx / gridSize) * gridSize + gridSize / 2,
    y: Math.floor(wy / gridSize) * gridSize + gridSize / 2,
  });

  // ── Canvas rendering ──
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    ctx.fillStyle = bgColor;
    ctx.fillRect(0, 0, w, h);

    ctx.save();
    ctx.translate(pan.x, pan.y);
    ctx.scale(zoom, zoom);

    if (bgImage) ctx.drawImage(bgImage, 0, 0);

    const mapW = bgImage ? bgImage.width : w / zoom;
    const mapH = bgImage ? bgImage.height : h / zoom;

    // Grid
    if (showGrid) {
      ctx.strokeStyle = "rgba(212,67,58,0.15)";
      ctx.lineWidth = 0.5;
      for (let x = 0; x <= mapW; x += gridSize) {
        ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, mapH); ctx.stroke();
      }
      for (let y = 0; y <= mapH; y += gridSize) {
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(mapW, y); ctx.stroke();
      }
    }

    // Terrain cells (after grid, before drawings)
    Object.entries(terrainCells).forEach(([key, terrainType]) => {
      if (!terrainType) return;
      const [gx, gy] = key.split(",").map(Number);
      const terrain = TERRAIN_TYPES[terrainType];
      if (!terrain) return;

      ctx.fillStyle = terrain.color;
      ctx.fillRect(gx * gridSize, gy * gridSize, gridSize, gridSize);

      // Terrain label
      ctx.fillStyle = "rgba(255, 255, 255, 0.4)";
      ctx.font = "6px Cinzel";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const label = terrain.label.substring(0, 1);
      ctx.fillText(label, gx * gridSize + gridSize / 2, gy * gridSize + gridSize / 2);
    });

    // Drawings
    drawings.forEach(d => {
      if (d.points.length < 2) return;
      ctx.strokeStyle = d.color;
      ctx.lineWidth = d.width;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.beginPath();
      ctx.moveTo(d.points[0].x, d.points[0].y);
      d.points.slice(1).forEach(p => ctx.lineTo(p.x, p.y));
      ctx.stroke();
    });

    // Walls
    ctx.strokeStyle = "#b574ff";
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    walls.forEach(wall => {
      ctx.beginPath();
      ctx.moveTo(wall.x1, wall.y1);
      ctx.lineTo(wall.x2, wall.y2);
      ctx.stroke();
    });
    // Wall preview
    if (wallStart && wallPreview) {
      ctx.strokeStyle = "rgba(181,116,255,0.5)";
      ctx.lineWidth = 3;
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      ctx.moveTo(wallStart.x, wallStart.y);
      ctx.lineTo(wallPreview.x, wallPreview.y);
      ctx.stroke();
      ctx.setLineDash([]);
      // Draw intersection dots
      ctx.fillStyle = "#b574ff";
      ctx.beginPath();
      ctx.arc(wallStart.x, wallStart.y, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.beginPath();
      ctx.arc(wallPreview.x, wallPreview.y, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Fog of war
    if (fogMode === "manual") {
      Object.entries(fogCells).forEach(([key, val]) => {
        if (!val) return;
        const [gx, gy] = key.split(",").map(Number);
        ctx.fillStyle = "rgba(4,4,10,0.88)";
        ctx.fillRect(gx * gridSize, gy * gridSize, gridSize, gridSize);
      });
    } else if (fogMode === "vision") {
      const visibleCells = computeVisibleCells(tokens, walls, gridSize, mapW, mapH);
      if (visibleCells) {
        const maxGX = Math.ceil(mapW / gridSize);
        const maxGY = Math.ceil(mapH / gridSize);
        for (let gx = 0; gx < maxGX; gx++) {
          for (let gy = 0; gy < maxGY; gy++) {
            const key = gx + "," + gy;
            const vis = visibleCells[key];
            // Also check manual reveals
            if (fogCells[key] === false) continue; // manually revealed
            if (vis === "full") continue;
            if (vis === "dim") {
              ctx.fillStyle = "rgba(4,4,10,0.50)";
            } else {
              ctx.fillStyle = "rgba(4,4,10,0.88)";
            }
            ctx.fillRect(gx * gridSize, gy * gridSize, gridSize, gridSize);
          }
        }
      }
    }

    // Movement overlay
    if (movementMode && selectedToken && selectedToken.speed) {
      const speedCells = Math.floor((selectedToken.speed || 30) / 5);
      const usedCells = movementPath.length;
      const remaining = speedCells - usedCells;
      const origin = movementOrigin || { x: selectedToken.x, y: selectedToken.y };
      const originGX = Math.floor(origin.x / gridSize);
      const originGY = Math.floor(origin.y / gridSize);

      // Show reachable range
      for (let dx = -speedCells; dx <= speedCells; dx++) {
        for (let dy = -speedCells; dy <= speedCells; dy++) {
          const dist = Math.abs(dx) + Math.abs(dy); // Manhattan distance
          if (dist > remaining) continue;
          const gx = originGX + dx;
          const gy = originGY + dy;
          if (gx < 0 || gy < 0) continue;
          ctx.fillStyle = dist <= remaining
            ? "rgba(46,139,87,0.15)"
            : "rgba(232,148,10,0.10)";
          ctx.fillRect(gx * gridSize, gy * gridSize, gridSize, gridSize);
        }
      }

      // Draw movement path
      if (movementPath.length > 0) {
        ctx.strokeStyle = "rgba(46,139,87,0.6)";
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 3]);
        ctx.beginPath();
        ctx.moveTo(origin.x, origin.y);
        movementPath.forEach(p => {
          ctx.lineTo(p.x * gridSize + gridSize / 2, p.y * gridSize + gridSize / 2);
        });
        ctx.stroke();
        ctx.setLineDash([]);
      }
    }

    // Tokens
    const now = Date.now();
    tokens.forEach(t => {
      // Skip hidden tokens in player view
      if (t.hidden && viewRole === "player") return;

      const r = gridSize * 0.4;
      const isSelected = t.id === selectedTokenId;
      const isActiveCombatant = t.id === activeCombatantId;

      // Vision radius indicator (only for selected token in select mode)
      if (isSelected && fogMode === "vision" && t.vision > 0) {
        const vr = t.vision * gridSize;
        ctx.beginPath();
        ctx.arc(t.x, t.y, vr, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(110,160,250,0.2)";
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);
        ctx.stroke();
        ctx.setLineDash([]);
        if (t.darkvision && t.darkvision > t.vision) {
          ctx.beginPath();
          ctx.arc(t.x, t.y, t.darkvision * gridSize, 0, Math.PI * 2);
          ctx.strokeStyle = "rgba(165,120,255,0.15)";
          ctx.stroke();
        }
      }

      // Active combatant glow (pulsing)
      if (isActiveCombatant && combatLive) {
        const pulse = 0.5 + 0.5 * Math.sin(now / 400);
        ctx.beginPath();
        ctx.arc(t.x, t.y, r + 6, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(220, 20, 60, " + (0.3 + 0.4 * pulse) + ")";
        ctx.lineWidth = 3;
        ctx.stroke();
      }

      // Selection ring
      if (isSelected) {
        ctx.beginPath();
        ctx.arc(t.x, t.y, r + 4, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(255, 215, 0, 0.8)";
        ctx.lineWidth = 2;
        ctx.setLineDash([4, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
      }

      // Hidden token opacity for DM view (affects circle, label, and HP bar)
      if (t.hidden && viewRole === "dm") {
        ctx.globalAlpha = 0.4;
      }

      // Token circle
      ctx.beginPath();
      ctx.arc(t.x, t.y, r, 0, Math.PI * 2);
      ctx.fillStyle = t.color;
      ctx.fill();
      ctx.strokeStyle = isSelected ? "rgba(255,220,30,0.9)" : "rgba(0,0,6,0.50)";
      ctx.lineWidth = isSelected ? 2.5 : 2;
      ctx.stroke();

      // Label
      ctx.fillStyle = "#fff";
      ctx.font = "bold " + Math.max(9, gridSize * 0.22) + "px Cinzel";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      const label = t.name.length > 3 ? t.name.substring(0,3) : t.name;
      ctx.fillText(label, t.x, t.y);

      ctx.globalAlpha = 1;

      // HP bar
      if (t.hp != null && t.maxHp) {
        const barW = gridSize * 0.7, barH = 4;
        const barX = t.x - barW/2, barY = t.y + r + 4;
        ctx.fillStyle = "rgba(0,0,0,0.6)";
        ctx.fillRect(barX, barY, barW, barH);
        ctx.fillStyle = t.hp < t.maxHp * 0.3 ? "#d4433a" : t.hp < t.maxHp * 0.6 ? "#e8940a" : "#2e8b57";
        ctx.fillRect(barX, barY, barW * Math.max(0, t.hp / t.maxHp), barH);
      }

      // Hidden indicator (DM only)
      if (t.hidden && viewRole === "dm") {
        ctx.beginPath();
        ctx.arc(t.x, t.y, r + 6, 0, Math.PI * 2);
        ctx.strokeStyle = "rgba(255,255,255,0.3)";
        ctx.lineWidth = 1;
        ctx.setLineDash([3, 3]);
        ctx.stroke();
        ctx.setLineDash([]);
      }
    });

    ctx.restore();

    // Pings (screen space)
    const nowPing = Date.now();
    const activePings = pings.filter(p => nowPing - p.time < 3000);
    if (activePings.length !== pings.length) {
      // Clean up expired pings on next frame
      setTimeout(() => setPings(prev => prev.filter(p => Date.now() - p.time < 3000)), 0);
    }
    activePings.forEach(p => {
      const sp = worldToCanvas(p.x, p.y);
      const age = (nowPing - p.time) / 3000;
      const alpha = 1 - age;
      for (let ring = 0; ring < 3; ring++) {
        const r = 8 + ring * 12 + age * 20;
        const ringAlpha = alpha * (1 - ring * 0.3);
        if (ringAlpha <= 0) continue;
        ctx.beginPath();
        ctx.arc(sp.x, sp.y, r, 0, Math.PI * 2);
        ctx.strokeStyle = p.color.replace(")", "," + ringAlpha + ")").replace("rgb(", "rgba(");
        // Handle hex colors
        if (p.color.startsWith("#")) {
          const hex = p.color;
          const r2 = parseInt(hex.slice(1,3), 16), g = parseInt(hex.slice(3,5), 16), b = parseInt(hex.slice(5,7), 16);
          ctx.strokeStyle = "rgba(" + r2 + "," + g + "," + b + "," + ringAlpha + ")";
        }
        ctx.lineWidth = 2;
        ctx.stroke();
      }
      // Center dot
      ctx.beginPath();
      ctx.arc(sp.x, sp.y, 4, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.globalAlpha = alpha;
      ctx.fill();
      ctx.globalAlpha = 1;
    });

    // Ruler overlay (screen space)
    if (activeTool === "ruler" && rulerStart && rulerEnd) {
      const rulerColor = cssVar("--crimson");
      ctx.strokeStyle = rulerColor;
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 4]);
      ctx.beginPath();
      const s = worldToCanvas(rulerStart.x, rulerStart.y);
      const e = worldToCanvas(rulerEnd.x, rulerEnd.y);
      ctx.moveTo(s.x, s.y);
      ctx.lineTo(e.x, e.y);
      ctx.stroke();
      ctx.setLineDash([]);
      const dist = Math.sqrt((rulerEnd.x - rulerStart.x)**2 + (rulerEnd.y - rulerStart.y)**2);
      const ft = Math.round(dist / gridSize * 5);
      ctx.fillStyle = rulerColor;
      ctx.font = "bold 12px Cinzel";
      ctx.fillText(ft + " ft", (s.x + e.x)/2, (s.y + e.y)/2 - 8);
    }

    // Movement mode HUD (screen space)
    if (movementMode && selectedToken) {
      const speedCells = Math.floor((selectedToken.speed || 30) / 5);
      const used = movementPath.length;
      const remaining = speedCells - used;
      ctx.fillStyle = "rgba(0,0,6,0.70)";
      ctx.fillRect(w/2 - 80, 8, 160, 28);
      ctx.strokeStyle = "rgba(46,139,87,0.6)";
      ctx.lineWidth = 1;
      ctx.strokeRect(w/2 - 80, 8, 160, 28);
      ctx.fillStyle = remaining > 0 ? "#5ee09a" : "#f06858";
      ctx.font = "bold 11px Cinzel";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("Move: " + (used * 5) + "/" + (speedCells * 5) + " ft  (" + (remaining * 5) + " left)", w/2, 22);
    }
  }, [bgColor, bgImage, showGrid, gridSize, zoom, pan, drawings, fogCells, tokens, walls, wallStart, wallPreview, activeTool, rulerStart, rulerEnd, selectedTokenId, activeCombatantId, combatLive, fogMode, movementMode, movementPath, movementOrigin, terrainCells, pings, viewRole]);

  // Animation loop for combat glow and pings
  useEffect(() => {
    if (!combatLive && pings.length === 0) return;
    let running = true;
    const animate = () => {
      if (!running) return;
      render();
      animRef.current = requestAnimationFrame(animate);
    };
    animate();
    return () => { running = false; cancelAnimationFrame(animRef.current); };
  }, [combatLive, pings.length, render]);

  useEffect(() => { if (!combatLive && pings.length === 0) render(); }, [render, combatLive, pings]);

  useEffect(() => {
    const resize = () => {
      const canvas = canvasRef.current;
      const wrap = wrapRef.current;
      if (!canvas || !wrap) return;
      canvas.width = wrap.clientWidth;
      canvas.height = wrap.clientHeight;
      render();
    };
    resize();
    window.addEventListener("resize", resize);
    return () => window.removeEventListener("resize", resize);
  }, [render]);

  // ── DM: Broadcast state changes ──
  const syncTimerRef = useRef(null);
  useEffect(() => {
    if (viewRole !== "dm") return;
    clearTimeout(syncTimerRef.current);
    syncTimerRef.current = setTimeout(() => {
      const state = {
        tokens, drawings, fogCells, walls, terrainCells, bgColor, gridSize, showGrid,
        combatLive, combatants, turn, round, conditions, fogMode, pings,
      };
      // Merge in any player pings
      try {
        const existing = JSON.parse(localStorage.getItem(SYNC_KEY) || '{}');
        if (existing.playerPings) {
          const fresh = existing.playerPings.filter(pp => Date.now() - pp.time < 3000);
          if (fresh.length > 0) {
            const myPingIds = new Set(pings.map(p => p.id));
            const newPlayerPings = fresh.filter(pp => !myPingIds.has(pp.id));
            if (newPlayerPings.length > 0) {
              state.pings = [...pings, ...newPlayerPings];
            }
          }
        }
      } catch {}
      localStorage.setItem(SYNC_KEY, JSON.stringify(state));
    }, 150);
    return () => clearTimeout(syncTimerRef.current);
  }, [tokens, drawings, fogCells, walls, terrainCells, bgColor, gridSize, showGrid, combatLive, combatants, turn, round, conditions, fogMode, pings, viewRole]);

  // ── Player: Read state changes ──
  useEffect(() => {
    if (viewRole !== "player") return;
    const interval = setInterval(() => {
      try {
        const raw = localStorage.getItem(SYNC_KEY);
        if (!raw) return;
        const state = JSON.parse(raw);
        if (state.tokens) setTokens(state.tokens);
        if (state.drawings) setDrawings(state.drawings);
        if (state.fogCells) setFogCells(state.fogCells);
        if (state.walls) setWalls(state.walls);
        if (state.terrainCells) setTerrainCells(state.terrainCells);
        if (state.bgColor) setBgColor(state.bgColor);
        if (state.gridSize) setGridSize(state.gridSize);
        if (state.showGrid !== undefined) setShowGrid(state.showGrid);
        if (state.combatLive !== undefined) setCombatLive(state.combatLive);
        if (state.combatants) setCombatants(state.combatants);
        if (state.turn !== undefined) setTurn(state.turn);
        if (state.round !== undefined) setRound(state.round);
        if (state.conditions) setConditions(state.conditions);
        if (state.fogMode) setFogMode(state.fogMode);
        if (state.pings) setPings(state.pings.filter(p => Date.now() - p.time < 3000));
      } catch {}
    }, 250);
    return () => clearInterval(interval);
  }, [viewRole]);

  // ── Player: Write pings back ──
  useEffect(() => {
    if (viewRole !== "player" || pings.length === 0) return;
    try {
      const raw = localStorage.getItem(SYNC_KEY);
      if (raw) {
        const state = JSON.parse(raw);
        state.playerPings = pings.filter(p => p.source === "player");
        localStorage.setItem(SYNC_KEY, JSON.stringify(state));
      }
    } catch {}
  }, [pings, viewRole]);

  // ── Keyboard handler ──
  useEffect(() => {
    const handleKey = (e) => {
      // Don't trigger shortcuts when typing in input fields
      const tag = e.target.tagName.toLowerCase();
      if (tag === "input" || tag === "textarea" || tag === "select") return;

      if (e.key === "p" || e.key === "P") {
        setPingMode(prev => !prev);
      }
      if (e.key === "m" || e.key === "M") {
        if (selectedToken) {
          if (!movementMode) {
            setMovementMode(true);
            setMovementPath([]);
            setMovementOrigin({ x: selectedToken.x, y: selectedToken.y });
          } else {
            setMovementMode(false);
            setMovementPath([]);
            setMovementOrigin(null);
          }
        }
      }
      if (e.key === "Escape") {
        setPingMode(false);
        setMovementMode(false);
        setMovementPath([]);
        setMovementOrigin(null);
        setContextMenu(null);
        setWallStart(null);
        setWallPreview(null);
        if (movementMode && selectedToken && movementOrigin) {
          // Cancel movement — return token to origin
          setTokens(p => p.map(t => t.id === selectedTokenId ? {...t, x: movementOrigin.x, y: movementOrigin.y} : t));
        }
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [selectedToken, movementMode, movementOrigin, selectedTokenId]);

  const getMouseWorld = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const cx = e.clientX - rect.left, cy = e.clientY - rect.top;
    return canvasToWorld(cx, cy);
  };

  // ── Mouse handlers ──
  const handleMouseDown = (e) => {
    if (e.button === 2) return;
    setContextMenu(null);
    const w = getMouseWorld(e);

    // Pings work for both DM and player
    if (pingMode) {
      const id = "ping-" + Date.now();
      const newPing = { id, x: w.x, y: w.y, color: viewRole === "dm" ? "#d4433a" : "#58aaff", time: Date.now(), source: viewRole };
      setPings(prev => [...prev, newPing]);
      setPingMode(false);
      return;
    }

    if (activeTool === "wall") {
      const snap = snapToGridIntersection(w.x, w.y);
      if (!wallStart) {
        setWallStart(snap);
      } else {
        if (snap.x !== wallStart.x || snap.y !== wallStart.y) {
          setWalls(p => [...p, { x1:wallStart.x, y1:wallStart.y, x2:snap.x, y2:snap.y }]);
        }
        setWallStart(null);
        setWallPreview(null);
      }
      return;
    }

    if (activeTool === "terrain") {
      const gx = Math.floor(w.x/gridSize), gy = Math.floor(w.y/gridSize);
      const key = gx + "," + gy;
      setTerrainCells(p => ({...p, [key]: selectedTerrain}));
      setDragState({ type:"terrain", adding: selectedTerrain });
      return;
    }

    if (activeTool === "select") {
      const hit = [...tokens].reverse().find(t => Math.hypot(t.x - w.x, t.y - w.y) < gridSize * 0.4);
      if (hit) {
        setSelectedTokenId(hit.id);
        if (movementMode && hit.id === selectedTokenId) {
          // In movement mode, clicking the selected token starts a move drag
          setDragState({ type:"token-move", id:hit.id, offsetX:w.x-hit.x, offsetY:w.y-hit.y });
        } else {
          setMovementMode(false);
          setMovementPath([]);
          setDragState({ type:"token", id:hit.id, offsetX:w.x-hit.x, offsetY:w.y-hit.y });
        }
      } else {
        setSelectedTokenId(null);
        setMovementMode(false);
        setMovementPath([]);
        setDragState({ type:"pan", startX:e.clientX, startY:e.clientY, panX:pan.x, panY:pan.y });
      }
    } else if (activeTool === "draw") {
      setDrawPoints([{ x:w.x, y:w.y }]);
    } else if (activeTool === "fog") {
      const gx = Math.floor(w.x/gridSize), gy = Math.floor(w.y/gridSize);
      const key = gx + "," + gy;
      if (fogMode === "vision") {
        // In vision mode, fog tool manually reveals/hides
        setFogCells(p => ({...p, [key]: p[key] === false ? undefined : false}));
      } else {
        setFogCells(p => ({...p, [key]: !p[key]}));
      }
      setDragState({ type:"fog", adding: fogMode === "vision" ? false : !fogCells[gx + "," + gy] });
    } else if (activeTool === "ruler") {
      setRulerStart(w);
      setRulerEnd(w);
    } else if (activeTool === "eraser") {
      // Eraser: delete tokens, walls, terrain, or drawings near click
      const hitToken = [...tokens].reverse().find(t => Math.hypot(t.x - w.x, t.y - w.y) < gridSize * 0.4);
      if (hitToken) {
        setTokens(p => p.filter(t => t.id !== hitToken.id));
        return;
      }
      // Check walls
      const hitWall = walls.findIndex(wall => {
        const dist = distToSegment(w.x, w.y, wall.x1, wall.y1, wall.x2, wall.y2);
        return dist < 8;
      });
      if (hitWall >= 0) {
        setWalls(p => p.filter((_, i) => i !== hitWall));
        return;
      }
      // Check terrain
      const tgx = Math.floor(w.x / gridSize), tgy = Math.floor(w.y / gridSize);
      const terrainKey = tgx + "," + tgy;
      if (terrainCells[terrainKey]) {
        setTerrainCells(p => { const n = {...p}; delete n[terrainKey]; return n; });
        return;
      }
      // Check drawings (find nearest drawing within threshold)
      const hitDrawing = drawings.findIndex(d => {
        return d.points.some(pt => Math.hypot(pt.x - w.x, pt.y - w.y) < 12);
      });
      if (hitDrawing >= 0) {
        setDrawings(p => p.filter((_, i) => i !== hitDrawing));
      }
    }
  };

  const handleMouseMove = (e) => {
    const w = getMouseWorld(e);

    // Wall preview
    if (activeTool === "wall" && wallStart) {
      setWallPreview(snapToGridIntersection(w.x, w.y));
      return;
    }

    if (!dragState && activeTool !== "draw" && activeTool !== "ruler" && activeTool !== "terrain") return;

    if (dragState?.type === "token" || dragState?.type === "token-move") {
      const newX = w.x - dragState.offsetX;
      const newY = w.y - dragState.offsetY;
      setTokens(p => p.map(t => t.id === dragState.id ? {...t, x:newX, y:newY} : t));

      // Track movement path in grid cells
      if (movementMode && dragState.type === "token-move") {
        const gx = Math.floor(newX / gridSize);
        const gy = Math.floor(newY / gridSize);
        setMovementPath(prev => {
          const last = prev[prev.length - 1];
          if (last && last.x === gx && last.y === gy) return prev;
          if (prev.length === 0) {
            const ogx = movementOrigin ? Math.floor(movementOrigin.x / gridSize) : gx;
            const ogy = movementOrigin ? Math.floor(movementOrigin.y / gridSize) : gy;
            if (gx === ogx && gy === ogy) return prev;
          }
          return [...prev, { x: gx, y: gy }];
        });
      }
    } else if (dragState?.type === "pan") {
      setPan({ x:dragState.panX + (e.clientX - dragState.startX), y:dragState.panY + (e.clientY - dragState.startY) });
    } else if (activeTool === "draw" && drawPoints.length > 0) {
      setDrawPoints(p => [...p, { x:w.x, y:w.y }]);
    } else if (dragState?.type === "fog") {
      const gx = Math.floor(w.x/gridSize), gy = Math.floor(w.y/gridSize);
      if (fogMode === "vision") {
        setFogCells(p => ({...p, [gx + "," + gy]: dragState.adding}));
      } else {
        setFogCells(p => ({...p, [gx + "," + gy]: dragState.adding}));
      }
    } else if (dragState?.type === "terrain") {
      const gx = Math.floor(w.x/gridSize), gy = Math.floor(w.y/gridSize);
      const key = gx + "," + gy;
      setTerrainCells(p => ({...p, [key]: dragState.adding}));
    } else if (activeTool === "ruler" && rulerStart) {
      setRulerEnd(w);
    }
  };

  const handleMouseUp = () => {
    if (activeTool === "draw" && drawPoints.length > 1) {
      setDrawings(p => [...p, { points:drawPoints, color:drawColor, width:drawWidth }]);
    }
    if (dragState?.type === "token" || dragState?.type === "token-move") {
      setTokens(p => p.map(t => {
        if (t.id !== dragState.id) return t;
        return { ...t, x: Math.floor(t.x / gridSize) * gridSize + gridSize / 2, y: Math.floor(t.y / gridSize) * gridSize + gridSize / 2 };
      }));
    }
    setDrawPoints([]);
    setDragState(null);
    if (activeTool === "ruler") { setRulerStart(null); setRulerEnd(null); }
  };

  const handleContextMenu = (e) => {
    e.preventDefault();
    const w = getMouseWorld(e);
    const hit = [...tokens].reverse().find(t => Math.hypot(t.x - w.x, t.y - w.y) < gridSize * 0.4);
    if (hit) {
      const rect = canvasRef.current.getBoundingClientRect();
      setContextMenu({ x: e.clientX - rect.left, y: e.clientY - rect.top, tokenId: hit.id });
      setSelectedTokenId(hit.id);
    }
  };

  const handleWheel = (e) => {
    e.preventDefault();
    if (selectedToken && selectedToken.hp != null && (mode === "select" || mode === "combat")) {
      const w = getMouseWorld(e);
      const isOverToken = Math.hypot(selectedToken.x - w.x, selectedToken.y - w.y) < gridSize * 0.4;
      if (isOverToken) {
        const delta = e.deltaY < 0 ? 1 : -1;
        setTokens(p => p.map(t => t.id === selectedTokenId ? {...t, hp: Math.max(0, Math.min(t.maxHp, t.hp + delta))} : t));
        return;
      }
    }
    const delta = e.deltaY > 0 ? -0.1 : 0.1;
    setZoom(z => Math.max(0.25, Math.min(4, z + delta)));
  };

  const handleMapUpload = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const img = new Image();
    img.onload = () => setBgImage(img);
    img.src = URL.createObjectURL(file);
  };

  const addToken = (name, color, hp, maxHp) => {
    const cx = (canvasRef.current?.width / 2 - pan.x) / zoom;
    const cy = (canvasRef.current?.height / 2 - pan.y) / zoom;
    const snap = snapToGridCenter(cx, cy);
    const id = "tk-" + Date.now() + "-" + Math.random();
    setTokens(p => [...p, { id, name, color, hp, maxHp, x:snap.x, y:snap.y, vision:0, darkvision:0, speed:30, hidden:false }]);
    setSelectedTokenId(id);
  };

  // ── Drag & Drop from sidebar ──
  const handleDragOver = (e) => { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; };
  const handleDrop = (e) => {
    e.preventDefault();
    const data = e.dataTransfer.getData("application/token");
    if (!data) return;
    const parsed = JSON.parse(data);
    const rect = canvasRef.current.getBoundingClientRect();
    const cx = e.clientX - rect.left, cy = e.clientY - rect.top;
    const w = canvasToWorld(cx, cy);
    const snap = snapToGridCenter(w.x, w.y);
    const id = "tk-" + Date.now() + "-" + Math.random();
    setTokens(p => [...p, { id, name:parsed.name, color:parsed.color, hp:parsed.hp, maxHp:parsed.maxHp, x:snap.x, y:snap.y, vision:0, darkvision:0, speed:30, hidden:false }]);
    setSelectedTokenId(id);
  };

  // ── Token actions ──
  const adjustTokenHp = (id, delta) => {
    setTokens(p => p.map(t => t.id === id ? {...t, hp: Math.max(0, Math.min(t.maxHp, t.hp + delta))} : t));
  };
  const removeToken = (id) => {
    setTokens(p => p.filter(t => t.id !== id));
    if (selectedTokenId === id) setSelectedTokenId(null);
  };
  const updateToken = (id, updates) => {
    setTokens(p => p.map(t => t.id === id ? {...t, ...updates} : t));
  };

  // ── Dice rolling ──
  const rollD20 = () => {
    const result = Math.floor(Math.random() * 20) + 1;
    setDiceResult({ value: result, type: "d20", time: Date.now() });
    setRollHistory(h => [{ expr: "1d20", result, rolls: [result], modifier: 0, time: Date.now() }, ...h.slice(0, 19)]);
    setTimeout(() => setDiceResult(null), 3000);
    return result;
  };

  const rollAttack = (tokenId) => {
    const result = Math.floor(Math.random() * 20) + 1;
    const tk = tokens.find(t => t.id === tokenId);
    const name = tk?.name || "Token";
    setDiceResult({ value: result, type: "attack", name, time: Date.now(), crit: result === 20, fumble: result === 1 });
    setRollHistory(h => [{ expr: "1d20 (attack)", result, rolls: [result], modifier: 0, who: name, time: Date.now() }, ...h.slice(0, 19)]);
    setTimeout(() => setDiceResult(null), 4000);
  };

  const rollDiceExpression = (expr) => {
    if (!expr.trim()) return;
    const parsed = parseDiceExpression(expr);
    setRollHistory(h => [{ expr: parsed.expression, result: parsed.total, rolls: parsed.rolls, modifier: parsed.modifier, time: Date.now() }, ...h.slice(0, 19)]);
    setDiceInput("");
  };

  // ── Combat functions ──
  const conditionsList = ["Blinded","Charmed","Deafened","Frightened","Grappled","Incapacitated","Invisible","Paralyzed","Petrified","Poisoned","Prone","Restrained","Stunned","Unconscious","Concentrating"];

  const startCombat = () => {
    setMode("combat");
    const combs = tokens.map(t => ({
      id: "cb-" + t.id,
      mapTokenId: t.id,
      name: t.name,
      init: Math.floor(Math.random() * 20) + 1,
      hp: t.hp || 30,
      maxHp: t.maxHp || 30,
      ac: 12,
      type: t.color === "#2e8b57" ? "pc" : "enemy",
    })).sort((a, b) => b.init - a.init);
    setCombatants(combs);
    setTurn(0);
    setRound(1);
    setCombatLive(true);
    setConditions({});
    if (combs.length > 0) setSelectedTokenId(combs[0].mapTokenId);
  };

  const endCombat = () => {
    setCombatLive(false);
    setCombatants([]);
    setConditions({});
    setMode("select");
  };

  const nextTurn = () => {
    let nextIdx = turn + 1;
    while (nextIdx < combatants.length && combatants[nextIdx].hp <= 0) nextIdx++;
    if (nextIdx >= combatants.length) {
      setRound(r => r + 1);
      let first = 0;
      while (first < combatants.length && combatants[first].hp <= 0) first++;
      setTurn(first);
      if (combatants[first]) setSelectedTokenId(combatants[first].mapTokenId);
    } else {
      setTurn(nextIdx);
      if (combatants[nextIdx]) setSelectedTokenId(combatants[nextIdx].mapTokenId);
    }
  };

  const prevTurn = () => {
    if (turn === 0 && round === 1) return;
    let prevIdx = turn - 1;
    if (prevIdx < 0) { setRound(r => Math.max(1, r - 1)); prevIdx = combatants.length - 1; }
    while (prevIdx >= 0 && combatants[prevIdx].hp <= 0) prevIdx--;
    if (prevIdx >= 0) {
      setTurn(prevIdx);
      if (combatants[prevIdx]) setSelectedTokenId(combatants[prevIdx].mapTokenId);
    }
  };

  const adjCombatantHp = (id, d) => {
    setCombatants(p => p.map(c => c.id === id ? {...c, hp: Math.max(0, Math.min(c.maxHp, c.hp + d))} : c));
    const combatant = combatants.find(c => c.id === id);
    if (combatant) {
      setTokens(p => p.map(t => t.id === combatant.mapTokenId ? {...t, hp: Math.max(0, Math.min(t.maxHp, t.hp + d))} : t));
    }
  };

  const addCondition = (id, cond) => { if(!cond) return; setConditions(p => ({...p, [id]: [...(p[id]||[]), cond]})); };
  const removeCondition = (id, idx) => { setConditions(p => ({...p, [id]: (p[id]||[]).filter((_,i) => i !== idx)})); };
  const removeCombatant = (id) => {
    setCombatants(p => p.filter(c => c.id !== id));
    if (turn >= combatants.length - 1) setTurn(t => Math.max(0, t - 1));
  };

  const addCombatantToEncounter = () => {
    if (!addName.trim() || !addInit) return;
    const tokenId = "tk-" + Date.now() + "-" + Math.random();
    const cx = (canvasRef.current?.width / 2 - pan.x) / zoom;
    const cy = (canvasRef.current?.height / 2 - pan.y) / zoom;
    const snap = snapToGridCenter(cx, cy);
    const hpNum = parseInt(addHp) || 30;
    setTokens(p => [...p, { id: tokenId, name: addName, color: cssVar("--crimson"), hp: hpNum, maxHp: hpNum, x: snap.x, y: snap.y, vision:0, darkvision:0, speed:30, hidden:false }]);
    const newC = { id: "cb-" + Date.now(), mapTokenId: tokenId, name: addName, init: parseInt(addInit), hp: hpNum, maxHp: hpNum, ac: parseInt(addAc) || 12, type: "enemy" };
    setCombatants(p => [...p, newC].sort((a, b) => b.init - a.init));
    setAddName(""); setAddInit(""); setAddHp(""); setAddAc("");
  };

  // ── Export/Import battle state ──
  const exportBattleState = () => {
    const state = {
      tokens, drawings, walls, terrainCells, fogCells, bgColor, gridSize, showGrid, fogMode,
      combatLive, combatants, turn, round, conditions,
    };
    const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "battlemap-" + new Date().toISOString().slice(0,10) + ".json";
    a.click();
    URL.revokeObjectURL(url);
  };

  const importBattleState = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const state = JSON.parse(ev.target.result);
        if (state.tokens) setTokens(state.tokens);
        if (state.drawings) setDrawings(state.drawings);
        if (state.walls) setWalls(state.walls);
        if (state.terrainCells) setTerrainCells(state.terrainCells);
        if (state.fogCells) setFogCells(state.fogCells);
        if (state.bgColor) setBgColor(state.bgColor);
        if (state.gridSize) setGridSize(state.gridSize);
        if (state.showGrid !== undefined) setShowGrid(state.showGrid);
        if (state.fogMode) setFogMode(state.fogMode);
        if (state.combatLive !== undefined) setCombatLive(state.combatLive);
        if (state.combatants) setCombatants(state.combatants);
        if (state.turn !== undefined) setTurn(state.turn);
        if (state.round !== undefined) setRound(state.round);
        if (state.conditions) setConditions(state.conditions);
      } catch (err) { console.error("Import failed:", err); }
    };
    reader.readAsText(file);
    e.target.value = "";
  };

  // ── Encounter templates ──
  const saveEncounterTemplate = () => {
    if (!templateName.trim()) return;
    const tpl = {
      id: "tpl-" + Date.now(),
      name: templateName,
      combatants: combatants.map(c => ({...c})),
      tokens: tokens.map(t => ({...t})),
      conditions: {...conditions},
    };
    const updated = [...templates, tpl];
    setTemplates(updated);
    localStorage.setItem(TEMPLATE_KEY, JSON.stringify(updated));
    setTemplateName("");
    setShowTemplateInput(false);
  };

  const loadEncounterTemplate = (id) => {
    const tpl = templates.find(t => t.id === id);
    if (!tpl) return;
    setTokens(tpl.tokens.map(t => ({...t})));
    setCombatants(tpl.combatants.map(c => ({...c})));
    setConditions({...tpl.conditions});
    setCombatLive(tpl.combatants.length > 0);
    if (tpl.combatants.length > 0) { setTurn(0); setRound(1); setMode("combat"); }
  };

  const deleteTemplate = (id) => {
    const updated = templates.filter(t => t.id !== id);
    setTemplates(updated);
    localStorage.setItem(TEMPLATE_KEY, JSON.stringify(updated));
  };

  // ── Quick macros ──
  const macroRollInitiative = () => {
    if (!selectedToken) return;
    const result = parseDiceExpression("1d20");
    setDiceResult({ value: result.total, type: "initiative", name: selectedToken.name, time: Date.now() });
    setRollHistory(prev => [{ expr: "1d20", rolls: result.rolls, mod: 0, total: result.total, who: selectedToken.name + " initiative", time: Date.now() }, ...prev].slice(0, 20));
    setTimeout(() => setDiceResult(null), 3000);
    // Update combatant init if in combat
    const cb = combatants.find(c => c.mapTokenId === selectedTokenId);
    if (cb) {
      setCombatants(prev => prev.map(c => c.id === cb.id ? {...c, init: result.total} : c).sort((a,b) => b.init - a.init));
    }
  };

  const macroSavingThrow = () => {
    const dc = prompt("DC for saving throw:");
    if (!dc) return;
    const result = parseDiceExpression("1d20");
    const pass = result.total >= parseInt(dc);
    setDiceResult({ value: result.total, type: "save", name: (selectedToken?.name || "Save") + (pass ? " PASS" : " FAIL"), time: Date.now(), crit: result.total === 20, fumble: result.total === 1 });
    setRollHistory(prev => [{ expr: "1d20 vs DC" + dc, rolls: result.rolls, mod: 0, total: result.total, who: (selectedToken?.name || "?") + " save " + (pass ? "PASS" : "FAIL"), time: Date.now() }, ...prev].slice(0, 20));
    setTimeout(() => setDiceResult(null), 3500);
  };

  const macroShortRest = () => {
    setTokens(prev => prev.map(t => t.maxHp ? {...t, hp: Math.min(t.maxHp, t.hp + Math.floor(t.maxHp / 2))} : t));
    setCombatants(prev => prev.map(c => ({...c, hp: Math.min(c.maxHp, c.hp + Math.floor(c.maxHp / 2))})));
    setRollHistory(prev => [{ expr: "Short Rest", rolls: [], mod: 0, total: 0, who: "Party healed", time: Date.now() }, ...prev].slice(0, 20));
  };

  const macroPerception = () => {
    const mod = prompt("WIS modifier:");
    const result = parseDiceExpression("1d20+" + (parseInt(mod) || 0));
    setDiceResult({ value: result.total, type: "perception", name: (selectedToken?.name || "Perception"), time: Date.now(), crit: result.rolls[0] === 20, fumble: result.rolls[0] === 1 });
    setRollHistory(prev => [{ expr: "1d20+" + (parseInt(mod) || 0), rolls: result.rolls, mod: result.modifier, total: result.total, who: (selectedToken?.name || "?") + " perception", time: Date.now() }, ...prev].slice(0, 20));
    setTimeout(() => setDiceResult(null), 3000);
  };

  // ── Point-to-segment distance (for eraser hitting walls) ──
  function distToSegment(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1, dy = y2 - y1;
    const len2 = dx * dx + dy * dy;
    if (len2 === 0) return Math.hypot(px - x1, py - y1);
    let t = ((px - x1) * dx + (py - y1) * dy) / len2;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  }

  // ── Presets & definitions ──
  const bgPresets = [
    { c:"#10101e", l:"Dark" }, { c:"#1e3e22", l:"Forest" }, { c:"#30281a", l:"Cave" },
    { c:"#143040", l:"Water" }, { c:"#4a3e30", l:"Sand" },
  ];

  const bmModes = viewRole === "player"
    ? [{ id:"select", icon:Target, label:"Select" }, { id:"combat", icon:Swords, label:"Combat" }]
    : [{ id:"select", icon:Target, label:"Select" }, { id:"draw", icon:Edit3, label:"Draw" }, { id:"combat", icon:Swords, label:"Combat" }];

  const drawToolDefs = [
    { id:"draw", label:"Draw", icon:Edit3 },
    { id:"fog", label:"Fog", icon:Eye },
    { id:"wall", label:"Wall", icon:Lock },
    { id:"terrain", label:"Terrain", icon:Mountain },
    { id:"ruler", label:"Ruler", icon:Compass },
    { id:"eraser", label:"Eraser", icon:Trash2 },
  ];

  const getCursor = () => {
    if (mode === "draw") {
      if (drawTool === "wall") return "crosshair";
      if (drawTool === "draw") return "crosshair";
      if (drawTool === "eraser") return "pointer";
      if (drawTool === "terrain") return "crosshair";
      return "crosshair";
    }
    if (pingMode) return "crosshair";
    if (movementMode) return "move";
    return dragState?.type === "pan" ? "grabbing" : "grab";
  };

  // ── Context menu condition submenu state ──
  const [showConditionMenu, setShowConditionMenu] = useState(false);

  return (
    <div style={{ display:"flex", flexDirection:"column", flex:1, minHeight:0 }}>
      <div style={{ display:"flex", flex:1, minHeight:0 }}>

        {/* ── LEFT: Mode Strip ── */}
        <div style={{ width:48, background:T.bgCard, borderRight:"1px solid " + T.crimsonBorder, display:"flex", flexDirection:"column", alignItems:"center", paddingTop:8, gap:2 }}>
          {bmModes.map(m => (
            <button key={m.id} onClick={() => { if (m.id === "draw" && viewRole === "player") return; setMode(m.id); }} title={m.label}
              style={{
                width:38, height:38, display:"flex", alignItems:"center", justifyContent:"center",
                background: mode === m.id ? T.crimsonSoft : "transparent",
                border: mode === m.id ? "1px solid " + T.crimsonBorder : "1px solid transparent",
                borderRadius:"4px", cursor:"pointer", transition:"all 0.15s",
              }}>
              <m.icon size={18} color={mode === m.id ? cssVar("--crimson") : cssVar("--text-muted")} />
            </button>
          ))}

          <div style={{ width:28, height:1, background:T.border, margin:"6px 0" }} />

          {mode === "draw" && drawToolDefs.map(dt => (
            <button key={dt.id} onClick={() => { setDrawTool(dt.id); setWallStart(null); setWallPreview(null); }} title={dt.label}
              style={{
                width:34, height:34, display:"flex", alignItems:"center", justifyContent:"center",
                background: drawTool === dt.id ? "rgba(212,67,58,0.12)" : "transparent",
                border: drawTool === dt.id ? "1px solid rgba(212,67,58,0.3)" : "1px solid transparent",
                borderRadius:"3px", cursor:"pointer", transition:"all 0.15s",
              }}>
              <dt.icon size={14} color={drawTool === dt.id ? cssVar("--crimson") : cssVar("--text-faint")} />
            </button>
          ))}

          {mode === "draw" && drawTool === "terrain" && (
            <React.Fragment>
              <div style={{ width:28, height:1, background:T.border, margin:"4px 0" }} />
              {Object.entries(TERRAIN_TYPES).map(([key, terrain]) => (
                <button key={key} onClick={() => setSelectedTerrain(key)} title={terrain.label}
                  style={{
                    width:34, height:34, display:"flex", alignItems:"center", justifyContent:"center",
                    background: selectedTerrain === key ? terrain.color : "transparent",
                    border: selectedTerrain === key ? "1px solid rgba(255,255,255,0.3)" : "1px solid transparent",
                    borderRadius:"3px", cursor:"pointer", transition:"all 0.15s", fontSize:10, fontFamily:T.ui, color:T.text
                  }}>
                  {terrain.label.substring(0, 1)}
                </button>
              ))}
            </React.Fragment>
          )}

          {mode === "draw" && drawTool === "draw" && (
            <React.Fragment>
              <div style={{ width:28, height:1, background:T.border, margin:"4px 0" }} />
              <input type="color" value={drawColor} onChange={e=>setDrawColor(e.target.value)}
                style={{ width:28, height:28, border:"1px solid " + T.border, background:"none", padding:0, cursor:"pointer", borderRadius:"3px" }} />
              <select value={drawWidth} onChange={e=>setDrawWidth(parseInt(e.target.value))} title="Brush width"
                style={{ width:36, padding:"2px", fontSize:8, fontFamily:T.ui, background:T.bgCard, border:"1px solid " + T.border, color:T.textMuted, borderRadius:"2px", textAlign:"center" }}>
                <option value="2">S</option><option value="3">M</option><option value="6">L</option><option value="10">XL</option>
              </select>
            </React.Fragment>
          )}

          <div style={{ flex:1 }} />

          <button onClick={() => setShowGrid(!showGrid)} title="Toggle Grid"
            style={{ width:34, height:34, display:"flex", alignItems:"center", justifyContent:"center", background:showGrid?"rgba(212,67,58,0.12)":"transparent", border:"1px solid transparent", borderRadius:"3px", cursor:"pointer" }}>
            <Layers size={14} color={showGrid ? cssVar("--crimson") : cssVar("--text-faint")} />
          </button>

          <button onClick={() => setPingMode(!pingMode)} title="Ping (P)"
            style={{ width:34, height:34, display:"flex", alignItems:"center", justifyContent:"center", background:pingMode?"rgba(88,170,255,0.15)":"transparent", border:"1px solid " + (pingMode?"rgba(88,170,255,0.3)":"transparent"), borderRadius:"3px", cursor:"pointer" }}>
            <MapPin size={14} color={pingMode ? "#58aaff" : cssVar("--text-faint")} />
          </button>

          <button onClick={() => setShowDicePanel(!showDicePanel)} title="Toggle Dice Panel"
            style={{ width:34, height:34, display:"flex", alignItems:"center", justifyContent:"center", background:showDicePanel?"rgba(212,67,58,0.12)":"transparent", border:"1px solid transparent", borderRadius:"3px", cursor:"pointer" }}>
            <Dice6 size={14} color={showDicePanel ? cssVar("--crimson") : cssVar("--text-faint")} />
          </button>

          <button onClick={() => { setZoom(1); setPan({x:0,y:0}); }} title="Reset View"
            style={{ width:34, height:34, display:"flex", alignItems:"center", justifyContent:"center", background:"transparent", border:"1px solid transparent", borderRadius:"3px", cursor:"pointer", marginBottom:8 }}>
            <RefreshCw size={14} color={cssVar("--text-faint")} />
          </button>
        </div>

        {/* ── CENTER: Canvas ── */}
        <div style={{ flex:1, display:"flex", flexDirection:"column", minWidth:0 }}>
          <div ref={wrapRef} style={{ flex:1, position:"relative", overflow:"hidden", background:bgColor, boxShadow:"inset 0 2px 8px rgba(0,0,6,0.45)", cursor:getCursor() }}
            onDragOver={handleDragOver} onDrop={handleDrop}>
            <canvas ref={canvasRef} style={{ display:"block", width:"100%", height:"100%", position:"absolute", top:0, left:0 }}
              onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp} onWheel={handleWheel} onContextMenu={handleContextMenu} />
            <input type="file" ref={fileRef} style={{display:"none"}} accept="image/*" onChange={handleMapUpload} />

            {/* Zoom indicator */}
            <div style={{ position:"absolute", bottom:8, left:8, background:"rgba(0,0,0,0.6)", padding:"4px 10px", borderRadius:"3px", fontFamily:T.ui, fontSize:9, color:"rgba(255,255,255,0.7)", letterSpacing:"1px", pointerEvents:"none" }}>
              {Math.round(zoom*100)}%
            </div>

            {/* Mode indicators (stacked top-left) */}
            {pingMode && (
              <div style={{ position:"absolute", top:8, left:8, background:"rgba(88,170,255,0.8)", padding:"4px 10px", borderRadius:"3px", fontFamily:T.ui, fontSize:9, color:"#f2e8d6", letterSpacing:"1px", pointerEvents:"none", zIndex:10 }}>
                PING MODE (click to ping, Esc to cancel)
              </div>
            )}
            {movementMode && !pingMode && (
              <div style={{ position:"absolute", top:8, left:8, background:"rgba(46,139,87,0.8)", padding:"4px 10px", borderRadius:"3px", fontFamily:T.ui, fontSize:9, color:"#f2e8d6", letterSpacing:"1px", pointerEvents:"none", zIndex:10 }}>
                MOVEMENT MODE (M to toggle, Esc to cancel)
              </div>
            )}

            {/* Player view badge */}
            {viewRole === "player" && (
              <div style={{ position:"absolute", top:8, right:8, background:"rgba(88,170,255,0.8)", padding:"4px 10px", borderRadius:"3px", fontFamily:T.ui, fontSize:9, color:"#f2e8d6", letterSpacing:"1px", pointerEvents:"none" }}>
                PLAYER VIEW
              </div>
            )}

            {/* Dice result popup */}
            {diceResult && (
              <div style={{ position:"absolute", top:"50%", left:"50%", transform:"translate(-50%,-50%)", background: diceResult.crit ? "rgba(46,139,87,0.95)" : diceResult.fumble ? "rgba(212,67,58,0.95)" : "rgba(4,4,10,0.88)", padding:"16px 28px", borderRadius:"8px", zIndex:200, textAlign:"center", border: diceResult.crit ? "2px solid #5ee09a" : diceResult.fumble ? "2px solid #e8605a" : "1px solid rgba(255,255,255,0.2)", pointerEvents:"none", boxShadow:"0 4px 20px rgba(0,0,6,0.50)" }}>
                <div style={{ fontSize:10, fontFamily:T.ui, color:"rgba(255,255,255,0.6)", letterSpacing:"2px", textTransform:"uppercase", marginBottom:4 }}>{diceResult.name ? diceResult.name + (diceResult.type === "attack" ? " attacks" : diceResult.type === "initiative" ? " initiative" : diceResult.type === "save" ? "" : diceResult.type === "perception" ? " perception" : "") : "d20"}</div>
                <div style={{ fontSize:36, fontFamily:T.ui, color:"#f2e8d6", fontWeight:700 }}>{diceResult.value}</div>
                {diceResult.crit && <div style={{ fontSize:10, fontFamily:T.ui, color:"#5ee09a", letterSpacing:"2px", marginTop:2 }}>NAT 20!</div>}
                {diceResult.fumble && <div style={{ fontSize:10, fontFamily:T.ui, color:"#f06858", letterSpacing:"2px", marginTop:2 }}>NAT 1!</div>}
              </div>
            )}

            {/* Dice panel */}
            {showDicePanel && (
              <div style={{ position:"absolute", bottom:16, right:16, width:240, maxHeight:300, background:T.bgCard, border:"1px solid " + T.crimsonBorder, borderRadius:"4px", boxShadow:"0 4px 16px rgba(0,0,6,0.45)", display:"flex", flexDirection:"column", zIndex:100, overflow:"hidden" }}>
                <div style={{ padding:"10px 12px", borderBottom:"1px solid " + T.border, display:"flex", alignItems:"center", gap:8 }}>
                  <input type="text" value={diceInput} onChange={e=>setDiceInput(e.target.value)} placeholder="2d6+3, 1d20, etc" onKeyDown={e=>{ if(e.key==="Enter") rollDiceExpression(diceInput); }}
                    style={{ flex:1, padding:"4px 6px", fontSize:10, fontFamily:T.body, background:T.bgInput, border:"1px solid " + T.border, color:T.text, borderRadius:"2px", outline:"none" }} />
                  <button onClick={() => rollDiceExpression(diceInput)} style={{ background:cssVar("--crimson"), border:"none", color:"#f2e8d6", padding:"4px 8px", borderRadius:"2px", cursor:"pointer", fontSize:9, fontFamily:T.ui, fontWeight:500 }}>Roll</button>
                </div>
                <div style={{ flex:1, overflowY:"auto", padding:"8px" }}>
                  {rollHistory.length === 0 ? (
                    <div style={{ fontSize:9, color:T.textFaint, textAlign:"center", padding:"12px 8px", fontStyle:"italic" }}>No rolls yet</div>
                  ) : (
                    rollHistory.map((roll, i) => (
                      <div key={i} style={{ padding:"6px 8px", marginBottom:"4px", background:T.bgInput, borderRadius:"2px", fontSize:8, color:T.text, borderLeft:"2px solid " + (roll.result > 15 ? "#5ee09a" : roll.result <= 5 ? "#f06858" : "transparent") }}>
                        <div style={{ fontFamily:T.ui, letterSpacing:"0.5px", fontWeight:500, marginBottom:2 }}>{roll.expr}</div>
                        <div style={{ color:T.textMuted, marginBottom:1 }}>Rolls: {roll.rolls.join(", ")}</div>
                        <div style={{ color:T.text, fontWeight:600 }}>Total: {roll.result}</div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Right-click context menu (expanded) */}
            {contextMenu && (() => {
              const tk = tokens.find(t => t.id === contextMenu.tokenId);
              if (!tk) return null;
              return (
                <div style={{ position:"absolute", left:contextMenu.x, top:contextMenu.y, background:T.bgCard, border:"1px solid " + T.crimsonBorder, borderRadius:"4px", boxShadow:"0 4px 16px rgba(0,0,6,0.45)", zIndex:100, minWidth:160, padding:"4px 0" }}
                  onMouseLeave={() => { setContextMenu(null); setShowConditionMenu(false); }}>
                  <div style={{ padding:"6px 12px", fontSize:11, color:T.text, fontWeight:500, borderBottom:"1px solid " + T.border, fontFamily:T.body }}>{tk.name}</div>
                  {tk.hp != null && (
                    <React.Fragment>
                      <button onClick={() => { adjustTokenHp(tk.id, -5); setContextMenu(null); }}
                        style={{ display:"block", width:"100%", padding:"7px 12px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:11, color:"#f06858", fontFamily:T.body }}>
                        Damage (-5 HP)
                      </button>
                      <button onClick={() => { adjustTokenHp(tk.id, 5); setContextMenu(null); }}
                        style={{ display:"block", width:"100%", padding:"7px 12px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:11, color:"#5ee09a", fontFamily:T.body }}>
                        Heal (+5 HP)
                      </button>
                      <button onClick={() => { const v = prompt("Adjust HP by (negative to damage):"); if (v) adjustTokenHp(tk.id, parseInt(v)); setContextMenu(null); }}
                        style={{ display:"block", width:"100%", padding:"7px 12px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:11, color:T.textDim, fontFamily:T.body }}>
                        Custom HP...
                      </button>
                    </React.Fragment>
                  )}
                  <div style={{ height:1, background:T.border, margin:"2px 0" }} />
                  <button onClick={() => { rollAttack(tk.id); setContextMenu(null); }}
                    style={{ display:"block", width:"100%", padding:"7px 12px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:11, color:"#b99aff", fontFamily:T.body }}>
                    Roll Attack (d20)
                  </button>
                  <div style={{ position:"relative" }}>
                    <button onClick={() => setShowConditionMenu(!showConditionMenu)}
                      style={{ display:"flex", width:"100%", padding:"7px 12px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:11, color:T.textDim, fontFamily:T.body, alignItems:"center", justifyContent:"space-between" }}>
                      <span>Add Condition</span> <ChevronRight size={10}/>
                    </button>
                    {showConditionMenu && (
                      <div style={{ position:"absolute", left:"100%", top:0, background:T.bgCard, border:"1px solid " + T.crimsonBorder, borderRadius:"4px", boxShadow:"0 4px 12px rgba(0,0,6,0.35)", minWidth:130, padding:"4px 0", maxHeight:220, overflowY:"auto" }}>
                        {conditionsList.map(cond => (
                          <button key={cond} onClick={() => {
                            // Find combatant for this token
                            const cb = combatants.find(c => c.mapTokenId === tk.id);
                            if (cb) addCondition(cb.id, cond);
                            setContextMenu(null); setShowConditionMenu(false);
                          }}
                            style={{ display:"block", width:"100%", padding:"5px 10px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:10, color:T.textDim, fontFamily:T.body }}>
                            {cond}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <div style={{ height:1, background:T.border, margin:"2px 0" }} />
                  {viewRole === "dm" && (
                    <button onClick={() => { updateToken(tk.id, { hidden: !tk.hidden }); setContextMenu(null); }}
                      style={{ display:"block", width:"100%", padding:"7px 12px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:11, color:T.textMuted, fontFamily:T.body }}>
                      {tk.hidden ? "Show Token" : "Hide Token"}
                    </button>
                  )}
                  <button onClick={() => { removeToken(tk.id); setContextMenu(null); }}
                    style={{ display:"block", width:"100%", padding:"7px 12px", background:"none", border:"none", textAlign:"left", cursor:"pointer", fontSize:11, color:T.textMuted, fontFamily:T.body }}>
                    Remove Token
                  </button>
                </div>
              );
            })()}
          </div>

          {/* ── BOTTOM: Combat Bar ── */}
          {combatLive && (
            <div style={{ height:56, background:T.bgCard, borderTop:"1px solid " + T.crimsonBorder, display:"flex", alignItems:"center", padding:"0 16px", gap:16, flexShrink:0 }}>
              <Tag variant="danger">Round {round}</Tag>
              <div style={{ display:"flex", alignItems:"center", gap:8 }}>
                <span style={{ width:6, height:6, borderRadius:"50%", background:combatants[turn]?.type==="pc"?"#5ee09a":cssVar("--crimson") }} />
                <span style={{ fontFamily:T.body, fontSize:14, color:T.text, fontWeight:400 }}>
                  {combatants[turn]?.name || "\u2014"}
                </span>
                <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1px" }}>
                  {turn+1}/{combatants.filter(c=>c.hp>0).length}
                </span>
              </div>
              <div style={{ flex:1 }} />
              {viewRole === "dm" && (
                <React.Fragment>
                  <CrimsonBtn onClick={prevTurn} secondary small><ChevronUp size={11}/></CrimsonBtn>
                  <CrimsonBtn onClick={nextTurn} small><SkipForward size={11}/> Next Turn</CrimsonBtn>
                  <CrimsonBtn onClick={endCombat} secondary small><X size={11}/> End</CrimsonBtn>
                </React.Fragment>
              )}
            </div>
          )}
        </div>

        {/* ── RIGHT: Context Panel ── */}
        <div style={{ width:280, background:T.bgCard, overflowY:"auto", display:"flex", flexDirection:"column", borderLeft:"1px solid " + T.crimsonBorder }}>

          {mode === "combat" ? (
            <div style={{ padding:14, display:"flex", flexDirection:"column", gap:10 }}>
              <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", paddingBottom:5, borderBottom:"1px solid " + T.crimsonBorder }}>
                {combatLive ? "Initiative Order" : "Combat Setup"}
              </span>

              {!combatLive ? (
                <div style={{ textAlign:"center", padding:"28px 0" }}>
                  <Swords size={28} color={cssVar("--text-faint")} style={{ marginBottom:10 }} />
                  <p style={{ fontFamily:T.body, fontSize:13, color:T.textMuted, fontStyle:"italic", fontWeight:300, marginBottom:12 }}>
                    {tokens.length === 0 ? "Place tokens on the map first" : tokens.length + " token" + (tokens.length!==1?"s":"") + " ready"}
                  </p>
                  <CrimsonBtn onClick={startCombat} disabled={tokens.length === 0}><Swords size={13}/> Start Encounter</CrimsonBtn>
                </div>
              ) : (
                <React.Fragment>
                  <div style={{ display:"flex", flexDirection:"column", gap:2, maxHeight:340, overflowY:"auto" }}>
                    {combatants.map((c, i) => (
                      <div key={c.id}
                        onClick={() => setSelectedTokenId(c.mapTokenId)}
                        style={{
                          padding:"8px 10px", background: i===turn ? T.crimsonSoft : "transparent",
                          borderRadius:"2px", borderLeft: i===turn ? "3px solid " + cssVar("--crimson") : "3px solid transparent",
                          opacity: c.hp<=0 ? 0.3 : 1, transition:"all 0.15s", cursor:"pointer",
                        }}>
                        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                          <span style={{ fontSize:11, fontFamily:T.body, fontWeight:500, color:T.textFaint, minWidth:18 }}>{c.init}</span>
                          <span style={{ width:5, height:5, borderRadius:"50%", flexShrink:0, background:c.type==="pc"?"#5ee09a":cssVar("--crimson") }} />
                          <span style={{ flex:1, fontSize:12, fontFamily:T.body, fontWeight:400, color:T.text, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>{c.name}</span>
                          <span style={{ fontFamily:T.ui, fontSize:7, color:T.textFaint, letterSpacing:"0.5px" }}>AC{c.ac}</span>
                        </div>
                        <div style={{ display:"flex", alignItems:"center", gap:3, marginTop:3, paddingLeft:24 }}>
                          <button onClick={e=>{e.stopPropagation();adjCombatantHp(c.id,-5);}} style={{ background:"none", border:"none", cursor:"pointer", color:"#f06858", fontSize:12, padding:"1px 3px" }}>-</button>
                          <div style={{ flex:1, height:5, background:T.bgInput, borderRadius:"2px", overflow:"hidden" }}>
                            <div style={{ width: Math.round(c.hp/c.maxHp*100) + "%", height:"100%", background:c.hp<c.maxHp*0.3?"#d4433a":c.hp<c.maxHp*0.6?"#e8940a":"#2e8b57", transition:"width 0.2s" }} />
                          </div>
                          <span style={{ fontSize:9, fontFamily:T.body, minWidth:32, textAlign:"center", color:T.textMuted }}>{c.hp}/{c.maxHp}</span>
                          <button onClick={e=>{e.stopPropagation();adjCombatantHp(c.id,5);}} style={{ background:"none", border:"none", cursor:"pointer", color:"#5ee09a", fontSize:12, padding:"1px 3px" }}>+</button>
                          {c.type==="enemy" && <button onClick={e=>{e.stopPropagation();removeCombatant(c.id);}} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:"1px" }}><X size={9}/></button>}
                        </div>
                        {(conditions[c.id]||[]).length > 0 && (
                          <div style={{ display:"flex", gap:3, flexWrap:"wrap", marginTop:3, paddingLeft:24 }}>
                            {(conditions[c.id]||[]).map((cond,ci) => (
                              <span key={ci} onClick={e=>{e.stopPropagation();removeCondition(c.id,ci);}}
                                style={{ display:"inline-flex", alignItems:"center", gap:2, background:T.crimsonSoft, border:"1px solid " + T.crimsonBorder, padding:"1px 5px", borderRadius:"2px", fontSize:7, fontFamily:T.ui, letterSpacing:"0.5px", color:cssVar("--crimson"), cursor:"pointer", textTransform:"uppercase" }}>
                                {cond} <X size={6}/>
                              </span>
                            ))}
                          </div>
                        )}
                        {i === turn && c.hp > 0 && (
                          <div style={{ paddingLeft:24, marginTop:3 }}>
                            <select onChange={e=>{addCondition(c.id,e.target.value);e.target.value="";}} value=""
                              onClick={e=>e.stopPropagation()}
                              style={{ padding:"2px 4px", fontSize:9, fontFamily:T.ui, background:T.bgInput, border:"1px solid " + T.border, color:T.textMuted, borderRadius:"2px", cursor:"pointer" }}>
                              <option value="">+ Condition</option>
                              {conditionsList.map(co=><option key={co} value={co}>{co}</option>)}
                            </select>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>

                  <div style={{ borderTop:"1px solid " + T.border, paddingTop:10, marginTop:6 }}>
                    <span style={{ fontFamily:T.ui, fontSize:8, color:T.textFaint, letterSpacing:"1px", textTransform:"uppercase", display:"block", marginBottom:6 }}>Add Combatant</span>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 40px", gap:4 }}>
                      <Input value={addName} onChange={setAddName} placeholder="Name" style={{ padding:"5px 8px", fontSize:11 }} />
                      <Input value={addInit} onChange={setAddInit} placeholder="Init" type="number" style={{ padding:"5px 4px", fontSize:11, textAlign:"center" }} />
                    </div>
                    <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 32px", gap:4, marginTop:4 }}>
                      <Input value={addHp} onChange={setAddHp} placeholder="HP" type="number" style={{ padding:"5px 8px", fontSize:11 }} />
                      <Input value={addAc} onChange={setAddAc} placeholder="AC" type="number" style={{ padding:"5px 8px", fontSize:11 }} />
                      <CrimsonBtn onClick={addCombatantToEncounter} secondary small style={{ padding:"5px 6px" }}><Plus size={11}/></CrimsonBtn>
                    </div>
                  </div>
                </React.Fragment>
              )}
            </div>

          ) : selectedToken ? (
            <div style={{ padding:14, display:"flex", flexDirection:"column", gap:12 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase" }}>Selected Token</span>
                <button onClick={() => setSelectedTokenId(null)} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:2 }}><X size={12}/></button>
              </div>

              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <span style={{ width:24, height:24, borderRadius:"50%", background:selectedToken.color, border:"2px solid rgba(255,220,30,0.6)", flexShrink:0 }} />
                <span style={{ fontSize:16, fontFamily:T.body, color:T.text, fontWeight:400 }}>{selectedToken.name}</span>
              </div>

              {selectedToken.hp != null && selectedToken.maxHp && (
                <div>
                  <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textFaint, textTransform:"uppercase", display:"block", marginBottom:6 }}>Hit Points</span>
                  <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:6 }}>
                    <span style={{ fontSize:28, fontFamily:T.body, fontWeight:300, color: selectedToken.hp < selectedToken.maxHp * 0.3 ? "#f06858" : selectedToken.hp < selectedToken.maxHp * 0.6 ? "#f5c45c" : "#5ee09a" }}>
                      {selectedToken.hp}
                    </span>
                    <span style={{ fontSize:14, color:T.textFaint, fontFamily:T.body }}>/ {selectedToken.maxHp}</span>
                  </div>
                  <HpBar val={selectedToken.hp} max={selectedToken.maxHp} color={selectedToken.hp < selectedToken.maxHp * 0.3 ? "#d4433a" : selectedToken.hp < selectedToken.maxHp * 0.6 ? "#e8940a" : "#2e8b57"} />

                  <div style={{ display:"flex", gap:6, marginTop:10 }}>
                    {[{d:-10,c:"rgba(212,67,58,0.15)",bc:"rgba(212,67,58,0.3)",tc:"#f06858"},{d:-5,c:"rgba(212,67,58,0.10)",bc:"rgba(212,67,58,0.2)",tc:"#f06858"},{d:-1,c:"rgba(212,67,58,0.06)",bc:"rgba(212,67,58,0.15)",tc:"#f06858"},{d:1,c:"rgba(46,139,87,0.06)",bc:"rgba(46,139,87,0.15)",tc:"#5ee09a"},{d:5,c:"rgba(46,139,87,0.10)",bc:"rgba(46,139,87,0.2)",tc:"#5ee09a"},{d:10,c:"rgba(46,139,87,0.15)",bc:"rgba(46,139,87,0.3)",tc:"#5ee09a"}].map(btn => (
                      <button key={btn.d} onClick={() => adjustTokenHp(selectedToken.id, btn.d)}
                        style={{ flex:1, padding:"7px 0", background:btn.c, border:"1px solid " + btn.bc, borderRadius:"3px", color:btn.tc, fontFamily:T.ui, fontSize:9, letterSpacing:"1px", cursor:"pointer" }}>
                        {btn.d > 0 ? "+" : ""}{btn.d}
                      </button>
                    ))}
                  </div>
                  <p style={{ fontSize:9, color:T.textFaint, fontStyle:"italic", marginTop:6, fontFamily:T.body }}>Scroll wheel over token to adjust HP</p>
                </div>
              )}

              {/* Vision & Movement settings */}
              <div style={{ borderTop:"1px solid " + T.border, paddingTop:10 }}>
                <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textFaint, textTransform:"uppercase", display:"block", marginBottom:8 }}>Token Settings</span>

                <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:6 }}>
                  <div>
                    <span style={{ fontFamily:T.ui, fontSize:7, color:T.textMuted, letterSpacing:"0.5px", display:"block", marginBottom:3 }}>SPEED (ft)</span>
                    <input type="number" value={selectedToken.speed || 30} onChange={e => updateToken(selectedToken.id, { speed: parseInt(e.target.value) || 30 })}
                      style={{ width:"100%", padding:"4px 6px", fontSize:11, fontFamily:T.body, background:T.bgInput, border:"1px solid " + T.border, color:T.text, borderRadius:"2px", outline:"none" }} />
                  </div>
                  <div>
                    <span style={{ fontFamily:T.ui, fontSize:7, color:T.textMuted, letterSpacing:"0.5px", display:"block", marginBottom:3 }}>VISION (cells)</span>
                    <input type="number" value={selectedToken.vision || 0} onChange={e => updateToken(selectedToken.id, { vision: parseInt(e.target.value) || 0 })}
                      style={{ width:"100%", padding:"4px 6px", fontSize:11, fontFamily:T.body, background:T.bgInput, border:"1px solid " + T.border, color:T.text, borderRadius:"2px", outline:"none" }} />
                  </div>
                </div>

                <div style={{ marginTop:6 }}>
                  <span style={{ fontFamily:T.ui, fontSize:7, color:T.textMuted, letterSpacing:"0.5px", display:"block", marginBottom:3 }}>DARKVISION (cells)</span>
                  <input type="number" value={selectedToken.darkvision || 0} onChange={e => updateToken(selectedToken.id, { darkvision: parseInt(e.target.value) || 0 })}
                    style={{ width:"100%", padding:"4px 6px", fontSize:11, fontFamily:T.body, background:T.bgInput, border:"1px solid " + T.border, color:T.text, borderRadius:"2px", outline:"none" }} />
                  <p style={{ fontSize:8, color:T.textFaint, fontStyle:"italic", marginTop:3, fontFamily:T.body }}>
                    Vision: 12 = 60ft, Darkvision: 12 = 60ft dim
                  </p>
                </div>

                <div style={{ display:"flex", gap:6, marginTop:8 }}>
                  <CrimsonBtn onClick={() => { if (selectedToken) { setMovementMode(!movementMode); if (!movementMode) { setMovementPath([]); setMovementOrigin({x:selectedToken.x,y:selectedToken.y}); } } }} secondary small style={{ flex:1 }}>
                    {movementMode ? "End Move" : "Move (M)"}
                  </CrimsonBtn>
                  <CrimsonBtn onClick={() => rollAttack(selectedToken.id)} secondary small style={{ flex:1 }}>
                    Roll d20
                  </CrimsonBtn>
                </div>
              </div>

              <div style={{ borderTop:"1px solid " + T.border, paddingTop:10 }}>
                <CrimsonBtn onClick={() => removeToken(selectedToken.id)} secondary small style={{ width:"100%" }}>
                  <Trash2 size={11}/> Remove Token
                </CrimsonBtn>
              </div>
            </div>

          ) : (
            <div style={{ padding:14, display:"flex", flexDirection:"column", gap:14 }}>
              <div>
                <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", display:"block", marginBottom:6, paddingBottom:5, borderBottom:"1px solid " + T.crimsonBorder }}>Map Settings</span>
                {viewRole === "dm" && (
                  <React.Fragment>
                    <div onClick={() => fileRef.current?.click()} style={{ width:"100%", padding:10, background:T.bg, border:"1px dashed " + T.border, borderRadius:"2px", cursor:"pointer", fontSize:11, color:T.textMuted, textAlign:"center", transition:"all 0.15s" }}>
                      {bgImage ? "Replace Map Image" : "Upload Map Image"}
                    </div>
                  </React.Fragment>
                )}
                <div style={{ display:"flex", gap:4, flexWrap:"wrap", marginTop:8 }}>
                  {bgPresets.map(p => (
                    <button key={p.c} onClick={() => setBgColor(p.c)} style={{ padding:"3px 7px", background:bgColor===p.c?T.crimsonSoft:"transparent", border:"1px solid " + (bgColor===p.c?T.crimsonBorder:T.border), color:bgColor===p.c?cssVar("--crimson"):T.textMuted, fontFamily:T.ui, fontSize:7, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"2px", textTransform:"uppercase" }}>{p.l}</button>
                  ))}
                </div>
                <div style={{ display:"flex", gap:6, alignItems:"center", marginTop:6 }}>
                  <span style={{ fontFamily:T.ui, fontSize:7, color:T.textMuted, letterSpacing:"1px" }}>GRID</span>
                  <select value={gridSize} onChange={e=>setGridSize(parseInt(e.target.value))} style={{ padding:"3px 4px", fontSize:10, fontFamily:T.ui, background:T.bgCard, border:"1px solid " + T.border, color:T.textMuted, borderRadius:"2px", flex:1 }}>
                    <option value="20">Tiny</option><option value="30">Small</option><option value="40">Medium</option><option value="50">Large</option><option value="60">XL</option>
                  </select>
                </div>

                {/* Fog mode toggle */}
                <div style={{ display:"flex", gap:4, marginTop:8 }}>
                  <button onClick={() => setFogMode("manual")} style={{ flex:1, padding:"5px 0", background:fogMode==="manual"?T.crimsonSoft:"transparent", border:"1px solid " + (fogMode==="manual"?T.crimsonBorder:T.border), color:fogMode==="manual"?cssVar("--crimson"):T.textMuted, fontFamily:T.ui, fontSize:7, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"2px 0 0 2px", textTransform:"uppercase" }}>Manual Fog</button>
                  <button onClick={() => setFogMode("vision")} style={{ flex:1, padding:"5px 0", background:fogMode==="vision"?T.crimsonSoft:"transparent", border:"1px solid " + (fogMode==="vision"?T.crimsonBorder:T.border), color:fogMode==="vision"?cssVar("--crimson"):T.textMuted, fontFamily:T.ui, fontSize:7, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"0 2px 2px 0", textTransform:"uppercase" }}>Vision Fog</button>
                </div>
                {fogMode === "vision" && (
                  <p style={{ fontSize:8, color:T.textFaint, fontStyle:"italic", marginTop:4, fontFamily:T.body }}>
                    Set vision on tokens to auto-reveal. Walls block line of sight.
                  </p>
                )}

                {viewRole === "dm" && (
                  <div style={{ display:"flex", gap:4, marginTop:6 }}>
                    <button onClick={() => setFogCells({})} style={{ flex:1, padding:"5px 0", background:"transparent", border:"1px solid " + T.border, color:T.textMuted, fontFamily:T.ui, fontSize:7, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"2px", textTransform:"uppercase" }}>Reveal All</button>
                    <button onClick={() => { setDrawings([]); setTokens([]); setFogCells({}); setWalls([]); setTerrainCells({}); }} style={{ flex:1, padding:"5px 0", background:"transparent", border:"1px solid " + T.border, color:T.textMuted, fontFamily:T.ui, fontSize:7, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"2px", textTransform:"uppercase" }}>Clear All</button>
                  </div>
                )}
                {viewRole === "dm" && walls.length > 0 && (
                  <button onClick={() => setWalls([])} style={{ width:"100%", padding:"5px 0", background:"transparent", border:"1px solid " + T.border, color:"#b574ff", fontFamily:T.ui, fontSize:7, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"2px", textTransform:"uppercase", marginTop:4 }}>
                    Clear Walls ({walls.length})
                  </button>
                )}
                {viewRole === "dm" && Object.keys(terrainCells).length > 0 && (
                  <button onClick={() => setTerrainCells({})} style={{ width:"100%", padding:"5px 0", background:"transparent", border:"1px solid " + T.border, color:cssVar("--crimson"), fontFamily:T.ui, fontSize:7, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"2px", textTransform:"uppercase", marginTop:4 }}>
                    Clear Terrain ({Object.keys(terrainCells).length})
                  </button>
                )}
              </div>

              <div>
                <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", display:"block", marginBottom:6, paddingBottom:5, borderBottom:"1px solid " + T.crimsonBorder }}>Token Library</span>
                <p style={{ fontSize:9, color:T.textFaint, fontStyle:"italic", marginBottom:6, fontFamily:T.body }}>Drag onto map or click to place</p>
                {party.map(p => (
                  <div key={p.id}
                    draggable
                    onDragStart={e => e.dataTransfer.setData("application/token", JSON.stringify({ name:p.name, color:"#2e8b57", hp:p.hp, maxHp:p.maxHp }))}
                    onClick={() => addToken(p.name, "#2e8b57", p.hp, p.maxHp)}
                    style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"7px 10px", background:T.bg, border:"1px solid " + T.border, borderRadius:"2px", cursor:"grab", marginBottom:3, transition:"all 0.15s" }}>
                    <div>
                      <div style={{ fontSize:12, color:T.text }}>{p.name}</div>
                      <div style={{ fontSize:10, color:T.textMuted }}>PC · {p.hp}/{p.maxHp}</div>
                    </div>
                    <Plus size={12} color={cssVar("--crimson")}/>
                  </div>
                ))}
                {viewRole === "dm" && (
                  <div onClick={() => { const n=prompt("Token name:"); if(n) addToken(n, cssVar("--crimson"), null, null); }}
                    style={{ display:"flex", justifyContent:"center", alignItems:"center", gap:4, padding:"7px 10px", background:T.bg, border:"1px dashed " + T.border, borderRadius:"2px", cursor:"pointer", marginTop:4, fontSize:10, color:T.textMuted, fontFamily:T.ui, letterSpacing:"1px", textTransform:"uppercase" }}>
                    <Plus size={10}/> Enemy Token
                  </div>
                )}
              </div>

              <div>
                <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", display:"block", marginBottom:6, paddingBottom:5, borderBottom:"1px solid " + T.crimsonBorder }}>On Map ({tokens.filter(t => viewRole === "player" ? !t.hidden : true).length})</span>
                {tokens.filter(t => viewRole === "player" ? !t.hidden : true).map(t => (
                  <div key={t.id}
                    onClick={() => { setSelectedTokenId(t.id); setMode("select"); }}
                    style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"5px 8px", background: t.id === selectedTokenId ? T.crimsonSoft : T.bg, border:"1px solid " + (t.id === selectedTokenId ? T.crimsonBorder : T.border), borderRadius:"2px", marginBottom:2, fontSize:11, color:T.text, cursor:"pointer", transition:"all 0.15s" }}>
                    <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                      <span style={{ width:8, height:8, borderRadius:"50%", background:t.color, flexShrink:0 }}/>
                      <span>{t.name.length>12?t.name.substring(0,12)+"...":t.name}</span>
                      {t.hidden && viewRole === "dm" && <EyeOff size={8} color={T.textFaint} style={{ marginLeft: 4 }}/>}
                    </div>
                    {viewRole === "dm" && (
                      <button onClick={e=>{e.stopPropagation();removeToken(t.id);}} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:0 }}><X size={10}/></button>
                    )}
                  </div>
                ))}
                {tokens.filter(t => viewRole === "player" ? !t.hidden : true).length===0 && <div style={{ fontSize:10, color:T.textFaint, fontStyle:"italic", padding:4 }}>No tokens placed</div>}
              </div>

              {viewRole === "dm" && (
                <React.Fragment>
                  <div>
                    <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", display:"block", marginBottom:6, paddingBottom:5, borderBottom:"1px solid " + T.crimsonBorder }}>Encounter Templates</span>
                    {showTemplateInput ? (
                      <div style={{ display:"flex", gap:4, marginBottom:6 }}>
                        <Input value={templateName} onChange={setTemplateName} placeholder="Template name" style={{ flex:1, padding:"5px 8px", fontSize:10 }} />
                        <CrimsonBtn onClick={saveEncounterTemplate} secondary small><Plus size={10}/></CrimsonBtn>
                      </div>
                    ) : (
                      <button onClick={() => setShowTemplateInput(true)} style={{ width:"100%", padding:"5px 0", background:"transparent", border:"1px solid " + T.border, color:T.textMuted, fontFamily:T.ui, fontSize:8, letterSpacing:"0.5px", cursor:"pointer", borderRadius:"2px", textTransform:"uppercase", marginBottom:6 }}>
                        + Save Current
                      </button>
                    )}
                    {templates.length === 0 ? (
                      <div style={{ fontSize:9, color:T.textFaint, fontStyle:"italic", padding:4 }}>No templates saved</div>
                    ) : (
                      templates.map(tpl => (
                        <div key={tpl.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"5px 8px", background:T.bg, border:"1px solid " + T.border, borderRadius:"2px", marginBottom:2, fontSize:10, color:T.text }}>
                          <button onClick={() => loadEncounterTemplate(tpl.id)} style={{ flex:1, background:"none", border:"none", cursor:"pointer", color:T.text, textAlign:"left", fontSize:10 }}>
                            {tpl.name}
                          </button>
                          <button onClick={() => deleteTemplate(tpl.id)} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:0 }}><X size={10}/></button>
                        </div>
                      ))
                    )}
                  </div>

                  <div>
                    <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", display:"block", marginBottom:6, paddingBottom:5, borderBottom:"1px solid " + T.crimsonBorder }}>Export/Import</span>
                    <div style={{ display:"flex", gap:4 }}>
                      <CrimsonBtn onClick={exportBattleState} secondary small style={{ flex:1 }}>
                        <Download size={10}/> Export
                      </CrimsonBtn>
                      <CrimsonBtn onClick={() => { const input = document.createElement("input"); input.type="file"; input.accept=".json"; input.onchange=(e)=>importBattleState(e); input.click(); }} secondary small style={{ flex:1 }}>
                        <Upload size={10}/> Import
                      </CrimsonBtn>
                    </div>
                  </div>

                  <div>
                    <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", display:"block", marginBottom:6, paddingBottom:5, borderBottom:"1px solid " + T.crimsonBorder }}>Quick Macros</span>
                    <div style={{ display:"flex", flexDirection:"column", gap:4 }}>
                      <CrimsonBtn onClick={macroRollInitiative} secondary small style={{ width:"100%" }}>
                        Roll Initiative
                      </CrimsonBtn>
                      <CrimsonBtn onClick={macroSavingThrow} secondary small style={{ width:"100%" }}>
                        Saving Throw
                      </CrimsonBtn>
                      <CrimsonBtn onClick={macroShortRest} secondary small style={{ width:"100%" }}>
                        Short Rest (Heal)
                      </CrimsonBtn>
                      <CrimsonBtn onClick={macroPerception} secondary small style={{ width:"100%" }}>
                        Perception Check
                      </CrimsonBtn>
                    </div>
                  </div>
                </React.Fragment>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function PlayView({ data, setData }) {
  const [viewMode, setViewMode] = useState("battlemap");
  const isPlayer = new URLSearchParams(window.location.search).get("role") === "player";

  useEffect(() => {
    document.title = isPlayer ? "Player View — Phmurt Studios" : "DM View — Phmurt Studios";
  }, [isPlayer]);

  const openPlayerView = () => {
    const url = window.location.href.split("?")[0] + "?role=player";
    window.open(url, "_blank");
  };

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"calc(100vh - 56px)" }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"12px 24px", borderBottom:"1px solid " + T.border, flexShrink:0 }}>
        <div style={{ display:"flex", alignItems:"center", gap:16 }}>
          <div>
            <div style={{ fontSize:24, color:T.text, fontWeight:300 }}>Play Mode</div>
            <p style={{ fontSize:11, color:T.textMuted, fontStyle:"italic", margin:"2px 0 0", fontWeight:300 }}>Session {data.sessionsPlayed + 1}</p>
          </div>
          <Tag variant="critical"><span style={{ width:5, height:5, borderRadius:"50%", background:cssVar("--crimson"), display:"inline-block", animation:"pulse 2s infinite" }}/> Live</Tag>
          {isPlayer && <Tag variant="muted">Player View</Tag>}
        </div>
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          {!isPlayer && (
            <button onClick={openPlayerView}
              style={{ padding:"6px 14px", background:T.crimsonSoft, border:"1px solid " + T.crimsonBorder, borderRadius:"3px", cursor:"pointer", color:cssVar("--crimson"), fontFamily:T.ui, fontSize:9, letterSpacing:"1px", textTransform:"uppercase", display:"flex", alignItems:"center", gap:6 }}>
              <Globe size={11}/> Open Player View
            </button>
          )}
          <div style={{ display:"flex", gap:0 }}>
            {[{id:"battlemap",label:"Battle Map"},{id:"npcs",label:"NPCs"}].map(t=>(
              <button key={t.id} onClick={()=>setViewMode(t.id)} style={{
                padding:"8px 16px", background:viewMode===t.id?T.crimsonSoft:"transparent",
                border:"1px solid " + (viewMode===t.id?T.crimsonBorder:T.border), cursor:"pointer",
                color:viewMode===t.id?cssVar("--crimson"):T.textMuted, fontFamily:T.ui, fontSize:9, letterSpacing:"1.5px",
                textTransform:"uppercase", fontWeight:500, borderRadius:t.id==="battlemap"?"2px 0 0 2px":"0 2px 2px 0",
              }}>{t.label}</button>
            ))}
          </div>
        </div>
      </div>

      {viewMode==="battlemap" ? (
        <Battlemap party={data.party} npcs={data.npcs} viewRole={isPlayer ? "player" : "dm"} />
      ) : (
        <div style={{ padding:24, overflowY:"auto", flex:1 }}>
          <SectionTitle icon={Users} count={data.npcs.filter(n=>n.alive).length}>NPC Reference</SectionTitle>
          <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:12 }}>
            {data.npcs.filter(n=>n.alive).map(n => (
              <div key={n.id} style={{
                padding:"12px 16px", background:T.bgCard, border:"1px solid " + T.border, borderRadius:"4px",
                borderLeft:"3px solid " + (n.attitude==="allied"||n.attitude==="friendly"?"#2e8b57":n.attitude==="hostile"?cssVar("--crimson"):T.textFaint),
              }}>
                <div style={{ fontSize:13, fontWeight:300, color:T.text, marginBottom:2 }}>{n.name}</div>
                <div style={{ fontSize:11, color:T.textFaint, fontWeight:300, fontStyle:"italic" }}>{n.role} — {n.loc}</div>
                {n.faction && <Tag variant="muted" style={{marginTop:4}}>{n.faction}</Tag>}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}



// NOTES
// ═══════════════════════════════════════════════════════════════════════════

function NotesView({ data, setData }) {
  const [notes, setNotes] = useState(data.campaignNotes || []);
  const [activeNote, setActiveNote] = useState(null);
  const [reformatMode, setReformatMode] = useState(false);
  const [rawInput, setRawInput] = useState("");

  useEffect(() => { setData(d=>({...d, campaignNotes:notes})); }, [notes]);

  const addNote = () => {
    const n = { id:uid(), title:"Untitled Note", content:"", created:new Date().toISOString(), modified:new Date().toISOString() };
    setNotes(prev=>[n,...prev]);
    setActiveNote(n.id);
  };
  const updateNote = (id, updates) => {
    setNotes(prev=>prev.map(n=>n.id===id?{...n,...updates,modified:new Date().toISOString()}:n));
  };
  const deleteNote = (id) => {
    setNotes(prev=>prev.filter(n=>n.id!==id));
    if(activeNote===id) setActiveNote(null);
  };

  const active = notes.find(n=>n.id===activeNote);

  return (
    <div style={{ display:"grid", gridTemplateColumns:"280px 1fr", height:"calc(100vh - 56px)", overflow:"hidden" }}>
      {/* Sidebar */}
      <div style={{ borderRight:`1px solid ${T.border}`, display:"flex", flexDirection:"column" }}>
        <div style={{ padding:16, borderBottom:`1px solid ${T.border}`, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
          <span style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", fontWeight:500 }}>Notes</span>
          <CrimsonBtn small onClick={addNote}><Plus size={10}/> New</CrimsonBtn>
        </div>
        <div style={{ flex:1, overflowY:"auto" }}>
          {notes.map(n => (
            <div key={n.id} onClick={()=>setActiveNote(n.id)} style={{
              padding:"14px 16px", cursor:"pointer", borderBottom:`1px solid ${T.borderMid}`,
              background:activeNote===n.id?T.bgHover:"transparent", transition:"background 0.15s",
            }}>
              <div style={{ fontSize:13, fontWeight:activeNote===n.id?400:300, color:T.text, marginBottom:4 }}>{n.title || "Untitled"}</div>
              <div style={{ fontSize:10, color:T.textFaint }}>{new Date(n.modified).toLocaleDateString()}</div>
            </div>
          ))}
          {notes.length===0 && <p style={{ padding:24, fontSize:13, color:T.textFaint, fontStyle:"italic", textAlign:"center", fontWeight:300 }}>No notes yet.</p>}
        </div>
      </div>

      {/* Editor */}
      <div style={{ display:"flex", flexDirection:"column", overflow:"hidden" }}>
        {active ? (
          <>
            <div style={{ padding:"16px 24px", borderBottom:`1px solid ${T.border}`, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
              <input value={active.title} onChange={e=>updateNote(active.id,{title:e.target.value})}
                style={{ fontSize:20, fontWeight:300, color:T.text, background:"transparent", border:"none", outline:"none", fontFamily:T.body, flex:1 }} placeholder="Note title..." />
              <button onClick={()=>deleteNote(active.id)} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint, padding:4 }}><Trash2 size={14}/></button>
            </div>
            <div style={{ flex:1, padding:24, overflowY:"auto" }}>
              <Textarea value={active.content} onChange={v=>updateNote(active.id,{content:v})} placeholder="Write your notes here..." rows={20} style={{ minHeight:"100%", resize:"none", border:"none", background:"transparent", fontSize:14, lineHeight:1.8 }} />
            </div>
          </>
        ) : (
          <div style={{ flex:1, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:16 }}>
            <FileText size={40} color={T.textFaint}/>
            <p style={{ fontSize:14, color:T.textMuted, fontWeight:300 }}>Select a note or create a new one</p>
            <CrimsonBtn onClick={addNote}><Plus size={12}/> New Note</CrimsonBtn>
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SETTINGS
// ═══════════════════════════════════════════════════════════════════════════

function SettingsView({ data, setData }) {
  const [confirmReset, setConfirmReset] = useState(false);

  const exportData = () => {
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type:"application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `${data.name.replace(/\s+/g,"-").toLowerCase()}-backup.json`;
    a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div style={{ padding:"32px 56px", maxWidth:700 }}>
      <div style={{ fontSize:28, color:T.text, fontWeight:300, marginBottom:32 }}>Campaign Settings</div>

      <Section style={{ marginBottom:24 }}>
        <SectionTitle icon={Settings}>General</SectionTitle>
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
          <div>
            <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Campaign Name</span>
            <Input value={data.name} onChange={v=>setData(d=>({...d,name:v}))} />
          </div>
          <div>
            <span style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:6 }}>Status</span>
            <Select value={data.status} onChange={v=>setData(d=>({...d,status:v}))} style={{width:"100%"}}>
              <option value="active">Active</option>
              <option value="paused">Paused</option>
              <option value="completed">Completed</option>
            </Select>
          </div>
        </div>
      </Section>

      <Section style={{ marginBottom:24 }}>
        <SectionTitle icon={Package}>Modules</SectionTitle>
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12 }}>
          {Object.entries(data.modules).map(([key,val]) => (
            <ToggleSwitch key={key} on={val} onToggle={()=>setData(d=>({...d,modules:{...d.modules,[key]:!val}}))} label={key.replace(/([A-Z])/g," $1").replace(/^./,s=>s.toUpperCase())} />
          ))}
        </div>
      </Section>

      <Section style={{ marginBottom:24 }}>
        <SectionTitle icon={Download}>Data</SectionTitle>
        <div style={{ display:"flex", gap:12 }}>
          <CrimsonBtn onClick={exportData}><Download size={12}/> Export JSON</CrimsonBtn>
        </div>
      </Section>

      <Section>
        <SectionTitle icon={AlertTriangle}>Danger Zone</SectionTitle>
        {!confirmReset ? (
          <CrimsonBtn secondary onClick={()=>setConfirmReset(true)}><Trash2 size={12}/> Reset Campaign</CrimsonBtn>
        ) : (
          <div style={{ padding:16, background:"rgba(212,67,58,0.08)", border:`1px solid rgba(212,67,58,0.3)`, borderRadius:"4px" }}>
            <p style={{ fontSize:13, color:T.crimson, marginBottom:12, fontWeight:300 }}>This will erase all campaign data. Are you sure?</p>
            <div style={{ display:"flex", gap:12 }}>
              <CrimsonBtn onClick={()=>{setData(d=>({...NEW_CAMPAIGN(),name:d.name}));setConfirmReset(false);}}><Trash2 size={12}/> Confirm Reset</CrimsonBtn>
              <CrimsonBtn secondary onClick={()=>setConfirmReset(false)}>Cancel</CrimsonBtn>
            </div>
          </div>
        )}
      </Section>
    </div>
  );
}


// ═══════════════════════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════════════════════
// FANTASY MAP GENERATOR — "Map Forge"
// Comprehensive procedural fantasy world generator with SVG cartography
// ═══════════════════════════════════════════════════════════════════════════

// ─── SEEDED PRNG ────────────────────────────────────────────────────────────

function mulberry32(seed) {
  let s = seed | 0;
  return function() {
    s = (s + 0x6D2B79F5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hashStr(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = ((h << 5) - h + str.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function seededShuffle(arr, rng) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function pick(arr, rng) { return arr[Math.floor(rng() * arr.length)]; }
function pickN(arr, n, rng) { return seededShuffle(arr, rng).slice(0, n); }
function randRange(min, max, rng) { return min + rng() * (max - min); }
function randInt(min, max, rng) { return Math.floor(randRange(min, max + 1, rng)); }
function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function lerp(a, b, t) { return a + (b - a) * t; }
function smoothstep(t) { return t * t * (3 - 2 * t); }
function dist(x1, y1, x2, y2) { return Math.sqrt((x2-x1)**2 + (y2-y1)**2); }

// ─── COMPREHENSIVE NAME GENERATION ─────────────────────────────────────────

const GEN_NAMES = {
  prefixes: {
    mountain:  ["Iron","Storm","Thunder","Grey","Black","White","Frost","Stone","Dragon","Eagle","Cloud","Silver","Shadow","Red","Dark","Ancient","Bone","Fire","Wind","Grim","Broken","Sheer","Jagged","Crimson","Frozen","Granite","Obsidian","Basalt","Marble","Slate","Copper","Crystal","Sapphire","Ruby","Amber","Jade","Onyx","Scarlet","Azure","Emerald"],
    forest:    ["Green","Dark","Whisper","Ancient","Shadow","Thorn","Moss","Silver","Twilight","Elder","Deep","Wild","Fey","Moon","Mystic","Pale","Amber","Golden","Hollow","Twisted","Winding","Misty","Silent","Tangled","Verdant","Enchanted","Sacred","Primeval","Haunted","Singing","Weeping","Dancing","Dreaming","Sleeping","Waking","Rooted","Branching","Canopied","Dappled","Shaded"],
    city:      ["King's","Queen's","Gold","Silver","Iron","Bright","High","Storm","River","Lake","Star","Crown","Shield","Dragon","Lion","Eagle","Falcon","Wolf","Crimson","Azure","Grand","Noble","Royal","Sacred","Holy","Blessed","Radiant","Shining","Gleaming","Eternal","Dawn","Dusk","Sun","Moon","Crystal","Ivory","Marble","Gilded","Jeweled","Emerald"],
    town:      ["Mill","Oak","Elm","Ash","Fox","Deer","Copper","Stone","Brook","Green","Thorn","Rose","Ivy","Fern","Birch","Willow","Reed","Moss","Hazel","Clover","Berry","Raven","Sparrow","Lark","Wren","Finch","Badger","Otter","Hare","Hart","Honey","Apple","Pear","Plum","Cherry","Wheat","Barley","Rye","Flax","Hemp"],
    ruins:     ["Lost","Fallen","Broken","Forsaken","Cursed","Shattered","Silent","Forgotten","Dead","Hollow","Blighted","Sunken","Buried","Haunted","Void","Doom","Ash","Ghost","Shadow","Wither","Crumbling","Desolate","Ravaged","Abandoned","Forlorn","Decrepit","Decaying","Ruined","Collapsed","Shunned","Accursed","Blasted","Scorched","Rotting","Infested","Defiled","Desecrated","Profane","Unholy","Damned"],
    dungeon:   ["Shadow","Deep","Dark","Bone","Skull","Doom","Dread","Iron","Black","Blood","Void","Worm","Spider","Rot","Crypt","Tomb","Pit","Abyss","Nether","Plague","Wyrm","Serpent","Demon","Devil","Lich","Wraith","Specter","Ghoul","Phantom","Horror","Terror","Gloom","Night","Death","Grave","Corpse","Marrow","Sinew","Bile","Venom"],
    lake:      ["Crystal","Mirror","Silver","Moon","Still","Deep","Blue","Clear","Silent","Glass","Frost","Starlight","Azure","Sapphire","Mist","Dream","Shimmer","Pale","Dawn","Twilight","Serene","Tranquil","Placid","Glimmering","Sparkling","Luminous","Opal","Pearl","Diamond","Emerald"],
    river:     ["Silver","Serpent","Swift","Rush","Winding","Long","Dark","Cold","White","Wild","Rapid","Gentle","Broad","Deep","Clear","Bright","Spring","Storm","Thunder","Iron","Singing","Laughing","Roaring","Murmuring","Whispering","Dancing","Leaping","Tumbling","Cascading","Surging"],
    swamp:     ["Murk","Black","Dead","Rot","Mire","Foul","Bog","Slime","Stink","Gloom","Blight","Dread","Vile","Dark","Poison","Plague","Wither","Stagnant","Fetid","Rank","Reeking","Sour","Brackish","Mouldering","Festering","Seeping","Oozing","Crawling","Choking","Drowning"],
    desert:    ["Sun","Scorched","Burning","Red","Golden","Dry","Dust","Sand","Bone","Fire","Blaze","Ember","Heat","Wither","Ash","Shimmering","Barren","Desolate","Parched","Blazing","Searing","Molten","Blistering","Cracked","Windswept","Howling","Merciless","Endless","Vast","Eternal"],
    island:    ["Storm","Sea","Coral","Pearl","Shell","Tide","Wave","Wind","Salt","Spray","Mist","Fog","Drift","Anchor","Harbor","Haven","Lost","Forgotten","Hidden","Phantom","Emerald","Sapphire","Jade","Golden","Sunken","Floating","Wandering","Lonely","Distant","Sacred"],
    kingdom:   ["Grand","High","Noble","Royal","Ancient","Mighty","Golden","Silver","Iron","Crystal","Sacred","Eternal","Divine","Blessed","Sovereign","Imperial","Hallowed","Radiant","Glorious","Celestial","Sublime","Exalted","Resplendent","Magnificent","Illustrious","Venerable","August","Majestic","Paramount","Supreme"],
    tavern:    ["Prancing","Golden","Silver","Rusty","Jolly","Drunken","Sleeping","Dancing","Singing","Laughing","Weeping","Howling","Roaring","Whispering","Stumbling","Leaping","Flying","Wandering","Lucky","Proud","Broken","Gilded","Tattered","Merry","Crooked","Crimson","Azure","Emerald","Ivory","Obsidian"],
    npc_first: ["Aldric","Brenna","Cedric","Dahlia","Edric","Fiona","Gareth","Helena","Idris","Jasper","Keira","Lysander","Mira","Nolan","Ophelia","Percival","Quinn","Rowan","Sienna","Theron","Ursula","Viktor","Wren","Xander","Yelena","Zephyr","Aric","Isolde","Tormund","Elara","Fenwick","Gwendolyn","Hadrian","Ingrid","Jareth","Katarina","Leoric","Maeve","Nathaniel","Oriana"],
    npc_last:  ["Ashford","Blackwood","Cromwell","Darkmore","Eldergrove","Fairweather","Greymane","Hawthorne","Ironwood","Jasperstone","Kingsley","Lancaster","Moonshadow","Nightingale","Oakenheart","Proudmoor","Queensbury","Ravencrest","Stormwind","Thornwall","Underhill","Valenthorne","Whitecliff","Xaviermont","Youngblood","Zephyrsteel","Battleborn","Covenlight","Dragonsbane","Emberheart"],
  },
  suffixes: {
    mountain:  ["peak","crag","horn","spire","fang","ridge","tor","summit","mount","cliff","crest","needle","crown","tooth","pillar","stone","fall","reach","top","throne","spine","backbone","rampart","bulwark","sentinel","warden","watch","guard","bastion","keep"],
    forest:    ["wood","grove","weald","glen","thicket","copse","shade","hollow","dell","brake","glade","holt","bough","leaf","vale","wild","deep","heart","tangle","root","canopy","bower","arbor","garden","maze","labyrinth","realm","domain","sanctuary","haven"],
    city:      ["haven","gate","hold","keep","port","ford","burg","vale","ward","cross","bridge","tower","hall","march","stead","borough","court","reach","field","throne","citadel","bastion","fortress","stronghold","palace","capitol","crown","spire","pinnacle","summit"],
    town:      ["shire","bury","dale","ton","wick","ham","ford","well","field","vale","stead","bridge","hollow","croft","thorpe","leigh","worth","mere","mead","beck","mill","cross","green","end","hill","bottom","pool","spring","marsh","moor"],
    ruins:     ["spire","gate","keep","hold","hall","throne","temple","altar","sanctum","vault","bastion","tower","citadel","palace","crypt","tomb","barrow","cairn","mound","obelisk","monument","memorial","reliquary","ossuary","catacomb","labyrinth","warren","chamber","gallery","rotunda"],
    dungeon:   ["depths","pit","lair","den","cave","hollow","warren","maze","labyrinth","catacomb","dungeon","vault","cell","chamber","grotto","abyss","chasm","burrow","tunnels","maw","gullet","throat","bowels","heart","core","nexus","sanctum","prison","cage","tomb"],
    lake:      ["lake","mere","pool","waters","pond","loch","tarn","basin","depths","bay","reservoir","spring","font","well","lagoon","sea","shallows","expanse","mirror","reach"],
    river:     ["river","run","stream","flow","creek","brook","channel","rapids","falls","current","course","branch","fork","bend","crossing","wash","waters","rill","cascade","torrent"],
    swamp:     ["mire","bog","fen","marsh","swamp","slough","moor","quag","morass","wetland","bayou","hollow","bottoms","flats","reach","sink","waste","pool","seep","muck"],
    desert:    ["waste","sands","dunes","expanse","flats","badlands","barrens","reach","stretch","void","plains","steppe","wastes","wilds","frontier","desolation","scape","basin","canyon","mesa"],
    island:    ["isle","island","atoll","cay","key","rock","reef","shoal","point","head","cape","haven","refuge","sanctuary","berth","landing","rest","watch","vigil","roost"],
    kingdom:   ["realm","domain","empire","sovereignty","dominion","dynasty","confederation","alliance","union","republic","principality","duchy","barony","march","protectorate","federation","commonwealth","territory","province","lands"],
    tavern:    ["Pony","Dragon","Griffin","Unicorn","Phoenix","Barrel","Tankard","Flagon","Goblet","Shield","Sword","Dagger","Helm","Boot","Lantern","Candle","Star","Moon","Sun","Rose","Lily","Thistle","Crown","Stag","Boar","Bear","Wolf","Fox","Hawk","Raven"],
  },
  standalone: {
    mountain:  ["Dragonspine","Worldpeak","Skyreach","Cloudpiercer","Thundertop","Stormcrown","Ironspire","Frostfang","Shadowcrest","Eaglenest","Bonecrag","Firehorn","Windshear","Grimtooth","Stonethrone","Doomcrag","Voidpeak","Starshatter","Mooncrest","Sunspire"],
    forest:    ["Thornwood","Darkhollow","Greenmantle","Shadowbark","Moongrove","Elderweald","Whisperleaf","Silverbough","Deeproot","Fernglade","Nightshade","Mistwood","Hexwood","Briarheart","Dreamcanopy","Starweave","Gloomheart","Sunveil","Duskmantle","Dawntangle"],
    city:      ["Astoria","Meridian","Valdris","Ironhaven","Stormgate","Brighthollow","Kingsreach","Solara","Nordheim","Caldera","Arcanis","Luminara","Thronehall","Dragoncrest","Starfall","Crystalholm","Runewall","Embervault","Frostmere","Goldcrown"],
    sea:       ["The Sapphire Deep","The Endless Blue","Mare Tenebris","The Churning Expanse","The Abyssal Main","The Crystal Tide","The Storm Sea","The Dragon's Wake","The Frozen Deep","The Merchant's Way","The Siren's Veil","The Leviathan's Rest","The Moonlit Waters","The Crimson Strait","The Jade Passage"],
    tavern:    ["The Salty Dog","The Broken Compass","Rest for the Wicked","The Last Drop","The Wanderer's End","Ye Olde Flask","The Tipsy Troll","Dragon's Breath Inn","The Copper Cup","The Velvet Curtain","The Rusty Anchor","The Gilded Lily","The Cracked Cauldron","The Blind Bard","The Silent Knight"],
  },
};

function genName(rng, type) {
  const r = rng();
  if (r < 0.25 && GEN_NAMES.standalone[type]) return pick(GEN_NAMES.standalone[type], rng);
  const pre = pick(GEN_NAMES.prefixes[type] || GEN_NAMES.prefixes.city, rng);
  const suf = pick(GEN_NAMES.suffixes[type] || GEN_NAMES.suffixes.city, rng);
  if (rng() < 0.4) return pre + suf.toLowerCase();
  if (rng() < 0.5) return pre + " " + suf.charAt(0).toUpperCase() + suf.slice(1);
  return "The " + pre + " " + suf.charAt(0).toUpperCase() + suf.slice(1);
}

function genKingdomName(rng) {
  const r = rng();
  const pre = pick(GEN_NAMES.prefixes.kingdom, rng);
  const suf = pick(GEN_NAMES.suffixes.kingdom, rng);
  const city = genName(rng, "city");
  if (r < 0.15) return "The " + pre + " " + suf.charAt(0).toUpperCase() + suf.slice(1);
  if (r < 0.30) return pre + " " + suf.charAt(0).toUpperCase() + suf.slice(1) + " of " + city;
  if (r < 0.45) return "Kingdom of " + city;
  if (r < 0.60) return "The " + pre + " " + suf.charAt(0).toUpperCase() + suf.slice(1) + " of " + city;
  if (r < 0.75) return city + " " + suf.charAt(0).toUpperCase() + suf.slice(1);
  if (r < 0.85) return "The Free " + suf.charAt(0).toUpperCase() + suf.slice(1) + " of " + city;
  return "United " + suf.charAt(0).toUpperCase() + suf.slice(1) + " of " + city;
}

function genNPCName(rng) {
  return pick(GEN_NAMES.prefixes.npc_first, rng) + " " + pick(GEN_NAMES.prefixes.npc_last, rng);
}

function genTavernName(rng) {
  if (rng() < 0.35) return pick(GEN_NAMES.standalone.tavern, rng);
  return "The " + pick(GEN_NAMES.prefixes.tavern, rng) + " " + pick(GEN_NAMES.suffixes.tavern, rng);
}

// ─── NPC GENERATION ─────────────────────────────────────────────────────────

const NPC_RACES = ["Human","Elf","Dwarf","Halfling","Half-Elf","Half-Orc","Gnome","Tiefling","Dragonborn","Aasimar","Goliath","Tabaxi","Firbolg","Kenku","Lizardfolk","Genasi","Changeling","Warforged","Tortle","Triton"];
const NPC_CLASSES = ["Fighter","Wizard","Rogue","Cleric","Ranger","Paladin","Barbarian","Bard","Druid","Sorcerer","Warlock","Monk","Artificer","Blood Hunter","None","None","None","None","None","None"];
const NPC_ROLES = ["Blacksmith","Innkeeper","Merchant","Guard Captain","Herbalist","Scholar","Priest","Farmer","Hunter","Fisher","Sailor","Miner","Noble","Thief","Spy","Healer","Alchemist","Enchanter","Beastmaster","Bounty Hunter","Caravan Master","Diplomat","Entertainer","Fortune Teller","Gravedigger","Jailer","Librarian","Mason","Navigator","Oracle","Quartermaster","Scribe","Tanner","Undertaker","Vintner","Weaver","Woodcutter","Apothecary","Brewer","Cartographer"];
const NPC_TRAITS = ["brave","cunning","loyal","treacherous","wise","foolish","kind","cruel","generous","greedy","patient","impulsive","honest","deceptive","proud","humble","ambitious","content","curious","cautious","jovial","melancholic","stoic","passionate","reclusive","social","pious","skeptical","superstitious","pragmatic"];
const NPC_QUIRKS = ["speaks in riddles","collects unusual trinkets","always humming a tune","has a noticeable scar","never makes eye contact","laughs at inappropriate times","obsessively clean","perpetually disheveled","speaks very quietly","gestures wildly when talking","always eating something","fidgets with a coin","tells long-winded stories","forgets names constantly","overly formal in speech","uses strange idioms","pauses mid-sentence often","whistles while working","taps fingers rhythmically","always looking over shoulder"];
const NPC_MOTIVATIONS = ["wealth","power","knowledge","revenge","redemption","love","duty","freedom","glory","survival","curiosity","justice","faith","family","legacy","adventure","peace","protection","creation","destruction"];

function generateNPC(rng, settlement) {
  const race = pick(NPC_RACES, rng);
  const cls = pick(NPC_CLASSES, rng);
  const role = pick(NPC_ROLES, rng);
  const trait1 = pick(NPC_TRAITS, rng);
  let trait2 = pick(NPC_TRAITS, rng);
  while (trait2 === trait1) trait2 = pick(NPC_TRAITS, rng);
  return {
    name: genNPCName(rng),
    race, class: cls === "None" ? null : cls, role,
    level: cls !== "None" ? randInt(1, 15, rng) : null,
    traits: [trait1, trait2],
    quirk: pick(NPC_QUIRKS, rng),
    motivation: pick(NPC_MOTIVATIONS, rng),
    settlement: settlement?.name || null,
    attitude: pick(["friendly","neutral","hostile","cautious","helpful","indifferent"], rng),
    alive: rng() > 0.05,
    age: randInt(18, 85, rng),
    gender: pick(["male","female","non-binary"], rng),
  };
}

// ─── ENCOUNTER TABLE GENERATION ─────────────────────────────────────────────

const ENCOUNTER_TABLES = {
  deepOcean:   { monsters:["Kraken","Sea Serpent","Aboleth","Dragon Turtle","Merrow","Sahuagin","Storm Giant","Water Elemental"], cr:[8,6,10,12,4,2,9,5] },
  ocean:       { monsters:["Giant Shark","Merfolk Patrol","Ghost Ship","Sea Hag","Pirate Crew","Water Weird","Reef Drake","Plesiosaur"], cr:[5,3,7,4,4,3,6,5] },
  shallows:    { monsters:["Merfolk Scout","Giant Crab","Sahuagin Raider","Sea Hag","Kuo-toa","Reef Shark","Swarm of Quippers","Water Mephit"], cr:[1,2,2,3,1,1,1,1] },
  beach:       { monsters:["Giant Crab","Sand Worm","Pirate Scout","Bandit","Merfolk Emissary","Sea Drake Hatchling","Coconut Crab","Hermit Druid"], cr:[1,3,1,1,2,2,1,2] },
  tundra:      { monsters:["Frost Giant","Winter Wolf","Ice Mephit","Yeti","Remorhaz","White Dragon Wyrmling","Snow Owlbear","Frost Troll"], cr:[8,3,1,3,6,2,4,5] },
  snowfield:   { monsters:["Yeti","Ice Elemental","Frost Salamander","Chill Touch Specter","Arctic Fox Pack","Snow Golem","Frozen Revenant","Glacier Worm"], cr:[3,5,6,3,2,4,5,7] },
  grassland:   { monsters:["Centaur Patrol","Griffon","Worg Pack","Gnoll War Band","Ankheg","Giant Eagle","Peryton","Bulette"], cr:[2,2,3,4,2,1,2,5] },
  plains:      { monsters:["Bandit Highwayman","Traveling Merchant (Guard)","Wild Horse Herd","Gnoll Scout","Giant Vulture","Prairie Drake","Dust Devil","Nomad Raider"], cr:[1,2,0,2,1,3,2,3] },
  savanna:     { monsters:["Lion Pride","Giant Hyena Pack","Werelion","Gnoll Fang","Yuan-ti Scout","Thri-kreen Hunter","Giant Scorpion","Fire Snake"], cr:[1,2,4,3,3,3,3,2] },
  desert:      { monsters:["Blue Dragon","Purple Worm","Giant Scorpion","Mummy Lord","Lamia","Dust Mephit","Sand Golem","Brass Dragon Wyrmling"], cr:[9,15,3,8,4,1,5,3] },
  forest:      { monsters:["Owlbear","Green Hag","Displacer Beast","Treant","Dire Wolf","Giant Spider","Dryad","Ettercap"], cr:[3,5,3,9,1,1,1,2] },
  denseForest: { monsters:["Young Green Dragon","Shambling Mound","Ettercap Nest","Grick Alpha","Assassin Vine","Wood Woad","Korred","Dryad Circle"], cr:[8,5,4,7,3,5,7,6] },
  jungle:      { monsters:["Yuan-ti Abomination","Giant Ape","Couatl","Tyrannosaurus Rex","Giant Constrictor","Grung War Party","Vegepygmy Colony","Eblis"], cr:[7,7,4,8,2,3,2,1] },
  swamp:       { monsters:["Black Dragon","Hydra","Shambling Mound","Will-o'-Wisp","Bullywug Chief","Giant Crocodile","Froghemoth","Catoblepas"], cr:[7,8,5,2,3,5,10,5] },
  hills:       { monsters:["Hill Giant","Manticore","Chimera","Ogre Gang","Harpy Flock","Stone Giant","Galeb Duhr","Wyvern"], cr:[5,3,6,4,2,7,6,6] },
  highlands:   { monsters:["Stone Giant Elder","Roc Juvenile","Cyclops","Mountain Troll","Highland Barbarian War Band","Air Elemental","Griffon Rider","Storm Herald"], cr:[7,5,6,5,4,5,6,7] },
  mountain:    { monsters:["Red Dragon","Roc","Cloud Giant","Fire Giant","Mountain Troll","Air Elemental","Galeb Duhr","Chimera"], cr:[10,11,9,9,5,5,6,6] },
  snowMountain:{ monsters:["Ancient White Dragon","Frost Giant Everlasting One","Abominable Yeti","Remorhaz","Ice Devil","Bheur Hag","Frost Worm","Crystal Dragon"], cr:[17,12,9,11,11,7,10,8] },
  volcanic:    { monsters:["Red Dragon","Fire Giant","Fire Elemental","Salamander","Magma Mephit","Azer","Phoenix","Efreeti"], cr:[10,9,5,5,1,2,16,11] },
};

function generateEncounterTable(rng, biome, partyLevel) {
  const table = ENCOUNTER_TABLES[biome] || ENCOUNTER_TABLES.grassland;
  const encounters = [];
  for (let i = 0; i < table.monsters.length; i++) {
    const monster = table.monsters[i];
    const cr = table.cr[i];
    const difficulty = cr <= partyLevel - 3 ? "trivial" : cr <= partyLevel - 1 ? "easy" : cr <= partyLevel + 1 ? "medium" : cr <= partyLevel + 3 ? "hard" : "deadly";
    encounters.push({
      monster, cr, difficulty,
      count: cr <= partyLevel ? randInt(1, 4, rng) : 1,
      notes: pick([
        "Ambush from concealment","Territorial dispute","Hunting for prey","Guarding a lair entrance",
        "Migrating through the area","Wounded and desperate","Performing a ritual","Accompanied by young",
        "In conflict with another group","Fleeing from something worse","Setting up camp","Patrolling territory",
      ], rng),
      treasure: cr >= 3 ? pick(["Small hoard","Magic item","Rare materials","Ancient coins","Gems","Scroll","Potion","Weapon"], rng) : pick(["Trinkets","A few coins","Nothing of value","Odd keepsake"], rng),
    });
  }
  return encounters.sort((a, b) => a.cr - b.cr);
}

// ─── LORE GENERATION ────────────────────────────────────────────────────────

const LORE_TEMPLATES = {
  kingdom_founding: [
    "Founded {years} years ago by {founder}, who united the warring clans through {method}.",
    "Established when {founder} discovered {artifact} in the {location}, granting divine right to rule.",
    "Born from the ashes of the {old_realm} after the {cataclysm}, {founder} forged a new order.",
    "Created through a pact between {founder} and the {entity}, binding the land to {purpose}.",
  ],
  settlement_history: [
    "Originally a {origin} established by {people}, {name} grew into a {type} when {event}.",
    "Known for its {feature}, {name} has been a center of {activity} since the {era}.",
    "{name} was built atop the ruins of {ancient_site}, and strange {phenomena} still occur here.",
    "Three times destroyed and three times rebuilt, {name} earned its nickname: The {epithet}.",
  ],
  ruin_legend: [
    "Once the seat of {ruler}, {name} fell when {disaster} struck during the {event}.",
    "Legend says {name} was cursed by {entity} after {transgression}. None who enter return unchanged.",
    "The {artifact} is said to still lie within {name}, guarded by {guardian}.",
    "{name} was the site of the Battle of {battle}, where {outcome}.",
  ],
  dungeon_rumor: [
    "They say {creature} lairs in the deepest level, guarding {treasure}.",
    "Adventurers who've returned speak of {hazard} and {feature} in the {area}.",
    "The {faction} has been sending expeditions to {name}. They seek {objective}.",
    "A map to {name}'s hidden vault was recently found in {location}. It's likely a trap.",
  ],
};

const LORE_FRAGMENTS = {
  years: [100,200,300,500,800,1000,1500,2000,3000],
  method: ["diplomacy","conquest","a sacred oath","dragon-slaying","divine intervention","an arcane ritual","marriage alliance","a tournament of champions"],
  artifact: ["the Crown of Stars","an ancient scepter","the First Blade","a dragonstone","the Book of Ages","a divine relic","the Heartstone","an elder scroll"],
  old_realm: ["Ar'Kaneth","the Sunless Empire","the Dragon Kingdoms","Dwarfholt","the Elder Dominion","the Fey Courts","the Shadow Concordance","the Titan's Domain"],
  cataclysm: ["Great Sundering","Dragon Wars","Planar Convergence","Arcane Cataclysm","Divine Silence","Undying Night","Worldquake","Demon Incursion"],
  entity: ["an ancient dragon","a primordial being","the Fey Queen","a lich king","an elder god","the Spirit of the Land","a celestial patron","a bound demon"],
  purpose: ["eternal protection","magical prosperity","arcane research","divine service","military dominance","trade supremacy","knowledge preservation","planar stability"],
  origin: ["frontier outpost","fishing village","mining camp","trading post","religious retreat","military fort","refugee settlement","wizard's retreat"],
  people: ["human settlers","dwarven miners","elven exiles","halfling traders","mixed refugees","military veterans","religious pilgrims","arcane scholars"],
  event: ["gold was discovered nearby","a major trade route shifted","a dragon was slain in the region","a holy site was revealed","refugees flooded in from the wars","a powerful wizard established a tower","the old kingdom collapsed","a portal was discovered"],
  feature: ["ancient architecture","magical wellspring","defensible position","natural harbor","hot springs","crystal caverns","ancient library","dragonbone foundations"],
  activity: ["trade","scholarship","worship","military training","magical research","artisan crafts","brewing","shipbuilding"],
  era: ["First Age","Age of Dragons","Great Migration","after the Sundering","Time of Heroes","Golden Era","Age of Shadows","Dawn of Magic"],
  ruler: ["a mad king","an elven archmage","a dwarven war-chief","a dragon cult","a lich","a celestial being","a forgotten god","a powerful sorcerer"],
  disaster: ["a great earthquake","dark magic","a dragon attack","a demonic invasion","plague","civil war","divine punishment","an arcane experiment gone wrong"],
  creature: ["a dracolich","an elder beholder","a mind flayer colony","a bound demon","undead legions","a vampire lord","an aboleth","a death knight"],
  treasure: ["an ancient artifact","mountains of gold","a trapped soul","a planar gate","the key to immortality","a divine weapon","forbidden knowledge","a dragon egg"],
  hazard: ["shifting walls","poisonous gas","magical darkness","time distortions","gravity anomalies","psychic interference","arcane traps","living architecture"],
  guardian: ["animated suits of armor","a spectral army","bound elementals","construct guardians","a sphinx","cursed champions","shadow duplicates","a trapped deity"],
  faction: ["Thieves' Guild","Crown's agents","a cult","mercenary company","scholarly order","religious sect","merchant consortium","rebel faction"],
  objective: ["a weapon of mass destruction","an ancient prophecy","the secret to lichdom","a planar portal","political leverage","arcane secrets","buried treasure","a seal that must not be broken"],
  epithet: ["Undying","Phoenix City","Stubborn Stone","Cockroach","Defiant","Rising","Eternal Ember","Last Bastion"],
  phenomena: ["at midnight","during full moons","when storms gather","in deep winter","at the equinox","during eclipses","when magic surges","in complete silence"],
  battle: ["the Broken Banner","Last Stand","Crimson Fields","Shattered Gates","Dragon's Fall","the Burning Sky","the Silent Dawn","the Red Wedding"],
  outcome: ["both sides were destroyed","the victor vanished into legend","the dead rose and fought for neither side","a dragon ended the battle","the gods intervened","reality itself cracked","time stopped for a year","the battlefield became cursed ground"],
};

function generateLore(rng, template, context) {
  const templates = LORE_TEMPLATES[template] || LORE_TEMPLATES.settlement_history;
  let text = pick(templates, rng);
  // Replace all {placeholders}
  text = text.replace(/\{(\w+)\}/g, (match, key) => {
    if (context && context[key]) return context[key];
    const options = LORE_FRAGMENTS[key];
    if (options) return Array.isArray(options) ? pick(options, rng) : options;
    return match;
  });
  return text;
}

// ─── TREASURE & LOOT GENERATION ─────────────────────────────────────────────

const MAGIC_ITEMS = {
  common: ["Potion of Healing","Scroll of Identify","Driftglobe","Cloak of Many Fashions","Hat of Wizardry","Mystery Key","Tankard of Sobriety","Pole of Collapsing","Wand of Smiles","Instrument of Illusions"],
  uncommon: ["Bag of Holding","+1 Weapon","Cloak of Protection","Boots of Elvenkind","Goggles of Night","Gauntlets of Ogre Power","Pearl of Power","Ring of Jumping","Immovable Rod","Winged Boots"],
  rare: ["+2 Weapon","Flame Tongue","Ring of Protection","Amulet of Health","Belt of Giant Strength","Cape of the Mountebank","Helm of Teleportation","Instrument of the Bards","Staff of Healing","Wand of Fireballs"],
  veryRare: ["+3 Weapon","Holy Avenger","Staff of Power","Robe of Stars","Ring of Regeneration","Crystal Ball","Rod of Absorption","Tome of Understanding","Cloak of Invisibility","Dancing Sword"],
  legendary: ["Vorpal Sword","Staff of the Magi","Luck Blade","Ring of Three Wishes","Robe of the Archmagi","Talisman of Pure Good","Deck of Many Things","Sphere of Annihilation","Rod of Lordly Might","Apparatus of Kwalish"],
};

function generateTreasureHoard(rng, cr) {
  const coins = {
    copper: cr < 5 ? randInt(100, 600, rng) : 0,
    silver: cr < 10 ? randInt(50, 300, rng) : randInt(0, 100, rng),
    gold: randInt(cr * 10, cr * 100, rng),
    platinum: cr >= 10 ? randInt(1, cr * 5, rng) : 0,
  };
  const gems = [];
  const gemCount = randInt(0, Math.ceil(cr / 3), rng);
  const gemTypes = ["Ruby","Sapphire","Emerald","Diamond","Amethyst","Topaz","Opal","Pearl","Garnet","Aquamarine","Tourmaline","Jade","Moonstone","Bloodstone","Tiger's Eye","Lapis Lazuli"];
  for (let i = 0; i < gemCount; i++) {
    gems.push({ type: pick(gemTypes, rng), value: randInt(10, cr * 50, rng) });
  }
  const items = [];
  const itemCount = randInt(0, Math.ceil(cr / 5) + 1, rng);
  for (let i = 0; i < itemCount; i++) {
    const rarity = cr < 5 ? "common" : cr < 10 ? (rng() < 0.6 ? "uncommon" : "common") : cr < 15 ? (rng() < 0.5 ? "rare" : "uncommon") : (rng() < 0.3 ? "veryRare" : "rare");
    items.push({ name: pick(MAGIC_ITEMS[rarity], rng), rarity });
  }
  return { coins, gems, items, totalGPValue: coins.gold + coins.platinum * 10 + coins.silver / 10 + gems.reduce((s, g) => s + g.value, 0) };
}

// ─── TERRAIN GENERATION ENGINE ──────────────────────────────────────────────

function generateHeightmap(width, height, rng, octaves, persistence, lacunarity) {
  const grid = Array.from({ length: height }, () => new Float32Array(width));
  for (let oct = 0; oct < octaves; oct++) {
    const freq = Math.pow(lacunarity, oct);
    const amp = Math.pow(persistence, oct);
    const noiseW = Math.ceil(width / (32 / freq)) + 2;
    const noiseH = Math.ceil(height / (32 / freq)) + 2;
    const noise = Array.from({ length: noiseH }, () => {
      const row = new Float32Array(noiseW);
      for (let i = 0; i < noiseW; i++) row[i] = rng();
      return row;
    });
    const cellSize = 32 / freq;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const nx = x / cellSize, ny = y / cellSize;
        const ix = Math.floor(nx), iy = Math.floor(ny);
        const fx = nx - ix, fy = ny - iy;
        const sx = smoothstep(fx), sy = smoothstep(fy);
        const n00 = noise[iy % noiseH]?.[ix % noiseW] || 0;
        const n10 = noise[iy % noiseH]?.[(ix + 1) % noiseW] || 0;
        const n01 = noise[(iy + 1) % noiseH]?.[ix % noiseW] || 0;
        const n11 = noise[(iy + 1) % noiseH]?.[(ix + 1) % noiseW] || 0;
        grid[y][x] += ((n00*(1-sx)+n10*sx)*(1-sy)+(n01*(1-sx)+n11*sx)*sy) * amp;
      }
    }
  }
  let min = Infinity, max = -Infinity;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) { if (grid[y][x]<min) min=grid[y][x]; if (grid[y][x]>max) max=grid[y][x]; }
  const range = max - min || 1;
  for (let y = 0; y < height; y++) for (let x = 0; x < width; x++) grid[y][x] = (grid[y][x] - min) / range;
  return grid;
}

// Hydraulic erosion simulation
function applyErosion(heightmap, width, height, rng, iterations) {
  const inertia = 0.3, capacity = 8, deposition = 0.02, erosionRate = 0.3, evaporation = 0.01, gravity = 4, minSlope = 0.01;
  for (let iter = 0; iter < iterations; iter++) {
    let px = rng() * (width - 2) + 1, py = rng() * (height - 2) + 1;
    let dx = 0, dy = 0, speed = 1, water = 1, sediment = 0;
    for (let step = 0; step < 64; step++) {
      const ix = Math.floor(px), iy = Math.floor(py);
      if (ix < 1 || ix >= width-1 || iy < 1 || iy >= height-1) break;
      const fx = px - ix, fy = py - iy;
      // Gradient
      const h00 = heightmap[iy][ix], h10 = heightmap[iy][ix+1], h01 = heightmap[iy+1][ix], h11 = heightmap[iy+1][ix+1];
      const gx = (h10-h00)*(1-fy)+(h11-h01)*fy;
      const gy = (h01-h00)*(1-fx)+(h11-h10)*fx;
      dx = dx*inertia - gx*(1-inertia);
      dy = dy*inertia - gy*(1-inertia);
      const len = Math.sqrt(dx*dx+dy*dy);
      if (len < 0.0001) break;
      dx /= len; dy /= len;
      const npx = px + dx, npy = py + dy;
      if (npx < 1 || npx >= width-1 || npy < 1 || npy >= height-1) break;
      const oldH = h00*(1-fx)*(1-fy)+h10*fx*(1-fy)+h01*(1-fx)*fy+h11*fx*fy;
      const nix = Math.floor(npx), niy = Math.floor(npy), nfx = npx-nix, nfy = npy-niy;
      const newH = (heightmap[niy]?.[nix]||0)*(1-nfx)*(1-nfy)+(heightmap[niy]?.[nix+1]||0)*nfx*(1-nfy)+(heightmap[niy+1]?.[nix]||0)*(1-nfx)*nfy+(heightmap[niy+1]?.[nix+1]||0)*nfx*nfy;
      const dh = newH - oldH;
      const cap = Math.max(-dh, minSlope) * speed * water * capacity;
      if (sediment > cap || dh > 0) {
        const deposit = dh > 0 ? Math.min(sediment, dh) : (sediment - cap) * deposition;
        sediment -= deposit;
        heightmap[iy][ix] += deposit * (1-fx)*(1-fy);
        heightmap[iy][ix+1] += deposit * fx*(1-fy);
        heightmap[iy+1][ix] += deposit * (1-fx)*fy;
        heightmap[iy+1][ix+1] += deposit * fx*fy;
      } else {
        const erode = Math.min((cap-sediment)*erosionRate, -dh);
        sediment += erode;
        heightmap[iy][ix] -= erode*(1-fx)*(1-fy);
        heightmap[iy][ix+1] -= erode*fx*(1-fy);
        heightmap[iy+1][ix] -= erode*(1-fx)*fy;
        heightmap[iy+1][ix+1] -= erode*fx*fy;
      }
      speed = Math.sqrt(Math.max(0, speed*speed + dh*gravity));
      water *= (1 - evaporation);
      px = npx; py = npy;
    }
  }
  return heightmap;
}

function generateMoisture(w, h, rng) { return generateHeightmap(w, h, rng, 4, 0.6, 2.2); }

function generateTemperature(w, h, rng, latBias) {
  const base = generateHeightmap(w, h, rng, 3, 0.5, 2.0);
  if (latBias) for (let y = 0; y < h; y++) { const lat = Math.abs(y/h-0.5)*2; for (let x = 0; x < w; x++) base[y][x] = base[y][x]*0.4+(1-lat)*0.6; }
  return base;
}

// Wind map for weather patterns
function generateWindMap(w, h, rng) {
  const base = generateHeightmap(w, h, rng, 3, 0.4, 2.0);
  // Prevailing westerlies pattern
  for (let y = 0; y < h; y++) {
    const lat = (y / h - 0.5) * 2;
    for (let x = 0; x < w; x++) {
      base[y][x] = base[y][x] * 0.5 + (0.5 + 0.3 * Math.cos(lat * Math.PI)) * 0.5;
    }
  }
  return base;
}

// ─── BIOME SYSTEM ───────────────────────────────────────────────────────────

const BIOMES = {
  deepOcean:    { color:"#0f2a47", label:"Deep Ocean",      iconColor:"#1a3a5c" },
  ocean:        { color:"#1a4570", label:"Ocean",            iconColor:"#2a5a8c" },
  shallows:     { color:"#2a6898", label:"Shallow Water",    iconColor:"#3a7ab0" },
  beach:        { color:"#d4c088", label:"Beach",            iconColor:"#c8b070" },
  tundra:       { color:"#b8c8d0", label:"Tundra",           iconColor:"#a0b0b8" },
  snowfield:    { color:"#dde8f0", label:"Snowfield",        iconColor:"#c8d4dc" },
  grassland:    { color:"#6d9858", label:"Grassland",        iconColor:"#5a8048" },
  plains:       { color:"#98b060", label:"Plains",           iconColor:"#88a050" },
  savanna:      { color:"#b8a040", label:"Savanna",          iconColor:"#a89030" },
  desert:       { color:"#c49850", label:"Desert",           iconColor:"#b48840" },
  forest:       { color:"#3a6830", label:"Temperate Forest", iconColor:"#2a5820" },
  denseForest:  { color:"#1d4818", label:"Dense Forest",     iconColor:"#0d3808" },
  jungle:       { color:"#1a5028", label:"Jungle",           iconColor:"#0a4018" },
  swamp:        { color:"#3a5830", label:"Swamp",            iconColor:"#2a4820" },
  hills:        { color:"#7a8a50", label:"Hills",            iconColor:"#6a7a40" },
  highlands:    { color:"#8a7a58", label:"Highlands",        iconColor:"#7a6a48" },
  mountain:     { color:"#706860", label:"Mountain",         iconColor:"#605850" },
  snowMountain: { color:"#c0c8cc", label:"Snow Peak",        iconColor:"#a8b0b4" },
  volcanic:     { color:"#4a2828", label:"Volcanic",         iconColor:"#3a1818" },
  taiga:        { color:"#2a5038", label:"Taiga",            iconColor:"#1a4028" },
  steppe:       { color:"#a8a060", label:"Steppe",           iconColor:"#989050" },
  mesa:         { color:"#b07040", label:"Mesa",             iconColor:"#a06030" },
  oasis:        { color:"#48884a", label:"Oasis",            iconColor:"#38783a" },
  reef:         { color:"#28889a", label:"Coral Reef",       iconColor:"#18787a" },
  glacier:      { color:"#a8d0e8", label:"Glacier",          iconColor:"#90b8d0" },
  marshland:    { color:"#506838", label:"Marshland",        iconColor:"#405828" },
  badlands:     { color:"#8a5838", label:"Badlands",         iconColor:"#7a4828" },
};

function classifyBiome(h, m, t) {
  if (h < 0.20) return "deepOcean";
  if (h < 0.30) return "ocean";
  if (h < 0.35) { if (m > 0.7) return "reef"; return "shallows"; }
  if (h > 0.90) return "snowMountain";
  if (h > 0.82 && m < 0.2 && t > 0.6) return "volcanic";
  if (h > 0.82) return "glacier";
  if (h > 0.72) return "mountain";
  if (h > 0.65) return "highlands";
  if (h > 0.58) return "hills";
  if (h < 0.40) {
    if (m > 0.7 && t > 0.4) return "swamp";
    if (m > 0.5 && t > 0.3) return "marshland";
    if (t < 0.2) return "tundra";
    return "beach";
  }
  if (t < 0.15) return m > 0.3 ? "snowfield" : "tundra";
  if (t < 0.30) return m > 0.4 ? "taiga" : "tundra";
  if (t > 0.55 && m < 0.10) return h > 0.55 ? "mesa" : "desert";
  if (t > 0.55 && m < 0.12 && rng_temp_hack(h) > 0.5) return "badlands";
  if (t > 0.60 && m < 0.30) return "savanna";
  if (t > 0.50 && m < 0.20) return "steppe";
  if (t > 0.70 && m > 0.70) return "jungle";
  if (m > 0.75) return "denseForest";
  if (m > 0.50) return "forest";
  if (m > 0.25) return "grassland";
  return "plains";
}

// Hack to add variety without extra rng param
function rng_temp_hack(h) { return (Math.sin(h * 127.1) * 43758.5453) % 1; }

// PART 1: WEATHER SYSTEM (~300 lines)
// ═══════════════════════════════════════════════════════════════════════════

const WEATHER_TYPES = {
  clear: {
    name: "Clear Skies",
    description: "Perfect weather with clear visibility",
    effects: { visibility: 1.0, travelSpeed: 1.0, combatMod: 0 },
    severity: 1,
    seasonWeights: { spring: 0.35, summer: 0.45, autumn: 0.40, winter: 0.25 }
  },
  overcast: {
    name: "Overcast",
    description: "Cloudy skies, potential for rain",
    effects: { visibility: 0.8, travelSpeed: 1.0, combatMod: 0 },
    severity: 1,
    seasonWeights: { spring: 0.30, summer: 0.20, autumn: 0.35, winter: 0.30 }
  },
  lightRain: {
    name: "Light Rain",
    description: "Gentle rainfall, nothing too severe",
    effects: { visibility: 0.7, travelSpeed: 0.9, combatMod: -1 },
    severity: 1,
    seasonWeights: { spring: 0.20, summer: 0.10, autumn: 0.15, winter: 0.10 }
  },
  rain: {
    name: "Rain",
    description: "Moderate rainfall, travel is hindered",
    effects: { visibility: 0.6, travelSpeed: 0.75, combatMod: -2 },
    severity: 2,
    seasonWeights: { spring: 0.15, summer: 0.08, autumn: 0.12, winter: 0.08 }
  },
  heavyRain: {
    name: "Heavy Rain",
    description: "Severe downpour, difficult conditions",
    effects: { visibility: 0.4, travelSpeed: 0.5, combatMod: -3 },
    severity: 3,
    seasonWeights: { spring: 0.05, summer: 0.02, autumn: 0.08, winter: 0.05 }
  },
  thunderstorm: {
    name: "Thunderstorm",
    description: "Lightning and thunder, dangerous conditions",
    effects: { visibility: 0.5, travelSpeed: 0.3, combatMod: -4 },
    severity: 4,
    seasonWeights: { spring: 0.08, summer: 0.15, autumn: 0.05, winter: 0.02 }
  },
  blizzard: {
    name: "Blizzard",
    description: "Severe snow and wind, visibility nearly gone",
    effects: { visibility: 0.2, travelSpeed: 0.2, combatMod: -5 },
    severity: 5,
    seasonWeights: { spring: 0.02, summer: 0.0, autumn: 0.01, winter: 0.40 }
  },
  hail: {
    name: "Hail",
    description: "Ice stones fall from sky, painful conditions",
    effects: { visibility: 0.5, travelSpeed: 0.4, combatMod: -3 },
    severity: 3,
    seasonWeights: { spring: 0.08, summer: 0.05, autumn: 0.06, winter: 0.15 }
  },
  fog: {
    name: "Fog",
    description: "Dense mist reduces visibility severely",
    effects: { visibility: 0.3, travelSpeed: 0.6, combatMod: -2 },
    severity: 2,
    seasonWeights: { spring: 0.12, summer: 0.08, autumn: 0.15, winter: 0.10 }
  },
  mist: {
    name: "Mist",
    description: "Light mist hangs in the air",
    effects: { visibility: 0.65, travelSpeed: 0.85, combatMod: -1 },
    severity: 1,
    seasonWeights: { spring: 0.15, summer: 0.05, autumn: 0.12, winter: 0.08 }
  },
  sandstorm: {
    name: "Sandstorm",
    description: "Whirling sand blinds all who venture out",
    effects: { visibility: 0.25, travelSpeed: 0.3, combatMod: -4 },
    severity: 4,
    seasonWeights: { spring: 0.15, summer: 0.30, autumn: 0.20, winter: 0.05 }
  },
  tornado: {
    name: "Tornado",
    description: "Devastating winds tear across the land",
    effects: { visibility: 0.1, travelSpeed: 0.0, combatMod: -6 },
    severity: 5,
    seasonWeights: { spring: 0.12, summer: 0.10, autumn: 0.08, winter: 0.01 }
  },
  hurricane: {
    name: "Hurricane",
    description: "Catastrophic storm with extreme destruction",
    effects: { visibility: 0.05, travelSpeed: 0.0, combatMod: -6 },
    severity: 5,
    seasonWeights: { spring: 0.02, summer: 0.08, autumn: 0.15, winter: 0.01 }
  },
  arcaneStorm: {
    name: "Arcane Storm",
    description: "Magical energies crackle through the air",
    effects: { visibility: 0.55, travelSpeed: 0.5, combatMod: -2 },
    severity: 3,
    seasonWeights: { spring: 0.05, summer: 0.05, autumn: 0.05, winter: 0.05 }
  },
  bloodRain: {
    name: "Blood Rain",
    description: "Red rain falls from cursed skies",
    effects: { visibility: 0.45, travelSpeed: 0.4, combatMod: -3 },
    severity: 4,
    seasonWeights: { spring: 0.02, summer: 0.02, autumn: 0.02, winter: 0.02 }
  },
  feyMist: {
    name: "Fey Mist",
    description: "Otherworldly mist with reality-bending properties",
    effects: { visibility: 0.25, travelSpeed: 0.5, combatMod: -2 },
    severity: 3,
    seasonWeights: { spring: 0.08, summer: 0.05, autumn: 0.08, winter: 0.03 }
  },
  ashFall: {
    name: "Ash Fall",
    description: "Volcanic ash covers everything in sight",
    effects: { visibility: 0.4, travelSpeed: 0.6, combatMod: -2 },
    severity: 3,
    seasonWeights: { spring: 0.08, summer: 0.10, autumn: 0.08, winter: 0.08 }
  },
  earthquake: {
    name: "Earthquake",
    description: "Ground shakes violently, terrain unstable",
    effects: { visibility: 0.6, travelSpeed: 0.2, combatMod: -4 },
    severity: 4,
    seasonWeights: { spring: 0.05, summer: 0.05, autumn: 0.05, winter: 0.05 }
  },
  drought: {
    name: "Drought",
    description: "Extreme heat and dryness",
    effects: { visibility: 0.9, travelSpeed: 0.5, combatMod: -2 },
    severity: 3,
    seasonWeights: { spring: 0.05, summer: 0.40, autumn: 0.10, winter: 0.01 }
  },
  heatWave: {
    name: "Heat Wave",
    description: "Oppressive, sweltering temperatures",
    effects: { visibility: 0.85, travelSpeed: 0.6, combatMod: -1 },
    severity: 2,
    seasonWeights: { spring: 0.08, summer: 0.35, autumn: 0.10, winter: 0.01 }
  },
  coldSnap: {
    name: "Cold Snap",
    description: "Brutal cold freezes all moisture",
    effects: { visibility: 0.75, travelSpeed: 0.4, combatMod: -2 },
    severity: 3,
    seasonWeights: { spring: 0.03, summer: 0.01, autumn: 0.05, winter: 0.35 }
  },
  acidRain: {
    name: "Acid Rain",
    description: "Corrosive rain burns exposed skin",
    effects: { visibility: 0.55, travelSpeed: 0.5, combatMod: -3 },
    severity: 4,
    seasonWeights: { spring: 0.02, summer: 0.03, autumn: 0.02, winter: 0.01 }
  },
  meteorShower: {
    name: "Meteor Shower",
    description: "Falling meteors light the sky",
    effects: { visibility: 0.8, travelSpeed: 0.3, combatMod: -4 },
    severity: 4,
    seasonWeights: { spring: 0.02, summer: 0.03, autumn: 0.04, winter: 0.02 }
  },
  aurora: {
    name: "Aurora",
    description: "Dancing lights paint the sky beautifully",
    effects: { visibility: 0.9, travelSpeed: 1.0, combatMod: 1 },
    severity: 1,
    seasonWeights: { spring: 0.10, summer: 0.05, autumn: 0.10, winter: 0.20 }
  },
  eclipse: {
    name: "Eclipse",
    description: "Moon blocks sun, day becomes night",
    effects: { visibility: 0.3, travelSpeed: 0.7, combatMod: -2 },
    severity: 2,
    seasonWeights: { spring: 0.02, summer: 0.02, autumn: 0.02, winter: 0.02 }
  },
  planarRift: {
    name: "Planar Rift",
    description: "Dimensions begin to overlap dangerously",
    effects: { visibility: 0.2, travelSpeed: 0.2, combatMod: -5 },
    severity: 5,
    seasonWeights: { spring: 0.01, summer: 0.01, autumn: 0.01, winter: 0.01 }
  },
  wildMagic: {
    name: "Wild Magic Surge",
    description: "Magic runs wild and unpredictable",
    effects: { visibility: 0.65, travelSpeed: 0.5, combatMod: -3 },
    severity: 4,
    seasonWeights: { spring: 0.04, summer: 0.04, autumn: 0.04, winter: 0.04 }
  },
  divineRadiance: {
    name: "Divine Radiance",
    description: "Holy light bathes the land",
    effects: { visibility: 1.2, travelSpeed: 1.1, combatMod: 2 },
    severity: 1,
    seasonWeights: { spring: 0.08, summer: 0.08, autumn: 0.08, winter: 0.08 }
  },
  shadowCreep: {
    name: "Shadow Creep",
    description: "Unnatural darkness spreads across landscape",
    effects: { visibility: 0.1, travelSpeed: 0.3, combatMod: -4 },
    severity: 4,
    seasonWeights: { spring: 0.03, summer: 0.02, autumn: 0.04, winter: 0.08 }
  },
  timeDistortion: {
    name: "Time Distortion",
    description: "Time flows strangely, causing temporal anomalies",
    effects: { visibility: 0.65, travelSpeed: 0.0, combatMod: -5 },
    severity: 5,
    seasonWeights: { spring: 0.01, summer: 0.01, autumn: 0.01, winter: 0.01 }
  },
  gravityFlux: {
    name: "Gravity Flux",
    description: "Gravity becomes unpredictable and unstable",
    effects: { visibility: 0.75, travelSpeed: 0.1, combatMod: -4 },
    severity: 4,
    seasonWeights: { spring: 0.02, summer: 0.02, autumn: 0.02, winter: 0.02 }
  },
  crystalRain: {
    name: "Crystal Rain",
    description: "Crystalline shards fall from sky like rain",
    effects: { visibility: 0.5, travelSpeed: 0.4, combatMod: -3 },
    severity: 3,
    seasonWeights: { spring: 0.04, summer: 0.04, autumn: 0.04, winter: 0.10 }
  },
};

function generateWeather(rng, biome, season) {
  const weatherKeys = Object.keys(WEATHER_TYPES);
  let totalWeight = 0;
  const weights = [];

  weatherKeys.forEach(key => {
    const seasonKey = season || "spring";
    const weight = WEATHER_TYPES[key].seasonWeights[seasonKey] || 0.05;
    weights.push(weight);
    totalWeight += weight;
  });

  let rand = rng() * totalWeight;
  for (let i = 0; i < weatherKeys.length; i++) {
    rand -= weights[i];
    if (rand <= 0) {
      const key = weatherKeys[i];
      return {
        type: key,
        ...WEATHER_TYPES[key],
        temperature: randRange(5, 35, rng),
        windSpeed: randRange(0, 100, rng),
        humidity: randRange(0, 1, rng),
      };
    }
  }

  return { type: "clear", ...WEATHER_TYPES.clear, temperature: 20, windSpeed: 10, humidity: 0.5 };
}

function generateWeatherForecast(rng, biome, season, days) {
  const forecast = [];
  for (let i = 0; i < days; i++) {
    forecast.push(generateWeather(rng, biome, season));
  }
  return forecast;
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 2: CALENDAR & TIME (~200 lines)
// ═══════════════════════════════════════════════════════════════════════════

const CALENDAR = {
  months: [
    { name: "Winterhold", days: 31, season: "winter" },
    { name: "Frostwind", days: 28, season: "winter" },
    { name: "Thawspring", days: 31, season: "spring" },
    { name: "Greensap", days: 30, season: "spring" },
    { name: "Bloomtide", days: 31, season: "spring" },
    { name: "Sunpeak", days: 30, season: "summer" },
    { name: "Summertide", days: 31, season: "summer" },
    { name: "Harvestmoon", days: 31, season: "summer" },
    { name: "Goldleaf", days: 30, season: "autumn" },
    { name: "Fallbringer", days: 31, season: "autumn" },
    { name: "Darkmoon", days: 30, season: "autumn" },
    { name: "Deathwinter", days: 31, season: "winter" }
  ],
  holidays: [
    { name: "New Year's Dawn", month: 0, day: 1 },
    { name: "Festival of Thaw", month: 2, day: 15 },
    { name: "Spring Equinox", month: 3, day: 21 },
    { name: "Midsummer's Eve", month: 6, day: 15 },
    { name: "Harvest Festival", month: 8, day: 1 },
    { name: "Autumn Equinox", month: 10, day: 21 },
    { name: "Winter Solstice", month: 11, day: 21 },
    { name: "Day of Ancestors", month: 11, day: 10 },
    { name: "Foundation Day", month: 1, day: 14 },
    { name: "Festival of Blooms", month: 4, day: 10 },
    { name: "Midsummer Festival", month: 7, day: 1 },
    { name: "Harvest Moon Night", month: 8, day: 20 },
    { name: "All Spirits Eve", month: 11, day: 29 },
    { name: "First Snow", month: 0, day: 10 },
    { name: "Kindling Night", month: 0, day: 25 },
  ],
  moonPhases: ["New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous", "Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent"],
};

function getCurrentDate(dayNumber) {
  let day = dayNumber || 0;
  let month = 0;

  while (day >= CALENDAR.months[month].days) {
    day -= CALENDAR.months[month].days;
    month++;
    if (month >= CALENDAR.months.length) month = 0;
  }

  return {
    day: day + 1,
    month: month,
    monthName: CALENDAR.months[month].name,
    season: CALENDAR.months[month].season,
    year: Math.floor(dayNumber / 365),
  };
}

function getMoonPhase(dayNumber) {
  const phase = Math.floor((dayNumber % 28) / 3.5);
  return CALENDAR.moonPhases[phase] || "New Moon";
}

function getHoliday(month, day) {
  const holiday = CALENDAR.holidays.find(h => h.month === month && h.day === day);
  return holiday ? holiday.name : null;
}

function getSeasonalModifiers(season) {
  const modifiers = {
    spring: { cropGrowth: 1.3, travelDifficulty: 0.9, diseaseRisk: 0.8 },
    summer: { cropGrowth: 1.5, travelDifficulty: 1.0, diseaseRisk: 1.0 },
    autumn: { cropGrowth: 0.8, travelDifficulty: 0.95, diseaseRisk: 0.9 },
    winter: { cropGrowth: 0.2, travelDifficulty: 1.4, diseaseRisk: 1.3 },
  };
  return modifiers[season] || modifiers.summer;
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 3: DEITY & RELIGION (~400 lines)
// ═══════════════════════════════════════════════════════════════════════════

const DEITY_DOMAINS = [
  "War", "Agriculture", "Magic", "Death", "Love", "Trickery", "Forge", "Tempest",
  "Knowledge", "Life", "Light", "Darkness", "Healing", "Vengeance", "Nature", "Sea",
  "Sky", "Crafts", "Abundance", "Prophecy", "Music", "Art", "Thieves", "Beasts",
  "Fertility", "Chaos", "Order", "Luck", "Madness", "Twilight", "Dreams", "Secrets"
];

const DEITY_ALIGNMENTS = ["LG", "NG", "CG", "LN", "N", "CN", "LE", "NE", "CE"];

const SACRED_ANIMALS = [
  "Eagle", "Wolf", "Bear", "Serpent", "Lion", "Raven", "Swan", "Stag", "Boar", "Owl",
  "Dragon", "Phoenix", "Goat", "Horse", "Fish", "Spider", "Crow", "Falcon", "Tiger", "Badger",
  "Fox", "Hare", "Deer", "Buffalo", "Elephant", "Peacock", "Hawk", "Dove", "Tortoise", "Lamb"
];

const FAVORED_WEAPONS = [
  "Longsword", "Greatsword", "Mace", "Morningstar", "Flail", "Spear", "Halberd", "Warhammer",
  "Battleaxe", "Scimitar", "Rapier", "Dagger", "Quarterstaff", "Club", "Maul", "Pike",
  "Trident", "Javelin", "Bow", "Crossbow", "Whip", "Chain", "Sickle", "Scythe", "Glaive", "Nunchuk",
  "Katana", "Broadsword", "Cutlass", "Goshawk"
];

const COMMANDMENTS = [
  "Seek justice and punish the wicked",
  "Protect the innocent and defend the weak",
  "Honor your oaths and agreements",
  "Spread knowledge and wisdom",
  "Embrace nature and live in harmony with the land",
  "Seek pleasure and avoid pain",
  "Live in secret and work from the shadows",
  "Accumulate wealth and power",
  "Bring chaos and disorder to the world",
  "Embrace freedom and resist tyranny",
  "Serve the divine and obey the gods",
  "Create beauty and art in all things",
  "Heal the sick and mend the wounded",
  "Celebrate life and all its richness",
  "Preserve ancient knowledge and traditions",
  "Explore and discover new lands",
  "Build and create lasting monuments",
  "Maintain balance and equilibrium",
  "Guard secrets and hide the truth",
  "Seek enlightenment and transcendence"
];

function generatePantheon(rng, count) {
  count = count || 12;
  const pantheon = [];
  const usedDomains = new Set();

  for (let i = 0; i < count; i++) {
    let domain = pick(DEITY_DOMAINS, rng);
    while (usedDomains.has(domain)) {
      domain = pick(DEITY_DOMAINS, rng);
    }
    usedDomains.add(domain);

    const god = {
      name: genKingdomName(rng),
      domain: domain,
      alignment: pick(DEITY_ALIGNMENTS, rng),
      symbol: pick(["Crescent Moon", "Five Pointed Star", "Circle", "Triangle", "Square", "Spiral", "Cross", "Flame", "Leaf", "Wave"], rng),
      description: `The deity of ${domain.toLowerCase()}`,
      commandments: pickN(COMMANDMENTS, 3, rng),
      sacredAnimal: pick(SACRED_ANIMALS, rng),
      favoredWeapon: pick(FAVORED_WEAPONS, rng),
      followers: randInt(100, 100000, rng),
      temples: randInt(1, 50, rng),
    };

    pantheon.push(god);
  }

  return pantheon;
}

function generateReligion(rng) {
  const pantheon = generatePantheon(rng, randInt(3, 12, rng));
  return {
    name: genKingdomName(rng) + " Faith",
    pantheon: pantheon,
    primaryDeity: pantheon[0],
    practitioners: randInt(1000, 1000000, rng),
    temples: randInt(5, 100, rng),
    clergy: randInt(10, 500, rng),
    values: pickN(COMMANDMENTS, 5, rng),
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 4: FACTION SYSTEM (~400 lines)
// ═══════════════════════════════════════════════════════════════════════════

const FACTION_TYPES = [
  "Thieves Guild", "Merchant Consortium", "Adventurer's Company", "Military Order", "Religious Order",
  "Craft Guild", "Scholarly Academy", "Noble House", "Criminal Syndicate", "Mercenary Band",
  "Wizard's Circle", "Ranger's Lodge", "Druid Enclave", "Bardic College", "Monastic Order",
  "Secret Society", "Political Movement", "Trade League", "Mercenary Company", "Pirate Crew"
];

const FACTION_GOALS = [
  "Accumulate wealth and power",
  "Gain political influence",
  "Expand territory",
  "Protect members",
  "Preserve ancient knowledge",
  "Achieve enlightenment",
  "Spread their faith",
  "Create chaos and disorder",
  "Maintain law and order",
  "Seek vengeance",
  "Support the poor",
  "Exploit the weak",
  "Discover magical secrets",
  "Recover lost artifacts",
  "Unite the fractured peoples",
  "Conquer rival factions",
  "Maintain peace",
  "Bring about the apocalypse",
  "Perfect their craft",
  "Understand the mysteries of the universe"
];

const FACTION_METHODS = [
  "Bribery and corruption",
  "Violence and intimidation",
  "Diplomacy and negotiation",
  "Espionage and manipulation",
  "Economic leverage",
  "Magic and sorcery",
  "Religious conversion",
  "Community service",
  "Mercenary contracts",
  "Underground networks",
  "Political campaigns",
  "Assassination",
  "Theft and robbery",
  "Sabotage",
  "Research and study",
  "Charity and aid",
  "Trade and commerce",
  "Military conquest",
  "Cultural influence",
  "Blackmail and extortion"
];

const FACTION_RANKS = [
  "Initiate",
  "Apprentice",
  "Member",
  "Adept",
  "Master",
  "Elder",
  "Council Member",
  "Inner Circle",
  "High Council",
  "Grand Master"
];

const FACTION_SECRETS = [
  "Hidden treasure",
  "Blackmail material",
  "Forbidden knowledge",
  "Prophecy",
  "Magical artifact location",
  "Powerful magic",
  "Ancient curse",
  "Dark ritual",
  "Conspiracy",
  "Murder",
  "Betrayal",
  "Forbidden love",
  "Illegitimate heir",
  "Reincarnation",
  "Portal to another realm"
];

function generateFaction(rng, type) {
  type = type || pick(FACTION_TYPES, rng);
  const leader = generateNPC(rng);
  const ranks = seededShuffle(FACTION_RANKS, rng);

  return {
    name: genKingdomName(rng),
    type: type,
    leader: leader,
    ranks: ranks.slice(0, randInt(5, 10, rng)),
    members: randInt(10, 1000, rng),
    goals: pickN(FACTION_GOALS, randInt(1, 3, rng), rng),
    methods: pickN(FACTION_METHODS, randInt(1, 4, rng), rng),
    allies: [],
    enemies: [],
    secrets: pickN(FACTION_SECRETS, randInt(1, 3, rng), rng),
    motto: "\"" + pick(["Blood", "Honor", "Gold", "Magic", "Justice", "Power", "Truth", "Freedom", "Unity", "Victory"], rng) + " above all\"",
    influence: randInt(0, 100, rng),
    resources: {
      gold: randInt(1000, 1000000, rng),
      items: randInt(0, 50, rng),
      information: randInt(0, 100, rng)
    }
  };
}

function generateFactionRelations(rng, factions) {
  const relations = {};

  for (let i = 0; i < factions.length; i++) {
    for (let j = i + 1; j < factions.length; j++) {
      const relation = randInt(-100, 100, rng);
      const key = i + "-" + j;

      relations[key] = {
        faction1: i,
        faction2: j,
        relation: relation,
        status: relation > 50 ? "Ally" : relation < -50 ? "Enemy" : "Neutral"
      };
    }
  }

  return relations;
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 5: QUEST GENERATION (~500 lines)
// ═══════════════════════════════════════════════════════════════════════════

const QUEST_TYPES = {
  rescue: {
    name: "Rescue Quest",
    template: "Rescue {TARGET} from {LOCATION}",
    complications: ["Guarded heavily", "Trap-filled", "Time limit", "Deceiver involved"]
  },
  retrieve: {
    name: "Retrieval Quest",
    template: "Retrieve {OBJECT} from {LOCATION}",
    complications: ["Cursed", "Guarded by monster", "Fragile", "Multiple owners"]
  },
  protect: {
    name: "Protection Quest",
    template: "Protect {TARGET} from {THREAT}",
    complications: ["Threat larger than expected", "Traitor in group", "Supplies running low", "Unexpected arrival"]
  },
  explore: {
    name: "Exploration Quest",
    template: "Explore {LOCATION} and map it",
    complications: ["Dangerous creatures", "Environmental hazards", "Haunted", "Cursed"]
  },
  investigate: {
    name: "Investigation Quest",
    template: "Investigate {MYSTERY} at {LOCATION}",
    complications: ["Clues are misleading", "Witnesses lie", "Evidence destroyed", "Culprit has power"]
  },
  defeat: {
    name: "Defeat Quest",
    template: "Defeat {ENEMY} at {LOCATION}",
    complications: ["Enemy has allies", "Enemy is immortal", "Collateral damage risk", "Enemy is clever"]
  },
  escort: {
    name: "Escort Quest",
    template: "Escort {TARGET} to {LOCATION}",
    complications: ["Slow pace", "Ambushes", "Target is difficult", "Enemy pursuit"]
  },
  gather: {
    name: "Gathering Quest",
    template: "Gather {AMOUNT} of {ITEM}",
    complications: ["Rare item", "Dangerous location", "Limited time", "Competitors"]
  },
  negotiate: {
    name: "Negotiation Quest",
    template: "Negotiate peace between {FACTION1} and {FACTION2}",
    complications: ["Both sides hostile", "Trust issues", "Third party interference", "Demands unreasonable"]
  },
  sabotage: {
    name: "Sabotage Quest",
    template: "Sabotage {TARGET} at {LOCATION}",
    complications: ["Heavy guard", "Detection penalty", "Important innocents", "Replacement of target"]
  },
  hunt: {
    name: "Hunting Quest",
    template: "Hunt down {CREATURE} in {LOCATION}",
    complications: ["Intelligent prey", "Multiple creatures", "Endangered species", "Collateral risk"]
  },
  defend: {
    name: "Defense Quest",
    template: "Defend {LOCATION} from {THREAT}",
    complications: ["Overwhelming numbers", "Supply shortage", "Morale low", "Unexpected reinforcements"]
  },
  cure: {
    name: "Cure Quest",
    template: "Find cure for {DISEASE} afflicting {LOCATION}",
    complications: ["Cure is dangerous", "Ingredients rare", "Dark ritual needed", "Time pressure"]
  },
  steal: {
    name: "Theft Quest",
    template: "Steal {OBJECT} from {TARGET}",
    complications: ["Heavily guarded", "Magical protection", "Owner knows theft", "Multiple thieves"]
  },
  build: {
    name: "Construction Quest",
    template: "Build {STRUCTURE} in {LOCATION}",
    complications: ["Supplies scarce", "Hostile locals", "Terrain difficult", "Funding issues"]
  },
  undo: {
    name: "Undo Quest",
    template: "Undo the curse of {VICTIM} in {LOCATION}",
    complications: ["Curse complex", "Caster powerful", "Victim dying", "Side effects"]
  },
  find: {
    name: "Search Quest",
    template: "Find {PERSON} who is {LOST}",
    complications: ["Person doesn't want to be found", "Dangerous location", "False trails", "Person changed"]
  },
  deliver: {
    name: "Delivery Quest",
    template: "Deliver {ITEM} to {TARGET}",
    complications: ["Item is dangerous", "Recipient far away", "Thieves pursuing", "Item wants to stay put"]
  },
  purify: {
    name: "Purification Quest",
    template: "Purify {LOCATION} of {CORRUPTION}",
    complications: ["Source very powerful", "Innocents harmed", "Ritual required", "Corruption returns"]
  },
  awaken: {
    name: "Awakening Quest",
    template: "Awaken {ENTITY} from slumber",
    complications: ["Risky ritual", "Entity is dangerous", "Guardian opposition", "Unknown consequences"]
  },
};

const QUEST_REWARDS = [
  "Gold", "Magic Item", "Land", "Title", "Magical Knowledge", "Favor", "Artifact",
  "Blessing", "Curse Lifted", "Information", "Recruitment", "Alliance", "Safe Haven"
];

function generateQuest(rng, difficulty, context) {
  difficulty = difficulty || "medium";
  const questType = pick(Object.keys(QUEST_TYPES), rng);
  const quest = {
    type: questType,
    name: QUEST_TYPES[questType].name,
    template: QUEST_TYPES[questType].template,
    difficulty: difficulty,
    reward: pick(QUEST_REWARDS, rng),
    rewardAmount: randInt(50, 5000, rng),
    complications: pickN(QUEST_TYPES[questType].complications, randInt(1, 2, rng), rng),
    objectives: [],
    hooks: [],
    secrets: []
  };

  if (difficulty === "easy") quest.rewardAmount *= 0.5;
  if (difficulty === "hard") quest.rewardAmount *= 2;
  if (difficulty === "deadly") quest.rewardAmount *= 3;

  return quest;
}

function generateQuestChain(rng, length, theme) {
  length = length || 5;
  const chain = [];

  for (let i = 0; i < length; i++) {
    const quest = generateQuest(rng, "medium", theme);
    quest.chainPosition = i + 1;
    quest.chainLength = length;
    if (i > 0) quest.prerequisite = chain[i - 1];
    chain.push(quest);
  }

  return chain;
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 6: ECONOMY & TRADE (~300 lines)
// ═══════════════════════════════════════════════════════════════════════════

const TRADE_GOODS = [
  { name: "Grain", basePrice: 5, rarity: "common", weight: 10, seasonal: true },
  { name: "Wheat", basePrice: 4, rarity: "common", weight: 8, seasonal: true },
  { name: "Barley", basePrice: 3, rarity: "common", weight: 8, seasonal: true },
  { name: "Rice", basePrice: 6, rarity: "common", weight: 10, seasonal: true },
  { name: "Corn", basePrice: 4, rarity: "common", weight: 9, seasonal: true },
  { name: "Potatoes", basePrice: 2, rarity: "common", weight: 5, seasonal: true },
  { name: "Onions", basePrice: 1, rarity: "common", weight: 2, seasonal: true },
  { name: "Carrots", basePrice: 1, rarity: "common", weight: 2, seasonal: true },
  { name: "Apples", basePrice: 2, rarity: "common", weight: 3, seasonal: true },
  { name: "Grapes", basePrice: 3, rarity: "common", weight: 4, seasonal: true },
  { name: "Wine", basePrice: 15, rarity: "common", weight: 8, seasonal: false },
  { name: "Beer", basePrice: 8, rarity: "common", weight: 6, seasonal: false },
  { name: "Mead", basePrice: 10, rarity: "common", weight: 6, seasonal: false },
  { name: "Ale", basePrice: 6, rarity: "common", weight: 5, seasonal: false },
  { name: "Cheese", basePrice: 5, rarity: "common", weight: 3, seasonal: false },
  { name: "Butter", basePrice: 4, rarity: "common", weight: 2, seasonal: false },
  { name: "Milk", basePrice: 1, rarity: "common", weight: 2, seasonal: false },
  { name: "Bread", basePrice: 2, rarity: "common", weight: 1, seasonal: false },
  { name: "Meat", basePrice: 8, rarity: "common", weight: 4, seasonal: false },
  { name: "Fish", basePrice: 7, rarity: "common", weight: 3, seasonal: true },
  { name: "Salt", basePrice: 10, rarity: "common", weight: 1, seasonal: false },
  { name: "Spices", basePrice: 30, rarity: "uncommon", weight: 1, seasonal: false },
  { name: "Silk", basePrice: 50, rarity: "uncommon", weight: 2, seasonal: false },
  { name: "Wool", basePrice: 5, rarity: "common", weight: 3, seasonal: false },
  { name: "Cotton", basePrice: 4, rarity: "common", weight: 3, seasonal: false },
  { name: "Linen", basePrice: 8, rarity: "common", weight: 2, seasonal: false },
  { name: "Iron", basePrice: 20, rarity: "common", weight: 15, seasonal: false },
  { name: "Steel", basePrice: 40, rarity: "uncommon", weight: 12, seasonal: false },
  { name: "Copper", basePrice: 15, rarity: "common", weight: 12, seasonal: false },
  { name: "Gold", basePrice: 100, rarity: "rare", weight: 1, seasonal: false },
  { name: "Silver", basePrice: 50, rarity: "uncommon", weight: 2, seasonal: false },
  { name: "Tin", basePrice: 18, rarity: "common", weight: 10, seasonal: false },
  { name: "Lead", basePrice: 12, rarity: "common", weight: 14, seasonal: false },
  { name: "Gems", basePrice: 200, rarity: "rare", weight: 1, seasonal: false },
  { name: "Coal", basePrice: 8, rarity: "common", weight: 8, seasonal: false },
  { name: "Oil", basePrice: 12, rarity: "common", weight: 3, seasonal: false },
  { name: "Timber", basePrice: 10, rarity: "common", weight: 20, seasonal: true },
  { name: "Stone", basePrice: 5, rarity: "common", weight: 25, seasonal: false },
  { name: "Clay", basePrice: 4, rarity: "common", weight: 15, seasonal: false },
  { name: "Pottery", basePrice: 8, rarity: "common", weight: 5, seasonal: false },
  { name: "Glass", basePrice: 15, rarity: "uncommon", weight: 3, seasonal: false },
  { name: "Herbs", basePrice: 20, rarity: "uncommon", weight: 1, seasonal: true },
  { name: "Potions", basePrice: 50, rarity: "uncommon", weight: 1, seasonal: false },
  { name: "Scrolls", basePrice: 25, rarity: "uncommon", weight: 1, seasonal: false },
  { name: "Books", basePrice: 30, rarity: "uncommon", weight: 3, seasonal: false },
  { name: "Maps", basePrice: 15, rarity: "uncommon", weight: 1, seasonal: false },
  { name: "Jewelry", basePrice: 100, rarity: "rare", weight: 1, seasonal: false },
  { name: "Fur", basePrice: 25, rarity: "uncommon", weight: 5, seasonal: true },
  { name: "Leather", basePrice: 15, rarity: "common", weight: 4, seasonal: false },
  { name: "Hide", basePrice: 10, rarity: "common", weight: 5, seasonal: false },
  { name: "Bone", basePrice: 5, rarity: "common", weight: 2, seasonal: false },
  { name: "Ivory", basePrice: 80, rarity: "rare", weight: 3, seasonal: false },
  { name: "Horn", basePrice: 15, rarity: "uncommon", weight: 2, seasonal: false },
  { name: "Feathers", basePrice: 10, rarity: "common", weight: 1, seasonal: false },
  { name: "Ink", basePrice: 8, rarity: "common", weight: 1, seasonal: false },
  { name: "Paper", basePrice: 5, rarity: "common", weight: 2, seasonal: false },
  { name: "Canvas", basePrice: 12, rarity: "uncommon", weight: 4, seasonal: false },
  { name: "Dye", basePrice: 40, rarity: "uncommon", weight: 1, seasonal: false },
  { name: "Perfume", basePrice: 60, rarity: "uncommon", weight: 1, seasonal: false },
  { name: "Incense", basePrice: 15, rarity: "uncommon", weight: 1, seasonal: false },
];

function generateMarketPrices(rng, settlement, season) {
  const prices = {};

  TRADE_GOODS.forEach(good => {
    let price = good.basePrice;

    if (good.seasonal && season) {
      if (season === "summer" && good.name.match(/grain|wheat|fruit/i)) price *= 0.7;
      if (season === "winter" && good.name.match(/grain|fruit/i)) price *= 1.5;
    }

    price *= (0.8 + rng() * 0.4);
    prices[good.name] = Math.round(price);
  });

  return prices;
}

function generateTradeRoute(rng, from, to) {
  return {
    name: from.name + " to " + to.name,
    from: from,
    to: to,
    distance: randInt(10, 500, rng),
    danger: pick(["Safe", "Moderate", "Dangerous", "Deadly"], rng),
    tollCost: randInt(0, 500, rng),
    length: randInt(3, 60, rng) + " days",
    merchants: randInt(1, 20, rng),
    goods: pickN(TRADE_GOODS, randInt(5, 15, rng), rng),
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 7: FLORA & FAUNA (~400 lines)
// ═══════════════════════════════════════════════════════════════════════════

const FLORA_BY_BIOME = {
  forest: [
    "Oak", "Maple", "Birch", "Pine", "Spruce", "Fir", "Elm", "Ash", "Beech", "Ash",
    "Poplar", "Willow", "Holly", "Hazel", "Hawthorn", "Rowan", "Alder", "Larch", "Yew", "Cedar",
    "Moss", "Lichen", "Fern", "Ivy", "Mushroom", "Toadstool", "Clover", "Nettle", "Thistle", "Blackberry"
  ],
  grassland: [
    "Grass", "Clover", "Buttercup", "Dandelion", "Daisy", "Poppy", "Thistle", "Nettle", "Fescue", "Wheat",
    "Rye", "Barley", "Oats", "Cowslip", "Speedwell", "Plantain", "Dock", "Sorrel", "Vetch", "Trefoil",
    "Chamomile", "Thyme", "Sage", "Rosemary", "Lavender", "Marjoram", "Mint", "Oregano", "Basil", "Borage"
  ],
  desert: [
    "Cactus", "Yucca", "Creosote", "Joshua Tree", "Mesquite", "Acacia", "Saguaro", "Prickly Pear", "Barrel Cactus", "Cholla",
    "Desert Rose", "Desert Willow", "Palo Verde", "Ironwood", "Smoke Tree", "Ghost Flower", "Desert Marigold", "Desert Lupine", "Desert Aster", "Desert Sunflower",
    "Desert Sage", "Desert Mint", "Desert Thyme", "Desert Broom", "Desert Amaranth", "Creeping Devil", "Teddy Bear Cholla", "Night-Blooming Cereus", "Organ Pipe", "Greasewood"
  ],
  jungle: [
    "Mahogany", "Teak", "Rosewood", "Ebony", "Bamboo", "Orchid", "Bromeliad", "Fern", "Palm", "Rubber Tree",
    "Cacao", "Brazil Nut", "Acai", "Guarana", "Fig", "Passion Fruit", "Banana", "Plantain", "Coconut", "Lianas",
    "Vines", "Moss", "Lichen", "Epiphytes", "Bromeliads", "Arums", "Anthuriums", "Philodendrons", "Monsteras", "Clematis"
  ],
  mountain: [
    "Pine", "Spruce", "Fir", "Larch", "Juniper", "Cedar", "Hemlock", "Lodgepole", "Whitebark", "Bristlecone",
    "Alpine Meadow", "Alpine Poppy", "Edelweiss", "Gentian", "Arnica", "Columbine", "Lupine", "Paintbrush", "Stonecrop", "Saxifrage",
    "Moss", "Lichen", "Beargrass", "Sedge", "Heather", "Bilberry", "Crowberry", "Cloudberry", "Lingonberry", "Cowberry"
  ],
  swamp: [
    "Mangrove", "Cypress", "Tupelo", "Ash", "Maple", "Oak", "Willow", "Birch", "Alder", "Cedar",
    "Cattail", "Bulrush", "Reed", "Sedge", "Iris", "Arrowhead", "Water Lily", "Lotus", "Duckweed", "Algae",
    "Moss", "Liverwort", "Mushroom", "Fern", "Skunk Cabbage", "Jack-in-the-Pulpit", "Swamp Rose", "Pickerel Rush", "Marsh Mallow", "Swamp Milkweed"
  ],
  tundra: [
    "Lichen", "Moss", "Sedge", "Grass", "Heather", "Bilberry", "Crowberry", "Bearberry", "Cloudberry", "Lingonberry",
    "Willow", "Birch", "Alder", "Juniper", "Dwarf Pine", "Labrador Tea", "Beargrass", "Alpine Poppy", "Edelweiss", "Gentian",
    "Saxifrage", "Stonecrop", "Arctic Poppy", "Forget-me-not", "Lousewort", "Sorrel", "Buttercup", "Daisy", "Chickweed", "Cushion Pink"
  ],
  ocean: [
    "Kelp", "Seaweed", "Algae", "Phytoplankton", "Seagrass", "Eelgrass", "Wrack", "Dulse", "Nori", "Kombu",
    "Bladderwort", "Serrated Wrack", "Egg Wrack", "Channel Wrack", "Spiral Wrack", "Knotted Wrack", "Pod Weeds", "Sea Lettuce", "Green Crab Weed", "Irish Moss",
    "Carrageenan", "Agar", "Laver", "Sea Pickle", "Glasswort", "Samphire", "Sea Rocket", "Sea Purslane", "Sea Aster", "Saltmarsh Cordgrass"
  ],
  volcanic: [
    "Lichen", "Fireweed", "Lava Fern", "Lupine", "Willow", "Birch", "Alder", "Aspen", "Poplar", "Pine",
    "Spruce", "Juniper", "Arctic Poppy", "Columbine", "Bleeding Heart", "Solomon's Seal", "Bistort", "Yarrow", "Buckwheat", "Paintbrush",
    "Aster", "Daisy", "Dandelion", "Clover", "Vetch", "Pea", "Sage", "Thistle", "Nettle", "Dock"
  ],
};

const FAUNA_BY_BIOME = {
  forest: [
    "Deer", "Elk", "Moose", "Black Bear", "Wolf", "Fox", "Squirrel", "Rabbit", "Badger", "Otter",
    "Beaver", "Porcupine", "Raccoon", "Opossum", "Owl", "Hawk", "Eagle", "Woodpecker", "Raven", "Crow",
    "Jay", "Sparrow", "Finch", "Thrush", "Dove", "Pheasant", "Grouse", "Snake", "Frog", "Turtle"
  ],
  grassland: [
    "Bison", "Antelope", "Elk", "Deer", "Prairie Dog", "Coyote", "Wolf", "Fox", "Badger", "Weasel",
    "Rabbit", "Hare", "Squirrel", "Gopher", "Marmot", "Eagle", "Hawk", "Falcon", "Owl", "Vulture",
    "Crow", "Raven", "Songbirds", "Insects", "Grasshopper", "Cricket", "Snake", "Lizard", "Frog", "Toad"
  ],
  desert: [
    "Camel", "Coyote", "Jackal", "Fox", "Rattlesnake", "Lizard", "Scorpion", "Tarantula", "Gila Monster", "Tortoise",
    "Roadrunner", "Quail", "Raven", "Hawk", "Eagle", "Vulture", "Owl", "Toad", "Frog", "Beetle",
    "Ant", "Wasp", "Bee", "Centipede", "Millipede", "Spider", "Worm", "Badger", "Hare", "Kangaroo Rat"
  ],
  jungle: [
    "Jaguar", "Puma", "Ocelot", "Monkey", "Ape", "Sloth", "Capybara", "Anteater", "Tapir", "Peccary",
    "Parrot", "Macaw", "Toucan", "Hummingbird", "Condor", "Jaguar", "Caiman", "Anaconda", "Poisonous Frog", "Spider",
    "Insect", "Beetle", "Butterfly", "Ant", "Termite", "Wasp", "Scorpion", "Lizard", "Snake", "Caiman"
  ],
  mountain: [
    "Mountain Goat", "Bighorn Sheep", "Eagle", "Hawk", "Falcon", "Vulture", "Pika", "Marmot", "Hare", "Squirrel",
    "Fox", "Coyote", "Wolf", "Bear", "Cougar", "Lynx", "Badger", "Weasel", "Raven", "Crow",
    "Owl", "Ptarmigan", "Pipit", "Finch", "Sparrow", "Snake", "Lizard", "Frog", "Salamander", "Insect"
  ],
  swamp: [
    "Alligator", "Crocodile", "Otter", "Beaver", "Muskrat", "Nutria", "Marsh Rabbit", "Water Snake", "Frog", "Toad",
    "Turtle", "Flamingo", "Heron", "Egret", "Ibis", "Crane", "Duck", "Goose", "Rail", "Coot",
    "Fish", "Catfish", "Perch", "Pike", "Crab", "Lobster", "Shrimp", "Snail", "Insect", "Mosquito"
  ],
  tundra: [
    "Musk Ox", "Caribou", "Arctic Hare", "Arctic Fox", "Polar Bear", "Lemming", "Vole", "Weasel", "Wolf", "Raven",
    "Arctic Tern", "Ptarmigan", "Snowy Owl", "Eagle", "Gull", "Skua", "Seal", "Walrus", "Whale", "Fish",
    "Mosquito", "Fly", "Beetle", "Ant", "Spider", "Mite", "Louse", "Tick", "Centipede", "Worm"
  ],
  ocean: [
    "Whale", "Dolphin", "Seal", "Sea Lion", "Walrus", "Manatee", "Dugong", "Sea Otter", "Polar Bear", "Penguin",
    "Albatross", "Petrel", "Cormorant", "Pelican", "Gull", "Tern", "Puffin", "Murre", "Gannet", "Frigatebird",
    "Shark", "Ray", "Tuna", "Salmon", "Cod", "Herring", "Sardine", "Anchovies", "Flounder", "Squid"
  ],
  volcanic: [
    "Sheep", "Goat", "Horse", "Elk", "Deer", "Fox", "Coyote", "Wolf", "Badger", "Weasel",
    "Eagle", "Hawk", "Falcon", "Vulture", "Owl", "Raven", "Crow", "Jay", "Sparrow", "Finch",
    "Snake", "Lizard", "Frog", "Toad", "Salamander", "Newt", "Insect", "Beetle", "Spider", "Ant"
  ],
};

function generateEcosystem(rng, biome) {
  const flora = pickN(FLORA_BY_BIOME[biome] || FLORA_BY_BIOME.forest, randInt(3, 8, rng), rng);
  const fauna = pickN(FAUNA_BY_BIOME[biome] || FAUNA_BY_BIOME.forest, randInt(3, 8, rng), rng);

  return {
    biome: biome,
    plants: flora,
    animals: fauna,
    foodChain: [fauna[0] + " eats " + flora[0], fauna[1] + " eats " + fauna[0]],
    threats: pickN(fauna, 2, rng),
    resources: pickN(flora, 2, rng),
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 8: EXPANDED NPC (~500 lines)
// ═══════════════════════════════════════════════════════════════════════════

const NPC_BACKSTORIES = [
  "Born in poverty, rose to prominence through hard work",
  "Once royalty, fell from grace",
  "Survivor of a massacre",
  "Cursed by a vengeful mage",
  "Escaped from slavery",
  "Soldier hardened by war",
  "Apprentice to a master",
  "Bastard child of nobility",
  "Escaped criminal",
  "Monk who abandoned the order",
  "Farmer whose land was seized",
  "Shipwrecked and stranded",
  "Survivor of a plague",
  "Abandoned by their family",
  "Marked by destiny",
  "Lost their memories",
  "Betrayed by trusted friend",
  "Survivor of a dragon attack",
  "Refugee from conquest",
  "Raised by non-human parents",
  "Sold into servitude",
  "Rescued from certain death",
  "Defected from their faction",
  "Discovered they have magical power",
  "Lost love to disease",
  "Revenge-driven by murder",
  "Seeking atonement",
  "Searching for their family",
  "Protecting a dark secret",
  "Running from their past",
  "Saved by a mysterious stranger",
  "Tested by the gods",
  "Inheritor of a legendary item",
  "Cursed with immortality",
  "Infected with lycanthropy",
  "Bonded with a magical familiar",
  "Chosen by an ancient artifact",
  "Bearing a prophecy",
  "Hunted by assassins",
  "Guardian of forbidden knowledge",
  "Seeker of redemption",
  "Last of their line",
  "Cursed with compulsion",
  "Blessed by the divine",
  "Infected with vampirism",
  "Bound to another soul",
  "Marked by fate",
  "Walking between worlds",
  "Living in exile",
  "Seeking ultimate power"
];

const NPC_DIALOGUE = {
  greeting: [
    "Hail and well met, traveler!",
    "Welcome, what brings you to these parts?",
    "I don't believe we've met before.",
    "Good to see a new face around here.",
    "Greetings, friend.",
    "What can I do for you?",
    "How do you do?",
    "Well met!",
    "Good morning/afternoon/evening.",
    "I hope you're having a better day than I am.",
    "Did you need something?",
    "Come to join the celebration?",
    "Might I ask your business here?",
    "Welcome to my humble home.",
    "Good to see you again!",
    "I wasn't expecting visitors.",
    "Please, make yourself comfortable.",
    "What an unexpected pleasure!",
    "You've chosen quite the time to visit.",
    "Fair winds and following seas to you!"
  ],
  gossip: [
    "Have you heard about the dragon in the mountains?",
    "They say the lord has gone mad.",
    "A merchant was robbed on the south road.",
    "The crops are failing this season.",
    "Strange lights in the forest at night.",
    "The church has a new high priest.",
    "There's been murders in town.",
    "A child has gone missing.",
    "The tavern burned down last week.",
    "The river is running black.",
    "A wizard has come to town.",
    "The mayor's daughter eloped with a beggar.",
    "Bandits are working the north road.",
    "There's an illness spreading in the slums.",
    "The kingdom is at war with its neighbors.",
    "An ancient tomb was discovered.",
    "The statue in the square came to life!",
    "The blacksmith disappeared.",
    "Doppelgangers are replacing town folk.",
    "Something foul is happening at the temple."
  ],
  complaint: [
    "These taxes are getting out of hand!",
    "The guards don't protect us anymore.",
    "I'm tired of working for so little.",
    "The roads are unsafe these days.",
    "Nobody respects the old ways anymore.",
    "Everything costs too much gold.",
    "The young people have no respect.",
    "This town is going to the dogs.",
    "I haven't had a decent meal in weeks.",
    "The nobles don't care about us common folk.",
    "My business is ruined!",
    "Why should I pay for their war?",
    "The laws are unjust!",
    "Nobody will hire me anymore.",
    "My family is starving.",
    "The landlord raised the rent again.",
    "I'm cursed, I swear it!",
    "My harvest failed again.",
    "The adventurers are destroying the town!",
    "When will things get better?"
  ],
  secret: [
    "I'm not who I claim to be.",
    "I killed someone and no one knows.",
    "I've been stealing from my employer.",
    "I'm in love with someone I shouldn't be.",
    "I made a deal with something dark.",
    "I know who the real murderer is.",
    "I'm hiding someone dangerous.",
    "I have magic, though it's forbidden.",
    "I'm actually nobility in hiding.",
    "I'm working for multiple masters.",
    "I betrayed my own family.",
    "I'm slowly being poisoned.",
    "I don't remember my real name.",
    "I'm not entirely human.",
    "I've seen things that shouldn't exist.",
    "Someone is blackmailing me.",
    "I know the lord's terrible secret.",
    "I've bargained with demons.",
    "I'm cursed and dying.",
    "Nothing is what it seems."
  ]
};

const NPC_INVENTORIES = [
  ["Dagger", "Coin Purse", "Bedroll", "Rope"],
  ["Longsword", "Shield", "Armor"],
  ["Spellbook", "Wand", "Component Pouch"],
  ["Shortbow", "Quiver", "Arrows"],
  ["Holy Symbol", "Mace", "Chain Mail"],
  ["Thieves Tools", "Lockpick", "Grappling Hook"],
  ["Musical Instrument", "Sheet Music", "Songbook"],
  ["Hammer", "Nails", "Wood"],
  ["Mortar", "Pestle", "Herbs"],
  ["Fishing Rod", "Bait", "Catch"],
  ["Lantern", "Oil", "Torch"],
  ["Lockpick", "Caltrops", "Smoke Bomb"],
  ["Healing Kit", "Bandages", "Poultices"],
  ["Writing Materials", "Ink", "Parchment"],
  ["Religious Texts", "Incense", "Candles"],
  ["Merchant's Scale", "Ledger", "Merchandise"],
  ["Disguise Kit", "Makeup", "Costumes"],
  ["Animal Collar", "Treats", "Brushes"],
  ["Cooking Equipment", "Ingredients", "Recipes"],
  ["Gardening Tools", "Seeds", "Fertilizer"]
];

function generateNPCBackstory(rng, npc) {
  const backstory = pick(NPC_BACKSTORIES, rng);
  return {
    ...npc,
    backstory: backstory,
    backstoryDetail: generateLore(rng)
  };
}

function generateNPCDialogue(rng, npc, context) {
  context = context || "greeting";
  const dialogue = pick(NPC_DIALOGUE[context] || NPC_DIALOGUE.greeting, rng);
  return {
    npc: npc.name,
    context: context,
    dialogue: dialogue
  };
}

function generateNPCSchedule(rng, npc) {
  const schedule = {};
  const activities = ["sleeping", "working", "eating", "traveling", "praying", "drinking", "training", "studying"];

  for (let hour = 0; hour < 24; hour++) {
    schedule[hour] = pick(activities, rng);
  }

  return {
    npc: npc.name,
    schedule: schedule
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 9: DUNGEON GENERATION (~500 lines)
// ═══════════════════════════════════════════════════════════════════════════

const ROOM_TYPES = [
  "Entrance Hall",
  "Main Chamber",
  "Throne Room",
  "Guard Room",
  "Barracks",
  "Armory",
  "Treasury",
  "Library",
  "Study",
  "Laboratory",
  "Ritual Chamber",
  "Prison",
  "Torture Chamber",
  "Slave Quarters",
  "Kitchen",
  "Dining Hall",
  "Bedchamber",
  "Bathing Chamber",
  "Workshops",
  "Forge",
  "Stables",
  "Storage Room",
  "Crypt",
  "Ossuary",
  "Underground Lake",
  "Mushroom Farm",
  "Crystal Cavern",
  "Lava Chamber",
  "Geode Chamber",
  "Flooded Cavern"
];

const ROOM_HAZARDS = [
  "Pit Trap",
  "Spikes",
  "Pendulum Blade",
  "Poison Gas",
  "Statue Guardians",
  "Magical Runes",
  "Unstable Floor",
  "Cursed Mirrors",
  "Animated Paintings",
  "Triggering Stones",
  "Collapsing Ceiling",
  "Acid Pool",
  "Extreme Cold",
  "Extreme Heat",
  "Darkness (magical)",
  "Ooze",
  "Giant Spiders",
  "Ghosts",
  "Undead",
  "Tentacles",
  "Chains",
  "Guillotine",
  "Pressure Plates",
  "Falling Rocks",
  "Magical Stasis",
  "Time Distortion",
  "Planar Anomaly",
  "Temporal Loop",
  "Dimensional Rift",
  "Gravity Inversion"
];

const DUNGEON_THEMES = [
  "Ancient Tomb",
  "Haunted Castle",
  "Goblin Stronghold",
  "Dragon Lair",
  "Cult Temple",
  "Wizard's Tower",
  "Dwarven Mine",
  "Underground Kingdom",
  "Corrupted Forest",
  "Demonic Portal",
  "Lich's Phylactery",
  "Giant's Hall",
  "Undead Warren",
  "Mad Mage's Laboratory",
  "Slave Pens",
  "Monster Zoo",
  "Planar Prison",
  "Eldritch Horror Nest",
  "Twisted Mirror Realm",
  "Fey Court Underground"
];

function generateDungeonLayout(rng, floors, size) {
  const layout = [];

  for (let f = 0; f < floors; f++) {
    const floor = {
      floorNumber: f + 1,
      rooms: [],
      connections: [],
      hazards: []
    };

    const roomCount = randInt(size * 2, size * 5, rng);

    for (let r = 0; r < roomCount; r++) {
      const room = {
        id: f + "-" + r,
        type: pick(ROOM_TYPES, rng),
        width: randInt(10, 50, rng),
        height: randInt(10, 50, rng),
        hasExit: rng() > 0.5,
        hasTreasure: rng() > 0.7,
        hasMonster: rng() > 0.4,
        trapCount: randInt(0, 3, rng),
        traps: pickN(ROOM_HAZARDS, randInt(0, 3, rng), rng)
      };

      floor.rooms.push(room);
    }

    // Connect rooms
    for (let r = 0; r < floor.rooms.length - 1; r++) {
      if (rng() > 0.3) {
        floor.connections.push({ from: r, to: r + 1, type: pick(["Door", "Passage", "Stairs", "Chasm", "Secret"], rng) });
      }
    }

    layout.push(floor);
  }

  return layout;
}

function generateDungeonEcology(rng, theme) {
  const ecology = {
    theme: theme || pick(DUNGEON_THEMES, rng),
    rulers: [],
    minions: [],
    ecosystem: [],
    oddities: []
  };

  // Generate rulers
  for (let i = 0; i < randInt(1, 3, rng); i++) {
    ecology.rulers.push(generateNPC(rng));
  }

  // Generate minions
  for (let i = 0; i < randInt(3, 10, rng); i++) {
    ecology.minions.push(generateNPC(rng));
  }

  return ecology;
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 10: HISTORY GENERATION (~300 lines)
// ═══════════════════════════════════════════════════════════════════════════

const HISTORICAL_EVENTS = [
  "Great Empire Founded",
  "Devastating Plague",
  "Catastrophic War",
  "Monster Invasion",
  "Natural Disaster",
  "Religious Schism",
  "Magical Awakening",
  "Dark Curse",
  "Great Victory",
  "Terrible Defeat",
  "King Assassinated",
  "Kingdom United",
  "Kingdom Shattered",
  "City Founded",
  "City Destroyed",
  "Dragon Appearance",
  "Hero Emerges",
  "Villain Ascends",
  "Ancient Secret Revealed",
  "Forbidden Magic Discovered",
  "Peace Treaty Signed",
  "Betrayal Unveiled",
  "Golden Age Begins",
  "Dark Age Begins",
  "Revolution Starts",
  "Tyrant Overthrown",
  "Savior Arrives",
  "Prophecy Fulfilled",
  "Ancient Curse Lifted",
  "Doomsday Averted",
  "Portal Opened",
  "Realm Merged",
  "Time Reversed",
  "Reality Shattered",
  "Gods Intervene",
  "Demons Summoned",
  "Heroes Sacrifice",
  "Resurrection Miracle",
  "Extinction Event",
  "New Civilization Arises",
  "Old Magic Returns",
  "Technology Discovered",
  "Knowledge Lost",
  "Library Burned",
  "Artifact Forged",
  "Artifact Destroyed",
  "Sacred Site Desecrated",
  "Holy Ground Blessed",
  "Mass Exodus",
  "Refugee Crisis"
];

function generateWorldHistory(rng, kingdoms, age) {
  age = age || 1000;
  const history = [];
  const eventCount = Math.floor(age / 100);

  for (let i = 0; i < eventCount; i++) {
    const year = randInt(0, age, rng);
    const event = {
      year: year,
      event: pick(HISTORICAL_EVENTS, rng),
      kingdom: pick(kingdoms, rng),
      significance: pick(["Local", "Regional", "Continental", "World-Changing"], rng),
      outcome: generateLore(rng)
    };

    history.push(event);
  }

  return history.sort((a, b) => a.year - b.year);
}

function generateTimeline(rng, years) {
  years = years || 100;
  const timeline = [];

  for (let y = 0; y < years; y++) {
    timeline.push({
      year: y,
      event: rng() > 0.7 ? pick(HISTORICAL_EVENTS, rng) : "Quiet Year",
      details: rng() > 0.8 ? generateLore(rng) : ""
    });
  }

  return timeline;
}

function generateLegend(rng, type) {
  const legTypes = ["Heroic", "Tragic", "Mysterious", "Comedic", "Romantic", "Horrifying"];
  type = type || pick(legTypes, rng);

  return {
    type: type,
    title: genKingdomName(rng) + " of " + pick(["Legend", "Lore", "Myth", "Tale", "Story"], rng),
    protagonist: generateNPC(rng),
    antagonist: generateNPC(rng),
    conflict: generateLore(rng),
    resolution: generateLore(rng),
    moral: pick(["Good triumphs", "Evil wins", "Balance restored", "Lessons learned", "Curse endures"], rng)
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// PART 11: MAGIC SYSTEM (~300 lines)
// ═══════════════════════════════════════════════════════════════════════════

const ARCANE_TRADITIONS = [
  "Abjuration - Protection and banishment",
  "Conjuration - Summoning and creation",
  "Divination - Knowledge and foresight",
  "Enchantment - Charm and influence",
  "Evocation - Energy and force",
  "Illusion - Deception and misdirection",
  "Necromancy - Death and undeath",
  "Transmutation - Change and transformation",
  "Chronomancy - Time manipulation",
  "Numerology - Number and fate",
  "Geomancy - Earth magic",
  "Hydromancy - Water magic",
  "Pyromancy - Fire magic",
  "Aeromancy - Air magic",
  "Biomancy - Life magic",
  "Hemomancy - Blood magic",
  "Technomancy - Machine magic",
  "Thermonancy - Heat magic",
  "Cryomancy - Ice magic",
  "Demonology - Demon summoning",
  "Angelology - Celestial magic",
  "Witchcraft - Nature and potions",
  "Shamanism - Spirit magic",
  "Sorcery - Bloodline magic",
  "Warlock Pacts - Infernal magic",
  "Chaos Magic - Unpredictable magic",
  "Order Magic - Lawful magic",
  "Fey Magic - Faerie magic",
  "Shadow Magic - Darkness magic",
  "Light Magic - Holy magic"
];

const LEY_LINE_TYPES = [
  "Major Ley Line",
  "Minor Ley Line",
  "Void Ley Line",
  "Divine Ley Line",
  "Infernal Ley Line",
  "Fey Ley Line",
  "Shadow Ley Line",
  "Temporal Ley Line",
  "Spatial Ley Line",
  "Dimensional Ley Line"
];

const SPELL_SCHOOLS = [
  "Abjuration",
  "Conjuration",
  "Divination",
  "Enchantment",
  "Evocation",
  "Illusion",
  "Necromancy",
  "Transmutation",
  "Universal",
  "Exotic"
];

const SPELL_NAMES = [
  "Arcane Missile", "Mage Armor", "Magic Missile", "Shocking Grasp", "Cure Wounds", "Identify",
  "Detect Magic", "Light", "Prestidigitation", "Cantrip", "Fireball", "Lightning Bolt",
  "Magic Circle", "Teleportation Circle", "Plane Shift", "Wish", "Time Stop", "Gate",
  "Power Word Kill", "Meteor Storm", "Tsunami", "Earthquake", "Summon Monster", "Polymorph",
  "True Polymorph", "Transmute Rock", "Move Earth", "Shape Water", "Gust", "Mold",
  "Mirror Image", "Invisibility", "Disguise Self", "Silent Image", "Phantasmal Killer",
  "Finger of Death", "Circle of Death", "Animate Dead", "Raise Dead", "Resurrection",
  "Charm Person", "Hold Person", "Dominate Person", "Suggestion", "Hypnotic Pattern",
  "Counterspell", "Dispel Magic", "Banishment", "Imprisonment", "Trap the Soul",
  "Comprehend Languages", "Scrying", "True Seeing", "Legend Lore", "Commune",
  "Plane Detection", "Darkvision", "See Invisibility", "Detect Thoughts", "Hex",
  "Bless", "Curse", "Protection Circle", "Sanctuary", "Magic Weapon",
  "Summon Beast", "Summon Demon", "Summon Celestial", "Summon Fey", "Summon Dragon"
];

const MAGIC_ITEM_RARITIES = ["Common", "Uncommon", "Rare", "Very Rare", "Legendary", "Artifact"];

function generateMagicSystem(rng) {
  const traditions = pickN(ARCANE_TRADITIONS, randInt(3, 8, rng), rng);
  const leyLines = [];

  for (let i = 0; i < randInt(3, 10, rng); i++) {
    leyLines.push({
      type: pick(LEY_LINE_TYPES, rng),
      power: randInt(1, 10, rng),
      intersections: randInt(0, 5, rng)
    });
  }

  return {
    traditions: traditions,
    leyLines: leyLines,
    powerLevel: pick(["Weak", "Moderate", "Strong", "Very Strong", "Apocalyptic"], rng),
    restrictions: pick(["None", "Forbidden", "Regulated", "Underground", "Extinct"], rng),
    alignment: pick(["Neutral", "Chaotic", "Lawful", "Mixed"], rng)
  };
}

function generateSpellbook(rng, level, school) {
  level = level || randInt(1, 9, rng);
  school = school || pick(SPELL_SCHOOLS, rng);
  const spellCount = Math.min(level * 4, 30);
  const spells = [];

  for (let i = 0; i < spellCount; i++) {
    spells.push({
      name: pick(SPELL_NAMES, rng),
      level: randInt(1, level, rng),
      school: school,
      range: pick(["Self", "Touch", "30 feet", "60 feet", "120 feet", "1 mile", "Sight", "Unlimited"], rng),
      duration: pick(["Instantaneous", "1 round", "1 minute", "1 hour", "1 day", "1 month", "1 year", "Permanent"], rng),
      concentration: rng() > 0.5,
      damage: rng() > 0.7 ? randInt(1, 10) + "d6" : "None"
    });
  }

  return {
    level: level,
    school: school,
    spells: spells,
    totalSpells: spells.length
  };
}

function generateMagicItem(rng, rarity) {
  rarity = rarity || pick(MAGIC_ITEM_RARITIES, rng);

  const rarityProperties = {
    "Common": { basePrice: 50, effects: 1, powers: 1 },
    "Uncommon": { basePrice: 500, effects: 2, powers: 2 },
    "Rare": { basePrice: 5000, effects: 3, powers: 3 },
    "Very Rare": { basePrice: 50000, effects: 4, powers: 4 },
    "Legendary": { basePrice: 500000, effects: 5, powers: 5 },
    "Artifact": { basePrice: 5000000, effects: 6, powers: 6 }
  };

  const props = rarityProperties[rarity] || rarityProperties["Common"];
  const types = ["Armor", "Weapon", "Wand", "Ring", "Cloak", "Amulet", "Belt", "Boots", "Gloves", "Helmet", "Staff"];

  return {
    name: pick(MAGIC_ITEMS, rng),
    type: pick(types, rng),
    rarity: rarity,
    basePrice: props.basePrice,
    effects: randInt(1, props.effects, rng),
    powers: pickN(["Detect Magic", "Cast Spell", "Gain Ability", "Summon Beast", "Teleport", "Heal", "Protect", "Enhance"], props.powers, rng),
    curse: rng() > 0.85 ? true : false,
    attunement: rng() > 0.5,
    description: generateLore(rng)
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// EXTENDED FUNCTIONS AND SUBSYSTEMS
// ═══════════════════════════════════════════════════════════════════════════

// ─── WEATHER EXTENDED ──────────────────────────────────────────────────────

function analyzeWeatherPattern(forecast) {
  let stormDays = 0, clearDays = 0, precipitation = 0;
  const severities = [];

  forecast.forEach(day => {
    if (day.severity >= 3) stormDays++;
    if (day.type === "clear" || day.type === "aurora" || day.type === "divineRadiance") clearDays++;
    if (day.name.match(/rain|snow|hail|storm/i)) precipitation++;
    severities.push(day.severity);
  });

  return {
    stormDays: stormDays,
    clearDays: clearDays,
    precipitationDays: precipitation,
    averageSeverity: severities.length > 0 ? severities.reduce((a, b) => a + b) / severities.length : 0,
    pattern: stormDays > clearDays ? "Stormy Season" : "Pleasant Season"
  };
}

function getWeatherForTraveling(weather) {
  const safeSpeed = weather.effects.travelSpeed > 0.7 ? "Safe" : weather.effects.travelSpeed > 0.4 ? "Risky" : "Dangerous";
  return {
    canTravel: weather.effects.travelSpeed > 0,
    safetyRating: safeSpeed,
    timeMultiplier: 1 / (weather.effects.travelSpeed || 0.1),
    exhaustionRisk: Math.round(weather.severity * 10)
  };
}

function weatherAffectsCrop(weather, cropType) {
  const benefits = { rain: "crops", clear: "grain", temperate: "vegetables" };
  const harms = { drought: "allcrops", frost: "tender", heat: "leafy" };

  let damage = 0;
  if (weather.temperature < 0) damage += weather.severity * 5;
  if (weather.temperature > 40) damage += weather.severity * 3;
  if (weather.humidity < 0.2) damage += weather.severity * 4;

  return {
    cropType: cropType,
    damagePercent: Math.min(100, damage),
    harmed: damage > 20,
    destroyed: damage > 75
  };
}

function generateSeasonalWeatherPatterns(rng, region, daysPerSeason) {
  const seasons = ["spring", "summer", "autumn", "winter"];
  const patterns = {};

  seasons.forEach(season => {
    const forecast = generateWeatherForecast(rng, region, season, daysPerSeason);
    patterns[season] = {
      forecast: forecast,
      analysis: analyzeWeatherPattern(forecast),
      averageTemp: forecast.reduce((a, w) => a + w.temperature, 0) / forecast.length,
      averageHumidity: forecast.reduce((a, w) => a + w.humidity, 0) / forecast.length
    };
  });

  return patterns;
}

// ─── CALENDAR EXTENDED ─────────────────────────────────────────────────────

function getSeasonFromMonth(monthIndex) {
  return CALENDAR.months[monthIndex % 12].season;
}

function getDayName(dayOfWeek) {
  const days = ["Starday", "Moonday", "Twoday", "Trueday", "Waterday", "Marketday", "Godday"];
  return days[dayOfWeek % 7];
}

function calculateAstralogyInfluence(dayNumber) {
  const signs = ["Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"];
  return signs[Math.floor((dayNumber % 365) / 30.4) % 12];
}

function getCalendarInfo(dayNumber) {
  const date = getCurrentDate(dayNumber);
  const moon = getMoonPhase(dayNumber);
  const holiday = getHoliday(date.month, date.day);
  const dayOfWeek = getDayName(dayNumber);
  const astro = calculateAstralogyInfluence(dayNumber);
  const seasonMods = getSeasonalModifiers(date.season);

  return {
    date: date,
    dayOfWeek: dayOfWeek,
    moonPhase: moon,
    holiday: holiday,
    astrologySign: astro,
    seasonalMod: seasonMods,
    isFestival: holiday !== null,
    daysPassed: dayNumber
  };
}

function addDays(dayNumber, daysToAdd) {
  return dayNumber + daysToAdd;
}

function daysBetween(day1, day2) {
  return Math.abs(day2 - day1);
}

function getAgeInYears(birthDay, currentDay) {
  const birth = getCurrentDate(birthDay);
  const current = getCurrentDate(currentDay);
  return current.year - birth.year;
}

// ─── RELIGION EXTENDED ────────────────────────────────────────────────────

function generateReligiousOrder(rng, religion) {
  const deity = pick(religion.pantheon, rng);
  return {
    name: "Order of " + deity.name,
    deity: deity,
    purpose: "Worship and serve " + deity.name,
    leader: generateNPC(rng),
    members: randInt(10, 500, rng),
    temples: randInt(1, 20, rng),
    doctrines: pickN(deity.commandments, 3, rng),
    practices: pickN(["Meditation", "Prayer", "Ritual", "Pilgrimage", "Charity", "Asceticism", "Fasting", "Celebration", "Study", "Service"], 5, rng),
    influence: randInt(0, 100, rng)
  };
}

function generateHolyRelic(rng, deity) {
  const materials = ["Gold", "Silver", "Bone", "Crystal", "Wood", "Stone", "Cloth", "Metal", "Glass"];
  const forms = ["Statue", "Amulet", "Chalice", "Ring", "Crown", "Sword", "Scroll", "Orb", "Staff", "Altar"];

  return {
    name: "The " + pick(["Holy", "Sacred", "Blessed", "Divine", "Eternal"], rng) + " " + pick(forms, rng) + " of " + deity.name,
    deity: deity,
    material: pick(materials, rng),
    form: pick(forms, rng),
    power: pick(["Healing", "Protection", "Revelation", "Judgment", "Blessing", "Resurrection", "Warding", "Cleansing"], rng),
    age: randInt(100, 10000, rng),
    location: "Unknown",
    rumors: pickN(["Lost", "Buried", "Guarded", "Stolen", "Cursed", "Holy", "Protected", "Forgotten"], 2, rng),
    value: randInt(10000, 1000000, rng)
  };
}

function generateHeresy(rng, religion) {
  const trueBelief = pick(religion.pantheon[0].commandments, rng);
  const falseBeliefs = ["Deny the gods", "Worship a dark entity", "Reject the commandments", "Combine forbidden faiths", "Claim divinity", "Demand sacrifice", "Preach chaos"];

  return {
    name: "Heresy of " + genKingdomName(rng),
    parentReligion: religion.name,
    trueBelief: trueBelief,
    falseBelief: pick(falseBeliefs, rng),
    founder: generateNPC(rng),
    followers: randInt(10, 1000, rng),
    severity: pick(["Minor Deviation", "Serious Contradiction", "Dangerous Schism", "Absolute Corruption"], rng),
    punishment: pick(["Exile", "Execution", "Redemption Ritual", "Banishment", "Purification", "Penance"], rng)
  };
}

// ─── FACTION EXTENDED ─────────────────────────────────────────────────────

function generateFactionHierarchy(rng, faction) {
  const hierarchy = {};

  faction.ranks.forEach((rank, index) => {
    hierarchy[rank] = {
      rank: rank,
      level: index,
      members: randInt(1, Math.max(2, Math.floor(faction.members / (index + 1)))),
      privileges: pickN(["Extra Pay", "Authority", "Magic Items", "Information Access", "Safe Hideout", "Resources"], randInt(1, 3, rng), rng),
      duties: pickN(["Lead Members", "Enforce Rules", "Gather Information", "Perform Missions", "Recruit", "Punish Betrayers"], randInt(1, 4, rng), rng)
    };
  });

  return hierarchy;
}

function generateFactionConflict(rng, faction1, faction2) {
  const causes = ["Territory", "Resources", "Ideology", "Revenge", "Leadership", "Power", "Love", "Betrayal", "Secrets"];
  const escalation = ["Cold War", "Espionage", "Skirmishes", "Open Conflict", "War"];

  return {
    faction1: faction1.name,
    faction2: faction2.name,
    cause: pick(causes, rng),
    currentEscalation: pick(escalation, rng),
    casualties: randInt(0, 1000, rng),
    duration: randInt(1, 100, rng) + " years",
    resolution: pick(["Truce", "Victory", "Stalemate", "Merger", "Destruction"], rng),
    neutral: pick(["Few", "Several", "Many", "Most"], rng) + " factions remain neutral"
  };
}

function generateFactionPlot(rng, faction) {
  const plots = [
    "Acquire powerful artifact",
    "Eliminate rival faction leader",
    "Discover enemy secret",
    "Steal valuable information",
    "Infiltrate rival faction",
    "Control trade route",
    "Win political election",
    "Summon ancient power",
    "Find hidden treasure",
    "Trigger revolution",
    "Control major city",
    "Eliminate witness",
    "Forge false evidence",
    "Corrupt noble",
    "Start war between others",
    "Achieve immortality",
    "Resurrect dead ally",
    "Build secret base",
    "Mass recruitment",
    "Obtain forbidden magic"
  ];

  return {
    faction: faction.name,
    plot: pick(plots, rng),
    stages: randInt(2, 5, rng),
    timeline: randInt(1, 60, rng) + " months",
    resourcesRequired: randInt(1000, 100000, rng),
    successChance: randInt(20, 95, rng) + "%",
    exposure: randInt(0, 100, rng) + "% discovered",
    keyAlly: generateNPC(rng),
    keyEnemy: generateNPC(rng)
  };
}

// ─── QUEST EXTENDED ────────────────────────────────────────────────────────

function generateQuestHook(rng, quest) {
  const hooks = [
    "Overheard in tavern",
    "Bulletin board notice",
    "NPC in distress",
    "Strange dream",
    "Mysterious letter",
    "Found artifact",
    "Prophetic vision",
    "Guild request",
    "Rumor spreading",
    "Witness testimony"
  ];

  return {
    quest: quest.type,
    hook: pick(hooks, rng),
    discoveredBy: generateNPC(rng),
    credibility: randInt(20, 100, rng) + "%",
    urgency: pick(["Low", "Medium", "High", "Critical"], rng),
    complications: quest.complications,
    reward: quest.reward + ": " + quest.rewardAmount + " gold"
  };
}

function generateQuestReward(rng, difficulty) {
  const rewards = {
    easy: 50,
    medium: 250,
    hard: 1000,
    deadly: 5000
  };

  const amount = rewards[difficulty] || 250;
  const bonusItems = randInt(0, 3, rng);
  const items = [];

  for (let i = 0; i < bonusItems; i++) {
    items.push(pick(MAGIC_ITEMS, rng));
  }

  return {
    gold: amount,
    items: items,
    experience: amount * 10,
    reputation: randInt(10, 50, rng),
    favor: generateNPC(rng).name + " owes you a favor",
    boon: pick(["Safe lodging", "Information access", "Recruitment opportunity", "Magic training"], rng)
  };
}

function generateQuestNPC(rng, quest) {
  const npc = generateNPC(rng);
  const motivations = ["Reward money", "Personal quest", "Moral obligation", "Debt repayment", "Redemption", "Punishment", "Duty", "Greed", "Revenge"];

  return {
    npc: npc,
    role: pick(["Questgiver", "Ally", "Enemy", "Neutral", "Betrayer", "Helper", "Red Herring"], rng),
    motivation: pick(motivations, rng),
    reliability: randInt(20, 100, rng) + "%",
    secret: generateLore(rng),
    hidden: rng() > 0.7
  };
}

function generateQuestComplication(rng) {
  const complications = [
    "Time limit approaching",
    "Traitor in party",
    "Supplies running low",
    "Unexpected reinforcements",
    "Objective changed",
    "New threat emerged",
    "Ally captured",
    "Resources destroyed",
    "Path blocked",
    "Enemy reinforcement",
    "Betrayal discovered",
    "Curse activated",
    "Monster spawn",
    "Area becomes hostile",
    "Weather worsens",
    "Guide becomes lost",
    "Equipment damaged",
    "Moral dilemma",
    "Strange phenomenon",
    "True enemy revealed"
  ];

  return pick(complications, rng);
}

// ─── ECONOMY EXTENDED ─────────────────────────────────────────────────────

function calculateInflation(basePrice, inflation) {
  return Math.round(basePrice * (1 + (inflation / 100)));
}

function generateSettlementEconomy(rng, settlementType, population) {
  settlementType = settlementType || pick(["Village", "Town", "City", "Metropolis"], rng);
  population = population || randInt(100, 100000, rng);

  const economyHealth = randInt(20, 100, rng);
  const priceMultiplier = economyHealth < 40 ? 1.5 : economyHealth > 80 ? 0.7 : 1.0;

  return {
    settlementType: settlementType,
    population: population,
    economyHealth: economyHealth + "%",
    wealthLevel: economyHealth > 70 ? "Rich" : economyHealth > 50 ? "Moderate" : economyHealth > 30 ? "Poor" : "Impoverished",
    priceMultiplier: priceMultiplier,
    unemployment: 100 - economyHealth + "%",
    mainExports: pickN(["Grain", "Livestock", "Crafts", "Magic Items", "Minerals", "Timber", "Textiles", "Wine", "Weapons"], 3, rng),
    mainImports: pickN(["Food", "Tools", "Luxury Goods", "Raw Materials", "Magic Components", "Slaves", "Weapons"], 3, rng),
    corruptionLevel: randInt(0, 100, rng) + "%",
    taxRate: randInt(10, 50, rng) + "%"
  };
}

function generateMerchantProfile(rng) {
  const specialties = ["Food", "Armor", "Weapons", "Magic", "Textiles", "Jewelry", "Information", "Forbidden Goods", "Services", "Bulk Cargo"];

  return {
    name: genNPCName(rng),
    specialty: pick(specialties, rng),
    wealth: pick(["Poor", "Moderate", "Wealthy", "Rich", "Extremely Wealthy"], rng),
    reputation: randInt(-50, 100, rng),
    baseInventory: pickN(TRADE_GOODS, randInt(5, 15, rng), rng),
    markup: randInt(10, 200, rng) + "%",
    inventory: randInt(10, 1000, rng),
    reliability: randInt(20, 100, rng) + "%",
    connections: randInt(2, 20, rng),
    secrets: generateLore(rng),
    stronghold: pick(["Shop", "Trading Post", "Warehouse", "Caravan", "Ship", "Manor", "Castle", "Underground"], rng)
  };
}

// ─── FLORA & FAUNA EXTENDED ────────────────────────────────────────────────

function generateBiomeFoodWeb(rng, biome) {
  const ecosystem = generateEcosystem(rng, biome);
  const foodWeb = {};

  ecosystem.plants.forEach((plant, idx) => {
    foodWeb[plant] = {
      plant: plant,
      herbivores: ecosystem.animals.slice(0, Math.ceil(ecosystem.animals.length / 2)),
      nutrients: ["Nitrogen", "Phosphorus", "Potassium", "Iron", "Calcium"].slice(0, randInt(2, 4, rng))
    };
  });

  return foodWeb;
}

function generateWildlifePopulation(rng, biome, area) {
  const fauna = FAUNA_BY_BIOME[biome] || FAUNA_BY_BIOME.forest;
  const population = [];

  fauna.forEach(animal => {
    if (rng() > 0.3) {
      population.push({
        animal: animal,
        count: randInt(1, 500, rng),
        predator: rng() > 0.6,
        threat: randInt(0, 10, rng),
        rarity: pick(["Common", "Uncommon", "Rare", "Very Rare"], rng)
      });
    }
  });

  return {
    biome: biome,
    area: area,
    totalAnimals: population.reduce((a, b) => a + b.count, 0),
    populationBySpecies: population,
    biodiversity: population.length,
    ecosystem: generateBiomeFoodWeb(rng, biome)
  };
}

// ─── NPC EXTENDED ──────────────────────────────────────────────────────────

function generateNPCFamily(rng, npc) {
  const relationships = [];
  const relationTypes = ["Parent", "Sibling", "Child", "Grandparent", "Aunt/Uncle", "Cousin", "Spouse", "Ex-Spouse", "Rival", "Enemy"];

  for (let i = 0; i < randInt(0, 5, rng); i++) {
    relationships.push({
      name: genNPCName(rng),
      relation: pick(relationTypes, rng),
      status: pick(["Alive", "Dead", "Lost", "Unknown"], rng),
      feelings: randInt(-100, 100, rng),
      lastSeen: randInt(1, 50, rng) + " years ago"
    });
  }

  return {
    npc: npc.name,
    family: relationships
  };
}

function generateNPCHook(rng, npc) {
  const hooks = [
    "Seeking someone",
    "Running from someone",
    "In debt to someone",
    "Owes favor to someone",
    "Has secret relationship",
    "Hiding illegal activity",
    "Protecting someone",
    "Searching for artifact",
    "Cursed or blessed",
    "On run from law",
    "Working undercover",
    "Blackmailing someone",
    "Being blackmailed",
    "Performing sacrifice",
    "Conducting ritual",
    "Building power base",
    "Planning heist",
    "Seeking revenge",
    "Making redemption",
    "Pursuing forbidden love"
  ];

  return {
    npc: npc.name,
    hook: pick(hooks, rng),
    detail: generateLore(rng),
    danger: randInt(0, 10, rng),
    opportunity: rng() > 0.5
  };
}

function generateNPCEquipment(rng, npc) {
  const baseEquip = pick(NPC_INVENTORIES, rng);
  const extraItems = randInt(0, 5, rng);
  const equipment = [...baseEquip];

  for (let i = 0; i < extraItems; i++) {
    equipment.push(pick(MAGIC_ITEMS, rng));
  }

  return {
    npc: npc.name,
    items: equipment,
    totalWeight: equipment.length * randInt(1, 10, rng),
    value: equipment.length * randInt(10, 100, rng),
    worn: pick(equipment, rng),
    hidden: pick(equipment, rng)
  };
}

// ─── DUNGEON EXTENDED ──────────────────────────────────────────────────────

function generateDungeonTreasure(rng, floorNumber) {
  const treasureTypes = ["Gold Coins", "Gems", "Magic Items", "Weapons", "Armor", "Art Objects", "Manuscripts", "Relics", "Jewelry", "Artifacts"];
  const treasures = [];

  const treasureCount = Math.min(floorNumber, 5);

  for (let i = 0; i < treasureCount; i++) {
    treasures.push({
      type: pick(treasureTypes, rng),
      value: randInt(100 * floorNumber, 10000 * floorNumber, rng),
      rarity: pick(["Common", "Uncommon", "Rare", "Very Rare", "Legendary"], rng),
      cursed: rng() > 0.85,
      trapped: rng() > 0.7
    });
  }

  return {
    floorNumber: floorNumber,
    totalValue: treasures.reduce((a, b) => a + b.value, 0),
    treasures: treasures,
    guardianType: pick(["Monster", "Golem", "Ghost", "Trap", "Cult", "Construct", "Beast", "Swarm"], rng)
  };
}

function generateDungeonEncounter(rng, floorNumber, theme) {
  const monsterTypes = ["Goblin", "Orc", "Undead", "Beast", "Construct", "Demon", "Cult Member", "Dragon", "Giant", "Aberration"];
  const difficulty = floorNumber < 3 ? "Easy" : floorNumber < 6 ? "Medium" : floorNumber < 10 ? "Hard" : "Deadly";

  return {
    floor: floorNumber,
    theme: theme,
    monsterType: pick(monsterTypes, rng),
    monsterCount: randInt(1, 4 + floorNumber, rng),
    difficulty: difficulty,
    treasure: randInt(0, 500 * floorNumber, rng),
    morale: randInt(0, 100, rng),
    hasLeader: rng() > 0.5,
    isAmbush: rng() > 0.6,
    objective: pick(["Defend Area", "Retrieve Item", "Capture Prisoner", "Deliver Message", "Guard Treasure", "Patrol", "Rituals", "Experiment"], rng)
  };
}

// ─── HISTORY EXTENDED ──────────────────────────────────────────────────────

function generateHistoricalFigure(rng) {
  const titles = ["King", "Queen", "Emperor", "Empress", "Lord", "Lady", "Duke", "Duchess", "Count", "Countess", "Prince", "Princess", "General", "Admiral", "Pope", "Arch-Mage"];
  const epitaphs = ["The Conqueror", "The Wise", "The Mad", "The Just", "The Cruel", "The Fair", "The Strong", "The Clever"];

  return {
    name: genNPCName(rng),
    title: pick(titles, rng),
    epitaph: pick(epitaphs, rng),
    birthYear: randInt(-1000, 0, rng),
    deathYear: randInt(1, 1000, rng),
    reign: randInt(1, 60, rng) + " years",
    accomplishments: pickN(HISTORICAL_EVENTS, randInt(2, 5, rng), rng),
    failures: pickN(HISTORICAL_EVENTS, randInt(1, 3, rng), rng),
    legacy: generateLore(rng),
    descendants: randInt(0, 20, rng),
    fame: randInt(0, 100, rng)
  };
}

function generateHistoricalWar(rng, kingdom1, kingdom2) {
  const length = randInt(1, 100, rng);
  const casualties = randInt(1000, 1000000, rng);

  return {
    name: "The War between " + kingdom1 + " and " + kingdom2,
    kingdom1: kingdom1,
    kingdom2: kingdom2,
    startYear: randInt(-500, 500, rng),
    duration: length + " years",
    totalCasualties: casualties,
    causedBy: pick(["Territory", "Religion", "Succession", "Betrayal", "Honor", "Resources", "Revenge"], rng),
    majorBattles: randInt(5, 50, rng),
    outcome: pick(["Victory for " + kingdom1, "Victory for " + kingdom2, "Stalemate", "Mutual Destruction", "Treaty", "Absorption"], rng),
    aftermath: generateLore(rng),
    legends: randInt(1, 10, rng) + " legendary tales"
  };
}

// ─── MAGIC EXTENDED ────────────────────────────────────────────────────────

function generateSpell(rng, level, school) {
  level = level || randInt(0, 9, rng);
  school = school || pick(SPELL_SCHOOLS, rng);

  const components = [];
  if (rng() > 0.3) components.push("Verbal");
  if (rng() > 0.3) components.push("Somatic");
  if (rng() > 0.4) components.push("Material");

  const materials = components.includes("Material") ? [
    pick(["Rare Gem", "Animal Part", "Metal", "Crystal", "Herb", "Incense", "Oil"], rng)
  ] : [];

  return {
    name: pick(SPELL_NAMES, rng),
    level: level,
    school: school,
    castingTime: pick(["1 Action", "1 Bonus Action", "1 Reaction", "1 Minute", "10 Minutes"], rng),
    range: pick(["Self", "Touch", "30 feet", "60 feet", "120 feet", "1 mile", "Sight", "Unlimited"], rng),
    components: components,
    materials: materials,
    duration: pick(["Instantaneous", "1 Round", "1 Minute", "10 Minutes", "1 Hour", "1 Day", "1 Month", "1 Year", "Permanent"], rng),
    concentration: level > 0 ? rng() > 0.3 : false,
    ritual: rng() > 0.7,
    damageType: pick(["Acid", "Cold", "Fire", "Force", "Lightning", "Necrotic", "Poison", "Psychic", "Radiant", "Thunder", "None"], rng),
    savingThrow: rng() > 0.5 ? pick(["STR", "DEX", "CON", "INT", "WIS", "CHA"], rng) : null,
    description: generateLore(rng),
    highlevel: level > 5 ? "Upcast Benefit: " + generateLore(rng) : null
  };
}

function generateLeyLineNetwork(rng, nodeCount) {
  nodeCount = nodeCount || randInt(5, 20, rng);
  const nodes = [];

  for (let i = 0; i < nodeCount; i++) {
    nodes.push({
      id: i,
      type: pick(LEY_LINE_TYPES, rng),
      powerLevel: randInt(1, 10, rng),
      x: randInt(0, 1000, rng),
      y: randInt(0, 1000, rng),
      effects: pickN(["Spell Boost", "Mana Pool", "Summoning", "Divination", "Healing", "Corruption", "Binding", "Channeling"], randInt(1, 3, rng), rng)
    });
  }

  const connections = [];
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      if (rng() > 0.6) {
        const distance = dist(nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y);
        connections.push({
          from: i,
          to: j,
          distance: Math.round(distance),
          power: randInt(1, 10, rng),
          active: rng() > 0.3
        });
      }
    }
  }

  return {
    nodes: nodes,
    connections: connections,
    totalPower: nodes.reduce((a, b) => a + b.powerLevel, 0),
    stability: randInt(0, 100, rng) + "%"
  };
}

function generateArcaneSchool(rng) {
  const traditions = pickN(ARCANE_TRADITIONS, randInt(3, 6, rng), rng);
  const curriculum = [];

  for (let i = 0; i <= 9; i++) {
    curriculum.push({
      level: i,
      spells: randInt(2, 8, rng),
      requiredKnowledge: i > 0 ? "Level " + (i - 1) + " Completion" : "Aptitude Test",
      masterTeacher: generateNPC(rng),
      curriculum: pickN(SPELL_NAMES, randInt(3, 10, rng), rng)
    });
  }

  return {
    name: genKingdomName(rng) + " Academy of " + pick(traditions, rng).split(" - ")[0],
    traditions: traditions,
    headmaster: generateNPC(rng),
    students: randInt(10, 500, rng),
    curriculum: curriculum,
    reputation: pick(["Unknown", "Minor", "Respected", "Renowned", "Legendary"], rng),
    founded: randInt(100, 5000, rng) + " years ago",
    location: pick(["Tower", "Citadel", "Underground", "Floating Island", "Interdimensional"], rng)
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// ADVANCED GENERATION FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

function generateCompleteSettlement(rng) {
  const name = genKingdomName(rng);
  const settlementType = pick(["Village", "Town", "City", "Metropolis"], rng);
  const population = settlementType === "Village" ? randInt(100, 1000, rng) :
                     settlementType === "Town" ? randInt(1000, 10000, rng) :
                     settlementType === "City" ? randInt(10000, 100000, rng) :
                     randInt(100000, 1000000, rng);

  const settlement = {
    name: name,
    type: settlementType,
    population: population,
    climate: pick(Object.keys(BIOMES), rng),
    biome: BIOMES[pick(Object.keys(BIOMES), rng)],
    economy: generateSettlementEconomy(rng, settlementType, population),
    government: pick(["Monarchy", "Democracy", "Oligarchy", "Theocracy", "Anarchy", "Corporate", "Military"], rng),
    ruler: generateNPC(rng),
    guards: randInt(10, population / 100, rng),
    factions: [generateFaction(rng), generateFaction(rng), generateFaction(rng)],
    religion: generateReligion(rng),
    districts: randInt(3, 12, rng),
    landmarks: pickN(["Market", "Temple", "Castle", "University", "Library", "Hospital", "Barracks", "Warehouse", "Inn", "Guild Hall", "Monument", "Garden"], randInt(4, 8, rng), rng),
    NPCs: [
      generateNPC(rng),
      generateNPC(rng),
      generateNPC(rng),
      generateNPC(rng),
      generateNPC(rng)
    ],
    quests: [
      generateQuest(rng, "easy"),
      generateQuest(rng, "medium"),
      generateQuest(rng, "hard")
    ],
    history: generateWorldHistory(rng, [name], 500),
    rumors: pickN(NPC_DIALOGUE.gossip, randInt(3, 8, rng), rng),
    threats: pickN(["Bandits", "Plague", "Famine", "Monsters", "Rival Settlement", "Internal Conflict", "Curse", "Invasion"], randInt(1, 3, rng), rng)
  };

  return settlement;
}

function generateCompleteRegion(rng) {
  const width = 100, height = 100;
  const heightmap = generateHeightmap(width, height, rng, 5, 0.55, 2.3);
  const moisture = generateMoisture(width, height, rng);
  const temperature = generateTemperature(width, height, rng, true);

  const settlements = [];
  const dungeons = [];
  const wilderness = [];

  for (let i = 0; i < randInt(3, 8, rng); i++) {
    settlements.push(generateCompleteSettlement(rng));
  }

  for (let i = 0; i < randInt(2, 5, rng); i++) {
    dungeons.push({
      name: genKingdomName(rng) + " Dungeon",
      layout: generateDungeonLayout(rng, randInt(2, 5, rng), 3),
      ecology: generateDungeonEcology(rng)
    });
  }

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const h = heightmap[y][x];
      const m = moisture[y][x];
      const t = temperature[y][x];
      wilderness.push({
        x: x,
        y: y,
        height: h,
        moisture: m,
        temperature: t,
        biome: classifyBiome(h, m, t)
      });
    }
  }

  return {
    settlements: settlements,
    dungeons: dungeons,
    wilderness: wilderness,
    heightmap: heightmap,
    moisture: moisture,
    temperature: temperature,
    width: width,
    height: height
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// COMPREHENSIVE UTILITY AND SIMULATION FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

// ─── POLITICAL SYSTEM ──────────────────────────────────────────────────────

function generateNoblehouse(rng) {
  const heraldry = ["Lion", "Dragon", "Eagle", "Wolf", "Bear", "Phoenix", "Serpent", "Stag"];
  const colors = ["Red", "Blue", "Green", "Gold", "Silver", "Black", "White", "Purple"];
  const houses = [];

  for (let i = 0; i < randInt(1, 3, rng); i++) {
    houses.push({
      name: "House of " + pick(["Gold", "Iron", "Stone", "Wind", "Fire", "Oak", "Ash", "Thorn"], rng),
      heraldry: pick(heraldry, rng),
      colors: [pick(colors, rng), pick(colors, rng)],
      founded: randInt(100, 5000, rng) + " years ago",
      head: generateNPC(rng),
      members: randInt(10, 100, rng),
      lands: randInt(10, 1000, rng) + " sq mi",
      wealth: randInt(10000, 10000000, rng),
      alliances: randInt(1, 8, rng),
      enemies: randInt(0, 5, rng),
      secrets: generateLore(rng),
      goals: pickN(FACTION_GOALS, 2, rng),
      weakness: generateLore(rng)
    });
  }

  return houses;
}

function generateCourt(rng) {
  const king = generateNPC(rng);
  const council = [];

  const positions = ["Chancellor", "Treasurer", "General", "Advisor", "Chamberlain", "Justice", "Spymaster", "Chief Priest"];

  positions.forEach(position => {
    if (rng() > 0.2) {
      council.push({
        position: position,
        holder: generateNPC(rng),
        influence: randInt(0, 100, rng),
        allegiance: pick(["King", "Self", "Faction", "Rival"], rng),
        secret: generateLore(rng)
      });
    }
  });

  return {
    ruler: king,
    council: council,
    courtIntrigue: randInt(0, 100, rng),
    stability: randInt(20, 100, rng) + "%",
    legitimacy: randInt(20, 100, rng) + "%",
    laws: pickN(["Strict", "Moderate", "Lenient", "Arbitrary", "Just", "Corrupt", "Military", "Religious", "Mercantile", "Anarchic"], randInt(3, 6, rng), rng),
    treasury: randInt(100000, 10000000, rng),
    army: randInt(100, 100000, rng),
    spies: randInt(10, 1000, rng),
    threat: pick(["Internal Revolt", "External Invasion", "Plague", "Curse", "Magic Gone Wrong", "Faction War", "Religious Crisis", "Economic Collapse", "Succession Crisis", "Assassination Plot"], rng)
  };
}

// ─── WARFARE AND MILITARY ──────────────────────────────────────────────────

function generateMilitaryForce(rng, strength) {
  strength = strength || randInt(100, 100000, rng);
  const composition = {};

  composition.infantry = Math.floor(strength * 0.4);
  composition.cavalry = Math.floor(strength * 0.15);
  composition.archers = Math.floor(strength * 0.25);
  composition.mages = Math.floor(strength * 0.1);
  composition.monsters = Math.floor(strength * 0.1);

  return {
    totalStrength: strength,
    composition: composition,
    equipment: pick(["Poor", "Decent", "Well-Equipped", "Legendary"], rng),
    morale: randInt(0, 100, rng) + "%",
    discipline: randInt(0, 100, rng) + "%",
    commander: generateNPC(rng),
    tactics: pickN(["Cavalry Charge", "Shield Wall", "Phalanx", "Archer Rain", "Magic Barrage", "Night Assault", "Siege", "Ambush"], randInt(2, 4, rng), rng),
    strengths: pickN(["Numbers", "Equipment", "Tactics", "Magic", "Morale", "Discipline"], randInt(1, 3, rng), rng),
    weaknesses: pickN(["Inexperienced", "Low Morale", "Poor Equipment", "Bad Tactics", "Weak Magic", "Disorganized"], randInt(1, 3, rng), rng)
  };
}

function simulateBattle(rng, army1, army2) {
  let strength1 = army1.totalStrength;
  let strength2 = army2.totalStrength;
  let rounds = 0;

  while (strength1 > 0 && strength2 > 0 && rounds < 20) {
    const damage1 = Math.floor(strength1 * (0.1 + rng() * 0.2) * (Math.random() > 0.5 ? 1 : 0.5));
    const damage2 = Math.floor(strength2 * (0.1 + rng() * 0.2) * (Math.random() > 0.5 ? 1 : 0.5));

    strength1 -= damage2;
    strength2 -= damage1;
    rounds++;
  }

  return {
    rounds: rounds,
    army1Losses: army1.totalStrength - Math.max(0, strength1),
    army2Losses: army2.totalStrength - Math.max(0, strength2),
    winner: strength1 > 0 ? "Army 1" : strength2 > 0 ? "Army 2" : "Draw",
    casualties: (army1.totalStrength - strength1) + (army2.totalStrength - strength2),
    siegeDuration: randInt(1, 100, rng) + " days"
  };
}

// ─── DISASTER AND CATACLYSM ────────────────────────────────────────────────

const DISASTER_TYPES = [
  "Earthquake", "Volcanic Eruption", "Tsunami", "Hurricane", "Tornado", "Flood", "Drought",
  "Famine", "Plague", "Magic Explosion", "Meteor Impact", "Portal Opening", "Dimensional Rift",
  "Time Collapse", "Undead Rising", "Demon Summoning", "Dragon Awakening", "Curse Activation",
  "Star Fall", "Moon Crash", "Sun Darkening", "Gravity Reversal", "Reality Fracture"
];

function generateDisaster(rng) {
  const type = pick(DISASTER_TYPES, rng);
  const severity = randInt(1, 10, rng);
  const casualties = randInt(1, 1000000, rng) * severity;

  return {
    type: type,
    severity: severity + "/10",
    casualties: casualties,
    displaced: casualties * randInt(2, 10, rng),
    damage: randInt(1000000, 1000000000, rng),
    durationDays: randInt(1, 365, rng),
    affectedArea: randInt(1, 10000, rng) + " square miles",
    causedBy: generateLore(rng),
    aftermath: generateLore(rng),
    recovery: randInt(1, 100, rng) + " years",
    legend: "The " + pick(["Great", "Dark", "Terrible", "Cursed", "Blessed", "Lost", "Eternal"], rng) + " " + type
  };
}

// ─── SCIENCE AND TECHNOLOGY ────────────────────────────────────────────────

const INVENTIONS = [
  "Printing Press", "Telescope", "Microscope", "Steam Engine", "Electricity", "Light Bulb",
  "Gunpowder Weapons", "Crossbow", "Siege Engine", "Mechanical Clock", "Compass", "Sextant",
  "Telescope for Stars", "Alchemy Laboratory", "Golem Blueprint", "Mechanical Automaton",
  "Airship Design", "Submarine", "Clockwork Dragon", "Perpetual Motion Machine", "Magical Engine"
];

function generateTechnologicalLevel(rng) {
  const levels = {
    stone: { name: "Stone Age", weapons: ["Spear", "Club", "Stone Axe"], armor: ["Leather", "Bone"] },
    bronze: { name: "Bronze Age", weapons: ["Bronze Sword", "Bronze Spear"], armor: ["Bronze Plate"] },
    iron: { name: "Iron Age", weapons: ["Iron Sword", "Iron Spear"], armor: ["Iron Plate"] },
    medieval: { name: "Medieval", weapons: ["Longsword", "Crossbow"], armor: ["Full Plate", "Chainmail"] },
    renaissance: { name: "Renaissance", weapons: ["Musket", "Cannon"], armor: ["Plate Armor"] },
    industrial: { name: "Industrial", weapons: ["Rifle", "Artillery"], armor: ["Steel Armor"] },
    magical: { name: "Magical", weapons: ["Enchanted Weapons"], armor: ["Magical Armor"] }
  };

  const level = pick(Object.keys(levels), rng);
  return {
    level: levels[level],
    innovations: pickN(INVENTIONS, randInt(2, 5, rng), rng),
    literacy: randInt(5, 95, rng) + "%",
    infrastructure: randInt(0, 100, rng) + "%",
    transportation: pick(["Foot", "Horse", "Cart", "Ship", "Airship"], rng),
    communication: pick(["Messenger", "Signal Fire", "Magical Sending", "Scrying"], rng)
  };
}

// ─── PLANAR AND COSMIC ─────────────────────────────────────────────────────

const PLANES = [
  "Material Plane", "Feywild", "Shadowfell", "Abyss", "Hells", "Celestia", "Mechanus",
  "Limbo", "Pandemonium", "Tarterus", "Gray Waste", "Ethereal Plane", "Astral Plane",
  "Outer Darkness", "Void", "Dream Realm", "Shadow Plane", "Positive Energy Plane", "Negative Energy Plane"
];

function generatePlanarConnection(rng) {
  return {
    name: pick(PLANES, rng) + " Gate",
    destination: pick(PLANES, rng),
    type: pick(["Portal", "Rift", "Door", "Tear", "Crossing", "Bridge", "Tunnel"], rng),
    stability: randInt(0, 100, rng) + "%",
    power: randInt(1, 10, rng),
    guardians: randInt(0, 20, rng),
    requirements: pickN(["Specific Time", "Blood Sacrifice", "Magic Word", "Key Item", "Ritual", "Prophecy"], randInt(0, 3, rng), rng),
    danger: pick(["Safe", "Risky", "Very Dangerous", "Deadly", "Apocalyptic"], rng),
    discovery: "Recently / Long Ago / Legendary"
  };
}

// ─── PROPHECY AND DIVINATION ────────────────────────────────────────────────

function generateProphecy(rng) {
  const subjects = ["A child", "A warrior", "A kingdom", "The world", "The gods", "Magic itself", "Humanity", "The realms"];
  const events = ["Rise to power", "Bring salvation", "Cause destruction", "Unite the realms", "Break the chains", "Seal the gates", "Open the doors", "End the age"];
  const timeframes = ["In a hundred years", "When the stars align", "At the darkest hour", "When the bell tolls", "Before the sun sets", "After the reckoning"];

  return {
    text: pick(subjects, rng) + " shall " + pick(events, rng) + " " + pick(timeframes, rng),
    origin: generateNPC(rng).name,
    revealed: randInt(1, 1000, rng) + " years ago",
    believers: randInt(10, 100000, rng),
    accuracy: randInt(0, 100, rng) + "%",
    interpretation: generateLore(rng),
    symbol: pick(["Crescent Moon", "Star", "Crown", "Sword", "Flame", "Shadow", "Light"], rng)
  };
}

// ─── SECRETS AND MYSTERIES ────────────────────────────────────────────────

function generateSecret(rng) {
  const secretTypes = [
    "Hidden treasure location",
    "Illegitimate heir",
    "Murder cover-up",
    "Forbidden love affair",
    "Curse or blessing",
    "Secret alliance",
    "Betrayal",
    "Hidden power source",
    "Ancient evil imprisoned",
    "Prophecy",
    "Magical artifact location",
    "Extortion material",
    "Dangerous knowledge",
    "Dark ritual",
    "Identity deception",
    "Forbidden magic use",
    "Assassination order",
    "Corruption scheme",
    "Resurrection ritual",
    "Portal location"
  ];

  return {
    secret: pick(secretTypes, rng),
    keeper: generateNPC(rng),
    knownBy: randInt(1, 100, rng),
    danger: randInt(0, 10, rng),
    consequence: "If revealed: " + generateLore(rng),
    clues: pickN([generateLore(rng), generateLore(rng), generateLore(rng), generateLore(rng), generateLore(rng)], randInt(1, 3, rng), rng),
    misdirection: generateLore(rng)
  };
}

// ─── RANDOM ENCOUNTER GENERATION ──────────────────────────────────────────

function generateRandomEncounter(rng, biome, difficulty) {
  difficulty = difficulty || pick(["Easy", "Medium", "Hard", "Deadly"], rng);
  const encounterTypes = ["Combat", "Social", "Environmental", "Mystery", "Chase", "Trap", "Moral Dilemma"];

  return {
    type: pick(encounterTypes, rng),
    biome: biome,
    difficulty: difficulty,
    enemies: randInt(1, 10, rng),
    environment: generateLore(rng),
    twist: generateLore(rng),
    treasure: randInt(0, 1000, rng),
    experience: randInt(100, 10000, rng),
    hook: pick(NPC_DIALOGUE.gossip, rng)
  };
}

// ─── ARTIFACT GENERATION ────────────────────────────────────────────────────

const ARTIFACT_POWERS = [
  "Raise the dead",
  "Control weather",
  "Shape reality",
  "Grant immortality",
  "Summon creatures",
  "Destroy civilizations",
  "Heal any wound",
  "Curse bloodlines",
  "Stop time",
  "Open portals",
  "Grant wishes",
  "Control minds",
  "Destroy magic",
  "Create magic",
  "End the world",
  "Save the world",
  "Merge planes",
  "Trap souls",
  "Free souls",
  "Unlock knowledge"
];

function generateArtifact(rng) {
  return {
    name: pick(["The", "Ancient", "Cursed", "Holy", "Legendary"], rng) + " " + pick(["Tome", "Sword", "Crown", "Ring", "Amulet", "Staff", "Chalice", "Orb"], rng) + " of " + pick(["Power", "Destiny", "Ruin", "Hope", "Eternal", "Void", "Creation", "Destruction"], rng),
    age: randInt(1000, 100000, rng) + " years",
    creator: generateLore(rng),
    material: pick(["Gold", "Silver", "Crystal", "Bone", "Wood", "Stone", "Metal", "Starlight", "Void Matter"], rng),
    power: pick(ARTIFACT_POWERS, rng),
    strength: randInt(1, 20, rng) + "/20",
    curse: rng() > 0.4 ? generateLore(rng) : "None",
    location: pick(["Lost", "Guarded", "Buried", "Sealed", "Stolen", "Hidden"], rng),
    legend: generateLore(rng),
    seeker: generateNPC(rng),
    trials: randInt(3, 12, rng),
    value: "Priceless"
  };
}

// ─── REALM GENERATION ──────────────────────────────────────────────────────

function generateFullRealm(rng) {
  const realmName = genKingdomName(rng);
  const kingdoms = [];

  for (let i = 0; i < randInt(3, 8, rng); i++) {
    kingdoms.push({
      name: genKingdomName(rng),
      capital: generateCompleteSettlement(rng),
      ruler: generateNPC(rng),
      government: pick(["Monarchy", "Democracy", "Theocracy", "Oligarchy"], rng),
      military: generateMilitaryForce(rng, randInt(1000, 100000, rng)),
      factions: [generateFaction(rng), generateFaction(rng)],
      history: generateWorldHistory(rng, [genKingdomName(rng)], 1000)
    });
  }

  return {
    name: realmName,
    kingdoms: kingdoms,
    pantheon: generatePantheon(rng, 12),
    magicLevel: pick(["Low", "Moderate", "High", "Extreme"], rng),
    technologyLevel: generateTechnologicalLevel(rng),
    age: randInt(100, 100000, rng) + " years",
    threats: pickN(DISASTER_TYPES, 3, rng),
    wonders: randInt(3, 12, rng),
    secrets: [generateSecret(rng), generateSecret(rng), generateSecret(rng)],
    prophecies: [generateProphecy(rng), generateProphecy(rng)],
    planarConnections: [generatePlanarConnection(rng), generatePlanarConnection(rng)],
    artifacts: [generateArtifact(rng), generateArtifact(rng)],
    weather: generateSeasonalWeatherPatterns(rng, pick(Object.keys(BIOMES), rng), 30),
    calendar: CALENDAR
  };
}

// ─── ADVANCED SIMULATION FUNCTIONS ──────────────────────────────────────────

function simulateEconomicTrade(rng, settlements, days) {
  const trades = [];

  for (let day = 0; day < days; day++) {
    if (rng() > 0.5) {
      const from = pick(settlements, rng);
      const to = pick(settlements, rng);

      if (from !== to) {
        trades.push({
          day: day,
          from: from.name,
          to: to.name,
          goods: pickN(TRADE_GOODS, randInt(2, 5, rng), rng),
          profit: randInt(-50, 500, rng) + "%",
          risk: pick(["Safe", "Risky", "Dangerous"], rng),
          merchant: generateNPC(rng)
        });
      }
    }
  }

  return trades;
}

function simulatePoliticalIntrigue(rng, court, days) {
  const events = [];

  for (let day = 0; day < days; day++) {
    if (rng() > 0.7) {
      events.push({
        day: day,
        event: generateLore(rng),
        involved: [generateNPC(rng), generateNPC(rng)],
        consequence: pick(["Scandal", "Alliance", "Betrayal", "Murder", "Promotion", "Disgrace"], rng),
        impact: randInt(0, 100, rng)
      });
    }
  }

  return events;
}

// ═══════════════════════════════════════════════════════════════════════════
// PROCEDURAL WORLD EVENT AND SCENARIO GENERATION
// ═══════════════════════════════════════════════════════════════════════════

const WORLD_EVENTS = [
  "Caravan robbed by bandits",
  "Noble assassinated by hired killer",
  "Crops fail due to strange blight",
  "Strange lights appear in the sky",
  "Important person goes missing",
  "Two nations sign peace treaty",
  "Plague breaks out in city",
  "Ancient tomb is discovered",
  "Magical phenomena occur",
  "Religious figure performs miracle",
  "Legendary hero returns",
  "Monster spotted near settlement",
  "Trade route disrupted",
  "Political scandal erupts",
  "Rare comet appears",
  "Natural disaster strikes",
  "Magic goes wild",
  "Ancient curse awakens",
  "Hidden treasure is found",
  "Enemy army approaches",
  "Great fire consumes district",
  "Famine threatens region",
  "New technology discovered",
  "Religious schism occurs",
  "Revolutionary movement starts",
  "Child with strange powers born",
  "Portal opens to other realm",
  "Undead rise from graves",
  "Magic stops working",
  "Time runs backwards",
  "Everyone forgets something important",
  "Person with split personality emerges",
  "Twins separated reunite",
  "Reincarnation discovered",
  "Doppelganger appears",
  "Person gains amnesia",
  "Miracle healing occurs",
  "Impossible disease spreads",
  "Technology malfunctions",
  "Weather becomes impossible"
];

function generateWorldEvent(rng, realm) {
  return {
    event: pick(WORLD_EVENTS, rng),
    date: getCurrentDate(randInt(1, 365, rng)),
    location: pick(realm.kingdoms, rng).name,
    involved: [generateNPC(rng), generateNPC(rng), generateNPC(rng)],
    consequence: generateLore(rng),
    impact: randInt(0, 100, rng),
    publicity: pick(["Secret", "Rumor", "Known", "Famous", "Legendary"], rng),
    duration: randInt(1, 365, rng) + " days",
    resolution: generateLore(rng)
  };
}

function generateCampaignArc(rng, length) {
  length = length || 10;
  const arc = [];

  for (let i = 0; i < length; i++) {
    arc.push({
      chapter: i + 1,
      title: pick(["The Beginning", "Rising Tensions", "Trials", "The Revelation", "The Betrayal", "The Search", "The Battle", "The Sacrifice", "The Triumph", "The Aftermath"], rng),
      questChain: generateQuestChain(rng, randInt(2, 5, rng)),
      majorEvent: generateWorldEvent(rng, {}),
      revelation: generateSecret(rng),
      climax: rng() > 0.7
    });
  }

  return arc;
}

// ─── CHARACTER DEVELOPMENT SYSTEM ──────────────────────────────────────────

function generateCharacterArc(rng, npc) {
  const traits = ["Gains Power", "Loses Power", "Finds Love", "Loses Love", "Betrayed", "Redeems Self", "Goes Insane", "Becomes Wise", "Gets Cursed", "Gets Blessed"];
  const chapters = [];

  for (let i = 0; i < 5; i++) {
    chapters.push({
      act: i + 1,
      trait: pick(traits, rng),
      event: generateLore(rng),
      consequence: generateLore(rng),
      allies: randInt(0, 5, rng),
      enemies: randInt(0, 3, rng)
    });
  }

  return {
    character: npc.name,
    beginning: generateNPCBackstory(rng, npc),
    arc: chapters,
    ending: generateLore(rng),
    legacy: generateLore(rng)
  };
}

// ─── SETTLEMENT DEVELOPMENT ────────────────────────────────────────────────

function simulateSettlementGrowth(rng, settlement, years) {
  const history = [];

  for (let year = 0; year < years; year++) {
    const event = pick(WORLD_EVENTS, rng);
    const growth = randInt(-20, 50, rng);
    const newPop = Math.max(0, settlement.population + (settlement.population * growth / 100));

    history.push({
      year: year,
      event: event,
      populationChange: growth + "%",
      newPopulation: Math.round(newPop),
      economy: randInt(0, 100, rng) + "%",
      stability: randInt(0, 100, rng) + "%",
      threat: rng() > 0.7 ? pick(DISASTER_TYPES, rng) : "None"
    });
  }

  return {
    settlement: settlement.name,
    startingPopulation: settlement.population,
    finalPopulation: Math.round(history[years - 1].newPopulation),
    growth: ((history[years - 1].newPopulation - settlement.population) / settlement.population * 100).toFixed(1) + "%",
    events: history
  };
}

// ─── RELATIONSHIP DYNAMICS ─────────────────────────────────────────────────

function generateRelationship(rng, npc1, npc2) {
  const types = ["Romantic", "Familial", "Adversarial", "Professional", "Mentorship", "Partnership", "Rivalry", "Alliance", "Betrayal"];
  const status = ["Starting", "Growing", "Stable", "Deteriorating", "Crisis", "Ended", "Secret", "Complex"];

  return {
    npc1: npc1.name,
    npc2: npc2.name,
    type: pick(types, rng),
    status: pick(status, rng),
    affection: randInt(-100, 100, rng),
    duration: randInt(0, 50, rng) + " years",
    secret: rng() > 0.5 ? generateSecret(rng) : "None",
    conflict: generateLore(rng),
    resolution: generateLore(rng),
    future: pick(["Happy Ending", "Tragic Ending", "Bitter Ending", "Uncertain"], rng)
  };
}

function generateNPCNetwork(rng, centerNPC, connections) {
  connections = connections || 5;
  const network = {
    center: centerNPC,
    connections: []
  };

  for (let i = 0; i < connections; i++) {
    const connected = generateNPC(rng);
    network.connections.push({
      npc: connected,
      relationship: generateRelationship(rng, centerNPC, connected),
      strength: randInt(0, 100, rng)
    });
  }

  return network;
}

// ─── ECONOMY SIMULATION ────────────────────────────────────────────────────

function simulateMarketFluctuations(rng, goods, days) {
  const history = [];

  goods.forEach(good => {
    const priceHistory = [];

    for (let day = 0; day < days; day++) {
      const volatility = randInt(-20, 20, rng) / 100;
      const newPrice = Math.max(1, Math.round(good.basePrice * (1 + volatility)));

      priceHistory.push({
        day: day,
        price: newPrice,
        change: newPrice - good.basePrice,
        supply: pick(["Scarce", "Limited", "Adequate", "Abundant", "Excessive"], rng),
        demand: pick(["Very Low", "Low", "Medium", "High", "Very High"], rng)
      });
    }

    history.push({
      good: good.name,
      basePrice: good.basePrice,
      history: priceHistory,
      averagePrice: Math.round(priceHistory.reduce((a, b) => a + b.price, 0) / days),
      highPrice: Math.max(...priceHistory.map(p => p.price)),
      lowPrice: Math.min(...priceHistory.map(p => p.price))
    });
  });

  return history;
}

// ─── RANDOM ENCOUNTER TABLE ────────────────────────────────────────────────

function generateRandomTable(rng, tableName, rollCount) {
  rollCount = rollCount || 20;
  const roll = randInt(1, rollCount, rng);

  const tables = {
    socialEncounter: [
      "Beggar asking for coin",
      "Traveling merchant",
      "Priest offering blessing",
      "Child lost from parents",
      "Drunk causing trouble",
      "Scholar looking for information",
      "Fleeing criminal",
      "Injured person needing help",
      "Suspicious figure watching",
      "Enthusiastic explorer",
      "Widow seeking help",
      "Gambler proposing game",
      "Storyteller with tale",
      "Runaway slave",
      "Con artist with scheme",
      "Noble requiring service",
      "Mysterious stranger",
      "Local official",
      "Traveling performer",
      "Thief casing area"
    ],
    treasureTypes: [
      "Gold coins (d100 x 10)",
      "Gemstones (d20)",
      "Jewelry (d10 pieces)",
      "Magic scroll (d4)",
      "Magic potion (d8)",
      "Rare weapon",
      "Armor of protection",
      "Spellbook",
      "Ancient tome",
      "Cursed item",
      "Holy relic",
      "Artwork (d20 x 100 gp)",
      "Musical instrument",
      "Rare component",
      "Alchemical supplies",
      "Trade goods (d100 gp)",
      "Deed or title",
      "Map to treasure",
      "Key to secret door",
      "Mysterious amulet"
    ],
    weatherShifts: [
      "Sudden clear skies",
      "Dark storm clouds",
      "Thick fog rolls in",
      "Wind picks up",
      "Temperature drops",
      "Heat becomes oppressive",
      "Lightning strikes nearby",
      "Snow begins falling",
      "Rain starts heavily",
      "Dust storm arrives",
      "Hail falls suddenly",
      "Aurora appears",
      "Eclipse occurs",
      "Strange lights",
      "Mist becomes magical",
      "Ground trembles",
      "Strange smell",
      "Eerie silence",
      "Unnatural sounds",
      "Reality distorts"
    ]
  };

  return {
    roll: roll,
    table: tableName,
    result: tables[tableName] ? tables[tableName][roll - 1] : "Unknown"
  };
}

// ─── TRAP AND PUZZLE GENERATION ────────────────────────────────────────────

const TRAP_TYPES = [
  "Pit Trap", "Poison Gas", "Pressure Plate", "Pendulum Blade", "Dart Launcher",
  "Falling Block", "Floor Collapse", "Spear Wall", "Fire Trap", "Acid Pool",
  "Electrical Discharge", "Magical Rune", "Guillotine", "Spring Blade", "Bear Trap",
  "Caltrops", "Glass Shards", "Quicksand", "Web", "Cursed Object"
];

const PUZZLE_TYPES = [
  "Riddle", "Lock and Key", "Pattern Recognition", "Combination Lock",
  "Moving Blocks", "Symbol Matching", "Weight Scale", "Pressure Plate Sequence",
  "Magic Circle", "Cipher", "Mechanical Puzzle", "Mirror Reflection",
  "Shadow Matching", "Color Sequence", "Number Puzzle", "Word Play",
  "Direction Puzzle", "Time Based", "Memory Test", "Physical Coordination"
];

function generateTrap(rng) {
  const complexity = randInt(1, 5, rng);
  return {
    type: pick(TRAP_TYPES, rng),
    complexity: complexity,
    damage: randInt(1, 10 * complexity, rng) + "d6",
    savingThrow: rng() > 0.5 ? pick(["DEX", "STR", "CON"], rng) : "None",
    disarmDifficulty: randInt(10, 20 + complexity * 2, rng),
    triggers: pickN(["Weight", "Pressure Plate", "Motion", "Sound", "Light", "Time"], randInt(1, 2, rng), rng),
    reset: pick(["Automatic", "Manual", "Never"], rng),
    hidden: rng() > 0.3
  };
}

function generatePuzzle(rng) {
  return {
    type: pick(PUZZLE_TYPES, rng),
    difficulty: randInt(1, 5, rng),
    solution: generateLore(rng),
    hints: pickN([generateLore(rng), generateLore(rng), generateLore(rng)], randInt(1, 3, rng), rng),
    reward: randInt(100, 5000, rng),
    penalty: generateLore(rng),
    timeLimit: rng() > 0.5 ? randInt(1, 60, rng) + " minutes" : "None",
    participants: randInt(1, 6, rng)
  };
}

// ─── NARRATIVE GENERATION ──────────────────────────────────────────────────

function generateShortStory(rng) {
  const protagonist = generateNPC(rng);
  const antagonist = generateNPC(rng);
  const setting = pick(Object.keys(BIOMES), rng);

  return {
    title: pick(["The Tale of", "The Legend of", "The Story of", "The Tragedy of"], rng) + " " + protagonist.name,
    protagonist: protagonist,
    antagonist: antagonist,
    setting: setting,
    exposition: generateLore(rng),
    risingAction: generateLore(rng),
    climax: generateLore(rng),
    fallingAction: generateLore(rng),
    resolution: generateLore(rng),
    moral: generateLore(rng),
    theme: pick(["Love", "Betrayal", "Redemption", "Sacrifice", "Greed", "Justice", "Revenge", "Hope"], rng)
  };
}

// ─── EXTENDED MONSTER GENERATION ────────────────────────────────────────────

const MONSTER_TYPES = [
  "Humanoid", "Undead", "Fiend", "Celestial", "Dragon", "Elemental",
  "Fey", "Giant", "Beast", "Monstrosity", "Ooze", "Plant",
  "Aberration", "Construct", "Swarm", "Hybrid"
];

const MONSTER_BEHAVIORS = [
  "Aggressive", "Territorial", "Protective", "Curious", "Fearful",
  "Intelligent", "Animalistic", "Chaotic", "Lawful", "Neutral",
  "Predatory", "Scavenger", "Pack Hunter", "Solitary", "Migratory"
];

function generateMonster(rng, difficulty) {
  difficulty = difficulty || "Medium";

  const hpMultiplier = difficulty === "Easy" ? 1 : difficulty === "Medium" ? 2 : difficulty === "Hard" ? 3 : 4;
  const damageMultiplier = difficulty === "Easy" ? 1 : difficulty === "Medium" ? 1.5 : difficulty === "Hard" ? 2 : 3;

  return {
    name: pick(["Dire", "Giant", "Ancient", "Corrupted", "Undead", "Shadow"], rng) + " " + pick(["Wolf", "Bear", "Spider", "Dragon", "Demon", "Ghost", "Beast"], rng),
    type: pick(MONSTER_TYPES, rng),
    difficulty: difficulty,
    hitPoints: randInt(10 * hpMultiplier, 100 * hpMultiplier, rng),
    armorClass: randInt(10, 20, rng),
    damage: randInt(1, 10, rng) + "d6 +" + randInt(0, 5, rng),
    attacks: randInt(1, 4, rng),
    abilities: pickN(["Breathe Fire", "Cast Spells", "Teleport", "Regenerate", "Fly", "Swim", "Climb", "Burrow"], randInt(1, 4, rng), rng),
    immunities: pickN(["Poison", "Fire", "Cold", "Lightning", "Psychic", "Radiant", "Necrotic"], randInt(0, 3, rng), rng),
    resistances: pickN(["Slashing", "Piercing", "Bludgeoning", "Fire", "Cold"], randInt(0, 2, rng), rng),
    behavior: pick(MONSTER_BEHAVIORS, rng),
    treasureMultiplier: difficulty === "Easy" ? 0.5 : difficulty === "Medium" ? 1 : difficulty === "Hard" ? 2 : 3,
    loot: [generateTreasureHoard(rng)],
    intelligence: randInt(2, 20, rng)
  };
}

// ─── DUNGEON ECOLOGY EXPANDED ──────────────────────────────────────────────

function generateDungeonLevel(rng, floorNumber, theme) {
  const roomCount = randInt(5, 20, rng);
  const rooms = [];

  for (let i = 0; i < roomCount; i++) {
    rooms.push({
      id: floorNumber + "-" + i,
      type: pick(ROOM_TYPES, rng),
      width: randInt(20, 80, rng),
      height: randInt(20, 80, rng),
      difficulty: floorNumber < 3 ? "Easy" : floorNumber < 6 ? "Medium" : "Hard",
      encounter: generateDungeonEncounter(rng, floorNumber, theme),
      treasure: generateDungeonTreasure(rng, floorNumber),
      trap: rng() > 0.5 ? generateTrap(rng) : null,
      puzzle: rng() > 0.6 ? generatePuzzle(rng) : null,
      connections: randInt(1, 4, rng)
    });
  }

  return {
    floor: floorNumber,
    theme: theme,
    rooms: rooms,
    hazards: pickN(ROOM_HAZARDS, randInt(1, 5, rng), rng),
    totalTreasure: rooms.reduce((sum, room) => sum + room.treasure.totalValue, 0),
    difficulty: floorNumber < 3 ? "Easy" : floorNumber < 6 ? "Medium" : floorNumber < 10 ? "Hard" : "Deadly"
  };
}

function generateCompleteDungeon(rng, floors, theme) {
  floors = floors || randInt(3, 10, rng);
  theme = theme || pick(DUNGEON_THEMES, rng);

  const dungeon = {
    name: genKingdomName(rng) + " Dungeon",
    theme: theme,
    floors: [],
    totalTreasure: 0,
    totalRooms: 0,
    difficulty: "Unknown",
    entranceType: pick(["Secret Door", "Obvious Door", "Hidden Trap", "Magical Portal", "Collapsed Building", "Well", "Cave Mouth"], rng),
    exitType: pick(["Same as Entrance", "Secret Passage", "One-Way Portal", "Escape Route", "Hidden Door", "Underground River"], rng),
    secrets: pickN(generateSecret(rng), 3, rng),
    legend: generateLegend(rng, pick(["Heroic", "Tragic", "Mysterious"], rng))
  };

  for (let f = 0; f < floors; f++) {
    const level = generateDungeonLevel(rng, f + 1, theme);
    dungeon.floors.push(level);
    dungeon.totalTreasure += level.rooms.reduce((sum, room) => sum + room.treasure.totalValue, 0);
    dungeon.totalRooms += level.rooms.length;
  }

  return dungeon;
}

// ═══════════════════════════════════════════════════════════════════════════
// ADVANCED CONTENT GENERATION AND WORLD SIMULATION
// ═══════════════════════════════════════════════════════════════════════════

// ─── PROFESSION AND SKILL GENERATION ────────────────────────────────────────

const PROFESSIONS = [
  "Soldier", "Knight", "Mercenary", "Assassin", "Thief", "Rogue", "Paladin",
  "Priest", "Monk", "Nun", "Wizard", "Sorcerer", "Warlock", "Druid",
  "Ranger", "Barbarian", "Fighter", "Bard", "Artificer", "Alchemist",
  "Blacksmith", "Armorer", "Weaponsmith", "Goldsmith", "Jeweler", "Leatherworker",
  "Tailor", "Weaver", "Dyer", "Mason", "Carpenter", "Stonemason",
  "Farmer", "Herder", "Fisherman", "Hunter", "Trapper", "Gatherer",
  "Merchant", "Trader", "Peddler", "Vendor", "Smuggler", "Fence",
  "Healer", "Doctor", "Surgeon", "Herbalist", "Midwife", "Apothecary",
  "Scholar", "Scribe", "Clerk", "Accountant", "Librarian", "Archivist",
  "Artist", "Painter", "Sculptor", "Musician", "Dancer", "Performer",
  "Entertainer", "Storyteller", "Poet", "Playwright", "Author", "Journalist",
  "Innkeeper", "Tavern Keeper", "Brewer", "Baker", "Cook", "Butcher",
  "Detective", "Constable", "Guard", "Watchman", "Sheriff", "Judge",
  "Gambler", "Fortune Teller", "Diviner", "Oracle", "Soothsayer", "Sage",
  "Sage", "Philosopher", "Mathematician", "Astronomer", "Alchemist", "Naturalist",
  "Explorer", "Adventurer", "Guide", "Scout", "Tracker", "Pathfinder"
];

const PROFESSION_TOOLS = {
  "Soldier": ["Sword", "Shield", "Armor", "Spear"],
  "Wizard": ["Spellbook", "Wand", "Robe", "Component Pouch"],
  "Thief": ["Lockpicks", "Rope", "Dagger", "Caltrops"],
  "Priest": ["Holy Symbol", "Mace", "Prayer Book", "Incense"],
  "Blacksmith": ["Hammer", "Anvil", "Tongs", "Furnace"],
  "Merchant": ["Scale", "Ledger", "Coin Purse", "Goods"],
  "Healer": ["Bandages", "Potions", "Herbs", "Medical Kit"]
};

function generateProfessionalNPC(rng) {
  const profession = pick(PROFESSIONS, rng);
  const npc = generateNPC(rng);

  return {
    ...npc,
    profession: profession,
    experience: randInt(1, 50, rng) + " years",
    skill: randInt(5, 20, rng),
    tools: PROFESSION_TOOLS[profession] || ["Basic Tools"],
    specialization: generateLore(rng),
    masterwork: rng() > 0.5,
    reputation: randInt(0, 100, rng),
    workplace: pick(["Shop", "Home", "Guild", "Organization", "Mobile", "Unknown"], rng),
    apprentices: randInt(0, 5, rng),
    mentors: randInt(0, 3, rng),
    masterpieces: pickN([generateLore(rng), generateLore(rng), generateLore(rng)], randInt(0, 3, rng), rng)
  };
}

// ─── GUILD AND ORGANIZATION GENERATION ──────────────────────────────────────

const GUILD_TYPES = [
  "Smiths' Guild", "Merchants' Guild", "Scholars' Guild", "Artists' Guild",
  "Thieves' Guild", "Assassins' Guild", "Healers' Guild", "Mages' Guild",
  "Knights' Order", "Religious Order", "Military Order", "Secret Society",
  "Academic Society", "Noble Club", "Craftsmen's Collective", "Trading Company",
  "Mercenary Company", "Explorer's Society", "Adventurers' League", "Bard's College"
];

function generateGuild(rng) {
  const type = pick(GUILD_TYPES, rng);
  const memberCount = randInt(10, 1000, rng);

  return {
    name: pick(["The", "Ancient", "Grand", "Sacred", "Hidden", "Royal", "Imperial", "Black", "Silver", "Golden"], rng) + " " + type,
    type: type,
    leader: generateProfessionalNPC(rng),
    members: memberCount,
    ranks: randInt(3, 10, rng),
    headquarters: pick(["Guild Hall", "Tower", "Underground", "Floating Castle", "Hidden Sanctuary", "Ship", "Mansion", "Temple"], rng),
    purpose: generateLore(rng),
    initiation: generateLore(rng),
    secrets: [generateSecret(rng), generateSecret(rng)],
    benefits: pickN(["Discounted Equipment", "Information Network", "Legal Protection", "Training", "Prestige", "Income", "Lodging"], randInt(2, 5, rng), rng),
    requirements: pickN(["Skill Test", "Sponsor", "Fee", "Blood Oath", "Sacrifice", "Trial by Combat", "Ritual"], randInt(1, 3, rng), rng),
    wealth: randInt(1000, 1000000, rng),
    enemies: randInt(0, 3, rng),
    allies: randInt(0, 5, rng)
  };
}

// ─── SCHOLARLY KNOWLEDGE SYSTEM ────────────────────────────────────────────

const FIELDS_OF_STUDY = [
  "Arcane Theory", "Natural Philosophy", "History", "Literature", "Mathematics",
  "Astronomy", "Medicine", "Alchemy", "Engineering", "Architecture",
  "Theology", "Ethics", "Logic", "Rhetoric", "Languages",
  "Mythology", "Herbalism", "Biology", "Geology", "Archaeology",
  "Economics", "Politics", "Military Science", "Navigation", "Agriculture"
];

function generateScholar(rng) {
  const field = pick(FIELDS_OF_STUDY, rng);
  const scholar = generateProfessionalNPC(rng);

  return {
    ...scholar,
    specialty: field,
    publications: randInt(0, 50, rng),
    students: randInt(0, 20, rng),
    theories: pickN([generateLore(rng), generateLore(rng), generateLore(rng)], randInt(1, 3, rng), rng),
    research: generateLore(rng),
    unfinishedWork: generateLore(rng),
    knownFor: generateLore(rng),
    controversies: randInt(0, 5, rng),
    library: {
      books: randInt(10, 10000, rng),
      rareBooks: randInt(0, 100, rng),
      forbidden: randInt(0, 10, rng),
      value: randInt(1000, 1000000, rng)
    }
  };
}

// ─── CALENDAR EVENTS AND SCHEDULE ──────────────────────────────────────────

function generateAnnualCalendar(rng) {
  const calendar = [];

  for (let month = 0; month < 12; month++) {
    const monthData = CALENDAR.months[month];
    const events = [];

    for (let day = 0; day < monthData.days; day++) {
      if (rng() > 0.9) {
        const isHoliday = CALENDAR.holidays.find(h => h.month === month && h.day === day + 1);
        if (isHoliday) {
          events.push({
            day: day + 1,
            event: isHoliday.name,
            type: "Holiday"
          });
        } else if (rng() > 0.8) {
          events.push({
            day: day + 1,
            event: generateWorldEvent(rng, {}),
            type: "Notable"
          });
        }
      }
    }

    calendar.push({
      month: month,
      name: monthData.name,
      days: monthData.days,
      season: monthData.season,
      events: events
    });
  }

  return calendar;
}

// ─── LOCATION AND GEOGRAPHY ────────────────────────────────────────────────

const LANDMARK_TYPES = [
  "Mountain Peak", "Waterfall", "Cave", "Ancient Ruins", "Sacred Grove",
  "Standing Stones", "Tower Ruin", "Sunken City", "Underground Lake", "Crystal Cavern",
  "Hot Springs", "Geysers", "Canyon", "Bridge", "Lighthouse",
  "Shrine", "Monument", "Statue", "Market", "Inn",
  "Fortress", "Castle", "Abbey", "Temple", "Museum"
];

function generateLandmark(rng) {
  return {
    name: pick(["The", "Ancient", "Lost", "Forgotten", "Sacred"], rng) + " " + pick(LANDMARK_TYPES, rng) + " of " + genKingdomName(rng),
    type: pick(LANDMARK_TYPES, rng),
    age: randInt(100, 100000, rng) + " years",
    significance: pick(["Religious", "Historical", "Magical", "Political", "Economic", "Cultural", "Unknown"], rng),
    legend: generateLegend(rng),
    challenges: pickN(["Dangerous Creatures", "Traps", "Weather", "Curse", "Guard Force", "Magical Wards", "Isolation", "Corruption"], randInt(1, 4, rng), rng),
    rewards: pickN(["Treasure", "Knowledge", "Blessing", "Artifact", "Revelation", "Power", "Allies"], randInt(1, 3, rng), rng),
    visited: rng() > 0.5,
    condition: pick(["Pristine", "Intact", "Ruined", "Corrupted", "Abandoned", "Active", "Forgotten"], rng),
    inhabitants: pick(MONSTER_TYPES, rng) + " swarms"
  };
}

// ─── FACTION OPERATIONS AND ACTIVITIES ───────────────────────────────────

function generateFactionOperation(rng, faction) {
  return {
    faction: faction.name,
    operation: generateLore(rng),
    type: pick(["Theft", "Espionage", "Sabotage", "Recruitment", "Diplomacy", "Combat", "Ritual", "Acquisition"], rng),
    objective: generateLore(rng),
    timeline: randInt(1, 365, rng) + " days",
    resources: randInt(1000, 1000000, rng),
    riskLevel: pick(["Low", "Medium", "High", "Extreme"], rng),
    participants: randInt(1, 50, rng),
    leader: generateNPC(rng),
    complications: pickN([generateLore(rng), generateLore(rng)], randInt(0, 2, rng), rng),
    success: randInt(20, 95, rng) + "%",
    reward: randInt(0, 100000, rng)
  };
}

function generateFactionCampaign(rng, faction, length) {
  length = length || randInt(3, 12, rng);
  const operations = [];

  for (let i = 0; i < length; i++) {
    operations.push({
      phase: i + 1,
      operation: generateFactionOperation(rng, faction),
      reinforcesGoal: pick(faction.goals, rng)
    });
  }

  return {
    faction: faction.name,
    campaign: generateLore(rng),
    operations: operations,
    overallGoal: generateLore(rng),
    expectedDuration: length * randInt(30, 180, rng) + " days",
    resources: operations.reduce((sum, op) => sum + op.operation.resources, 0),
    successRate: Math.round(operations.reduce((sum, op) => sum + parseInt(op.operation.success), 0) / length) + "%"
  };
}

// ─── RELIGIOUS AND SPIRITUAL CONTENT ────────────────────────────────────────

function generateSermon(rng, deity) {
  return {
    deity: deity.name,
    title: generateLore(rng),
    theme: pick(deity.commandments, rng),
    content: generateLore(rng) + " " + generateLore(rng),
    audience: randInt(10, 10000, rng),
    impact: randInt(0, 100, rng),
    controversy: rng() > 0.8,
    emotion: pick(["Uplifting", "Terrifying", "Inspiring", "Threatening", "Comforting", "Challenging"], rng)
  };
}

function generateMiracle(rng, deity) {
  return {
    deity: deity.name,
    miracle: generateLore(rng),
    location: genKingdomName(rng),
    date: randInt(1, 365, rng),
    witnesses: randInt(1, 10000, rng),
    verified: rng() > 0.5,
    benefits: pickN(["Healing", "Prosperity", "Protection", "Guidance", "Revelation"], randInt(1, 3, rng), rng),
    proof: pick(["Artifact", "Scar", "Mark", "Testimony", "Natural Phenomenon", "Written Record"], rng),
    skeptics: randInt(0, 100, rng) + "%"
  };
}

// ─── DISEASE AND PLAGUE SIMULATION ──────────────────────────────────────────

const DISEASE_TYPES = [
  "Plague", "Fever", "Rot", "Wasting", "Madness", "Blindness", "Paralysis",
  "Transformation", "Curse", "Possession", "Corruption", "Mutation",
  "Withering", "Blighting", "Petrification", "Undeath", "Undeath"
];

function generateDisease(rng) {
  const incubationDays = randInt(1, 30, rng);
  const duration = randInt(7, 365, rng);
  const mortality = randInt(0, 100, rng);

  return {
    name: pick(["The", "Plague of", "Sickness of", "Curse of", "Blight of"], rng) + " " + pick(DISEASE_TYPES, rng),
    type: pick(DISEASE_TYPES, rng),
    origin: generateLore(rng),
    incubationDays: incubationDays,
    duration: duration + " days",
    symptoms: pickN(["Fever", "Chills", "Weakness", "Pain", "Deformity", "Insanity", "Blindness", "Paralysis"], randInt(2, 5, rng), rng),
    transmission: pick(["Contact", "Airborne", "Water", "Food", "Magical", "Curse", "Hereditary"], rng),
    mortality: mortality + "%",
    cure: rng() > 0.5 ? generateLore(rng) : "Unknown",
    treatment: pickN(["Rest", "Medicine", "Magic", "Ritual", "Prayer", "Sacrifice"], randInt(1, 3, rng), rng),
    infected: randInt(0, 1000000, rng),
    deaths: Math.floor(randInt(0, 1000000, rng) * (mortality / 100))
  };
}

function simulatePlagueSpreading(rng, startPopulation, days) {
  const history = [];
  let infected = randInt(1, 10, rng);
  let recovered = 0;
  let dead = 0;
  const healthy = startPopulation - infected;
  const transmissionRate = randInt(0.1, 0.5, rng);
  const mortalityRate = randInt(0.01, 0.3, rng);

  for (let day = 0; day < days; day++) {
    const newInfected = Math.floor(infected * transmissionRate);
    const newDead = Math.floor(infected * mortalityRate);
    const newRecovered = Math.max(0, infected - newDead - Math.floor(infected * 0.1));

    infected = Math.max(0, infected + newInfected - newRecovered - newDead);
    dead += newDead;
    recovered += newRecovered;

    history.push({
      day: day,
      infected: infected,
      recovered: recovered,
      dead: dead,
      healthy: Math.max(0, startPopulation - infected - recovered - dead),
      newCases: newInfected,
      newDeaths: newDead
    });
  }

  return {
    startPopulation: startPopulation,
    totalDays: days,
    totalInfected: history.reduce((sum, h) => sum + h.newCases, 0),
    totalDead: dead,
    totalRecovered: recovered,
    history: history,
    finalPopulation: Math.max(0, startPopulation - dead)
  };
}

// ─── CRIME AND JUSTICE SYSTEM ──────────────────────────────────────────────

const CRIME_TYPES = [
  "Murder", "Theft", "Robbery", "Assault", "Treason", "Heresy", "Arson",
  "Slavery Trading", "Poisoning", "Forgery", "Smuggling", "Counterfeiting",
  "Blackmail", "Extortion", "Fraud", "Kidnapping", "Violation", "Trespassing",
  "Breaking Curfew", "Tax Evasion", "Witchcraft", "Necromancy", "Summoning"
];

const PUNISHMENTS = [
  "Execution", "Imprisonment", "Hard Labor", "Fine", "Exile", "Mutilation",
  "Servitude", "Shunning", "Branding", "Public Humiliation", "Restitution",
  "Redemption Quest", "Religious Penance", "Community Service", "Probation"
];

function generateCriminalRecord(rng, npc) {
  const crimes = [];

  for (let i = 0; i < randInt(0, 5, rng); i++) {
    crimes.push({
      crime: pick(CRIME_TYPES, rng),
      date: randInt(1, 50, rng) + " years ago",
      witnessed: rng() > 0.5,
      evidence: rng() > 0.6,
      convicted: rng() > 0.4,
      punishment: pick(PUNISHMENTS, rng),
      served: rng() > 0.4,
      escaped: rng() > 0.8,
      victim: generateNPC(rng).name
    });
  }

  return {
    npc: npc.name,
    crimes: crimes,
    totalCrimes: crimes.length,
    wanted: crimes.some(c => !c.served),
    bounty: randInt(0, 10000, rng),
    notoriety: randInt(0, 100, rng)
  };
}

// ─── COMPREHENSIVE WORLD GENERATION FUNCTION ────────────────────────────────

function generateMassiveRealm(rng) {
  const realms = [];

  for (let r = 0; r < 3; r++) {
    const realm = generateFullRealm(rng);

    realm.scholars = [];
    for (let i = 0; i < randInt(5, 20, rng); i++) {
      realm.scholars.push(generateScholar(rng));
    }

    realm.guilds = [];
    for (let i = 0; i < randInt(5, 15, rng); i++) {
      realm.guilds.push(generateGuild(rng));
    }

    realm.landmarks = [];
    for (let i = 0; i < randInt(10, 50, rng); i++) {
      realm.landmarks.push(generateLandmark(rng));
    }

    realm.diseases = [];
    for (let i = 0; i < randInt(1, 5, rng); i++) {
      realm.diseases.push(generateDisease(rng));
    }

    realm.criminalRecord = [];
    for (let i = 0; i < randInt(5, 50, rng); i++) {
      realm.criminalRecord.push(generateCriminalRecord(rng, generateNPC(rng)));
    }

    realms.push(realm);
  }

  return {
    multiverse: realms,
    totalRealms: realms.length,
    knownConnections: randInt(0, 10, rng),
    planarIncursions: randInt(0, 5, rng),
    artifacts: randInt(0, 20, rng),
    prophecies: randInt(0, 10, rng),
    age: randInt(100, 1000000, rng) + " years"
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// MASTER GENERATION AND INTEGRATION FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

// ─── INTEGRATED CAMPAIGN BUILDER ────────────────────────────────────────────

function generateFullCampaignWorld(rng) {
  const campaignName = genKingdomName(rng);
  const mapWidth = 200;
  const mapHeight = 200;
  const heightmap = generateHeightmap(mapWidth, mapHeight, rng, 6, 0.55, 2.3);
  const moisture = generateMoisture(mapWidth, mapHeight, rng);
  const temperature = generateTemperature(mapWidth, mapHeight, rng, true);

  const world = {
    name: campaignName,
    age: randInt(1000, 100000, rng),
    mapDimensions: { width: mapWidth, height: mapHeight },
    heightmap: heightmap,
    moisture: moisture,
    temperature: temperature,
    biomeDistribution: {},
    settlements: [],
    dungeons: [],
    landmarks: [],
    factions: [],
    NPCs: [],
    regions: [],
    quests: [],
    globalThreats: [],
    artifacts: [],
    pantheon: generatePantheon(rng, 15),
    calendar: CALENDAR,
    weather: generateSeasonalWeatherPatterns(rng, "temperate", 90),
    history: [],
    lore: []
  };

  // Count biome distribution
  for (let y = 0; y < mapHeight; y++) {
    for (let x = 0; x < mapWidth; x++) {
      const h = heightmap[y][x];
      const m = moisture[y][x];
      const t = temperature[y][x];
      const biome = classifyBiome(h, m, t);
      world.biomeDistribution[biome] = (world.biomeDistribution[biome] || 0) + 1;
    }
  }

  // Generate major settlements
  for (let i = 0; i < randInt(10, 30, rng); i++) {
    world.settlements.push(generateCompleteSettlement(rng));
  }

  // Generate dungeons
  for (let i = 0; i < randInt(5, 15, rng); i++) {
    world.dungeons.push(generateCompleteDungeon(rng, randInt(3, 8, rng)));
  }

  // Generate landmarks
  for (let i = 0; i < randInt(20, 50, rng); i++) {
    world.landmarks.push(generateLandmark(rng));
  }

  // Generate major factions
  for (let i = 0; i < randInt(8, 20, rng); i++) {
    world.factions.push(generateFaction(rng));
  }

  // Generate major NPCs
  for (let i = 0; i < randInt(20, 100, rng); i++) {
    world.NPCs.push(generateProfessionalNPC(rng));
  }

  // Generate global threats
  world.globalThreats = pickN(DISASTER_TYPES, randInt(2, 5, rng), rng);

  // Generate artifacts
  for (let i = 0; i < randInt(3, 10, rng); i++) {
    world.artifacts.push(generateArtifact(rng));
  }

  // Generate historical events
  world.history = generateWorldHistory(rng, world.settlements.map(s => s.name), 1000);

  // Generate world lore
  for (let i = 0; i < 20; i++) {
    world.lore.push(generateLore(rng));
  }

  return world;
}

// ─── PARTY AND CHARACTER GROUP GENERATION ──────────────────────────────────

function generateParty(rng, size, level) {
  size = size || 4;
  level = level || randInt(1, 20, rng);
  const party = [];

  const classDistribution = ["Fighter", "Wizard", "Rogue", "Cleric", "Ranger", "Paladin"];

  for (let i = 0; i < size; i++) {
    const character = generateNPC(rng);
    character.class = pick(classDistribution, rng);
    character.level = level;
    character.experience = (level - 1) * 300 + randInt(0, 300, rng);
    character.hitPoints = randInt(10 + (level - 1) * 5, 50 + (level - 1) * 10, rng);
    character.armorClass = randInt(10, 18, rng);
    character.equipment = generateNPCEquipment(rng, character);
    character.personality = generateCharacterArc(rng, character);

    party.push(character);
  }

  return {
    partySize: size,
    averageLevel: level,
    totalExperience: party.reduce((sum, c) => sum + c.experience, 0),
    characters: party,
    unity: randInt(0, 100, rng),
    relationships: [],
    treasury: randInt(100, 10000 * level, rng),
    reputation: pick(["Unknown", "Minor", "Respected", "Renowned", "Legendary"], rng),
    baseOfOperations: generateCompleteSettlement(rng),
    rivals: [generateNPC(rng), generateNPC(rng)],
    allies: [generateNPC(rng), generateNPC(rng), generateNPC(rng)]
  };
}

function buildPartyRelationships(rng, party) {
  const relationships = [];

  for (let i = 0; i < party.characters.length; i++) {
    for (let j = i + 1; j < party.characters.length; j++) {
      relationships.push(generateRelationship(rng, party.characters[i], party.characters[j]));
    }
  }

  return {
    party: party,
    relationships: relationships,
    partyDynamic: pick(["Tight-knit", "Fractured", "New", "Bonded", "Hostile", "Professional"], rng),
    conflicts: randInt(0, 3, rng),
    harmony: randInt(0, 100, rng) + "%"
  };
}

// ─── CAMPAIGN TIMELINE GENERATOR ────────────────────────────────────────────

function generateCampaignTimeline(rng, campaignLength) {
  campaignLength = campaignLength || 52; // weeks
  const timeline = [];
  const majorEvents = randInt(5, 15, rng);

  for (let week = 0; week < campaignLength; week++) {
    const weekData = {
      week: week + 1,
      date: getCurrentDate(week * 7),
      events: [],
      quests: [],
      discoveries: [],
      encounters: []
    };

    // Random events
    if (rng() > 0.8) {
      weekData.events.push(pick(WORLD_EVENTS, rng));
    }

    // Quest opportunities
    if (rng() > 0.7) {
      weekData.quests.push(generateQuest(rng, pick(["easy", "medium", "hard"], rng)));
    }

    // Discoveries
    if (rng() > 0.85) {
      weekData.discoveries.push(generateLandmark(rng));
    }

    // Encounters
    if (rng() > 0.6) {
      weekData.encounters.push(generateRandomEncounter(rng, pick(Object.keys(BIOMES), rng)));
    }

    timeline.push(weekData);
  }

  // Distribute major events
  for (let i = 0; i < majorEvents; i++) {
    const week = randInt(0, campaignLength - 1, rng);
    timeline[week].majorEvent = {
      name: generateLore(rng),
      impact: randInt(50, 100, rng),
      complications: randInt(1, 5, rng)
    };
  }

  return {
    campaignLength: campaignLength,
    timeline: timeline,
    majorEventCount: majorEvents,
    totalWeeks: campaignLength,
    estimatedPlayHours: campaignLength * randInt(2, 6, rng)
  };
}

// ─── TREASURE AND LOOT GENERATION ──────────────────────────────────────────

function generateLootCache(rng, difficulty, count) {
  difficulty = difficulty || "medium";
  count = count || randInt(3, 10, rng);

  const baseValues = {
    easy: { gold: 50, items: 1 },
    medium: { gold: 250, items: 2 },
    hard: { gold: 1000, items: 3 },
    deadly: { gold: 5000, items: 5 }
  };

  const base = baseValues[difficulty] || baseValues.medium;
  const treasures = [];

  for (let i = 0; i < count; i++) {
    const itemType = pick(["Gold", "Gem", "Jewelry", "Weapon", "Armor", "Potion", "Scroll", "Artifact", "Coin", "Art"], rng);

    treasures.push({
      type: itemType,
      value: randInt(base.gold * 10, base.gold * 100, rng),
      quantity: randInt(1, 10, rng),
      enchantment: rng() > 0.7 ? pick(["Magical", "Blessed", "Cursed", "Ancient"], rng) : "None",
      rarity: pick(["Common", "Uncommon", "Rare", "Very Rare", "Legendary"], rng)
    });
  }

  return {
    difficulty: difficulty,
    treasureCount: count,
    treasures: treasures,
    totalValue: treasures.reduce((sum, t) => sum + (t.value * t.quantity), 0),
    weight: treasures.reduce((sum, t) => sum + (t.quantity * randInt(1, 10, rng)), 0),
    carriedCapacity: "Difficult",
    transportNeeded: treasures.reduce((sum, t) => sum + t.quantity, 0) > 50
  };
}

// ─── SESSION PLANNER ────────────────────────────────────────────────────────

function generateGameSession(rng, partyLevel, duration) {
  duration = duration || randInt(3, 6, rng); // hours

  const encounter1 = generateRandomEncounter(rng, pick(Object.keys(BIOMES), rng), "medium");
  const encounter2 = generateRandomEncounter(rng, pick(Object.keys(BIOMES), rng), "medium");
  const encounter3 = generateDungeonEncounter(rng, partyLevel, "Campaign Dungeon");

  const session = {
    sessionName: generateLore(rng),
    estimatedDuration: duration + " hours",
    partyLevel: partyLevel,
    objectives: pickN([generateLore(rng), generateLore(rng), generateLore(rng)], randInt(1, 3, rng), rng),
    encounters: [encounter1, encounter2, encounter3],
    treasureReward: generateLootCache(rng, partyLevel <= 5 ? "easy" : partyLevel <= 10 ? "medium" : "hard"),
    npcInteractions: [generateNPC(rng), generateNPC(rng)],
    scenarioHooks: pickN(NPC_DIALOGUE.gossip, randInt(2, 5, rng), rng),
    twist: generateLore(rng),
    prepared: {
      monsters: [generateMonster(rng), generateMonster(rng), generateMonster(rng)],
      traps: [generateTrap(rng), generateTrap(rng)],
      puzzles: [generatePuzzle(rng)],
      treasureLocations: randInt(3, 8, rng)
    }
  };

  return session;
}

// ─── MASTER REFERENCE GENERATION ────────────────────────────────────────────

function generateDMReference(rng, world) {
  return {
    worldName: world.name,
    quickReference: {
      importantNPCs: world.NPCs.slice(0, 20),
      majorFactions: world.factions.slice(0, 10),
      keySites: world.landmarks.slice(0, 15),
      reigningMonarchs: world.settlements.slice(0, 10).map(s => ({ settlement: s.name, ruler: s.ruler })),
      importantDates: CALENDAR.holidays,
      pantheon: world.pantheon.slice(0, 12)
    },
    maps: {
      politicalBoundaries: randInt(0, 100, rng) + "% complete",
      geographicalFeatures: randInt(0, 100, rng) + "% complete",
      dungeonLocations: randInt(0, 100, rng) + "% complete",
      settlementDetails: randInt(0, 100, rng) + "% complete"
    },
    npcs: world.NPCs.slice(0, 100),
    factions: world.factions.slice(0, 20),
    lore: world.lore,
    quests: [
      generateQuest(rng, "easy"),
      generateQuest(rng, "medium"),
      generateQuest(rng, "hard"),
      generateQuest(rng, "deadly")
    ],
    monsters: [
      generateMonster(rng, "Easy"),
      generateMonster(rng, "Medium"),
      generateMonster(rng, "Hard"),
      generateMonster(rng, "Deadly")
    ],
    treasureGeneration: generateLootCache(rng, "medium", 20),
    sessionPlans: [
      generateGameSession(rng, 1),
      generateGameSession(rng, 5),
      generateGameSession(rng, 10),
      generateGameSession(rng, 15),
      generateGameSession(rng, 20)
    ]
  };
}

// ─── FINAL COMPREHENSIVE GENERATOR ──────────────────────────────────────────

function generateEverything(rng) {
  const world = generateFullCampaignWorld(rng);
  const party = generateParty(rng, 4, 1);
  const timeline = generateCampaignTimeline(rng, 52);
  const dmRef = generateDMReference(rng, world);

  return {
    world: world,
    party: buildPartyRelationships(rng, party),
    timeline: timeline,
    dmReference: dmRef,
    session1: generateGameSession(rng, 1),
    allNPCs: [
      ...world.NPCs,
      ...party.characters,
      ...party.allies,
      ...party.rivals
    ],
    allQuests: timeline.timeline.flatMap(w => w.quests),
    allEncounters: timeline.timeline.flatMap(w => w.encounters),
    worldState: {
      currentWeek: 0,
      currentDate: getCurrentDate(0),
      moonPhase: getMoonPhase(0),
      weather: generateWeather(rng, "temperate", "spring"),
      stability: randInt(0, 100, rng) + "%",
      threats: world.globalThreats
    }
  };
}

// ─── QUICK GENERATOR SHORTCUTS ──────────────────────────────────────────────

function quickNPC(rng) { return generateNPC(rng); }
function quickSettlement(rng) { return generateCompleteSettlement(rng); }
function quickDungeon(rng, floors) { return generateCompleteDungeon(rng, floors || 5); }
function quickQuest(rng, difficulty) { return generateQuest(rng, difficulty || "medium"); }
function quickFaction(rng) { return generateFaction(rng); }
function quickMonster(rng, diff) { return generateMonster(rng, diff || "Medium"); }
function quickWeather(rng, biome) { return generateWeather(rng, biome || "grassland", "summer"); }
function quickLoot(rng, diff) { return generateLootCache(rng, diff || "medium"); }
function quickEncounter(rng, biome) { return generateRandomEncounter(rng, biome || "forest"); }
function quickNPCGroup(rng, count) { const group = []; for(let i = 0; i < (count || 5); i++) group.push(generateNPC(rng)); return group; }

// ─── BULK GENERATION UTILITIES ──────────────────────────────────────────────

function generateBulkNPCs(rng, count) {
  const npcs = [];
  for (let i = 0; i < count; i++) {
    npcs.push(generateNPC(rng));
  }
  return npcs;
}

function generateBulkQuests(rng, count, difficulty) {
  const quests = [];
  for (let i = 0; i < count; i++) {
    quests.push(generateQuest(rng, difficulty || pick(["easy", "medium", "hard"], rng)));
  }
  return quests;
}

function generateBulkSettlements(rng, count) {
  const settlements = [];
  for (let i = 0; i < count; i++) {
    settlements.push(generateCompleteSettlement(rng));
  }
  return settlements;
}

function generateBulkDungeons(rng, count) {
  const dungeons = [];
  for (let i = 0; i < count; i++) {
    dungeons.push(generateCompleteDungeon(rng, randInt(3, 8, rng)));
  }
  return dungeons;
}

// ─── ENCOUNTER BUILDING TOOLS ──────────────────────────────────────────────

function buildCustomEncounter(rng, enemies, allies, environment) {
  return {
    enemies: enemies || [generateMonster(rng), generateMonster(rng)],
    allies: allies || [generateNPC(rng)],
    environment: environment || generateLore(rng),
    difficulty: "Custom",
    treasure: generateLootCache(rng, "medium"),
    complications: pickN([generateLore(rng), generateLore(rng)], 2, rng),
    escape: rng() > 0.5,
    ambush: rng() > 0.6
  };
}

function generateEncounterChain(rng, count, escalation) {
  escalation = escalation || true;
  const encounters = [];

  for (let i = 0; i < count; i++) {
    const difficulty = escalation ?
      (i < 2 ? "Easy" : i < 4 ? "Medium" : i < 6 ? "Hard" : "Deadly") :
      pick(["Easy", "Medium", "Hard"], rng);

    encounters.push({
      number: i + 1,
      difficulty: difficulty,
      encounter: generateRandomEncounter(rng, pick(Object.keys(BIOMES), rng), difficulty),
      connection: i > 0 ? "Follows from previous" : "Starting point"
    });
  }

  return {
    chain: encounters,
    totalEncounters: count,
    escalating: escalation,
    chainTheme: generateLore(rng)
  };
}

// ─── REWARD AND TREASURE PLANNING ──────────────────────────────────────────

function planTreasureDistribution(rng, partySize, level, sessions) {
  sessions = sessions || 10;
  const perSession = { gold: level * 100, items: Math.ceil(level / 3) };
  const total = {
    gold: perSession.gold * sessions,
    items: perSession.items * sessions,
    artifacts: Math.ceil(sessions / 3),
    magic: Math.ceil(sessions / 2)
  };

  const distribution = [];
  for (let session = 0; session < sessions; session++) {
    distribution.push({
      session: session + 1,
      goldPerPartyMember: Math.round(perSession.gold / partySize),
      totalGold: perSession.gold,
      items: perSession.items,
      specialReward: session % 3 === 0 ? "Magic Item" : "None"
    });
  }

  return {
    partySize: partySize,
    averageLevel: level,
    sessions: sessions,
    perSession: perSession,
    total: total,
    distribution: distribution,
    balanceNote: "Adjust based on party wealth and spending"
  };
}

// ─── WORLD SUMMARY FUNCTIONS ────────────────────────────────────────────────

function summarizeWorld(world) {
  return {
    worldName: world.name,
    totalSettlements: world.settlements.length,
    totalDungeons: world.dungeons.length,
    totalNPCs: world.NPCs.length,
    totalFactions: world.factions.length,
    totalLandmarks: world.landmarks.length,
    deities: world.pantheon.length,
    estimatedPlayTime: (world.settlements.length * 20 + world.dungeons.length * 30) + " hours",
    primaryThreats: world.globalThreats,
    mapDimensions: world.mapDimensions
  };
}

function summarizeParty(party) {
  const levels = party.characters.map(c => c.level);
  const avgLevel = Math.round(levels.reduce((a, b) => a + b) / levels.length);
  const totalWealth = party.characters.reduce((sum, c) => sum + (c.equipment ? c.equipment.value : 0), 0) + party.treasury;

  return {
    partySize: party.characters.length,
    averageLevel: avgLevel,
    classComposition: party.characters.map(c => c.class),
    totalWealth: totalWealth,
    reputation: party.reputation,
    baseOfOperations: party.baseOfOperations.name,
    enemies: party.rivals.length,
    allies: party.allies.length
  };
}

// ─── PRESET WORLD GENERATION ────────────────────────────────────────────────

function generateSmallWorld(rng) {
  return {
    name: genKingdomName(rng),
    settlements: generateBulkSettlements(rng, 5),
    dungeons: generateBulkDungeons(rng, 2),
    factions: [generateFaction(rng), generateFaction(rng)],
    npcs: generateBulkNPCs(rng, 20),
    scope: "Local"
  };
}

function generateMediumWorld(rng) {
  return {
    name: genKingdomName(rng),
    settlements: generateBulkSettlements(rng, 15),
    dungeons: generateBulkDungeons(rng, 5),
    factions: generateBulkNPCs(rng, 6).map(() => generateFaction(rng)),
    npcs: generateBulkNPCs(rng, 50),
    scope: "Regional"
  };
}

function generateLargeWorld(rng) {
  return {
    name: genKingdomName(rng),
    settlements: generateBulkSettlements(rng, 30),
    dungeons: generateBulkDungeons(rng, 10),
    factions: generateBulkNPCs(rng, 12).map(() => generateFaction(rng)),
    npcs: generateBulkNPCs(rng, 100),
    artifacts: generateBulkNPCs(rng, 5).map(() => generateArtifact(rng)),
    scope: "Continental"
  };
}

// ─── MASTER GENERATION FUNCTION ────────────────────────────────────────────

function generateCompleteFantasyWorld(rng, worldSize) {
  worldSize = worldSize || "medium";

  const baseWorld = worldSize === "small" ? generateSmallWorld(rng) :
                    worldSize === "large" ? generateLargeWorld(rng) :
                    generateMediumWorld(rng);

  return {
    world: baseWorld,
    campaign: generateCampaignTimeline(rng, worldSize === "small" ? 26 : worldSize === "large" ? 104 : 52),
    starterParty: generateParty(rng, 4, 1),
    dmKit: {
      npcQuickReference: baseWorld.npcs.slice(0, 20),
      factionOverview: baseWorld.factions,
      questHooks: generateBulkQuests(rng, 10),
      sessionIdeas: [generateGameSession(rng, 1), generateGameSession(rng, 5), generateGameSession(rng, 10)],
      encounterTemplates: generateEncounterChain(rng, 6, true)
    },
    ready: true,
    generatedAt: new Date().toISOString(),
    seed: "Dynamic"
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// END OF EXPANDED CORE ENGINE - FANTASY MAP GENERATOR PRO
// Complete Fantasy World Generation System with 150+ Functions
// Pure JavaScript - No imports, no exports - Safe for React concatenation
// Ready for embedding in web applications and campaign tools
// ═══════════════════════════════════════════════════════════════════════════

// ─── RIVER GENERATION (improved with tributaries, deltas, waterfalls) ────────

function generateRivers(hmap, mmap, gW, gH, rng, count) {
  const rivers = [];
  const seaLevel = 0.38;
  const riverCells = new Set();

  for (let i = 0; i < count; i++) {
    let sx, sy, attempts = 0;
    do { sx = Math.floor(rng()*gW); sy = Math.floor(rng()*gH); attempts++; }
    while (attempts < 300 && (hmap[sy]?.[sx] || 0) < 0.58);
    if (attempts >= 300) continue;

    const path = [{ x:sx, y:sy }];
    let cx = sx, cy = sy;
    const visited = new Set([`${cx},${cy}`]);
    let widthAccum = 0.5;

    for (let step = 0; step < 400; step++) {
      const h = hmap[cy]?.[cx] || 0;
      if (h < seaLevel) break;
      // Merge with existing river
      if (riverCells.has(`${cx},${cy}`) && step > 5) break;

      let bestX = cx, bestY = cy, bestH = h;
      const dirs = [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,-1],[-1,1],[1,1]];
      for (const [dx,dy] of dirs) {
        const nx = cx+dx, ny = cy+dy;
        if (nx<0||nx>=gW||ny<0||ny>=gH) continue;
        const nh = hmap[ny][nx];
        if (nh < bestH && !visited.has(`${nx},${ny}`)) { bestH = nh; bestX = nx; bestY = ny; }
      }
      if (bestX===cx && bestY===cy) break;
      cx = bestX; cy = bestY;
      visited.add(`${cx},${cy}`);
      path.push({ x:cx, y:cy });
      widthAccum += 0.02;
    }

    if (path.length > 10) {
      // Mark cells
      for (const p of path) riverCells.add(`${p.x},${p.y}`);

      // Detect waterfalls (large elevation drops)
      const waterfalls = [];
      for (let j = 1; j < path.length; j++) {
        const dh = (hmap[path[j-1].y]?.[path[j-1].x]||0) - (hmap[path[j].y]?.[path[j].x]||0);
        if (dh > 0.08) waterfalls.push({ x: path[j].x, y: path[j].y, drop: dh });
      }

      // Detect delta (river reaches sea, spreads)
      const lastPt = path[path.length - 1];
      const hasDelta = (hmap[lastPt.y]?.[lastPt.x] || 0) < seaLevel + 0.03;

      rivers.push({
        path, width: 0.8 + rng() * 1.5, name: genName(rng, "river"),
        waterfalls, hasDelta,
        tributaries: [], // populated later
      });
    }
  }

  // Generate tributaries for larger rivers
  for (const river of rivers) {
    if (river.path.length < 25) continue;
    const tribCount = randInt(1, 4, rng);
    for (let t = 0; t < tribCount; t++) {
      const joinIdx = randInt(Math.floor(river.path.length * 0.3), Math.floor(river.path.length * 0.8), rng);
      const joinPt = river.path[joinIdx];
      // Start tributary from a nearby high point
      let tx, ty, att = 0;
      do { tx = joinPt.x + randInt(-20, 20, rng); ty = joinPt.y + randInt(-20, 20, rng); att++; }
      while (att < 50 && (tx<0||tx>=gW||ty<0||ty>=gH||(hmap[ty]?.[tx]||0)<0.5));
      if (att >= 50) continue;

      const tribPath = [{ x:tx, y:ty }];
      let tcx = tx, tcy = ty;
      const tv = new Set([`${tcx},${tcy}`]);
      for (let step = 0; step < 100; step++) {
        const h = hmap[tcy]?.[tcx] || 0;
        if (dist(tcx,tcy,joinPt.x,joinPt.y) < 2) { tribPath.push(joinPt); break; }
        // Move toward join point with downhill preference
        let bX=tcx,bY=tcy,bScore=-Infinity;
        for (const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1],[-1,-1],[1,-1],[-1,1],[1,1]]) {
          const nx=tcx+dx, ny=tcy+dy;
          if (nx<0||nx>=gW||ny<0||ny>=gH||tv.has(`${nx},${ny}`)) continue;
          const nh = hmap[ny][nx];
          const downhill = h - nh;
          const toward = -(dist(nx,ny,joinPt.x,joinPt.y) - dist(tcx,tcy,joinPt.x,joinPt.y));
          const score = downhill * 3 + toward + rng() * 0.2;
          if (score > bScore) { bScore=score; bX=nx; bY=ny; }
        }
        if (bX===tcx&&bY===tcy) break;
        tcx=bX; tcy=bY; tv.add(`${tcx},${tcy}`); tribPath.push({x:tcx,y:tcy});
      }
      if (tribPath.length > 5) {
        river.tributaries.push({ path: tribPath, width: 0.5 + rng() * 0.8 });
      }
    }
  }
  return rivers;
}

// ─── EXPANDED RIVER SYSTEM (fish species, commerce, infrastructure) ────────

const RIVER_FISH = [
  { name: "Rainbow Trout", size: "medium", value: 45, season: ["spring","summer","fall"], bait: "worm" },
  { name: "Striped Bass", size: "large", value: 65, season: ["spring","summer"], bait: "shad" },
  { name: "Salmon", size: "large", value: 80, season: ["fall","winter"], bait: "roe" },
  { name: "Catfish", size: "large", value: 35, season: ["summer","fall"], bait: "stink" },
  { name: "Pike", size: "large", value: 50, season: ["spring","summer","fall"], bait: "frog" },
  { name: "Perch", size: "small", value: 15, season: ["summer","fall","winter"], bait: "worm" },
  { name: "Carp", size: "medium", value: 25, season: ["summer","fall"], bait: "corn" },
  { name: "Eel", size: "medium", value: 40, season: ["spring","summer","fall"], bait: "worm" },
  { name: "Sturgeon", size: "huge", value: 250, season: ["spring","fall"], bait: "caviar" },
  { name: "Lamprey", size: "small", value: 20, season: ["spring","summer","fall"], bait: "blood" },
  { name: "Bullhead", size: "small", value: 12, season: ["summer","fall"], bait: "worm" },
  { name: "Sunfish", size: "small", value: 8, season: ["spring","summer"], bait: "insect" },
  { name: "Walleye", size: "medium", value: 55, season: ["fall","winter"], bait: "minnow" },
  { name: "Char", size: "medium", value: 50, season: ["fall","winter"], bait: "krill" },
  { name: "Whitefish", size: "medium", value: 35, season: ["fall","winter"], bait: "worm" },
  { name: "Grayling", size: "medium", value: 40, season: ["summer","fall"], bait: "fly" },
  { name: "Shad", size: "medium", value: 30, season: ["spring","summer"], bait: "lure" },
  { name: "Herring", size: "small", value: 18, season: ["spring","fall"], bait: "worm" },
  { name: "Roach", size: "small", value: 10, season: ["summer","fall"], bait: "breadcrumb" },
  { name: "Tench", size: "medium", value: 28, season: ["summer","fall"], bait: "bloodworm" },
  { name: "Bream", size: "medium", value: 22, season: ["summer","fall"], bait: "corn" },
  { name: "Ling", size: "large", value: 60, season: ["fall","winter"], bait: "fish" },
  { name: "Pike Perch", size: "large", value: 70, season: ["fall","winter"], bait: "fry" },
  { name: "Silverbelly", size: "small", value: 14, season: ["spring","summer"], bait: "crumb" },
  { name: "Dragonfish", size: "medium", value: 120, season: ["summer"], bait: "rare" },
  { name: "Moonfish", size: "medium", value: 95, season: ["spring","fall"], bait: "phosphorescent" },
  { name: "Silverscale", size: "small", value: 35, season: ["summer","fall"], bait: "worm" },
  { name: "Glimmergill", size: "medium", value: 150, season: ["winter"], bait: "magic" },
  { name: "Frostbite", size: "small", value: 50, season: ["winter"], bait: "ice" },
  { name: "Ember Fin", size: "medium", value: 180, season: ["summer"], bait: "ash" },
];

const BRIDGE_TYPES = [
  { name: "Stone Arch Bridge", material: "granite", maxSpan: 80, durability: "excellent", age: 300 },
  { name: "Wooden Covered Bridge", material: "timber", maxSpan: 60, durability: "fair", age: 150 },
  { name: "Iron Drawbridge", material: "iron", maxSpan: 70, durability: "excellent", age: 200 },
  { name: "Rope Suspension Bridge", material: "hemp and wood", maxSpan: 120, durability: "good", age: 80 },
  { name: "Pontoon Bridge", material: "boats and wood", maxSpan: 100, durability: "fair", age: 40 },
  { name: "Ancient Elven Stone", material: "moonstone", maxSpan: 150, durability: "timeless", age: 1500 },
  { name: "Dwarven Ironwork", material: "mithril and stone", maxSpan: 90, durability: "legendary", age: 600 },
  { name: "Magical Glass Bridge", material: "enchanted crystal", maxSpan: 200, durability: "pristine", age: 250 },
  { name: "Collapsed Ancient Ruin", material: "broken stone", maxSpan: 0, durability: "ruined", age: 1000 },
  { name: "Troll Toll Bridge", material: "mixed salvage", maxSpan: 50, durability: "poor", age: 50 },
  { name: "Wizard's Teleport Gate", material: "arcane circles", maxSpan: "variable", durability: "magical", age: 180 },
  { name: "Slave-Built Causeway", material: "stone blocks", maxSpan: 70, durability: "worn", age: 400 },
  { name: "Goblin Chain Bridge", material: "rusty chains", maxSpan: 45, durability: "very poor", age: 30 },
  { name: "Living Wood Bridge", material: "petrified treant", maxSpan: 80, durability: "self-healing", age: 800 },
  { name: "Haunted Phantom Bridge", material: "ectoplasm", maxSpan: 100, durability: "ghostly", age: "unknown" },
];

function generateRiverEcosystem(rng, river) {
  const ecosystem = {
    fish: [],
    settlements: [],
    bridges: [],
    ferries: [],
    mills: [],
    tradeValue: 0,
  };

  // Populate fish species
  const fishCount = randInt(3, 8, rng);
  const selectedFish = [];
  for (let i = 0; i < fishCount; i++) {
    const fish = pick(RIVER_FISH, rng);
    selectedFish.push({
      ...fish,
      population: randInt(500, 5000, rng),
      lastCaught: randInt(1, 30, rng) + " days ago",
    });
  }
  ecosystem.fish = selectedFish;

  // Fishing spots along river
  for (let i = 0; i < Math.min(river.path.length / 80, 5); i++) {
    const idx = Math.floor(rng() * river.path.length);
    const pt = river.path[idx];
    ecosystem.settlements.push({
      x: pt.x,
      y: pt.y,
      type: "fishing_village",
      population: randInt(30, 150, rng),
      name: genName(rng, "hamlet"),
      specialty: pick(RIVER_FISH, rng).name + " fishing",
      buildings: ["Fish Huts", "Drying Racks", "Boat Dock", "Market Stall", "Smokehouse"],
    });
  }

  // Bridges
  for (let i = 0; i < randInt(1, 4, rng); i++) {
    const idx = Math.floor(rng() * river.path.length);
    const pt = river.path[idx];
    const bridgeType = pick(BRIDGE_TYPES, rng);
    ecosystem.bridges.push({
      x: pt.x,
      y: pt.y,
      ...bridgeType,
      condition: pick(["pristine", "well-maintained", "aging", "damaged", "barely passable"], rng),
      toll: bridgeType.material.includes("ancient") ? 0 : randInt(1, 15, rng),
      guardian: pick([null, genNPCName(rng), "Troll"], rng),
    });
  }

  // Ferries
  for (let i = 0; i < randInt(1, 3, rng); i++) {
    const idx = Math.floor(rng() * river.path.length);
    const pt = river.path[idx];
    ecosystem.ferries.push({
      x: pt.x,
      y: pt.y,
      name: genName(rng, "boat"),
      operator: genNPCName(rng),
      capacity: randInt(10, 50, rng),
      cost: randInt(2, 10, rng),
      frequency: pick(["hourly", "twice daily", "daily", "weekly", "on demand"], rng),
      condition: pick(["shipshape", "serviceable", "creaky", "leak-prone"], rng),
    });
  }

  // Watermills
  for (let i = 0; i < river.waterfalls.length && i < 3; i++) {
    const waterfall = river.waterfalls[i];
    ecosystem.mills.push({
      x: waterfall.x,
      y: waterfall.y,
      type: pick(["grain mill", "sawmill", "cloth mill", "paper mill", "ironworks"], rng),
      owner: genNPCName(rng),
      production: randInt(100, 1000, rng) + " units/month",
      workers: randInt(5, 30, rng),
      condition: pick(["productive", "aging", "damaged", "abandoned"], rng),
      power: Math.round(waterfall.drop * 500) + " hp",
    });
    ecosystem.tradeValue += randInt(200, 800, rng);
  }

  ecosystem.tradeValue += ecosystem.fish.reduce((s, f) => s + (f.population * f.value / 1000), 0);
  return ecosystem;
}

function generateBridge(rng, river, road) {
  const bridgeType = pick(BRIDGE_TYPES, rng);
  const intersection = river.path.find(pt =>
    road.path.some(rp => dist(rp.x, rp.y, pt.x, pt.y) < 3)
  );

  if (!intersection) return null;

  return {
    x: intersection.x,
    y: intersection.y,
    name: bridgeType.name + " over " + river.name,
    ...bridgeType,
    condition: pick(["pristine", "well-maintained", "aging", "damaged", "barely passable"], rng),
    toll: bridgeType.material.includes("ancient") ? 0 : randInt(1, 15, rng),
    guardian: pick([null, genNPCName(rng), "Troll"], rng),
    builtYear: Math.floor(2000 - bridgeType.age + rng() * 100),
  };
}

function generateFerry(rng, river) {
  const pt = pick(river.path, rng);
  return {
    x: pt.x,
    y: pt.y,
    name: genName(rng, "boat"),
    operator: genNPCName(rng),
    capacity: randInt(10, 50, rng),
    cost: randInt(2, 10, rng),
    frequency: pick(["hourly", "twice daily", "daily", "weekly", "on demand"], rng),
    condition: pick(["shipshape", "serviceable", "creaky", "leak-prone"], rng),
    destination: "opposite shore",
    riverName: river.name,
  };
}

function generateWatermill(rng, river) {
  const waterfall = pick(river.waterfalls, rng);
  if (!waterfall) return null;

  return {
    x: waterfall.x,
    y: waterfall.y,
    name: genName(rng, "place") + " " + pick(["Grain Mill", "Sawmill", "Cloth Mill", "Paper Mill", "Ironworks"], rng),
    type: pick(["grain mill", "sawmill", "cloth mill", "paper mill", "ironworks", "fulling mill", "oil press"], rng),
    owner: genNPCName(rng),
    production: randInt(100, 1000, rng) + " units/month",
    workers: randInt(5, 30, rng),
    condition: pick(["productive", "aging", "damaged", "abandoned"], rng),
    power: Math.round(waterfall.drop * 500) + " hp",
    established: Math.floor(1900 + rng() * 100),
    specialization: pick(["high quality", "bulk production", "experimental", "ancestral technique"], rng),
  };
}

function generateRiverCommerce(rng, river, settlements) {
  const commerce = {
    tradeRoutes: [],
    merchants: [],
    hazards: [],
    totalValue: 0,
  };

  // Find settlements near river
  const nearbySettlements = settlements.filter(s => {
    for (const pt of river.path) {
      if (dist(s.x, s.y, pt.x, pt.y) < 15) return true;
    }
    return false;
  });

  // Create trade routes between nearby settlements
  for (let i = 0; i < nearbySettlements.length - 1; i++) {
    const from = nearbySettlements[i];
    const to = nearbySettlements[i + 1];
    const goods = pickN(from.exports, randInt(2, 4, rng), rng);
    const route = {
      from: from.name,
      to: to.name,
      goods: goods,
      frequency: pick(["weekly", "biweekly", "monthly", "seasonal"], rng),
      vessels: randInt(1, 5, rng),
      value: goods.reduce((s) => s + randInt(50, 300, rng), 0),
    };
    commerce.tradeRoutes.push(route);
    commerce.totalValue += route.value;
  }

  // River merchants
  for (let i = 0; i < randInt(2, 5, rng); i++) {
    commerce.merchants.push({
      name: genNPCName(rng),
      baseSettlement: pick(nearbySettlements, rng).name,
      specialty: pick(RIVER_FISH.map(f => f.name), rng),
      boats: randInt(1, 3, rng),
      wealth: pick(["poor", "modest", "comfortable", "wealthy", "rich"], rng),
      reputation: pick(["honest", "fair", "shrewd", "ruthless", "cheating"], rng),
    });
  }

  // River hazards
  if (rng() > 0.5) {
    commerce.hazards.push({
      type: pick(["rapids", "waterfalls", "submerged rocks", "pirates", "monsters", "floods", "fog"], rng),
      location: Math.floor(rng() * river.path.length),
      severity: pick(["minor", "moderate", "severe"], rng),
      season: pick(["spring", "summer", "fall", "winter"], rng),
    });
  }

  return commerce;
}

// ─── SETTLEMENT GENERATION (full detail) ────────────────────────────────────

const SETTLEMENT_FEATURES = {
  capital: ["Grand Palace","Cathedral","Mage Tower","Arena","Grand Market","Royal Library","Harbor District","Noble Quarter","Thieves' Guild HQ","Military Academy","Diplomatic Quarter","Treasury","Royal Gardens","Monument Square","Grand Amphitheater"],
  city: ["Market Square","Temple District","Guild Hall","Inner Wall","Harbor","Barracks","Library","Garden District","Clock Tower","Foundry","Merchant Quarter","Warehouses","Noble Estate","Arena","Academy"],
  town: ["Town Hall","Market","Tavern","Temple","Blacksmith","Stable","Mill","Well","Watch Tower","Herbalist","General Store","Inn","Brewery","Tannery","Carpenter"],
  village: ["Village Green","Chapel","Well","Farmstead","Granary","Smithy","Elder's Cottage","Communal Hall","Root Cellar","Fishing Dock","Herb Garden","Sheep Pen","Cider Press","Weaver's Loom","Potter's Wheel"],
  hamlet: ["Well","Farmhouse","Barn","Root Cellar","Shrine","Communal Fire Pit","Chicken Coop","Woodshed","Fishing Shack","Herb Patch"],
};

const SETTLEMENT_EXPORTS = {
  capital: ["weapons","armor","luxury goods","magical items","art","books","wine","jewelry","silk","spices","enchanted materials","religious artifacts","diplomatic treaties","scholarly works","exotic pets"],
  city: ["iron goods","timber","textiles","pottery","ale","stone","grain","livestock","herbs","leather","dyes","glass","salt","wool","cheese"],
  town: ["grain","vegetables","dairy","wool","timber","honey","herbs","leather","pottery","ale","cider","hay","flax","tallow","charcoal"],
  village: ["grain","root vegetables","eggs","milk","wool","firewood","wild herbs","mushrooms","honey","berries","fish","feathers","straw","reeds","peat"],
  hamlet: ["foraged goods","firewood","simple crafts","animal skins","wild game","berries","nuts","medicinal herbs","rough wool","peat"],
};

function placeCities(hmap, mmap, rivers, gW, gH, rng, config) {
  const seaLevel = 0.38;
  const settlements = [];
  const minDist = { capital:40, city:25, town:15, village:8, hamlet:5 };
  const counts = { capital:config.capitals||3, city:config.cities||8, town:config.towns||15, village:config.villages||25, hamlet:config.hamlets||35 };

  // Pre-compute proximity maps
  const riverProx = Array.from({length:gH}, ()=>new Float32Array(gW));
  for (const river of rivers) for (const pt of river.path) {
    for (let dy=-5;dy<=5;dy++) for (let dx=-5;dx<=5;dx++) {
      const nx=pt.x+dx, ny=pt.y+dy;
      if (nx>=0&&nx<gW&&ny>=0&&ny<gH) { const d=Math.sqrt(dx*dx+dy*dy); riverProx[ny][nx]=Math.max(riverProx[ny][nx],1-d/6); }
    }
  }
  const coastProx = Array.from({length:gH}, ()=>new Uint8Array(gW));
  for (let y=0;y<gH;y++) for (let x=0;x<gW;x++) {
    if (hmap[y][x]>=seaLevel) {
      outer: for (let dy=-4;dy<=4;dy++) for (let dx=-4;dx<=4;dx++) {
        const nx=x+dx,ny=y+dy;
        if (nx>=0&&nx<gW&&ny>=0&&ny<gH&&hmap[ny][nx]<seaLevel) { coastProx[y][x]=1; break outer; }
      }
    }
  }

  function distToAll(x,y) { let m=Infinity; for (const s of settlements) { const d=dist(s.x,s.y,x,y); if(d<m) m=d; } return m; }

  function scoreCell(x,y,type) {
    const h = hmap[y]?.[x]||0;
    if (h<seaLevel||h>0.78) return -1;
    const m = mmap[y]?.[x]||0;
    let score = riverProx[y][x]*30 + coastProx[y][x]*20 + m*10 - Math.abs(h-0.5)*15;
    if (type==="capital") score += (riverProx[y][x]>0.3?20:0) + (coastProx[y][x]?15:0);
    if (type==="town") score += riverProx[y][x] * 15;
    return score;
  }

  for (const type of ["capital","city","town","village","hamlet"]) {
    for (let i = 0; i < counts[type]; i++) {
      let bestX=-1, bestY=-1, bestScore=-Infinity;
      for (let att = 0; att < 600; att++) {
        const x = Math.floor(rng()*gW), y = Math.floor(rng()*gH);
        if (distToAll(x,y) < minDist[type]) continue;
        const score = scoreCell(x,y,type) + rng()*10;
        if (score > bestScore) { bestScore=score; bestX=x; bestY=y; }
      }
      if (bestX < 0) continue;

      const nameType = type==="capital"?"city":type==="village"||type==="hamlet"?"town":type;
      const pop = type==="capital" ? randInt(10000,50000,rng) : type==="city" ? randInt(3000,18000,rng) : type==="town" ? randInt(500,3500,rng) : type==="village" ? randInt(50,500,rng) : randInt(10,60,rng);
      const features = pickN(SETTLEMENT_FEATURES[type]||[], randInt(3, Math.min(6, (SETTLEMENT_FEATURES[type]||[]).length), rng), rng);
      const exports = pickN(SETTLEMENT_EXPORTS[type]||[], randInt(2, 5, rng), rng);

      // Generate NPCs for this settlement
      const npcCount = type==="capital" ? 8 : type==="city" ? 5 : type==="town" ? 3 : type==="village" ? 2 : 1;
      const npcs = [];
      for (let n = 0; n < npcCount; n++) npcs.push(generateNPC(rng, { name: genName(rng, nameType) }));

      // Generate a tavern
      const tavern = type !== "hamlet" ? {
        name: genTavernName(rng),
        specialty: pick(["Strong ale","Exotic wines","Hearty stew","Roasted boar","Fresh bread","Spiced mead","Mushroom soup","Grilled fish","Elven pastries","Dwarven dark ale"], rng),
        rumor: pick([
          "Strange lights have been seen in the nearby ruins at night.",
          "A traveling merchant claims to have a map to a dragon's hoard.",
          "The local lord has been acting strangely since visiting the old tower.",
          "Bandits have been attacking caravans on the eastern road.",
          "A mysterious stranger has been asking about ancient artifacts.",
          "The well water has tasted funny since the earthquake last month.",
          "Wolves have been howling closer to town than usual.",
          "A child went missing near the old forest three days ago.",
          "The blacksmith found strange ore in the mountain that hums at night.",
          "Ships have been vanishing in the strait — sailors blame a sea creature.",
        ], rng),
        rooms: randInt(2, type==="capital"?20:type==="city"?12:6, rng),
        pricePerNight: type==="capital" ? randInt(5,20,rng) : type==="city" ? randInt(2,10,rng) : randInt(1,5,rng),
      } : null;

      // Determine biome at location
      const biomeAtLoc = classifyBiome(hmap[bestY]?.[bestX]||0.5, mmap[bestY]?.[bestX]||0.5, 0.5);

      // Generate local lore
      const lore = generateLore(rng, "settlement_history", { name: genName(rng, nameType), type, origin: pick(LORE_FRAGMENTS.origin, rng), people: pick(LORE_FRAGMENTS.people, rng), event: pick(LORE_FRAGMENTS.event, rng), feature: pick(LORE_FRAGMENTS.feature, rng), activity: pick(LORE_FRAGMENTS.activity, rng), era: pick(LORE_FRAGMENTS.era, rng) });

      // Defenses
      const defenses = type==="capital" ? pick(["Massive stone walls with towers","Triple-layered fortifications","Magical ward barrier","Moat and drawbridge complex","Cliff-side natural defenses"], rng)
        : type==="city" ? pick(["Stone walls","Fortified gates","Watch towers","Palisade and ditch","Harbor chain"], rng)
        : type==="town" ? pick(["Wooden palisade","Town militia","Watch tower","Stone gatehouse","Natural terrain"], rng)
        : "Minimal";

      settlements.push({
        x:bestX, y:bestY, type, name: genName(rng, nameType),
        population: pop, isCoastal: coastProx[bestY]?.[bestX]>0, isRiverside: riverProx[bestY]?.[bestX]>0.3,
        features, exports, npcs, tavern, lore, defenses, biome: biomeAtLoc,
        government: pick(["Monarchy","Council","Theocracy","Oligarchy","Democracy","Tribal","Military","Merchant Republic","Magocracy","Anarchy"], rng),
        alignment: pick(["Lawful Good","Neutral Good","Chaotic Good","Lawful Neutral","True Neutral","Chaotic Neutral","Lawful Evil","Neutral Evil","Chaotic Evil"], rng),
        wealth: type==="capital"?"rich":type==="city"?pick(["rich","moderate"],rng):type==="town"?pick(["moderate","poor"],rng):pick(["poor","destitute"],rng),
        mood: pick(["prosperous","content","anxious","fearful","rebellious","festive","mourning","suspicious","welcoming","isolated"], rng),
      });
    }
  }
  return settlements;
}

// ─── ROAD NETWORK ───────────────────────────────────────────────────────────

function generateRoads(settlements, hmap, gW, gH, rng) {
  const roads = [];
  const seaLevel = 0.38;

  function findPath(s1, s2) {
    const pts = [];
    const dx = s2.x-s1.x, dy = s2.y-s1.y, steps = Math.max(Math.abs(dx),Math.abs(dy));
    if (steps===0) return [];
    for (let i = 0; i <= steps; i++) {
      const t = i/steps;
      let x = Math.round(s1.x+dx*t), y = Math.round(s1.y+dy*t);
      const h = hmap[y]?.[x]||0;
      if (h<seaLevel||h>0.75) for (const off of [-1,1,-2,2]) { const ny=y+off; if ((hmap[ny]?.[x]||0)>=seaLevel&&(hmap[ny]?.[x]||0)<0.75) { y=ny; break; } }
      pts.push({x,y});
    }
    return pts;
  }

  const majors = settlements.filter(s=>s.type==="capital"||s.type==="city");
  for (let i = 0; i < majors.length; i++) {
    const nearest = majors.map((s,j)=>({s,j,d:dist(s.x,s.y,majors[i].x,majors[i].y)})).filter(x=>x.j!==i).sort((a,b)=>a.d-b.d).slice(0,3);
    for (const {s:target} of nearest) {
      const exists = roads.some(r => (r.from===majors[i].name&&r.to===target.name)||(r.from===target.name&&r.to===majors[i].name));
      if (!exists) roads.push({ path:findPath(majors[i],target), type:"major", from:majors[i].name, to:target.name });
    }
  }

  const towns = settlements.filter(s=>s.type==="town");
  for (const town of towns) {
    const near = majors.map(s=>({s,d:dist(s.x,s.y,town.x,town.y)})).sort((a,b)=>a.d-b.d)[0];
    if (near&&near.d<60) roads.push({ path:findPath(town,near.s), type:"minor", from:town.name, to:near.s.name });
  }

  // Trade routes between distant cities (long-range connections)
  const tradeRoutes = [];
  if (majors.length > 3) {
    for (let i = 0; i < Math.min(4, majors.length); i++) {
      const far = majors.map((s,j)=>({s,j,d:dist(s.x,s.y,majors[i].x,majors[i].y)})).filter(x=>x.j!==i).sort((a,b)=>b.d-a.d)[0];
      if (far && far.d > 40) {
        const exists = tradeRoutes.some(r => (r.from===majors[i].name&&r.to===far.s.name)||(r.from===far.s.name&&r.to===majors[i].name));
        if (!exists) tradeRoutes.push({ path:findPath(majors[i],far.s), type:"trade", from:majors[i].name, to:far.s.name });
      }
    }
  }

  return [...roads, ...tradeRoutes];
}

// ─── KINGDOM / TERRITORY GENERATION ─────────────────────────────────────────

const KINGDOM_COLORS = [
  { fill:"rgba(148,57,57,0.12)", stroke:"rgba(148,57,57,0.45)", accent:"#944039" },
  { fill:"rgba(57,100,148,0.12)", stroke:"rgba(57,100,148,0.45)", accent:"#396494" },
  { fill:"rgba(57,148,80,0.12)", stroke:"rgba(57,148,80,0.45)", accent:"#399450" },
  { fill:"rgba(148,120,57,0.12)", stroke:"rgba(148,120,57,0.45)", accent:"#947839" },
  { fill:"rgba(120,57,148,0.12)", stroke:"rgba(120,57,148,0.45)", accent:"#783994" },
  { fill:"rgba(57,148,140,0.12)", stroke:"rgba(57,148,140,0.45)", accent:"#39948c" },
  { fill:"rgba(148,57,120,0.12)", stroke:"rgba(148,57,120,0.45)", accent:"#943978" },
  { fill:"rgba(80,120,57,0.12)", stroke:"rgba(80,120,57,0.45)", accent:"#507839" },
  { fill:"rgba(100,80,140,0.12)", stroke:"rgba(100,80,140,0.45)", accent:"#64508c" },
  { fill:"rgba(140,100,80,0.12)", stroke:"rgba(140,100,80,0.45)", accent:"#8c6450" },
];

function generateKingdoms(settlements, hmap, gW, gH, rng, count) {
  const capitals = settlements.filter(s=>s.type==="capital");
  const kingdoms = [];

  for (let i = 0; i < Math.min(count, capitals.length); i++) {
    const cap = capitals[i];
    const mySettlements = [cap];
    for (const s of settlements) {
      if (s===cap) continue;
      const d = dist(s.x,s.y,cap.x,cap.y);
      let isNearest = true;
      for (let j = 0; j < Math.min(count,capitals.length); j++) {
        if (j===i) continue;
        if (dist(s.x,s.y,capitals[j].x,capitals[j].y) < d) { isNearest=false; break; }
      }
      if (isNearest && d < 80) mySettlements.push(s);
    }

    const pts = mySettlements.map(s=>({x:s.x,y:s.y}));
    if (pts.length < 3) { const r=15; for (let a=0;a<Math.PI*2;a+=Math.PI/5) pts.push({x:cap.x+Math.cos(a)*r,y:cap.y+Math.sin(a)*r}); }
    const cx = pts.reduce((s,p)=>s+p.x,0)/pts.length;
    const cy = pts.reduce((s,p)=>s+p.y,0)/pts.length;
    const sorted = [...pts].sort((a,b)=>Math.atan2(a.y-cy,a.x-cx)-Math.atan2(b.y-cy,b.x-cx));
    const hull = sorted.map(p => { const dx=p.x-cx,dy=p.y-cy,len=Math.sqrt(dx*dx+dy*dy)||1; return {x:p.x+(dx/len)*14,y:p.y+(dy/len)*14}; });

    const colors = KINGDOM_COLORS[i % KINGDOM_COLORS.length];
    const totalPop = mySettlements.reduce((s,st)=>s+st.population,0);

    // Kingdom-level lore
    const lore = generateLore(rng, "kingdom_founding", {
      years: pick(LORE_FRAGMENTS.years, rng).toString(),
      founder: genNPCName(rng),
      method: pick(LORE_FRAGMENTS.method, rng),
      artifact: pick(LORE_FRAGMENTS.artifact, rng),
      location: genName(rng, "mountain"),
      old_realm: pick(LORE_FRAGMENTS.old_realm, rng),
      cataclysm: pick(LORE_FRAGMENTS.cataclysm, rng),
      entity: pick(LORE_FRAGMENTS.entity, rng),
      purpose: pick(LORE_FRAGMENTS.purpose, rng),
    });

    // Government & relations
    const govt = pick(["Absolute Monarchy","Constitutional Monarchy","Feudal System","Theocracy","Oligarchy","Magocracy","Military Junta","Republic","Tribal Confederation","Merchant Republic"], rng);
    const militaryStr = pick(["formidable","strong","moderate","weak","decimated","legendary","growing","overstretched","elite but small","numerous but poorly trained"], rng);

    kingdoms.push({
      name: genKingdomName(rng), capital: cap.name,
      settlements: mySettlements.map(s=>s.name), hull,
      color: colors.fill, borderColor: colors.stroke, accent: colors.accent,
      population: totalPop, lore, government: govt, militaryStrength: militaryStr,
      relations: {}, // populated after all kingdoms exist
      ruler: { name: genNPCName(rng), title: pick(["King","Queen","Emperor","Empress","Archduke","Archduchess","High Lord","High Lady","Sovereign","Protector"], rng), trait: pick(NPC_TRAITS, rng) },
      economy: pick(["trade","agriculture","mining","fishing","manufacturing","magic","mercenary","scholarly","religious","raiding"], rng),
      religion: pick(["monotheistic","polytheistic","ancestor worship","nature worship","arcane devotion","atheistic","cult worship","animistic","philosophical","syncretic"], rng),
    });
  }

  // Generate inter-kingdom relations
  for (let i = 0; i < kingdoms.length; i++) {
    for (let j = i+1; j < kingdoms.length; j++) {
      const relation = pick(["allied","friendly","neutral","tense","hostile","at war","trading partners","non-aggression pact","vassal relationship","bitter rivals"], rng);
      kingdoms[i].relations[kingdoms[j].name] = relation;
      kingdoms[j].relations[kingdoms[i].name] = relation;
    }
  }

  return kingdoms;
}

// ─── POI GENERATION (expanded) ──────────────────────────────────────────────

const POI_DESCRIPTIONS = {
  dungeon: [
    "A sprawling underground complex filled with ancient traps and forgotten treasure.",
    "An abandoned dwarven stronghold overrun by creatures of the deep.",
    "A network of natural caverns expanded by dark magic into a labyrinth of horrors.",
    "The prison-fortress of a long-dead tyrant, where captive spirits still wander.",
    "An underground temple complex built to worship a slumbering elder entity.",
  ],
  ruins: [
    "Crumbling remnants of a civilization that predates recorded history.",
    "The shattered towers of a wizard's academy, destroyed in a catastrophic experiment.",
    "Ancient elven ruins slowly being reclaimed by the forest, still humming with old magic.",
    "A collapsed cathedral whose stained glass windows still glow with divine light.",
    "The foundations of a city swallowed by the earth during a great cataclysm.",
  ],
  tower: [
    "A solitary watchtower built on the highest point for leagues, now abandoned.",
    "A wizard's spire crackling with residual arcane energy.",
    "An ancient lighthouse that casts a beam visible in the ethereal plane.",
    "A fortified signal tower, part of a long-defunct early warning network.",
    "An impossibly tall, narrow tower that seems to sway in winds that don't exist.",
  ],
  shrine: [
    "A weathered stone altar surrounded by offerings from local pilgrims.",
    "A sacred grove where the barrier between planes is thin.",
    "An ancient prayer site built at the confluence of two ley lines.",
    "A small temple carved into living rock, maintained by a hermit priest.",
    "A circle of standing stones that glow faintly during celestial events.",
  ],
  cave: [
    "A deep natural cavern system with underground rivers and crystal formations.",
    "A cave mouth belching warm, sulfurous air from deep volcanic vents.",
    "An extensive cave network that locals claim connects to the Underdark.",
    "A sea cave that floods at high tide, revealing hidden passages at low water.",
    "A cave covered in ancient pictographs depicting events yet to come.",
  ],
  grove: [
    "An enchanted clearing where animals speak and time moves differently.",
    "A circle of ancient trees that are actually petrified treants.",
    "A fey-touched woodland where reality bends to imagination.",
    "A druidic sanctuary maintained by a circle of shapeshifters.",
    "A grove of crystal trees that sing harmonies in the moonlight.",
  ],
  monolith: [
    "A towering black obelisk covered in script no sage can decipher.",
    "A crystalline pillar that amplifies arcane magic within its radius.",
    "A carved stone monument depicting the prophesied end of the world.",
    "An ancient boundary marker between material and fey realms.",
    "A pulsating stone that draws creatures and travelers to its base.",
  ],
  mine: [
    "An abandoned gold mine with collapsed lower levels hiding something.",
    "A mithril vein still producing, heavily guarded by its current owners.",
    "A played-out quarry where workers recently broke through to something ancient.",
    "A gem mine infested with earth elementals after a mining accident.",
    "A deep shaft mine that has been sealed for decades after an 'incident'.",
  ],
  fortress: [
    "A ruined hilltop fortification with walls still standing despite centuries.",
    "A strategically vital border fortress contested by neighboring kingdoms.",
    "An ancient dwarven citadel carved into the mountainside itself.",
    "A warlord's stronghold surrounded by the bleached bones of failed siege armies.",
    "A magical fortress that appears and disappears according to unknown cycles.",
  ],
  temple: [
    "A grand cathedral to an active deity, radiating palpable divine presence.",
    "A syncretic temple where followers of many gods worship in uneasy peace.",
    "A cursed temple where the divine connection was severed by a dark ritual.",
    "A monastery where warrior-monks train in both martial and spiritual arts.",
    "An underwater temple visible through crystal-clear lake waters.",
  ],
  lighthouse: [
    "A coastal beacon whose light has guided sailors for a thousand years.",
    "A storm-battered tower maintained by a single, ageless keeper.",
    "A lighthouse whose beam reveals invisible ships from other planes.",
    "A decommissioned lighthouse recently relit by unknown parties.",
    "A lighthouse on a cliff that serves as a front for smuggling operations.",
  ],
  camp: [
    "A semi-permanent bandit encampment preying on nearby trade routes.",
    "A nomadic tribe's seasonal camp, rich with unfamiliar cultural traditions.",
    "A military bivouac positioned for an upcoming campaign.",
    "A ranger outpost monitoring monster migrations through the region.",
    "A traveling carnival that sets up camp, bringing wonder and pickpockets.",
  ],
  portal: [
    "A shimmering gateway between material and fey planes.",
    "An ancient teleportation circle, destination unknown.",
    "A planar rift slowly widening, leaking creatures from elsewhere.",
    "A mirror-smooth pool that reflects a different world entirely.",
    "A stone archway that activates during specific celestial alignments.",
  ],
  battlefield: [
    "The site of a legendary battle, where the dead are not fully at rest.",
    "Scorched earth and twisted metal from a conflict that reshaped the region.",
    "A field of enchanted weapons jutting from the ground like grave markers.",
    "An ancient killing field where no plants grow and animals refuse to tread.",
    "A battlefield preserved in time by residual magic, bodies frozen mid-combat.",
  ],
};

function generatePOIs(hmap, mmap, settlements, gW, gH, rng, config) {
  const pois = [];
  const seaLevel = 0.38;
  const types = [
    { type:"dungeon", count:config.dungeons||12, terrain:"high", icon:"dungeon" },
    { type:"ruins", count:config.ruins||10, terrain:"any", icon:"ruins" },
    { type:"tower", count:config.towers||8, terrain:"high", icon:"tower" },
    { type:"shrine", count:config.shrines||10, terrain:"any", icon:"shrine" },
    { type:"cave", count:config.caves||10, terrain:"mountain", icon:"cave" },
    { type:"grove", count:config.groves||6, terrain:"forest", icon:"grove" },
    { type:"monolith", count:config.monoliths||5, terrain:"any", icon:"monolith" },
    { type:"mine", count:config.mines||8, terrain:"mountain", icon:"mine" },
    { type:"fortress", count:config.fortresses||6, terrain:"high", icon:"fortress" },
    { type:"temple", count:config.temples||5, terrain:"any", icon:"temple" },
    { type:"lighthouse", count:config.lighthouses||4, terrain:"coast", icon:"lighthouse" },
    { type:"camp", count:config.camps||8, terrain:"any", icon:"camp" },
    { type:"portal", count:config.portals||3, terrain:"any", icon:"portal" },
    { type:"battlefield", count:config.battlefields||4, terrain:"any", icon:"battlefield" },
  ];

  function minDistToPOIs(x,y) {
    let md=Infinity;
    for (const p of pois) { const d=dist(p.x,p.y,x,y); if(d<md) md=d; }
    for (const s of settlements) { const d=dist(s.x,s.y,x,y); if(d<md) md=d; }
    return md;
  }

  for (const {type,count,terrain,icon} of types) {
    for (let i = 0; i < count; i++) {
      let bestX=-1, bestY=-1;
      for (let att = 0; att < 400; att++) {
        const x = Math.floor(rng()*gW), y = Math.floor(rng()*gH);
        const h = hmap[y]?.[x]||0, m = mmap[y]?.[x]||0;
        if (h<seaLevel) continue;
        if (terrain==="high"&&h<0.55) continue;
        if (terrain==="mountain"&&h<0.65) continue;
        if (terrain==="forest"&&m<0.5) continue;
        if (terrain==="coast"&&h>0.45) continue;
        if (minDistToPOIs(x,y)<6) continue;
        bestX=x; bestY=y; break;
      }
      if (bestX<0) continue;

      const descriptions = POI_DESCRIPTIONS[type] || POI_DESCRIPTIONS.ruins;
      const threatLevel = pick(["trivial","low","moderate","high","extreme","deadly"],rng);
      const cr = threatLevel==="trivial"?randInt(1,3,rng):threatLevel==="low"?randInt(2,5,rng):threatLevel==="moderate"?randInt(4,8,rng):threatLevel==="high"?randInt(7,12,rng):threatLevel==="extreme"?randInt(11,16,rng):randInt(15,20,rng);
      const treasure = generateTreasureHoard(rng, cr);
      const lore = generateLore(rng, type==="dungeon"?"dungeon_rumor":type==="ruins"?"ruin_legend":"ruin_legend", {name:genName(rng,type==="mine"?"dungeon":type), creature:pick(LORE_FRAGMENTS.creature,rng), treasure:pick(LORE_FRAGMENTS.treasure,rng), hazard:pick(LORE_FRAGMENTS.hazard,rng), faction:pick(LORE_FRAGMENTS.faction,rng), location:genName(rng,"town"), objective:pick(LORE_FRAGMENTS.objective,rng), feature:pick(LORE_FRAGMENTS.feature,rng), area:pick(["upper levels","lower chambers","central hall","hidden wing","collapsed section","flooded depths"],rng)});

      pois.push({
        x:bestX, y:bestY, type, icon,
        name: genName(rng, type==="mine"||type==="cave"?"dungeon":type==="fortress"||type==="tower"||type==="lighthouse"?"ruins":type==="portal"||type==="battlefield"?"ruins":type),
        description: pick(descriptions, rng),
        threat: threatLevel, cr,
        discovered: rng() > 0.4,
        treasure, lore,
        occupants: pick(["Empty","Undead","Bandits","Cultists","Monsters","Wildlife","Demons","Fey","Constructs","Aberrations","Dragon","Lich","Beholder","Mind Flayers","Kobolds","Goblins","Orcs","Trolls","Giants","Elementals"],rng),
        floors: type==="dungeon"?randInt(2,8,rng):type==="mine"?randInt(3,12,rng):type==="tower"?randInt(3,10,rng):1,
        condition: pick(["pristine","well-maintained","aging","crumbling","ruined","collapsed","overgrown","frozen","petrified","warped by magic"],rng),
      });
    }
  }
  return pois;
}

// ─── LANDMARK GENERATION ────────────────────────────────────────────────────

function generateLandmarks(hmap, mmap, gW, gH, rng) {
  const landmarks = [];
  const seaLevel = 0.38;

  // Mountain ranges
  for (let i=0;i<8;i++) {
    let bX=-1,bY=-1,bH=0;
    for (let att=0;att<300;att++) { const x=Math.floor(rng()*gW),y=Math.floor(rng()*gH),h=hmap[y]?.[x]||0; if(h>bH&&h>0.78) { let ok=true; for(const l of landmarks) if(l.type==="mountain_range"&&dist(l.x,l.y,x,y)<25) ok=false; if(ok){bH=h;bX=x;bY=y;} } }
    if(bX>=0) landmarks.push({x:bX,y:bY,type:"mountain_range",name:genName(rng,"mountain"),h:bH});
  }
  // Forests
  for (let i=0;i<6;i++) {
    let bX=-1,bY=-1,bM=0;
    for (let att=0;att<300;att++) { const x=Math.floor(rng()*gW),y=Math.floor(rng()*gH),h=hmap[y]?.[x]||0,m=mmap[y]?.[x]||0; if(h>seaLevel&&h<0.65&&m>bM&&m>0.6) { let ok=true; for(const l of landmarks) if(l.type==="forest"&&dist(l.x,l.y,x,y)<22) ok=false; if(ok){bM=m;bX=x;bY=y;} } }
    if(bX>=0) landmarks.push({x:bX,y:bY,type:"forest",name:genName(rng,"forest")});
  }
  // Deserts
  for (let i=0;i<4;i++) {
    let bX=-1,bY=-1;
    for (let att=0;att<300;att++) { const x=Math.floor(rng()*gW),y=Math.floor(rng()*gH),h=hmap[y]?.[x]||0,m=mmap[y]?.[x]||0; if(h>seaLevel&&h<0.6&&m<0.15) { let ok=true; for(const l of landmarks) if(l.type==="desert"&&dist(l.x,l.y,x,y)<25) ok=false; if(ok){bX=x;bY=y;} } }
    if(bX>=0) landmarks.push({x:bX,y:bY,type:"desert",name:genName(rng,"desert")});
  }
  // Lakes
  for (let i=0;i<6;i++) {
    let bX=-1,bY=-1;
    for (let att=0;att<400;att++) { const x=Math.floor(rng()*(gW-4))+2,y=Math.floor(rng()*(gH-4))+2,h=hmap[y][x]; if(h<seaLevel||h>0.55) continue; let isLow=true; for(let dy=-2;dy<=2;dy++) for(let dx=-2;dx<=2;dx++) { if(dx===0&&dy===0)continue; if((hmap[y+dy]?.[x+dx]||0)<h-0.02) isLow=false; } if(isLow) { let ok=true; for(const l of landmarks) if(l.type==="lake"&&dist(l.x,l.y,x,y)<18) ok=false; if(ok){bX=x;bY=y;break;} } }
    if(bX>=0) landmarks.push({x:bX,y:bY,type:"lake",name:genName(rng,"lake"),radius:3+rng()*6});
  }
  // Swamps
  for (let i=0;i<4;i++) {
    let bX=-1,bY=-1;
    for (let att=0;att<200;att++) { const x=Math.floor(rng()*gW),y=Math.floor(rng()*gH),h=hmap[y]?.[x]||0,m=mmap[y]?.[x]||0; if(h>0.38&&h<0.45&&m>0.6){bX=x;bY=y;break;} }
    if(bX>=0) landmarks.push({x:bX,y:bY,type:"swamp",name:genName(rng,"swamp")});
  }
  // Islands (isolated high points in ocean)
  for (let i=0;i<3;i++) {
    let bX=-1,bY=-1;
    for (let att=0;att<300;att++) { const x=Math.floor(rng()*gW),y=Math.floor(rng()*gH),h=hmap[y]?.[x]||0; if(h>0.35&&h<0.5) { let nearOcean=false; for(let dy=-6;dy<=6;dy++) for(let dx=-6;dx<=6;dx++) { if((hmap[y+dy]?.[x+dx]||0)<0.3) nearOcean=true; } if(nearOcean){bX=x;bY=y;break;} } }
    if(bX>=0) landmarks.push({x:bX,y:bY,type:"island",name:genName(rng,"island")});
  }
  return landmarks;
}


// ─── SETTLEMENT DISTRICTS ───────────────────────────────────────────────────

const DISTRICT_TYPES = [
  { name: "Noble Quarter", wealth: "wealthy", crime: 5, atmosphere: "elegant", buildings: ["mansions", "gardens", "private guards"] },
  { name: "Slums", wealth: "destitute", crime: 85, atmosphere: "crowded", buildings: ["hovels", "gambling dens", "thieves' hideouts"] },
  { name: "Market District", wealth: "moderate", crime: 35, atmosphere: "bustling", buildings: ["stalls", "warehouses", "money changers"] },
  { name: "Temple District", wealth: "moderate", crime: 10, atmosphere: "reverent", buildings: ["temples", "shrines", "monasteries"] },
  { name: "Harbor District", wealth: "moderate", crime: 60, atmosphere: "salty", buildings: ["docks", "taverns", "ship repairs"] },
  { name: "Warehouse District", wealth: "poor", crime: 40, atmosphere: "industrial", buildings: ["warehouses", "loading docks", "merchant houses"] },
  { name: "Artisan Quarter", wealth: "moderate", crime: 25, atmosphere: "creative", buildings: ["studios", "workshops", "galleries"] },
  { name: "Entertainment District", wealth: "moderate", crime: 70, atmosphere: "lively", buildings: ["theaters", "brothels", "gambling halls"] },
  { name: "Military Quarter", wealth: "moderate", crime: 15, atmosphere: "orderly", buildings: ["barracks", "armory", "training grounds"] },
  { name: "Foreign Quarter", wealth: "moderate", crime: 45, atmosphere: "exotic", buildings: ["merchant houses", "temples", "inns"] },
  { name: "Arcane Quarter", wealth: "wealthy", crime: 20, atmosphere: "magical", buildings: ["towers", "libraries", "research labs"] },
  { name: "Garden District", wealth: "wealthy", crime: 8, atmosphere: "peaceful", buildings: ["parks", "estates", "fountains"] },
  { name: "Underground District", wealth: "poor", crime: 65, atmosphere: "shadowy", buildings: ["cavern homes", "secret passages", "mines"] },
  { name: "Rooftop District", wealth: "poor", crime: 55, atmosphere: "lawless", buildings: ["platforms", "bridges", "makeshift homes"] },
  { name: "Floating District", wealth: "wealthy", crime: 30, atmosphere: "whimsical", buildings: ["island platforms", "sky bridges", "sky ships"] },
  { name: "Undercity", wealth: "destitute", crime: 90, atmosphere: "dangerous", buildings: ["tunnels", "slave markets", "necromancer dens"] },
  { name: "Alchemist Row", wealth: "moderate", crime: 40, atmosphere: "noxious", buildings: ["alchemic shops", "potion breweries", "ingredient markets"] },
  { name: "Blacksmith's Forge", wealth: "moderate", crime: 20, atmosphere: "hot", buildings: ["forges", "foundries", "armor shops"] },
  { name: "Scholars' Row", wealth: "moderate", crime: 15, atmosphere: "intellectual", buildings: ["libraries", "academies", "lecture halls"] },
  { name: "Dead Quarter", wealth: "poor", crime: 75, atmosphere: "haunted", buildings: ["cemeteries", "crypts", "funeral homes"] },
  { name: "Drowned Quarter", wealth: "poor", crime: 50, atmosphere: "wet", buildings: ["flooded ruins", "boat homes", "salvage yards"] },
  { name: "Red Light District", wealth: "poor", crime: 80, atmosphere: "scandalous", buildings: ["brothels", "pleasure houses", "secret rooms"] },
  { name: "Goblin Town", wealth: "destitute", crime: 88, atmosphere: "chaotic", buildings: ["ramshackle huts", "junk piles", "trash heaps"] },
  { name: "Elf Enclave", wealth: "wealthy", crime: 5, atmosphere: "serene", buildings: ["tree homes", "natural gardens", "meditation circles"] },
  { name: "Dwarf Hold", wealth: "moderate", crime: 12, atmosphere: "sturdy", buildings: ["stone halls", "ale houses", "gem shops"] },
  { name: "Holy Sanctuary", wealth: "moderate", crime: 2, atmosphere: "sacred", buildings: ["cathedrals", "reliquary", "healing temples"] },
  { name: "College of Magic", wealth: "wealthy", crime: 18, atmosphere: "arcane", buildings: ["tower apartments", "spell labs", "libraries"] },
  { name: "Thieves' Warren", wealth: "poor", crime: 100, atmosphere: "treacherous", buildings: ["hideouts", "fences", "assassin headquarters"] },
  { name: "Beast Quarter", wealth: "poor", crime: 70, atmosphere: "wild", buildings: ["stables", "beast pens", "hunter lodges"] },
  { name: "Plague Ward", wealth: "destitute", crime: 55, atmosphere: "diseased", buildings: ["plague houses", "herbalist shops", "quarantine zones"] },
];

function generateDistricts(rng, settlement) {
  const districtCount = settlement.type === "capital" ? randInt(8, 15, rng)
                      : settlement.type === "city" ? randInt(5, 10, rng)
                      : settlement.type === "town" ? randInt(2, 4, rng)
                      : 1;

  const districts = [];
  const selectedTypes = pickN(DISTRICT_TYPES, Math.min(districtCount, DISTRICT_TYPES.length), rng);

  for (const districtType of selectedTypes) {
    const district = {
      ...districtType,
      buildings: pickN(districtType.buildings.concat([
        "residences", "shops", "taverns", "inns", "temples", "marketplaces", "warehouses", "guard posts"
      ]), randInt(2, 6, rng), rng),
      npcs: [],
      shops: [],
      atmosphere: districtType.atmosphere,
      notableSights: pickN([
        "famous statue", "historic building", "unusual architecture", "fountain", "market square",
        "guild hall", "notable tree", "mural", "monument", "street performance space"
      ], randInt(1, 3, rng), rng),
    };

    // Generate NPCs for district
    const npcCount = Math.ceil(settlement.population / 100) + randInt(1, 3, rng);
    for (let i = 0; i < npcCount; i++) {
      district.npcs.push(generateNPC(rng, {
        role: pick(["merchant", "artisan", "laborer", "noble", "priest", "guard"], rng),
        alignment: settlement.alignment
      }));
    }

    // Generate shops
    const shopCount = randInt(1, 5, rng);
    for (let i = 0; i < shopCount; i++) {
      const shopType = pick([
        "blacksmith", "alchemist", "enchanter", "tailor", "baker", "fletcher", "jeweler",
        "herbalist", "scribe", "cartographer", "bookshop", "potion shop", "curiosity shop",
        "pet shop", "tavern", "inn", "armor shop", "weapon shop", "textile shop"
      ], rng);
      district.shops.push(generateShop(rng, shopType));
    }

    districts.push(district);
  }

  return districts;
}

const SHOP_TYPES = [
  "blacksmith", "alchemist", "enchanter", "tailor", "baker", "fletcher", "jeweler",
  "herbalist", "scribe", "cartographer", "bookshop", "potion shop", "curiosity shop",
  "pet shop", "tavern", "inn", "brothel", "gambling den", "fighting pit", "bath house",
  "library", "museum", "gallery", "theater", "temple", "guild hall", "bank", "warehouse",
  "smuggler's den", "fence", "armor shop", "weapon shop", "textile shop", "leather shop"
];

function generateShop(rng, type) {
  const shopNames = {
    blacksmith: ["Hammer and Anvil", "Iron Works", "The Forge", "Steelheart's Smithy", "Sparks and Cinder"],
    alchemist: ["Volatile Vials", "Essence Extraction", "The Cauldron", "Mystical Mixtures", "Potion's Promise"],
    enchanter: ["Arcane Artifacts", "Spell Weaver's Shop", "The Enchanted Emporium", "Magicraft", "Cursed Curios"],
    tailor: ["Fine Stitches", "The Needle's Eye", "Cloth and Cotton", "Fashion Forward", "Silken Threads"],
    baker: ["The Golden Loaf", "Rise and Shine", "Crusty Dreams", "Sweet Bread", "The Oven's Heart"],
    fletcher: ["Straight and True", "The Arrow Maker", "Bow and Quiver", "Feathered Flight", "Quick Shots"],
    jeweler: ["Precious Stones", "Glitter and Gold", "The Gem House", "Shiny Things", "Jeweled Crown"],
    herbalist: ["Nature's Medicine", "The Herb Garden", "Healing Leaves", "Green Remedies", "Plant Power"],
    scribe: ["Ink and Parchment", "The Quill", "Written Words", "Manuscript House", "Page Turner"],
    cartographer: ["Map Master", "Journey's Guide", "The Compass", "World's Cartography", "Path Finder"],
    bookshop: ["Tome and Tale", "The Library", "Reading Refuge", "Books and More", "Page Turner's Paradise"],
    potion_shop: ["Bubbling Brew", "Liquid Magic", "The Apothecary", "Potion Central", "Draught House"],
    curiosity_shop: ["Oddities and Ends", "Strange Wonders", "The Curiosity Cabinet", "Peculiar Finds", "Mysterious Goods"],
    pet_shop: ["Critter Corner", "Beasts and Creatures", "The Pet Emporium", "Friendly Fauna", "Animal Haven"],
    tavern: ["The Wandering Griffin", "The Laughing Harpy", "The Broken Wheel", "The Sleeping Dragon", "The Crooked Cup"],
    inn: ["The Restful Head", "The Comfortable Hearth", "Traveler's Rest", "The Weary Wanderer", "Safe Slumber Inn"],
  };

  const names = shopNames[type] || ["The " + pick(["Golden", "Silver", "Misty", "Gleaming", "Dusty"], rng) + " " + pick(["Emporium", "Shop", "Store", "House", "Hall"], rng)];
  const shopkeeper = generateNPC(rng, { name: genNPCName(rng), role: type });

  const basePrices = {
    blacksmith: 50, alchemist: 100, enchanter: 500, tailor: 25, baker: 2, fletcher: 15,
    jeweler: 200, herbalist: 10, scribe: 20, cartographer: 50, bookshop: 30, potion_shop: 75,
    curiosity_shop: 80, pet_shop: 40, tavern: 5, inn: 20
  };

  const inventory = [];
  const itemCount = randInt(8, 20, rng);
  for (let i = 0; i < itemCount; i++) {
    const basePrice = basePrices[type] || 50;
    inventory.push({
      item: genName(rng, "item"),
      quantity: randInt(1, 50, rng),
      price: Math.max(1, Math.round(basePrice + rng() * basePrice - basePrice / 2)),
      quality: pick(["shoddy", "fair", "good", "excellent", "masterwork"], rng),
    });
  }

  return {
    name: pick(names, rng),
    type,
    shopkeeper,
    inventory,
    specialties: pickN([
      "rare items", "bulk wholesale", "custom orders", "repair service", "appraisal service",
      "high quality", "discount goods", "import business", "auction house", "fencing operation"
    ], randInt(1, 3, rng), rng),
    reputation: pick(["honest", "fair", "shrewd", "overpriced", "suspicious"], rng),
    openingHours: pick(["dawn to dusk", "morning to evening", "all hours", "night only", "by appointment"], rng),
    condition: pick(["pristine", "well-maintained", "aging", "shabby", "ramshackle"], rng),
  };
}

// ─── BUILDING GENERATION ────────────────────────────────────────────────────

function generateBuilding(rng, type, settlement) {
  const styles = {
    medieval: { material: "stone", roofType: "thatch or tile", window: "narrow arches" },
    elven: { material: "wood and stone", roofType: "living plants", window: "flowing curves" },
    dwarven: { material: "carved stone", roofType: "reinforced slate", window: "small and deep" },
    magical: { material: "crystalline or enchanted", roofType: "floating shards", window: "glowing runes" },
    gothic: { material: "dark stone", roofType: "steep slate", window: "pointed arches" },
  };

  const style = pick(Object.keys(styles), rng);
  const styleData = styles[style];

  const building = {
    name: genName(rng, "place"),
    type: type || pick(["residence", "shop", "warehouse", "temple", "tower", "mansion", "cottage", "hall"], rng),
    style,
    material: styleData.material,
    roofType: styleData.roofType,
    windows: styleData.window,
    floors: randInt(1, type === "tower" ? 8 : 4, rng),
    rooms: randInt(2, type === "mansion" ? 20 : type === "shop" ? 3 : 6, rng),
    age: randInt(10, 500, rng),
    condition: pick(["pristine", "well-maintained", "aging", "damaged", "crumbling"], rng),
    inhabitants: randInt(1, 12, rng),
    notableFeatures: pickN([
      "secret room", "hidden passage", "enchanted door", "petrified wood", "animated stone",
      "ancient tapestry", "mysterious painting", "artifact collection", "library", "museum",
      "vault", "observatory", "alchemy lab", "spell circle", "haunting presence", "frescoes",
      "mosaic floors", "stained glass", "fountain courtyard", "garden maze"
    ], randInt(0, 3, rng), rng),
  };

  // Generate rooms
  building.roomList = [];
  for (let i = 0; i < building.rooms; i++) {
    building.roomList.push({
      name: pick(["bedroom", "dining room", "kitchen", "study", "workshop", "storage", "hall", "parlor", "bathroom"], rng),
      size: pick(["small", "medium", "large"], rng),
      contents: pickN([
        "furniture", "paintings", "books", "weapons", "tools", "food supplies", "bedding",
        "valuables", "magical artifacts", "strange machines", "preserved specimens", "documents"
      ], randInt(1, 3, rng), rng),
    });
  }

  return building;
}

function generateTavern(rng, settlement) {
  const tavern = {
    name: genTavernName(rng),
    specialty: pick(["Strong ale","Exotic wines","Hearty stew","Roasted boar","Fresh bread","Spiced mead","Mushroom soup","Grilled fish","Elven pastries","Dwarven dark ale"], rng),
    owner: genNPCName(rng),
    barkeep: generateNPC(rng, { role: "bartender" }),
    capacity: randInt(30, settlement.type === "capital" ? 200 : settlement.type === "city" ? 100 : 50, rng),
    atmosphere: pick(["cozy", "raucous", "elegant", "seedy", "scholarly", "rough", "friendly", "tense"], rng),
    rooms: randInt(2, settlement.type === "capital" ? 20 : settlement.type === "city" ? 12 : 6, rng),
    pricePerNight: settlement.type === "capital" ? randInt(5, 20, rng) : settlement.type === "city" ? randInt(2, 10, rng) : randInt(1, 5, rng),
  };

  // Menu items (20+)
  tavern.menu = [
    { item: "Ale (pint)", price: 0.5 },
    { item: "Mead (horn)", price: 1 },
    { item: "Wine (glass)", price: 2 },
    { item: "Whiskey (shot)", price: 1.5 },
    { item: "Bread and cheese", price: 0.3 },
    { item: "Meat pie", price: 1 },
    { item: "Stew (bowl)", price: 0.8 },
    { item: "Roasted leg of lamb", price: 3 },
    { item: "Grilled fish", price: 2.5 },
    { item: "Honey cakes", price: 0.5 },
    { item: "Butter and jam", price: 0.3 },
    { item: "Mushroom soup", price: 0.7 },
    { item: "Sausage and potatoes", price: 1.5 },
    { item: "Chicken roast", price: 2 },
    { item: "Pickled vegetables", price: 0.4 },
    { item: "Fresh fruit", price: 0.6 },
    { item: "Exotic spiced wine", price: 4 },
    { item: "Rare vintage", price: 8 },
    { item: "House specialty", price: randInt(1, 5, rng) },
    { item: "Mysterious potion", price: 10 },
  ];

  // Entertainment
  tavern.entertainment = pickN([
    "bard performances", "dice games", "card games", "arm wrestling", "storytelling circles",
    "dancing", "live music", "puppet shows", "shadow plays", "poetry readings", "magician tricks",
    "betting pools", "fighting pits", "drinking contests", "riddle games"
  ], randInt(1, 4, rng), rng);

  // Regular patrons
  tavern.regulars = [];
  for (let i = 0; i < randInt(3, 8, rng); i++) {
    tavern.regulars.push({
      name: genNPCName(rng),
      role: pick(["drunk", "merchant", "adventurer", "scholar", "noble", "beggar", "gambler"], rng),
      frequency: pick(["daily", "weekly", "whenever drunk", "evenings only"], rng),
      reputation: pick(["friendly", "aggressive", "helpful", "annoying", "mysterious"], rng),
    });
  }

  // Barkeep personality
  tavern.barkeepPersonality = pick([
    "gregarious and gossipy",
    "stern and business-like",
    "jovial and laughing",
    "mysterious and knowing",
    "cynical and world-weary",
    "cheerful and welcoming",
    "judgmental and critical",
    "secretive and cautious"
  ], rng);

  // Rumors (10+)
  tavern.rumors = [
    "Strange lights in the northern ruins have been spotted recently.",
    "A caravan vanished on the eastern road without a trace.",
    "The lord's chamberlain has been seen meeting with hooded figures.",
    "Bandits have been targeting merchants carrying certain goods.",
    "A wizard has taken up residence in the old tower outside town.",
    "The temple priest is secretly practicing forbidden magic.",
    "There's a tunnel network beneath the city that no one dares to map.",
    "A dragon was sighted flying toward the mountain range three days ago.",
    "The fishermen have found strange bones in the river recently.",
    "Undead have been walking the roads at night, searching for something.",
    "A lost artifact is said to be hidden in the crypt beneath the church.",
    "The mayor's youngest has disappeared, and foul play is suspected.",
    "An ancient gate has been discovered sealed in the cellar of the old library.",
    "Merchants are disappearing and their goods are being sold in black markets.",
    "The local militia commander has been replaced with a stranger.",
  ];

  // Secret basement
  tavern.basement = {
    exists: rng() > 0.3,
    purpose: tavern.basement?.exists ? pick(["smuggling operation", "illegal gambling", "secret society", "cultist meetings", "dungeon storage"], rng) : null,
    hazard: tavern.basement?.exists ? pick(["trapped door", "violent bouncers", "magical ward", "creature infestation", "unstable construction"], rng) : null,
  };

  // Back room activities
  tavern.backRoom = {
    exists: rng() > 0.4,
    activity: tavern.backRoom?.exists ? pick(["assassination plots", "noble intrigue", "criminal deals", "magical discussion", "romantic assignations"], rng) : null,
    accessRequired: tavern.backRoom?.exists ? pick(["invitation", "password", "bribe", "initiation", "special knock"], rng) : null,
  };

  return tavern;
}

// ─── KINGDOM DIPLOMACY ENGINE ───────────────────────────────────────────────

const DIPLOMATIC_ACTIONS = [
  "alliance formation", "trade treaty", "marriage pact", "war declaration", "embargo",
  "peace treaty", "vassalization", "tribute demand", "border dispute", "espionage mission",
  "assassination attempt", "cultural exchange", "joint expedition", "non-aggression pact",
  "mutual defense agreement", "trade sanctions", "naval blockade", "ceasefire proposal",
  "prisoner exchange", "hostage taking", "territorial expansion", "religious conversion",
  "scholar exchange", "diplomatic marriage", "mercenary contract", "artifact quest cooperation",
  "wizard council summit", "noble hostage exchange", "tariff agreement", "refugee acceptance"
];

function generateDiplomaticEvent(rng, k1, k2) {
  const action = pick(DIPLOMATIC_ACTIONS, rng);
  const initiator = pick([k1.name, k2.name], rng);
  const target = initiator === k1.name ? k2.name : k1.name;
  const outcome = pick(["accepted", "rejected", "under negotiation", "betrayed", "honored", "voided"], rng);
  const year = Math.floor(1990 + rng() * 30);

  return {
    action,
    initiator,
    target,
    outcome,
    year,
    details: `In the year ${year}, ${initiator} proposed ${action} with ${target}. The proposal was ${outcome}.`,
    consequences: pick([
      "strengthened bonds",
      "increased resentment",
      "economic impact",
      "military mobilization",
      "cultural shift",
      "hidden agenda revealed",
      "unexpected alliance",
      "secret betrayal"
    ], rng),
  };
}

function simulatePolitics(rng, kingdoms, years) {
  const events = [];
  for (let year = 0; year < years; year++) {
    if (kingdoms.length < 2) break;
    const k1 = pick(kingdoms, rng);
    const k2 = pick(kingdoms.filter(k => k !== k1), rng);
    if (rng() > 0.3) {
      events.push({
        year: 2000 + year,
        event: generateDiplomaticEvent(rng, k1, k2)
      });
    }
  }
  return events;
}

const GOVERNMENT_DETAILS = {
  "Absolute Monarchy": {
    ruler: "Absolute Monarch",
    courtPositions: ["Chancellor", "Chamberlain", "High General", "Court Wizard", "High Priest"],
    succession: "Hereditary, eldest child",
    powerStructure: "Monarch holds all power",
  },
  "Constitutional Monarchy": {
    ruler: "Constitutional Monarch",
    courtPositions: ["Prime Minister", "Speaker", "Chief Justice", "Military Commander"],
    succession: "Hereditary with limitations",
    powerStructure: "Shared between monarch and legislature",
  },
  "Feudal System": {
    ruler: "High Lord",
    courtPositions: ["Vassal Lords", "Court Steward", "Master-at-Arms", "Chief Priest"],
    succession: "Hereditary among nobles",
    powerStructure: "Hierarchical network of lords",
  },
  "Theocracy": {
    ruler: "High Priest",
    courtPositions: ["Cardinal", "High Oracle", "Inquisitor", "Temple Guard Commander"],
    succession: "Election among clergy",
    powerStructure: "Religious hierarchy",
  },
  "Oligarchy": {
    ruler: "Council of Lords",
    courtPositions: ["Council Members", "Treasurer", "General", "Ambassador"],
    succession: "Rotation among noble families",
    powerStructure: "Power concentrated in few families",
  },
  "Magocracy": {
    ruler: "Archmage",
    courtPositions: ["Archon", "Spell Master", "Lore Keeper", "Mage Commander"],
    succession: "Magical competency test",
    powerStructure: "Wizard hierarchy",
  },
  "Military Junta": {
    ruler: "Military Commander",
    courtPositions: ["General Staff", "Colonel Council", "Quartermaster", "Military Judge"],
    succession: "Strongest successor",
    powerStructure: "Military command structure",
  },
  "Republic": {
    ruler: "Elected President",
    courtPositions: ["Senate", "Congress", "Chief Justice", "Secretary of State"],
    succession: "Democratic election",
    powerStructure: "Represented by elected officials",
  },
};

// ─── MILITARY SYSTEM ────────────────────────────────────────────────────────

const UNIT_TYPES = [
  "infantry", "archers", "cavalry", "siege engineers", "battle mages", "holy priests",
  "scouts and rangers", "assassins and infiltrators", "berserkers", "paladins", "dragon riders",
  "golem corps", "necromancers", "war beasts", "naval fleet", "flying units", "undead legions",
  "construct army", "elemental corps", "guerrilla fighters", "pike formation", "crossbowmen",
  "heavy cavalry", "light cavalry", "chariots", "war elephants", "griffon riders", "wyvern corps",
  "ballista crew", "trebuchet team", "wizard conclave", "divine retribution squad"
];

function generateArmy(rng, kingdom) {
  const army = {
    name: kingdom.name + " Armed Forces",
    kingdom: kingdom.name,
    units: [],
    commander: generateNPC(rng, { name: genNPCName(rng), role: "general" }),
    strength: kingdom.militaryStrength,
    totalSize: randInt(5000, kingdom.population / 2, rng),
    morale: pick(["excellent", "good", "neutral", "poor", "terrible"], rng),
    tactics: pick(["aggressive", "defensive", "balanced", "evasive", "overwhelming force"], rng),
    supplyLines: [],
    fortifications: [],
  };

  // Generate units
  const unitCount = randInt(5, 15, rng);
  for (let i = 0; i < unitCount; i++) {
    const unitType = pick(UNIT_TYPES, rng);
    army.units.push({
      type: unitType,
      size: randInt(100, 5000, rng),
      commander: generateNPC(rng, { role: "captain" }),
      morale: army.morale,
      equipment: pick(["basic", "standard", "quality", "excellent", "legendary"], rng),
      experience: pick(["green", "trained", "veteran", "elite"], rng),
    });
  }

  // Supply lines
  for (let i = 0; i < randInt(1, 3, rng); i++) {
    army.supplyLines.push({
      origin: pick([kingdom.name, "allied kingdom", "conquered territory"], rng),
      supplies: pickN(["grain", "weapons", "armor", "horses", "medicine", "ale"], randInt(2, 4, rng), rng),
      reliability: pick(["secure", "maintained", "threatened", "unreliable"], rng),
    });
  }

  // Fortifications
  for (let i = 0; i < randInt(2, 5, rng); i++) {
    army.fortifications.push({
      location: genName(rng, "place"),
      type: pick(["castle", "fortress", "tower", "wall", "barracks"], rng),
      garrison: randInt(50, 500, rng),
      condition: pick(["perfect", "good", "fair", "poor", "ruined"], rng),
    });
  }

  return army;
}

function generateBattle(rng, army1, army2) {
  const total1 = army1.units.reduce((s, u) => s + u.size, 0);
  const total2 = army2.units.reduce((s, u) => s + u.size, 0);

  const advantage1 = army1.morale === "excellent" ? 1.3 : army1.morale === "good" ? 1.15 : army1.morale === "poor" ? 0.85 : 1;
  const advantage2 = army2.morale === "excellent" ? 1.3 : army2.morale === "good" ? 1.15 : army2.morale === "poor" ? 0.85 : 1;

  const strength1 = total1 * advantage1;
  const strength2 = total2 * advantage2;

  const winner = strength1 > strength2 ? army1.kingdom : strength2 > strength1 ? army2.kingdom : "draw";
  const casualties1 = Math.floor(total1 * (strength2 / (strength1 + strength2)) * 0.4);
  const casualties2 = Math.floor(total2 * (strength1 / (strength1 + strength2)) * 0.4);

  return {
    armies: [army1.name, army2.name],
    initiator: pick([army1.name, army2.name], rng),
    location: genName(rng, "place"),
    date: "Year " + Math.floor(2000 + rng() * 30),
    winner,
    casualties: { [army1.kingdom]: casualties1, [army2.kingdom]: casualties2 },
    aftermath: pick(["peace treaty", "bitter retreat", "pyrrhic victory", "unexpected truce", "continued conflict"], rng),
  };
}

// ─── EXPANDED ROAD SYSTEM ───────────────────────────────────────────────────

const ROAD_FEATURES = [
  { type: "wayside inn", name: "Tired Traveler's Rest", traffic: "moderate" },
  { type: "milestone marker", age: "ancient", readability: "worn" },
  { type: "toll gate", operator: "bandit lord", rate: 10 },
  { type: "brigand ambush point", danger: "high", activity: "current" },
  { type: "scenic overlook", view: "spectacular", rest: "recommended" },
  { type: "rest area", amenity: "well and benches", condition: "maintained" },
  { type: "water well", quality: "clean", depth: "deep" },
  { type: "crossroads shrine", deity: "local god", condition: "blessed" },
  { type: "abandoned wagon", cargo: "mysterious", hazard: "possibly trapped" },
  { type: "merchant camp", traders: "active", goods: "varied" },
  { type: "monster nest", creature: "dire wolf pack", threat: "extreme" },
  { type: "ancient signpost", language: "forgotten", meaning: "unclear" },
  { type: "collapsed bridge", river: "uncrossable", workaround: "ford nearby" },
  { type: "monument stone", inscription: "barely legible", era: "pre-cataclysm" },
  { type: "roadside farm", crops: "flourishing", hospitality: "warm" },
  { type: "refugee camp", origins: "war-torn region", condition: "struggling" },
  { type: "beast skull", size: "enormous", age: "recent" },
  { type: "herb garden", growth: "wild", utility: "medicinal" },
  { type: "sacred grove", reverence: "high", access: "restricted" },
  { type: "burned settlement", cause: "unclear", timeline: "recent" },
  { type: "crystal formation", property: "magical aura", extraction: "dangerous" },
  { type: "haunted location", phenomena: "ghosts reported", danger: "moderate" },
  { type: "tracker's stone", meaning: "creature passing indicator", age: "recent" },
  { type: "watchtower ruin", builder: "ancient kingdom", strategic: "high" },
  { type: "hermit shack", occupant: "reclusive mage", visibility: "hidden" },
];

function generateRoadFeatures(rng, road) {
  const features = [];
  const featureCount = Math.min(randInt(3, 8, rng), road.path.length / 15);

  for (let i = 0; i < featureCount; i++) {
    const idx = Math.floor(rng() * road.path.length);
    const pt = road.path[idx];
    const baseFeature = pick(ROAD_FEATURES, rng);

    features.push({
      x: pt.x,
      y: pt.y,
      ...baseFeature,
      distance: Math.floor(idx * road.path.length / 10) + " miles from " + road.from,
    });
  }

  return features;
}

function generateRoadEncounter(rng, road, dangerLevel) {
  const encounterTypes = [
    "merchant caravan",
    "wandering adventurers",
    "bandits and highwaymen",
    "monster attack",
    "natural disaster",
    "mysterious stranger",
    "lost traveler",
    "fleeing refugee",
    "patrol party",
    "wild beast herd",
  ];

  const encounterType = pick(encounterTypes, rng);
  let npcCount, threat;

  if (encounterType === "merchant caravan") {
    npcCount = randInt(3, 8, rng);
    threat = "low";
  } else if (encounterType === "wandering adventurers") {
    npcCount = randInt(2, 5, rng);
    threat = "moderate";
  } else if (encounterType === "bandits and highwaymen") {
    npcCount = randInt(4, 12, rng);
    threat = "high";
  } else if (encounterType === "monster attack") {
    npcCount = 0;
    threat = dangerLevel || "extreme";
  } else {
    npcCount = randInt(1, 3, rng);
    threat = "variable";
  }

  const npcs = [];
  for (let i = 0; i < npcCount; i++) {
    npcs.push(generateNPC(rng, { role: pick(["merchant", "adventurer", "bandit", "guard"], rng) }));
  }

  return {
    type: encounterType,
    threat,
    npcs,
    creatures: encounterType === "monster attack" ? randInt(1, 3, rng) + " " + pick(["dire wolves", "bandits", "undead", "trolls", "wyverns"], rng) : null,
    loot: pick([null, "coins", "goods", "weapons", "magic items", "information"], rng),
    negotiable: threat !== "extreme",
  };
}

// ─── MARITIME SYSTEM ────────────────────────────────────────────────────────

const SHIP_TYPES = [
  { name: "Merchant Galleon", cargo: 500, crew: 80, speed: "moderate", cost: 50000 },
  { name: "Warship", cargo: 200, crew: 200, speed: "fast", cost: 100000 },
  { name: "Pirate Vessel", cargo: 300, crew: 120, speed: "very fast", cost: 40000 },
  { name: "Fishing Boat", cargo: 50, crew: 6, speed: "slow", cost: 5000 },
  { name: "Elven Swan Ship", cargo: 250, crew: 40, speed: "very fast", cost: 75000 },
  { name: "Dwarven Ironclad", cargo: 400, crew: 100, speed: "very slow", cost: 150000 },
  { name: "Ghost Ship", cargo: 200, crew: "spectral", speed: "fast", cost: "priceless" },
  { name: "Dragon Boat", cargo: 600, crew: 150, speed: "very fast", cost: "impossible" },
  { name: "Trireme", cargo: 150, crew: 170, speed: "fast", cost: 35000 },
  { name: "Caravel", cargo: 200, crew: 50, speed: "fast", cost: 30000 },
  { name: "Longship", cargo: 100, crew: 60, speed: "very fast", cost: 25000 },
  { name: "Dhow", cargo: 80, crew: 20, speed: "moderate", cost: 8000 },
  { name: "Junk", cargo: 300, crew: 40, speed: "moderate", cost: 35000 },
  { name: "Catamaran", cargo: 150, crew: 30, speed: "very fast", cost: 40000 },
  { name: "Submarine", cargo: 50, crew: 15, speed: "slow underwater", cost: "experimental" },
  { name: "Flying Ship", cargo: 100, crew: 30, speed: "variable", cost: "magical" },
  { name: "Planar Vessel", cargo: 200, crew: 40, speed: "planar", cost: "arcane" },
  { name: "Kraken Hunter", cargo: 300, crew: 90, speed: "very fast", cost: 120000 },
  { name: "Slave Galley", cargo: 200, crew: 180, speed: "fast", cost: 60000 },
  { name: "Royal Flagship", cargo: 400, crew: 300, speed: "moderate", cost: "priceless" },
];

function generateShip(rng, type) {
  const shipType = SHIP_TYPES.find(s => s.name === type) || pick(SHIP_TYPES, rng);
  const ship = {
    ...shipType,
    name: genName(rng, "boat"),
    captain: generateNPC(rng, { role: "captain" }),
    crew: [],
    condition: pick(["pristine", "seaworthy", "weathered", "damaged", "barely afloat"], rng),
    age: randInt(5, 50, rng),
    cargo: [],
  };

  // Generate crew
  for (let i = 0; i < Math.min(shipType.crew, randInt(Math.floor(shipType.crew * 0.5), shipType.crew, rng)); i++) {
    const roles = ["first mate", "bosun", "navigator", "cook", "quartermaster", "cabin boy", "sailor", "gunner"];
    ship.crew.push(generateNPC(rng, { role: pick(roles, rng) }));
  }

  return ship;
}

function generateSeaRoute(rng, from, to) {
  const distance = dist(from.x, from.y, to.x, to.y);
  const waypoints = [];
  const steps = Math.ceil(distance / 20);

  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    waypoints.push({
      x: Math.round(from.x + (to.x - from.x) * t),
      y: Math.round(from.y + (to.y - from.y) * t),
      name: genName(rng, "island"),
      type: pick(["island", "reef", "current", "storm zone", "safe harbor"], rng),
    });
  }

  return {
    from: from.name,
    to: to.name,
    distance: Math.round(distance) + " leagues",
    duration: Math.round(distance / 5) + " days",
    waypoints,
    hazards: pickN([
      "sea monsters", "pirates", "storms", "uncharted reefs", "magical anomalies",
      "whirlpools", "sea hags", "naval patrols", "cursed waters", "ghost ships"
    ], randInt(1, 3, rng), rng),
    currents: pick(["favorable", "neutral", "opposing"], rng),
    season: pick(["spring", "summer", "fall", "winter"], rng),
    safest: rng() > 0.5,
  };
}

function generatePort(rng, settlement) {
  const port = {
    settlement: settlement.name,
    capacity: randInt(10, 100, rng),
    ships: [],
    harborMaster: generateNPC(rng, { role: "administrator" }),
    docks: randInt(2, 10, rng),
    shipwright: generateNPC(rng, { role: "craftsman" }),
    customs: pick(["strict", "moderate", "lax", "corrupt"], rng),
  };

  // Generate docked ships
  for (let i = 0; i < randInt(3, 15, rng); i++) {
    port.ships.push(generateShip(rng, pick(SHIP_TYPES.map(st => st.name), rng)));
  }

  // Black market
  port.blackMarket = {
    exists: rng() > 0.4,
    goods: port.blackMarket?.exists ? pickN([
      "stolen artifacts", "contraband weapons", "exotic slaves", "forbidden knowledge",
      "cursed items", "monster parts", "poisons", "forged documents", "smuggled gems"
    ], randInt(2, 5, rng), rng) : [],
    contact: port.blackMarket?.exists ? genNPCName(rng) : null,
    danger: port.blackMarket?.exists ? pick(["low", "moderate", "high"], rng) : null,
  };

  return port;
}

const SEA_MONSTERS = [
  { name: "Kraken", cr: 23, size: "colossal", behavior: "aggressive", territory: "deep water", treasure: "legendary" },
  { name: "Leviathan", cr: 24, size: "colossal", behavior: "territorial", territory: "abyss", treasure: "cursed" },
  { name: "Giant Octopus", cr: 12, size: "gargantuan", behavior: "intelligent", territory: "coastal", treasure: "good" },
  { name: "Sea Serpent", cr: 18, size: "gargantuan", behavior: "aggressive", territory: "open ocean", treasure: "excellent" },
  { name: "Sahuagin War Band", cr: 5, size: "small group", behavior: "organized", territory: "coral", treasure: "moderate" },
  { name: "Giant Shark", cr: 15, size: "huge", behavior: "predatory", territory: "warm waters", treasure: "none" },
  { name: "Dragon Turtle", cr: 17, size: "gargantuan", behavior: "proud", territory: "warm seas", treasure: "legendary" },
  { name: "Ghost Ship Crew", cr: 14, size: "variable", behavior: "haunted", territory: "cursed waters", treasure: "valuable" },
  { name: "Merrow Tribe", cr: 3, size: "group", behavior: "raiders", territory: "coastal", treasure: "fair" },
  { name: "Sea Hag", cr: 14, size: "medium", behavior: "manipulative", territory: "fog banks", treasure: "arcane" },
  { name: "Water Elemental", cr: 5, size: "huge", behavior: "chaotic", territory: "storms", treasure: "none" },
  { name: "Morkoth", cr: 12, size: "large", behavior: "magical", territory: "ruins", treasure: "arcane" },
  { name: "Hydra", cr: 8, size: "huge", behavior: "savage", territory: "bays", treasure: "good" },
  { name: "Drowned Souls", cr: 2, size: "group", behavior: "restless", territory: "shipwrecks", treasure: "scattered" },
  { name: "Aboleth", cr: 10, size: "huge", behavior: "alien", territory: "deep water", treasure: "unique" },
  { name: "Giant Jellyfish", cr: 6, size: "huge", behavior: "mindless", territory: "warm seas", treasure: "none" },
  { name: "Pirate Fleet", cr: "variable", size: "large", behavior: "mercenary", territory: "trade routes", treasure: "significant" },
  { name: "Siren Singers", cr: 8, size: "small group", behavior: "deceptive", territory: "reefs", treasure: "alluring" },
  { name: "Sunken Temple Guardian", cr: 13, size: "large", behavior: "defensive", territory: "ruins", treasure: "holy" },
  { name: "Plesiosaur", cr: 11, size: "huge", behavior: "territorial", territory: "deep lakes", treasure: "none" },
];

// ─── NATURAL DISASTER SYSTEM ────────────────────────────────────────────────

function generateNaturalDisaster(rng, region) {
  const types = [
    { name: "Earthquake", scope: "regional", duration: "days", casualties: "10-50%", recovery: "years", effects: ["collapsed buildings", "fissures", "dam breaks"] },
    { name: "Volcanic Eruption", scope: "continental", duration: "weeks", casualties: "30-70%", recovery: "decades", effects: ["lava flows", "ash cloud", "earthquakes"] },
    { name: "Tsunami", scope: "coastal", duration: "hours", casualties: "20-60%", recovery: "months", effects: ["flooding", "destroyed ports", "ship debris"] },
    { name: "Plague", scope: "widespread", duration: "years", casualties: "5-40%", recovery: "years", effects: ["population loss", "trade disruption", "social collapse"] },
    { name: "Magical Anomaly", scope: "local", duration: "variable", casualties: "variable", recovery: "unknown", effects: ["wild magic", "transformed creatures", "dimensional rifts"] },
    { name: "Dragon Attack", scope: "local", duration: "days", casualties: "5-20%", recovery: "months", effects: ["burned buildings", "terrorized population", "treasure hoarded"] },
    { name: "Undead Rising", scope: "regional", duration: "ongoing", casualties: "variable", recovery: "years", effects: ["necromantic blight", "graveyards empty", "villages haunted"] },
    { name: "Fey Incursion", scope: "local", duration: "weeks", casualties: "5-15%", recovery: "months", effects: ["reality warped", "time distortion", "magical creatures"] },
    { name: "Demonic Rift", scope: "local", duration: "variable", casualties: "20-40%", recovery: "unknown", effects: ["infernal creatures", "corruption spread", "chaos reigns"] },
    { name: "Wild Magic Storm", scope: "regional", duration: "days", casualties: "10-25%", recovery: "weeks", effects: ["unpredictable magic", "transmuted matter", "spell effects random"] },
    { name: "Forest Fire", scope: "local", duration: "weeks", casualties: "5-15%", recovery: "decades", effects: ["habitat loss", "animal migration", "smoke clouds"] },
    { name: "Massive Flood", scope: "regional", duration: "weeks", casualties: "15-35%", recovery: "months", effects: ["crops destroyed", "villages submerged", "bridges washed out"] },
    { name: "Severe Drought", scope: "widespread", duration: "years", casualties: "10-30%", recovery: "years", effects: ["crop failure", "well drying", "famine"] },
    { name: "Blizzard", scope: "regional", duration: "weeks", casualties: "5-15%", recovery: "months", effects: ["roads blocked", "food shortage", "exposure deaths"] },
    { name: "Meteor Impact", scope: "continental", duration: "instantaneous", casualties: "40-80%", recovery: "decades", effects: ["crater formation", "dust cloud", "climate shift"] },
    { name: "Sinkhole Formation", scope: "local", duration: "hours", casualties: "5-10%", recovery: "weeks", effects: ["buildings collapse", "roads destroyed", "water drainage"] },
    { name: "Landslide", scope: "local", duration: "hours", casualties: "10-20%", recovery: "months", effects: ["villages buried", "roads cut off", "dams blocked"] },
    { name: "Avalanche", scope: "local", duration: "hours", casualties: "5-15%", recovery: "weeks", effects: ["settlements buried", "supplies cut off", "animals fled"] },
    { name: "Whirlpool Formation", scope: "local", duration: "ongoing", casualties: "ships lost", recovery: "unknown", effects: ["ships sunk", "trade disrupted", "navigation hazard"] },
    { name: "Haunting", scope: "local", duration: "ongoing", casualties: "psychological", recovery: "years", effects: ["ghostly phenomena", "terror spreads", "sanctification needed"] },
  ];

  const type = pick(types, rng);
  const year = Math.floor(1990 + rng() * 30);

  return {
    ...type,
    year,
    severity: pick(["minor", "moderate", "severe", "catastrophic"], rng),
    warning: pick(["no warning", "few days", "weeks", "months"], rng),
    permanentEffects: pickN([
      "map changed", "settlement relocated", "trade routes altered", "new hazard zone",
      "magical properties shifted", "biome transformation", "population decimated", "leadership changed"
    ], randInt(1, 3, rng), rng),
  };
}
// [deduplicated: TRAP_TYPES - defined earlier]

function generateDungeonFloors(rng, poi) {
  const floors = [];
  const floorCount = poi.floors || randInt(2, 8, rng);

  for (let f = 0; f < floorCount; f++) {
    const floor = {
      level: f + 1,
      name: genName(rng, "place"),
      rooms: [],
      depth: f === 0 ? "entrance" : f === floorCount - 1 ? "deepest chamber" : "mid-level",
    };

    const roomCount = randInt(4, 12, rng);
    for (let r = 0; r < roomCount; r++) {
      const room = {
        name: pick([
          "grand hall", "throne room", "treasury", "armory", "library", "laboratory",
          "bedroom", "ritual chamber", "torture room", "prison", "garden", "kitchen",
          "throne room", "temple", "vault", "tomb", "archive", "workshop", "meditation chamber",
          "creature lair", "altar", "mirror chamber", "crystal room", "shadow sanctum"
        ], rng),
        description: genName(rng, "place") + " filled with " + pick(["ancient artifacts", "strange symbols", "skeletal remains", "glowing crystals", "magical auras"], rng),
        contents: pickN([
          "treasure hoard", "dangerous creatures", "magical items", "ancient texts", "cursed objects",
          "trapped passages", "hidden chambers", "glowing runes", "pools of liquid", "statues"
        ], randInt(1, 4, rng), rng),
        monsters: randInt(0, 4, rng) > 0 ? {
          type: pick(["undead", "demons", "elementals", "beasts", "humanoids", "aberrations"], rng),
          count: randInt(1, 6, rng),
          cr: randInt(1, 10, rng),
        } : null,
        traps: rng() > 0.4 ? [pick(TRAP_TYPES, rng), randInt(0, 2, rng) > 0 ? pick(TRAP_TYPES, rng) : null].filter(t => t) : [],
        treasure: rng() > 0.5 ? {
          gold: randInt(100, 5000, rng),
          items: pickN([
            "magic sword", "healing potion", "spell scroll", "ring of power", "cursed amulet",
            "gem", "ancient coin", "strange artifact", "legendary weapon", "holy relic"
          ], randInt(1, 3, rng), rng),
        } : null,
        connections: [],
        lighting: pick(["bright sunlight", "torch sconces", "magical glow", "bioluminescent", "complete darkness"], rng),
        atmosphere: pick(["pristine", "aged", "decayed", "magical", "corrupted", "holy", "cursed"], rng),
      };
      floor.rooms.push(room);
    }

    // Connect rooms
    for (let i = 0; i < floor.rooms.length - 1; i++) {
      floor.rooms[i].connections.push(floor.rooms[i + 1].name);
    }

    floors.push(floor);
  }

  return floors;
}
// [deduplicated: generatePuzzle - defined earlier]

// ─── WILDERNESS EXPLORATION ─────────────────────────────────────────────────

function generateWildernessHex(rng, biome, x, y) {
  const hex = {
    biome,
    x, y,
    terrain: pick([
      "plain", "hill", "forest", "mountain", "desert", "swamp", "river", "lake", "grassland"
    ], rng),
    features: [],
    encounters: [],
    foragingResults: [],
    weather: pick(["clear", "cloudy", "rainy", "stormy", "snow", "fog"], rng),
    shelterAvailability: pick(["none", "cave", "trees", "rock formation", "ruins", "structure"], rng),
    waterSources: rng() > 0.3 ? ["stream", "lake", "spring", "well", "river"] : [],
    navigationDifficulty: randInt(8, 18, rng),
    notableSights: pickN([
      "ancient ruins", "strange monument", "unusual rock formation", "crystal cave",
      "magical aura", "creature lair", "burned settlement", "abandoned mine", "ghost lights"
    ], randInt(0, 2, rng), rng),
    ambientSounds: pickN([
      "wind howling", "birds chirping", "insects buzzing", "water flowing", "distant thunder"
    ], randInt(1, 3, rng), rng),
    smells: pickN([
      "pine forest", "fresh water", "wet earth", "wildflowers", "smoke", "decay", "sulfur"
    ], randInt(1, 2, rng), rng),
  };

  // Generate terrain features by biome
  if (biome === "forest") {
    hex.features = pickN([
      "dense thicket", "clearing", "stream", "ancient tree", "cave entrance", "dead trees",
      "berry bushes", "mushroom ring", "animal trail", "hunter's shelter", "abandoned camp"
    ], randInt(2, 4, rng), rng);
  } else if (biome === "mountain") {
    hex.features = pickN([
      "cliff face", "pass", "cave", "peak", "avalanche zone", "mine entrance", "waterfall",
      "rocky outcrop", "narrow path", "shelter cave", "goat trail"
    ], randInt(2, 4, rng), rng);
  } else if (biome === "desert") {
    hex.features = pickN([
      "sand dune", "rocky outcrop", "oasis", "ruin", "cave", "dried riverbed", "salt flat",
      "dune field", "canyon", "buried structure", "mirage point"
    ], randInt(2, 4, rng), rng);
  } else if (biome === "swamp") {
    hex.features = pickN([
      "bog", "pool of water", "hummock", "dense vegetation", "rotting logs", "isolated island",
      "mangrove", "quicksand", "creature nest", "sunken ruin", "floating island"
    ], randInt(2, 4, rng), rng);
  } else {
    hex.features = pickN([
      "hill", "stream", "grove", "field", "clearing", "path", "rocks", "structure", "sign", "well"
    ], randInt(1, 3, rng), rng);
  }

  return hex;
}

function generateForagingTable(rng, biome, season) {
  const foragingResults = [];
  const items = biome === "forest" ? ["berries", "mushrooms", "nuts", "roots", "bark", "herbs", "wild vegetables"]
              : biome === "mountain" ? ["lichen", "edible plants", "mountain herbs", "mineral water", "crystal formations"]
              : biome === "desert" ? ["dates", "salt", "cacti fruit", "insects", "desert roots"]
              : biome === "swamp" ? ["water plants", "frogs", "fish", "herbs", "water snails"]
              : ["grains", "vegetables", "fruits", "herbs", "roots", "bark"];

  for (let i = 0; i < randInt(2, 5, rng); i++) {
    foragingResults.push({
      item: pick(items, rng),
      quantity: randInt(1, 20, rng),
      condition: pick(["fresh", "dried", "powdered", "preserved"], rng),
      dc: randInt(8, 16, rng),
      rarity: pick(["common", "uncommon", "rare", "very rare"], rng),
    });
  }

  return foragingResults;
}

function generateCampsite(rng, terrain) {
  return {
    terrain,
    defensibility: pick(["poor", "fair", "good", "excellent"], rng),
    comfort: pick(["terrible", "poor", "moderate", "good", "excellent"], rng),
    resources: pickN([
      "firewood", "fresh water", "shelter", "game", "edible plants", "dry ground", "hidden location"
    ], randInt(1, 4, rng), rng),
    hazards: pickN([
      "predators", "weather exposure", "flood risk", "avalanche risk", "monster lair nearby", "haunting",
      "magical anomaly", "unstable ground", "toxic fumes", "extreme temperature"
    ], randInt(0, 3, rng), rng),
    disturbances: rng() > 0.6 ? pick([
      "tracks indicate recent visitors", "signs of struggle", "bones scattered", "strange markings",
      "abandoned belongings", "recent fire", "blood trail"
    ], rng) : null,
    capacity: randInt(2, 20, rng),
    secretDC: randInt(8, 16, rng),
  };
}

// ─── MIGRATION & POPULATION ─────────────────────────────────────────────────

function generatePopulationFlow(rng, settlements, years) {
  const flows = [];

  for (let year = 0; year < years; year++) {
    if (rng() > 0.6) continue;

    const from = pick(settlements, rng);
    const to = pick(settlements.filter(s => s !== from), rng);
    const cause = pick(MIGRATION_CAUSES, rng);
    const population = randInt(50, Math.min(from.population / 10, 2000), rng);

    flows.push({
      year: 2000 + year,
      from: from.name,
      to: to.name,
      population,
      cause,
      outcome: pick(["successful settlement", "partial acceptance", "rejection", "conflict", "integration"], rng),
    });
  }

  return flows;
}

const MIGRATION_CAUSES = [
  "war in home region", "famine", "economic opportunity", "religious pilgrimage",
  "magical anomaly", "natural disaster", "gold rush", "plague", "persecution",
  "forced exile", "seeking refuge", "adventure", "family reunion", "mysterious call",
  "prophecy fulfillment", "contract work", "scholarly pursuit", "trade opportunity",
  "slave trade escape", "diplomatic mission", "mercenary employment"
];

function generateRefugeeEvent(rng, cause, origin, destination) {
  return {
    cause,
    originSettlement: origin.name,
    destinationSettlement: destination.name,
    populationArriving: randInt(100, 2000, rng),
    condition: pick(["desperate", "organized", "orderly", "panicked", "resourced"], rng),
    reception: pick(["welcoming", "neutral", "suspicious", "hostile", "mixed"], rng),
    integration: pick(["smooth", "challenging", "conflict", "segregation", "unknown"], rng),
    longTermOutcome: pick(["successful assimilation", "maintained separate culture", "ongoing tension", "unexpected advantages", "slow decline"], rng),
  };
}

function generateCensus(rng, settlement) {
  const census = {
    settlement: settlement.name,
    totalPopulation: settlement.population,
    demographics: {
      byRace: {
        human: Math.floor(settlement.population * (0.3 + rng() * 0.4)),
        elf: Math.floor(settlement.population * (0.1 + rng() * 0.15)),
        dwarf: Math.floor(settlement.population * (0.05 + rng() * 0.15)),
        gnome: Math.floor(settlement.population * (0.03 + rng() * 0.08)),
        halfling: Math.floor(settlement.population * (0.02 + rng() * 0.08)),
        half_orc: Math.floor(settlement.population * (0.02 + rng() * 0.08)),
        half_elf: Math.floor(settlement.population * (0.02 + rng() * 0.08)),
        dragonborn: Math.floor(settlement.population * (0.01 + rng() * 0.05)),
        tiefling: Math.floor(settlement.population * (0.01 + rng() * 0.03)),
        other: Math.floor(settlement.population * (0.01 + rng() * 0.05)),
      },
      byAge: {
        children: Math.floor(settlement.population * 0.25),
        young_adults: Math.floor(settlement.population * 0.25),
        middle_aged: Math.floor(settlement.population * 0.30),
        elderly: Math.floor(settlement.population * 0.20),
      },
      byOccupation: {
        farmers: Math.floor(settlement.population * (0.2 + rng() * 0.15)),
        craftspeople: Math.floor(settlement.population * (0.1 + rng() * 0.1)),
        merchants: Math.floor(settlement.population * (0.05 + rng() * 0.08)),
        warriors: Math.floor(settlement.population * (0.03 + rng() * 0.08)),
        priests: Math.floor(settlement.population * (0.02 + rng() * 0.05)),
        wizards: Math.floor(settlement.population * (0.01 + rng() * 0.03)),
        nobility: Math.floor(settlement.population * (0.01 + rng() * 0.05)),
        servants: Math.floor(settlement.population * (0.1 + rng() * 0.1)),
        unemployed: Math.floor(settlement.population * (0.05 + rng() * 0.15)),
      },
    },
    growthRate: (rng() - 0.5) * 10 + " percent per year",
    deathRate: randInt(2, 15, rng) + " per 1000 per year",
    birthRate: randInt(30, 50, rng) + " per 1000 per year",
    lifeExpectancy: randInt(35, 75, rng),
    healthStatus: pick(["excellent", "good", "fair", "poor", "epidemic"], rng),
    majorDiseases: pickN([
      "plague", "fever", "cholera", "dysentery", "smallpox", "tuberculosis",
      "influenza", "leprosy", "madness curse", "lycanthropy"
    ], randInt(0, 2, rng), rng),
  };

  return census;
}

// ─── GOVERNMENT DETAILS (expanded)

function generateGovernmentDetails(rng, governmentType) {
  const details = GOVERNMENT_DETAILS[governmentType] || GOVERNMENT_DETAILS["Republic"];
  return {
    ...details,
    courtIntrigues: pickN([
      "succession dispute", "hidden faction", "corruption scandal", "secret alliance",
      "power struggle", "assassination plot", "scandal cover-up", "magical influence"
    ], randInt(1, 3, rng), rng),
    recentDecisions: pickN([
      "tax increase", "military mobilization", "treaty signed", "law enacted",
      "trade embargo", "alliance formed", "infrastructure project", "religious decree"
    ], randInt(2, 4, rng), rng),
    stability: pick(["rock solid", "stable", "balanced", "fragile", "crumbling"], rng),
  };
}
// [deduplicated: genKingdomName - defined earlier]
// [deduplicated: DISTRICT_TYPES - defined earlier]
// [deduplicated: SHOP_TYPES - defined earlier]
// [deduplicated: generateDistricts - defined earlier]
// [deduplicated: generateShop - defined earlier]

// ────────────────────────────────────────────────────────────────
// ─── 2. DETAILED TAVERN GENERATION (~400 lines) ─────────────────
// ────────────────────────────────────────────────────────────────

const TAVERN_MENU = [
  { name: "Bread and Cheese", description: "Simple peasant fare", price: 2 },
  { name: "Stew", description: "Hot, hearty, and filling", price: 3 },
  { name: "Roasted Chicken", description: "Golden and perfectly seasoned", price: 8 },
  { name: "Beef Pie", description: "Meat encased in a flaky pastry", price: 6 },
  { name: "Fish Filet", description: "Fresh catch from local waters", price: 7 },
  { name: "Roasted Mutton", description: "Tender and juicy", price: 5 },
  { name: "Rabbit Stew", description: "Game hunter's favorite", price: 6 },
  { name: "Pork Chops", description: "Savory and filling", price: 5 },
  { name: "Venison Haunch", description: "Noble game meat", price: 12 },
  { name: "Wild Boar Roast", description: "Rich and intense flavor", price: 10 },
  { name: "Bread Pudding", description: "Sweet and comforting", price: 3 },
  { name: "Apple Tart", description: "Crispy pastry and sweet apples", price: 4 },
  { name: "Cheese and Fruit Plate", description: "Variety of local selections", price: 5 },
  { name: "Honey Cakes", description: "Sweet and sticky", price: 2 },
  { name: "Vegetable Medley", description: "Seasonal fresh vegetables", price: 3 },
  { name: "Mushroom Pie", description: "Earthy and savory", price: 4 },
  { name: "Sausage Links", description: "Spiced and smoky", price: 4 },
  { name: "Smoked Fish", description: "Tangy and preserved", price: 5 },
  { name: "Pickled Vegetables", description: "Sour and crunchy", price: 2 },
  { name: "Grain Porridge", description: "Warm and filling", price: 1 },
  { name: "Ale", description: "Local brew, slightly bitter", price: 4 },
  { name: "Lager", description: "Crisp and refreshing", price: 4 },
  { name: "Stout", description: "Dark and robust", price: 5 },
  { name: "Mead", description: "Honey-sweetened fermented drink", price: 6 },
  { name: "Wine", description: "Red or white, local vintage", price: 8 },
  { name: "Spirits", description: "Strong distilled liquor", price: 10 },
  { name: "Cider", description: "Sweet or dry apple drink", price: 3 },
  { name: "Mulled Wine", description: "Warm and spiced", price: 5 },
  { name: "Cordial", description: "Sweet fruity drink", price: 2 },
  { name: "Freshly Squeezed Juice", description: "From local fruits", price: 2 },
  { name: "Tea", description: "Herbal or regular, hot and soothing", price: 2 },
  { name: "Coffee", description: "Bitter, dark, energizing", price: 3 },
  { name: "Milk", description: "Fresh and cold", price: 1 },
  { name: "Water", description: "Clean and refreshing", price: 1 },
  { name: "Buttermilk", description: "Tangy dairy drink", price: 1 },
  { name: "Mead with Spices", description: "Enhanced honey drink", price: 7 },
  { name: "Specialty Cocktail", description: "Bartender's secret creation", price: 12 },
  { name: "House Wine", description: "Daily selection", price: 5 },
  { name: "Premium Spirits", description: "Rare and expensive", price: 20 },
  { name: "Exotic Liqueur", description: "Imported from distant lands", price: 15 }
];

const TAVERN_ENTERTAINMENT = [
  "bard playing lute", "lively dancing", "darts competition", "card games",
  "dice games", "fortune teller", "acrobat performance", "juggler",
  "storyteller spinning tales", "musicians playing", "dancing girls", "wrestling match",
  "drinking contest", "magic tricks", "puppet show", "comedy act"
];

const TAVERN_ACTIVITIES = [
  "smuggling operation basement", "thieves' guild front", "resistance meeting place",
  "love affair between regulars", "legendary treasure map", "mysterious artifact",
  "curse haunting the establishment", "ghost of previous owner",
  "secret passage to castle", "werewolf gathering place", "vampire nest",
  "wizard's apprenticeship hideout", "cult recruitment center", "black market operation"
];

function generateDetailedTavern(rng, settlement) {
  const tavernNames = [
    "The Prancing Pony", "The Leaping Dragon", "The Silent Swan",
    "The Golden Griffin", "The Red Dragon", "The Wandering Archer",
    "The Crown and Anchor", "The Merry Widow", "The Drunken Dwarf",
    "The White Hart", "The Purple Griffin", "The Royal Oak",
    "The Three Barrels", "The Ivy Leaf", "The Blacksmith's Anvil",
    "The Wyvern's Claw", "The Broken Wheel", "The Steadfast Knight",
    "The Silver Sabre", "The Roaring Lion"
  ];

  const tavernName = pick(tavernNames, rng);
  const barkeepNPC = generateNPC(rng, "tavern keeper");

  const roomTypes = [
    { name: "Common Room", quality: "basic", price: 5, description: "Shared sleeping space with straw bunks" },
    { name: "Private Room", quality: "comfortable", price: 15, description: "Single room with bed and basic furniture" },
    { name: "Deluxe Suite", quality: "luxurious", price: 30, description: "Fine room with quality furnishings and fireplace" },
    { name: "Stable Space", quality: "functional", price: 3, description: "Safe stabling for horse or beast" }
  ];

  const rumors = [
    "Adventurers say there's treasure in the nearby ruins",
    "A merchant prince was murdered here last month",
    "The owner's daughter has gone missing",
    "Strange noises come from the cellar at night",
    "A famous criminal hideaway is hidden somewhere nearby",
    "An ancient artifact was found in the basement",
    "The innkeeper pays protection money to local gangs",
    "A curse affects anyone who orders the stew",
    "The tavern is built on a graveyard",
    "Werewolves gather here on full moons",
    "A secret tunnel connects to the castle",
    "The owner is secretly nobility in hiding",
    "Spies use this location for clandestine meetings",
    "A legendary sword hangs above the fireplace",
    "Musicians here are actually thieves casing targets",
    "The tavern keeper can arrange anything for the right price",
    "Dark magic permeates the oldest part of the building",
    "The owner is slowly poisoning a rival",
    "A ghost haunts the upper floors",
    "Thieves' guild runs operations from the basement"
  ];

  const regulars = [];
  for (let i = 0; i < randInt(3, 5, rng); i++) {
    regulars.push({
      npc: generateNPC(rng, "tavern regular"),
      favoritedrink: pick(TAVERN_MENU.slice(20, 30), rng).name,
      quirk: pick([
        "always sits in same corner", "tells wild stories", "plays cards obsessively",
        "drinks alone and silent", "flirts with patrons", "starts fights when drunk",
        "sleeps at the bar", "hoards gold coins", "searches for lost love"
      ], rng)
    });
  }

  return {
    name: tavernName,
    description: pick([
      "A warm, welcoming establishment with roaring fireplace",
      "A rowdy, boisterous place full of adventurers",
      "An elegant tavern catering to nobility",
      "A dingy, smoke-filled hole-in-the-wall",
      "A cozy corner tavern in the merchant district"
    ], rng),
    owner: barkeepNPC,
    menu: TAVERN_MENU,
    rooms: roomTypes,
    entertainers: pickN(TAVERN_ENTERTAINMENT, randInt(2, 4, rng), rng),
    entertainment: pick(TAVERN_ENTERTAINMENT, rng),
    rumors: pickN(rumors, randInt(2, 4, rng), rng),
    regulars,
    hasSecretBasement: rng() > 0.6,
    secretBasementDescription: pick([
      "Thieves' guild operation center",
      "Underground fighting ring",
      "Smuggling operation",
      "Hidden treasure chamber",
      "Torture chamber",
      "Alchemy laboratory",
      "Cult gathering place",
      "Illegal gambling den"
    ], rng),
    backRoomActivity: pick([
      "high-stakes card games", "black market dealings", "assassin meetings",
      "thief guild planning", "resistance coordination", "magical research",
      "treasure map trading", "slave trading", "drug dealing"
    ], rng),
    atmosphereDescription: pick([
      "Heavy with pipe smoke and loud laughter",
      "Intimate and candlelit, encouraging quiet conversation",
      "Chaotic with music, dancing, and shouting",
      "Tense and quiet, patrons eyeing each other warily",
      "Warm and friendly, everyone seems to know each other"
    ], rng),
    notableFeature: pick([
      "A legendary sword hung above the fireplace",
      "Ancient tapestries depicting historical battles",
      "A haunted portrait that follows you with its eyes",
      "A massive bar carved from a single tree",
      "A well in the center of the main room",
      "A stage for performances",
      "A collection of strange artifacts",
      "Stained glass windows depicting legendary heroes"
    ], rng),
    priceRange: [2, 20],
    capacity: randInt(40, 150, rng)
  };
}
// [deduplicated: SHIP_TYPES - defined earlier]
// [deduplicated: SEA_MONSTERS - defined earlier]
// [deduplicated: generateShip - defined earlier]
// [deduplicated: generatePort - defined earlier]
// [deduplicated: generateSeaRoute - defined earlier]
// [deduplicated: UNIT_TYPES - defined earlier]
// [deduplicated: generateArmy - defined earlier]
// [deduplicated: generateBattle - defined earlier]
// [deduplicated: DIPLOMATIC_ACTIONS - defined earlier]

const COURT_POSITIONS = [
  "Chancellor", "Spymaster", "Court Wizard", "Grand Marshal", "High Priest",
  "Master of Coin", "Lord of Ships", "Warden of the North", "Warden of the South",
  "Royal Advisor", "Court Jester", "Ambassador", "Diplomat", "Justice Minister",
  "Royal Physician", "Court Historian", "Royal Architect", "Master of Ceremonies",
  "Keeper of Seals", "Royal Cartographer", "Master of the Hunt", "Tournament Master",
  "Royal Apothecary", "Siege Master", "Admiral", "General", "Knight Commander",
  "Magical Advisor", "Poisoner's Master", "Keeper of Dungeons"
];
// [deduplicated: generateDiplomaticEvent - defined earlier]

function simulatePoliticalHistory(rng, kingdoms, years) {
  const events = [];

  for (let year = 0; year < years; year++) {
    const k1 = pick(kingdoms, rng);
    let k2 = pick(kingdoms, rng);
    while (k2 === k1 && kingdoms.length > 1) k2 = pick(kingdoms, rng);

    if (rng() > 0.7) {
      events.push({
        year: 1000 + year,
        event: generateDiplomaticEvent(rng, k1, k2),
        importance: pick(["minor", "significant", "major"], rng)
      });
    }
  }

  return {
    kingdoms: kingdoms.map(k => k.name || k),
    years,
    events,
    majorTurningPoints: events.filter(e => e.importance === "major")
  };
}
// [deduplicated: DISASTER_TYPES - defined earlier]
// [deduplicated: generateDisaster - defined earlier]

// ────────────────────────────────────────────────────────────────
// ─── 7. WILDERNESS HEXCRAWL (~400 lines) ────────────────────────
// ────────────────────────────────────────────────────────────────

const TERRAIN_FEATURES_BY_BIOME = {
  forest: [
    "dense woods", "ancient trees", "hidden clearing", "moss-covered logs",
    "crystal spring", "deer trail", "mushroom ring", "berry bushes",
    "fallen giant tree", "tree home settlement", "hunting ground", "sacred grove",
    "dangerous predator lair", "abandoned hut", "smuggler's cache", "merchant's cairn"
  ],
  mountain: [
    "rocky peak", "narrow pass", "avalanche danger", "mountain goat trail",
    "cave mouth", "mining operation", "dwarf settlement", "snow field",
    "eagle nest", "cliff face", "alpine meadow", "glacial lake",
    "loose rocks", "goat skull cairn", "hidden refuge", "treasure trove location"
  ],
  plains: [
    "grassland", "wildflower field", "river crossing", "nomadic camp",
    "ancient ruins", "standing stones", "animal herd", "buffalo wallow",
    "farming community", "caravan route", "windmill", "lightning-struck tree",
    "tribe camp", "burial mound", "abandoned well", "hidden settlement"
  ],
  desert: [
    "sand dunes", "dry riverbed", "oasis", "ancient temple",
    "ghost town", "scorched rocks", "caravan route", "salt flat",
    "nomad camp", "buried treasure site", "lizard colony", "mirage location",
    "hot spring", "palm grove", "sphinx statue", "curse marker"
  ],
  swamp: [
    "murky water", "cypress grove", "floating island", "bog",
    "hermit hut", "monster nest", "will-o-wisps", "giant reptile",
    "quicksand", "peat deposit", "witch's hut", "decomposing corpse",
    "ghost light", "sunken ruin", "alligator nest", "poisonous plant"
  ],
  coast: [
    "sandy beach", "rocky shore", "tide pools", "shipwreck",
    "fishing village", "smuggler's cove", "lighthouse", "sea cave",
    "pirate hideout", "mermaid tale location", "shipyard", "treasure map location",
    "kelp forest", "seal colony", "dangerous current", "sea monster trail"
  ],
  underdark: [
    "fungal forest", "crystal cavern", "underground river", "drow settlement",
    "mushroom field", "glowing moss", "deep lake", "dwarven city",
    "mind flayer base", "madness zone", "treasure vault", "demon's chamber",
    "ancient library", "tyrant's throne", "slave market", "mining colony"
  ],
  volcanic: [
    "lava field", "hot spring", "sulfur pit", "dormant volcano",
    "obsidian deposits", "fire elemental presence", "ash plains", "lava cave",
    "heat shimmer", "phoenix nest", "magma flow", "sulfur geysers",
    "fire drake lair", "elemental binding site", "molten lake", "ash tower"
  ],
  tundra: [
    "ice sheet", "snow plain", "ice cave", "frozen lake",
    "northerner camp", "ice city", "aurora zone", "glacier",
    "frost dragon lair", "eternal winter", "frozen corpse", "ice temple",
    "blizzard zone", "frost giant hall", "aurora shrine", "cold spring"
  ],
  jungle: [
    "dense vegetation", "hidden temple", "tribal village", "canopy home",
    "waterfall", "underground river", "rare herb grove", "predator zone",
    "lost civilization", "poison dart frogs", "monkey troupe", "exotic flowers",
    "head-hunter territory", "abandoned city", "jaguar lair", "exotic birds"
  ]
};
// [deduplicated: generateWildernessHex - defined earlier]
// [deduplicated: generateCampsite - defined earlier]
// [deduplicated: generateForagingTable - defined earlier]
// [deduplicated: TRAP_TYPES - defined earlier]
// [deduplicated: PUZZLE_TYPES - defined earlier]
// [deduplicated: generateTrap - defined earlier]
// [deduplicated: generatePuzzle - defined earlier]

// ────────────────────────────────────────────────────────────────
// ─── EXTENDED SYSTEMS & UTILITIES (Additional ~1100 lines) ──────
// ────────────────────────────────────────────────────────────────

// UNDERGROUND CITY GENERATION
const UNDERGROUND_ARCHITECTURE = [
  { style: "dwarven", material: "carved stone", features: ["grand halls", "deep mines", "forges", "brewing chambers"] },
  { style: "drow", material: "obsidian and chitin", features: ["spider silks", "dripping caverns", "slave pens", "priestess temples"] },
  { style: "gnomish", material: "reinforced wood and stone", features: ["clockwork mechanisms", "gardens", "libraries", "tinkering shops"] },
  { style: "deep gnome", material: "svirfneblin stone", features: ["mushroom gardens", "wild areas", "natural caverns", "hidden enclaves"] },
  { style: "derro", material: "rough stone and bone", features: ["chaos shrines", "mutation labs", "paranoia halls", "slave warrens"] }
];

function generateUndergroundCity(rng, depth) {
  const architecture = pick(UNDERGROUND_ARCHITECTURE, rng);
  const depth_level = depth || randInt(1, 10, rng);

  return {
    name: genName(rng, "place") + " Underground",
    depth: depth_level + " levels below surface",
    architecture: architecture.style,
    material: architecture.material,
    features: pickN(architecture.features, randInt(2, 4, rng), rng),
    population: randInt(500, 50000, rng),
    government: pick(["clan based", "single ruler", "council", "theocracy", "anarchy"], rng),
    mainHall: {
      name: "Great Chamber",
      description: "Massive natural cavern serving as city center",
      size: pick(["immense", "vast", "enormous", "cathedral-like"], rng),
      purposes: pickN(["marketplace", "assembly hall", "religious ceremony", "military drills", "entertainment"], randInt(2, 3, rng), rng)
    },
    districts: pickN([
      "mining district", "merchant quarter", "residential caverns", "temple complex",
      "military garrison", "slave pens", "manufacturing center", "research labs",
      "agriculture caverns", "archives", "treasury vault", "sacred pools"
    ], randInt(3, 8, rng), rng),
    resources: pickN([
      "metal ore", "gemstones", "mushrooms", "underground rivers", "hot springs",
      "crystal formations", "salt deposits", "peat layers", "fossil fuels"
    ], randInt(3, 6, rng), rng),
    hazards: pickN([
      "cave-ins", "flooding", "toxic gas", "lava chambers", "unstable magic",
      "monsters", "rival factions", "collapsing infrastructure", "dark magic zones"
    ], randInt(2, 4, rng), rng),
    connections: pickN([
      "surface shaft", "river cave entrance", "ancient tunnel network",
      "portal chamber", "mine shafts", "hidden passage system"
    ], randInt(1, 3, rng), rng)
  };
}

// MONSTER LAIR GENERATION
const LAIR_TYPES = [
  { name: "Dragon's Hoard", threat: 5, size: "cavernous", features: ["treasure vault", "lava flows", "ancient magic"] },
  { name: "Vampire's Crypt", threat: 4, size: "sprawling", features: ["coffin chamber", "torture room", "thrall pens"] },
  { name: "Werewolf Den", threat: 3, size: "natural cavern", features: ["bone pile", "hunting trophy room", "full moon chamber"] },
  { name: "Lich's Tower", threat: 5, size: "tall tower", features: ["phylactery vault", "laboratory", "summoning circle"] },
  { name: "Giant Spider Web", threat: 2, size: "web-filled cavern", features: ["egg sacs", "prey store", "central hub"] },
  { name: "Demon's Gate", threat: 4, size: "planar pocket", features: ["ritual circle", "torture chambers", "dimensional rifts"] }
];

function generateMonsterLair(rng, monsterType) {
  const lairType = pick(LAIR_TYPES, rng);
  const threat = lairType.threat;

  return {
    name: "Lair of " + (monsterType || pick(["the Dragon", "the Vampire", "the Lich", "the Beast"], rng)),
    type: lairType.name,
    threatLevel: threat,
    size: lairType.size,
    depth: randInt(1, 5, rng) + " levels",
    features: lairType.features,
    treasureValue: Math.floor(Math.pow(threat, 2) * 5000) + " gold estimated",
    inhabitants: {
      primary: 1,
      minions: randInt(2, 20, rng),
      prisoners: randInt(0, 10, rng)
    },
    defenses: pickN([
      "traps", "guards", "magical wards", "illusions", "summons",
      "curses", "environmental hazards", "intelligent servants"
    ], randInt(3, 6, rng), rng),
    rooms: [
      { name: "Entrance", description: "Main entrance (possibly hidden)", hazards: "ambush points" },
      { name: "Guardroom", description: "Where minions gather", inhabitants: randInt(1, 8, rng) },
      { name: "Treasure Vault", description: "Where valuables are stored", security: "maximum" },
      { name: "Throne/Lair", description: "Monster's main chamber", inhabitant: "primary monster" },
      { name: "Sanctuary", description: "Safe resting place", security: "high" }
    ],
    knownWeakness: pick([
      "sensitive to sunlight", "vulnerable to holy water", "weakened by specific magic",
      "hates specific sound", "allergic to substance", "cannot cross salt line", "afraid of fire"
    ], rng)
  };
}
// [deduplicated: FACTION_TYPES - defined earlier]
// [deduplicated: generateFaction - defined earlier]

// MAGICAL LOCATION GENERATION
const MAGICAL_SITE_TYPES = [
  { name: "Ley Line Nexus", power: "5", description: "Convergence of magical flows" },
  { name: "Ancient Ruin", power: "4", description: "Remnant of fallen civilization" },
  { name: "Dragon Nest", power: "5", description: "Sacred draconic breeding ground" },
  { name: "Portal Junction", power: "4", description: "Crossroads between planes" },
  { name: "Faerie Ring", power: "3", description: "Gateway to the fey realm" },
  { name: "Sacred Mountain", power: "4", description: "Divine presence embodied in stone" },
  { name: "Cursed Ground", power: "3", description: "Site of ancient tragedy" },
  { name: "Wizard Tower", power: "4", description: "Living seat of magical power" }
];

function generateMagicalLocation(rng, biome) {
  const siteType = pick(MAGICAL_SITE_TYPES, rng);

  return {
    name: genName(rng, "place") + " - " + siteType.name,
    type: siteType.name,
    powerLevel: siteType.power,
    description: siteType.description,
    biome,
    location: {
      x: randInt(0, 200, rng),
      y: randInt(0, 200, rng),
      accessibility: pick(["easily accessible", "difficult journey", "dangerous approach", "hidden"], rng)
    },
    effects: pickN([
      "enhanced magic", "suppressed magic", "time distortion", "planar thinning",
      "immortality aura", "regeneration zone", "mutation field", "madness influence"
    ], randInt(1, 3, rng), rng),
    phenomena: pickN([
      "strange lights", "magical aurora", "singing crystals", "ethereal creatures",
      "temporal echoes", "prophetic visions", "unnatural weather", "electromagnetic storms"
    ], randInt(2, 4, rng), rng),
    danger: pick(["safe", "minor hazards", "dangerous", "deadly", "apocalyptic"], rng),
    researcher: generateNPC(rng, "magical researcher"),
    researchFindings: pick([
      "location of artifact", "spell formula", "magical theory", "planar secrets",
      "prophecy fragments", "ritual instructions", "monster lore"
    ], rng)
  };
}
// [deduplicated: generateDungeonLevel - defined earlier]

// TAVERN PATRON GENERATOR
const PATRON_ARCHETYPES = [
  "grizzled veteran", "young adventurer", "mysterious stranger", "scholar",
  "merchant", "nobility", "criminal", "cleric", "wizard", "bard",
  "rogue", "fighter", "ranger", "local farmer", "knight", "spy",
  "treasure hunter", "escaped slave", "con artist", "exiled noble"
];

function generateTavernPatron(rng) {
  const archetype = pick(PATRON_ARCHETYPES, rng);
  const npc = generateNPC(rng, archetype);

  return {
    npc,
    reason: pick([
      "drowning sorrows", "celebrating victory", "planning heist", "gathering rumors",
      "hiring mercenaries", "fence stolen goods", "romantic rendezvous", "business meeting",
      "hiding from law", "waiting for someone", "passing through", "local regular"
    ], rng),
    drunkenness: randInt(0, 10, rng),
    gold: randInt(5, 500, rng),
    secrets: rng() > 0.7 ? pick([
      "knows location of treasure", "wanted criminal", "lost heir", "spy",
      "cursed", "haunted", "betrayed friend", "marked for death"
    ], rng) : "none",
    quest: rng() > 0.6 ? pick([
      "rescue mission", "escort job", "information gathering", "artifact recovery",
      "assassination", "infiltration", "revenge", "lost love"
    ], rng) : "none",
    reliability: pick(["honest", "deceiving", "unstable", "desperate", "calculating"], rng)
  };
}

// CURSED ITEM GENERATION
const CURSE_TYPES = [
  { name: "Transformation Curse", effect: "wielder slowly changes form", severity: 4 },
  { name: "Mind Control Curse", effect: "item influences wielder's thoughts", severity: 5 },
  { name: "Weakness Curse", effect: "wielder grows weaker over time", severity: 3 },
  { name: "Addiction Curse", effect: "wielder becomes dependent on item", severity: 3 },
  { name: "Rage Curse", effect: "wielder becomes increasingly violent", severity: 4 },
  { name: "Decay Curse", effect: "wielder and equipment age rapidly", severity: 4 },
  { name: "Isolation Curse", effect: "people shun the wielder", severity: 3 },
  { name: "Pain Curse", effect: "constant pain while wielding", severity: 2 },
  { name: "Luck Curse", effect: "bad luck surrounds wielder", severity: 3 },
  { name: "Death Curse", effect: "wielder approaches death slowly", severity: 5 }
];

function generateCursedItem(rng) {
  const curse = pick(CURSE_TYPES, rng);
  const baseItem = pick([
    "sword", "ring", "amulet", "cloak", "gloves", "boots",
    "crown", "mirror", "dagger", "staff", "scroll", "book"
  ], rng);

  return {
    name: "Cursed " + baseItem,
    baseType: baseItem,
    curse: curse.name,
    effect: curse.effect,
    severity: curse.severity,
    origin: pick([
      "created by wizard", "corrupted by demon", "cursed by victim",
      "ancient evil", "ritual gone wrong", "divine punishment"
    ], rng),
    breakingMethod: pick([
      "true love's kiss", "specific ritual", "magic dispelling", "blood sacrifice",
      "find creator", "destroy item", "10 years service", "impossible task"
    ], rng),
    history: {
      previousOwners: randInt(1, 5, rng),
      deaths: randInt(0, 10, rng),
      legends: pick(["unknown", "whispered", "famous", "infamous"], rng)
    }
  };
}

// PROPHECY GENERATION
const PROPHECY_ARCHETYPES = [
  "doom prophecy", "heroic destiny", "cyclical pattern", "forbidden knowledge",
  "hidden truth", "paradoxical fate", "time loop", "parallel world"
];
// [deduplicated: generateProphecy - defined earlier]

// LEGENDARY MONSTER GENERATION
function generateLegendaryMonster(rng) {
  const baseName = pick([
    "Dragon", "Wyvern", "Hydra", "Basilisk", "Manticore",
    "Chimera", "Kraken", "Leviathan", "Demon", "Devil",
    "Lich", "Vampire", "Werewolf", "Giant", "Beast"
  ], rng);

  const legend = pick([
    "of the North", "the Devourer", "Skycleaver", "Earthshaker",
    "the Eternal", "Bonecrusher", "Flamerend", "Soulsteal",
    "the Ancient", "Despair", "the Unkillable", "Nightshadow"
  ], rng);

  return {
    name: baseName + " " + legend,
    threatLevel: randInt(15, 25, rng),
    lair: generateMonsterLair(rng, baseName),
    abilities: pickN([
      "breath weapon", "magic resistance", "regeneration", "teleportation",
      "mind control", "shape shifting", "time manipulation", "plane walking",
      "summoning", "curse", "plague", "immortality"
    ], randInt(4, 8, rng), rng),
    weaknesses: pickN([
      "specific magic", "holy symbol", "artifact weapon", "ritual",
      "true name", "true form", "loved one", "ancient enemy"
    ], randInt(1, 3, rng), rng),
    lair: {
      location: genName(rng, "place"),
      accessibility: pick(["inaccessible", "dangerous journey", "hidden path", "well known"], rng),
      treasureValue: randInt(50000, 500000, rng) + " gold"
    },
    personality: pick(["intelligent", "cunning", "bestial", "malevolent", "ancient"], rng),
    history: {
      age: randInt(100, 10000, rng) + " years",
      deeds: randInt(5, 20, rng),
      victims: randInt(10, 1000, rng)
    },
    hunterReward: randInt(10000, 100000, rng) + " gold"
  };
}

// ROYAL COURT GENERATION
function generateRoyalCourt(rng, kingdom) {
  const ruler = generateNPC(rng, "monarch");
  const courtSize = randInt(10, 50, rng);

  const positions = [];
  for (let i = 0; i < Math.min(courtSize, COURT_POSITIONS.length); i++) {
    if (rng() > 0.3) {
      const position = pick(COURT_POSITIONS, rng);
      positions.push({
        position,
        holder: generateNPC(rng, position.toLowerCase()),
        loyalty: pick(["absolute", "strong", "conditional", "doubtful", "traitor"], rng),
        influence: randInt(1, 10, rng)
      });
    }
  }

  return {
    kingdom: kingdom.name || kingdom,
    ruler,
    courtSize,
    positions,
    palace: {
      name: genName(rng, "place") + " Palace",
      size: pick(["small", "large", "massive", "sprawling"], rng),
      rooms: randInt(20, 200, rng),
      secretAreas: rng() > 0.6
    },
    treasury: {
      goldReserve: randInt(100000, 1000000, rng) + " gold",
      magicalArtifacts: randInt(1, 20, rng),
      secretWeapons: randInt(0, 5, rng)
    },
    ceremonies: pickN([
      "coronation", "state dinner", "tournament", "marriage", "execution",
      "peace treaty", "war declaration", "religious ceremony", "celebration"
    ], randInt(2, 4, rng), rng),
    intrigues: pickN([
      "succession dispute", "assassination plot", "blackmail scheme", "adultery",
      "treason", "magical influence", "demonic pact", "forbidden romance"
    ], randInt(1, 3, rng), rng)
  };
}
// [deduplicated: WORLD_EVENTS - defined earlier]
// [deduplicated: generateWorldEvent - defined earlier]

// GAMBLING ESTABLISHMENT GENERATION
const GAME_TYPES = [
  { name: "Dice Games", odds: "variable", cheating: "easy" },
  { name: "Card Games", odds: "favorable to house", cheating: "moderate" },
  { name: "Cockfighting", odds: "variable", cheating: "moderate" },
  { name: "Horse Racing", odds: "favorable to house", cheating: "hard" },
  { name: "Arm Wrestling", odds: "variable", cheating: "hard" },
  { name: "Magic Duel", odds: "balanced", cheating: "very hard" },
  { name: "Monster Fights", odds: "variable", cheating: "hard" },
  { name: "Betting Pools", odds: "favorable to house", cheating: "moderate" }
];

function generateGambleEstablishment(rng, settlement) {
  const games = pickN(GAME_TYPES, randInt(3, 6, rng), rng);

  return {
    name: genName(rng, "place") + " Gaming House",
    settlement: settlement.name || settlement,
    reputation: pick(["fair game", "slightly rigged", "heavily rigged", "criminal front"], rng),
    owner: generateNPC(rng, "gambling house proprietor"),
    games,
    tables: randInt(3, 20, rng),
    staff: {
      dealers: randInt(2, 10, rng),
      bouncers: randInt(2, 8, rng),
      cheaters: randInt(0, 3, rng)
    },
    minimumBet: randInt(1, 100, rng) + " gold",
    maximumBet: randInt(500, 5000, rng) + " gold",
    dailyRevenue: randInt(500, 5000, rng) + " gold",
    secretOperations: pick([
      "none", "money laundering", "robbery fence", "assassination contracts",
      "slave trading", "artifact theft", "blackmail scheme", "magical research"
    ], rng),
    securityLevel: randInt(1, 5, rng),
    famousPatrons: randInt(0, 5, rng),
    legendaryWins: randInt(0, 10, rng),
    notableLosses: {
      incidents: randInt(1, 10, rng),
      deathsFromDebt: randInt(0, 20, rng),
      murderAttempts: randInt(0, 5, rng)
    }
  };
}

// LIBRARY & ARCHIVE GENERATION
const LIBRARY_COLLECTION_TYPES = [
  "histories", "arcane texts", "poetry", "philosophy", "science",
  "maps", "religious scripture", "bestiaries", "grimoires", "legends",
  "languages", "mathematics", "astronomy", "alchemy", "medicine",
  "law codes", "military strategies", "art", "architecture", "agriculture"
];

function generateLibrary(rng, settlement) {
  const collections = pickN(LIBRARY_COLLECTION_TYPES, randInt(5, 10, rng), rng);
  const bookCount = randInt(100, 50000, rng);

  return {
    name: genName(rng, "place") + " Library",
    settlement: settlement.name || settlement,
    bookCount,
    collections,
    sections: randInt(5, 50, rng),
    librarian: generateNPC(rng, "head librarian"),
    staff: randInt(1, 20, rng),
    accessibility: pick(["public", "semi-public", "restricted", "secret"], rng),
    restrictions: pickN([
      "no magical users", "forbidden languages", "locked collections", "requiring references",
      "only nobility", "literacy required", "time limits", "copy restrictions"
    ], randInt(0, 3, rng), rng),
    specialCollections: {
      rareBooks: randInt(0, 100, rng),
      ancientTexts: randInt(0, 50, rng),
      forbiddenKnowledge: randInt(0, 20, rng),
      artifacts: randInt(0, 10, rng)
    },
    secrets: pickN([
      "hidden chamber", "forbidden text", "lost manuscript", "secret library",
      "coded messages", "hidden map", "prophecy", "dangerous knowledge"
    ], randInt(1, 3, rng), rng),
    knownFor: pick([
      "comprehensive collection", "rare manuscripts", "historical records",
      "magical knowledge", "artistic works", "scientific research", "forbidden texts"
    ], rng),
    visitorsPerDay: randInt(5, 100, rng),
    maintenanceStatus: pick(["pristine", "well-kept", "aging", "deteriorating"], rng)
  };
}
// [deduplicated: CRIME_TYPES - defined earlier]

function generateCrimeScene(rng, location) {
  const crimeType = pick(CRIME_TYPES, rng);
  const suspects = [];

  for (let i = 0; i < crimeType.suspect_count; i++) {
    suspects.push({
      npc: generateNPC(rng, "suspect"),
      motive: pick(crimeType.motive_types, rng),
      evidence: pickN(["at scene", "motive clear", "opportunity", "false alibi", "suspicious behavior"], randInt(1, 3, rng), rng),
      probability: randInt(10, 90, rng) + "%"
    });
  }

  return {
    crime: crimeType.name,
    location: location.name || location,
    discovered: randInt(0, 7, rng) + " days ago",
    witnesses: randInt(0, 5, rng),
    evidence: pickN([
      "bloodstains", "weapon", "note", "jewelry", "clothing", "poison residue",
      "burnt remains", "muddy footprints", "rope marks", "magical residue"
    ], randInt(2, 5, rng), rng),
    suspects,
    investigator: generateNPC(rng, "investigator"),
    difficulty: randInt(1, 5, rng),
    clues: {
      obvious: randInt(1, 3, rng),
      hidden: randInt(0, 5, rng),
      misleading: randInt(0, 3, rng)
    },
    timeline: {
      estimatedTime: genName(rng, "person") + " heard scream at night",
      discoveryTime: "discovered at dawn",
      events: [
        pick(["argument overheard", "lights seen", "stranger noticed"], rng),
        pick(["commotion", "silence", "activity"], rng),
        pick(["alarm raised", "discovery", "investigation begins"], rng)
      ]
    }
  };
}

// SPORTS ARENA GENERATION
const SPORT_TYPES = [
  { name: "Gladiatorial Combat", spectators: 5000, wagering: "heavy" },
  { name: "Beast Fighting", spectators: 3000, wagering: "moderate" },
  { name: "Tournament", spectators: 2000, wagering: "light" },
  { name: "Racing", spectators: 4000, wagering: "very heavy" },
  { name: "Magical Duels", spectators: 1000, wagering: "moderate" },
  { name: "Wrestling", spectators: 2000, wagering: "moderate" }
];

function generateArena(rng, settlement) {
  const sportType = pick(SPORT_TYPES, rng);

  return {
    name: genName(rng, "place") + " Arena",
    settlement: settlement.name || settlement,
    sportType: sportType.name,
    capacity: sportType.spectators + randInt(-500, 1000, rng),
    seating: {
      standiing: pick(["yes", "no"], rng),
      vip_boxes: randInt(2, 10, rng),
      nobility_section: pick(["yes", "no"], rng)
    },
    owner: generateNPC(rng, "arena owner"),
    manager: generateNPC(rng, "arena manager"),
    events: {
      perWeek: randInt(2, 4, rng),
      nextEvent: {
        name: pick(["championship", "exhibition", "grand melee", "hunt", "trial by combat"], rng),
        date: randInt(1, 30, rng) + " days",
        expectedAttendance: Math.floor(sportType.spectators * (0.5 + rng() * 0.5)),
        expectedWagering: sportType.wagering
      }
    },
    famous_fighters: randInt(2, 8, rng),
    legendary_fights: randInt(0, 20, rng),
    deaths: randInt(0, 100, rng),
    revenue: {
      ticketSales: randInt(100, 5000, rng) + " gold per event",
      wagering: randInt(1000, 50000, rng) + " gold per event"
    },
    corruption: pick(["none", "fixed matches", "rigged betting", "animal abuse", "slavery"], rng)
  };
}

// MONSTER HUNTER QUEST GENERATOR
const HUNT_OBJECTIVES = [
  "eliminate monster", "capture alive", "retrieve body part", "gather intelligence",
  "retrieve egg", "stop attacking settlements", "rescue captives", "destroy lair",
  "obtain venom/blood", "photograph evidence"
];

function generateHuntingQuest(rng, settlemnt, difficulty) {
  const objective = pick(HUNT_OBJECTIVES, rng);
  const monsterType = pick([
    "dragon", "giant spider", "basilisk", "manticore", "chimera",
    "werewolf pack", "vampire", "ogre tribe", "giant", "demon"
  ], rng);

  return {
    title: "Hunt: " + monsterType,
    objective,
    monsterType,
    difficulty: difficulty || randInt(2, 5, rng),
    settlement: settlement.name || settlement,
    location: {
      biome: pick(["forest", "mountain", "plains", "swamp", "coast"], rng),
      distance: randInt(5, 100, rng) + " leagues",
      terrain: pick(["mountainous", "forested", "open", "marshland", "underground"], rng)
    },
    monsterStats: {
      size: pick(["huge", "gargantuan"], rng),
      threat: randInt(3, 10, rng),
      intelligence: pick(["animalistic", "cunning", "intelligent", "highly intelligent"], rng),
      abilities: pickN([
        "flight", "magic", "regeneration", "summoning", "mind control",
        "shape shifting", "invisibility", "teleportation", "immortality"
      ], randInt(2, 4, rng), rng)
    },
    reward: {
      goldAmount: randInt(500, 10000, rng) + " gold",
      bonus: pick(["none", "rare item", "territory grant", "title"], rng),
      fame: pick(["local", "regional", "continental"], rng)
    },
    previousAttempts: randInt(0, 5, rng),
    previousFailures: randInt(0, 3, rng),
    timeLimit: rng() > 0.5 ? randInt(7, 60, rng) + " days" : "none",
    requirements: pickN([
      "minimum level", "specific magic", "special equipment", "proof of skill"
    ], randInt(0, 2, rng), rng),
    dangers: pickN([
      "lethal traps", "other hunters", "innocent bystanders", "collateral damage penalty"
    ], randInt(1, 3, rng), rng)
  };
}

// TRADING POST GENERATION
const TRADE_GOODS_COMMON = [
  "grain", "livestock", "wool", "timber", "stone", "metal ore",
  "salt", "fish", "honey", "leather", "cloth", "rope"
];

const TRADE_GOODS_EXOTIC = [
  "spices", "silk", "gems", "fur", "ivory", "wine",
  "perfume", "dyes", "incense", "pottery", "weapons", "artifacts"
];

function generateTradingPost(rng, mainBiome, nearbyBiomes) {
  const importedGoods = [];
  const exportedGoods = [];

  for (const biome of nearbyBiomes || [mainBiome]) {
    exportedGoods.push(...pickN(TRADE_GOODS_COMMON, randInt(2, 4, rng), rng));
  }

  for (let i = 0; i < 5; i++) {
    importedGoods.push(pick([...TRADE_GOODS_COMMON, ...TRADE_GOODS_EXOTIC], rng));
  }

  return {
    name: genName(rng, "place") + " Trading Post",
    mainBiome,
    nearbyBiomes: nearbyBiomes || [mainBiome],
    owner: generateNPC(rng, "merchant"),
    manager: generateNPC(rng, "trading post manager"),
    capacity: randInt(50, 500, rng) + " tons of cargo",
    currentInventory: randInt(20, 400, rng) + " tons",
    staffSize: randInt(5, 30, rng),
    tradeRoutes: pickN([
      "to capital city", "to neighboring kingdom", "to coastal port",
      "to mountain kingdom", "to distant lands", "internal network"
    ], randInt(2, 4, rng), rng),
    exportedGoods,
    importedGoods,
    priceMarkup: randInt(20, 100, rng) + "%",
    security: randInt(2, 5, rng),
    defenses: pick(["walls", "guards", "magic wards", "monster allies"], rng),
    specialization: pick([
      "general goods", "luxury items", "raw materials", "magical components",
      "weapons", "exotic creatures", "information", "smuggled goods"
    ], rng),
    blackMarketActivity: pick(["none", "minor", "moderate", "extensive"], rng),
    knownFor: pick([
      "fair prices", "exotic goods", "dangerous clientele", "recent robberies",
      "excellent security", "secret dealings", "rare artifacts"
    ], rng)
  };
}

// MONASTERY & TEMPLE GENERATION
const RELIGIOUS_FOCUS = [
  "healing", "warfare", "knowledge", "nature", "death",
  "magic", "law", "chaos", "agriculture", "crafts",
  "music", "philosophy", "prophecy", "asceticism"
];

function generateMonastery(rng, religion, settlement) {
  const focus = pick(RELIGIOUS_FOCUS, rng);
  const monkCount = randInt(10, 200, rng);

  return {
    name: genName(rng, "place") + " " + religion + " Monastery",
    religion,
    settlement: settlement.name || settlement,
    focus,
    architecture: pick(["stone tower", "wooden compound", "cliff dwelling", "underground caves", "fortified complex"], rng),
    monks: monkCount,
    abbot: generateNPC(rng, "religious leader"),
    grounds: {
      size: pick(["small", "medium", "large", "vast"], rng),
      walls: pick(["none", "simple", "strong", "fortified"], rng),
      structures: pickN([
        "dormitory", "library", "scriptorium", "chapel", "refectory", "kitchen",
        "garden", "workshop", "bell tower", "crypt", "underground passages", "watchtower"
      ], randInt(6, 10, rng), rng)
    },
    treasures: {
      religious_artifacts: randInt(1, 10, rng),
      manuscripts: randInt(10, 500, rng),
      gold: randInt(1000, 50000, rng) + " gold",
      magical_items: randInt(0, 5, rng)
    },
    knowledge: pickN([
      "healing arts", "ancient history", "prophecy", "alchemy",
      "forbidden rituals", "language expertise", "medicinal herbs"
    ], randInt(2, 4, rng), rng),
    secrets: pickN([
      "hidden relic", "forbidden text", "secret passage", "magical barrier",
      "time manipulation", "dimensional pocket", "possessed artifact"
    ], randInt(1, 3, rng), rng),
    visitors: pick(["pilgrims", "scholars", "injured travelers", "nobles"], rng),
    protection: pick(["divine", "magical", "martial", "mercenary"], rng)
  };
}

// PRISON GENERATION
function generatePrison(rng, settlement) {
  const capacity = randInt(20, 500, rng);
  const currentPopulation = Math.floor(capacity * (0.3 + rng() * 0.6));

  return {
    name: "The " + pick(["Crypt", "Pit", "Iron House", "Chains", "Tower", "Dungeons"], rng),
    settlement: settlement.name || settlement,
    capacity,
    currentPopulation,
    occupancyRate: Math.floor((currentPopulation / capacity) * 100) + "%",
    warden: generateNPC(rng, "prison warden"),
    guards: randInt(5, 50, rng),
    security_level: pick(["minimum", "medium", "maximum", "super maximum"], rng),
    construction: pick(["stone", "wood and stone", "magical barriers", "fortified tower"], rng),
    prisonBlocks: [
      { name: "Common Cells", capacity: randInt(10, 50, rng), security: "standard" },
      { name: "Solitary", capacity: randInt(5, 20, rng), security: "strict" },
      { name: "Death Row", capacity: randInt(1, 10, rng), security: "maximum" },
      { name: "Magical Detention", capacity: randInt(2, 10, rng), security: "extreme" }
    ],
    notablePrisoners: randInt(0, 20, rng),
    executions_per_year: randInt(0, 20, rng),
    escapes: randInt(0, 10, rng),
    violence_per_month: randInt(0, 50, rng),
    corruption_level: pick(["none", "minor", "moderate", "severe"], rng),
    specialPrisoners: pick(["none", "political prisoners", "magical beings", "monsters"], rng)
  };
}

// FRONTIER SETTLEMENT OUTPOST
function generateOutpost(rng, mainSettlement, biome) {
  return {
    name: mainSettlement.name + " Outpost",
    parentSettlement: mainSettlement.name || mainSettlement,
    biome,
    purpose: pick([
      "military defense", "trade route", "resource extraction",
      "exploration base", "research station", "holy site", "exile colony"
    ], rng),
    population: randInt(10, 500, rng),
    commander: generateNPC(rng, "outpost commander"),
    garrison: randInt(5, 100, rng),
    buildings: pickN([
      "barracks", "watchtower", "storage", "workshop", "shrine",
      "commander's quarters", "palisade wall", "well", "stables", "tavern"
    ], randInt(4, 8, rng), rng),
    supplies: {
      food: pick(["adequate", "low", "very low"], rng),
      weapons: pick(["well-stocked", "moderate", "low"], rng),
      morale: randInt(30, 100, rng)
    },
    threats: pickN([
      "native attacks", "monsters", "weather", "disease",
      "low supplies", "desertion", "mutiny", "isolation madness"
    ], randInt(2, 4, rng), rng),
    support: {
      frequency: pick(["weekly", "monthly", "quarterly", "yearly"], rng),
      supplies_per_delivery: randInt(10, 100, rng) + " tons"
    },
    lastContact: randInt(1, 365, rng) + " days ago",
    status: pick(["thriving", "stable", "struggling", "critical", "abandoned"], rng)
  };
}

// ALCHEMICAL LAB GENERATION
const ALCHEMICAL_EXPERIMENTS = [
  { name: "Transmutation", danger: 4, potential: "gold from lead" },
  { name: "Immortality Elixir", danger: 5, potential: "eternal life" },
  { name: "Plague Creation", danger: 5, potential: "bioweapon" },
  { name: "Shapeshifting Potion", danger: 3, potential: "form changes" },
  { name: "Flight Formula", danger: 3, potential: "aerial travel" },
  { name: "Teleportation", danger: 4, potential: "instant travel" },
  { name: "Golem Animation", danger: 4, potential: "magical servants" },
  { name: "Consciousness Transfer", danger: 5, potential: "body swap" }
];

function generateAlchemyLab(rng, settlement) {
  const activeExperiments = [];
  for (let i = 0; i < randInt(2, 5, rng); i++) {
    const exp = pick(ALCHEMICAL_EXPERIMENTS, rng);
    activeExperiments.push({
      ...exp,
      progress: randInt(10, 90, rng) + "%",
      resourcesCost: randInt(5000, 100000, rng) + " gold",
      timeRemaining: randInt(1, 365, rng) + " days",
      explosionRisk: randInt(1, 5, rng)
    });
  }

  return {
    name: genName(rng, "place") + " Alchemical Laboratory",
    settlement: settlement.name || settlement,
    alchemist: generateNPC(rng, "master alchemist"),
    apprentices: randInt(0, 5, rng),
    workspace: {
      security: randInt(2, 5, rng),
      magic_wards: pick(["none", "weak", "moderate", "strong"], rng),
      secret_chambers: rng() > 0.5
    },
    activeExperiments,
    inventory: {
      potion_recipes: randInt(5, 50, rng),
      rare_components: randInt(10, 200, rng),
      failed_batches: randInt(0, 20, rng)
    },
    successRate: randInt(20, 80, rng) + "%",
    accidents: {
      fires: randInt(0, 10, rng),
      explosions: randInt(0, 5, rng),
      mutations: randInt(0, 3, rng)
    },
    reputation: pick(["brilliant genius", "mad scholar", "dangerous", "reckless"], rng),
    recentSuccess: pick(["none", "minor potion", "major discovery", "legendary breakthrough"], rng),
    specialization: pick([
      "transmutation", "potions", "poisons", "magical components",
      "transmutation circles", "explosive research", "immortality research"
    ], rng)
  };
}

// SMITHY GENERATION
const SMITH_SPECIALTIES = [
  { specialty: "weapons", products: 15, masterwork_rate: 0.15 },
  { specialty: "armor", products: 12, masterwork_rate: 0.12 },
  { specialty: "tools", products: 20, masterwork_rate: 0.05 },
  { specialty: "ornamental", products: 10, masterwork_rate: 0.2 },
  { specialty: "magical", products: 5, masterwork_rate: 0.4 },
  { specialty: "horseshoes", products: 50, masterwork_rate: 0.02 }
];

function generateSmithy(rng, settlement) {
  const specialty = pick(SMITH_SPECIALTIES, rng);

  return {
    name: genName(rng, "person") + "'s Smithy",
    settlement: settlement.name || settlement,
    mastersmith: generateNPC(rng, "master blacksmith"),
    apprentices: randInt(0, 3, rng),
    specialty: specialty.specialty,
    productionPerMonth: specialty.products + randInt(-5, 5, rng),
    masterworkRate: Math.floor(specialty.masterwork_rate * 100) + "%",
    equipment: {
      forges: randInt(1, 3, rng),
      anvils: randInt(1, 4, rng),
      tools: randInt(10, 50, rng),
      quality: pick(["basic", "good", "excellent", "masterwork"], rng)
    },
    stockpile: {
      metal: {
        iron: randInt(100, 500, rng) + " pounds",
        steel: randInt(50, 300, rng) + " pounds",
        precious: randInt(0, 50, rng) + " pounds"
      },
      finishedGoods: randInt(5, 50, rng)
    },
    reputation: pick(["average work", "good quality", "excellent", "legendary", "overpriced"], rng),
    specialization: pickN([
      "decorative work", "enchantment-ready", "historical recreation", "oversized weapons",
      "delicate work", "mass production", "rare material specialist"
    ], randInt(1, 2, rng), rng),
    orderBacklog: randInt(0, 50, rng) + " weeks",
    notablePieces: randInt(0, 5, rng),
    waitTime: pick(["immediate", "few days", "few weeks", "months"], rng)
  };
}

// ARCANE TOWER GENERATION
const TOWER_SCHOOLS = [
  "evocation", "divination", "transmutation", "abjuration",
  "conjuration", "necromancy", "illusion", "enchantment"
];

function generateArcaneTower(rng, settlement) {
  const school = pick(TOWER_SCHOOLS, rng);
  const levels = randInt(3, 10, rng);

  const chambers = [];
  for (let i = 1; i <= levels; i++) {
    chambers.push({
      level: i,
      name: pick([
        "Library", "Laboratory", "Ritual Chamber", "Summoning Circle",
        "Living Quarters", "Library", "Vault", "Portal Room", "Scrying Chamber", "Study"
      ], rng),
      purpose: pick([
        "research", "living", "storage", "magical practice", "binding", "observation"
      ], rng),
      security: randInt(i, 10, rng)
    });
  }

  return {
    name: genName(rng, "place") + " Tower",
    settlement: settlement.name || settlement,
    archmage: generateNPC(rng, "arch-mage"),
    school,
    levels,
    chambers,
    staffSize: randInt(3, 20, rng),
    students: randInt(0, 50, rng),
    library: {
      spellbooks: randInt(50, 1000, rng),
      research_texts: randInt(100, 5000, rng),
      forbidden_knowledge: randInt(1, 20, rng)
    },
    magicalArtifacts: {
      defensive_wards: randInt(3, 10, rng),
      scrying_pools: randInt(1, 3, rng),
      summoning_circles: randInt(1, 5, rng),
      legendary_artifacts: randInt(0, 5, rng)
    },
    currentProjects: pickN([
      "planar research", "immortality study", "time magic", "dimensional gates",
      "golem creation", "artifact cataloging", "spell refinement", "monster summoning"
    ], randInt(2, 4, rng), rng),
    dangers: pickN([
      "summoned creatures", "magical experiments", "planar tears", "curses",
      "magical radiation", "explosive reactions", "possession", "madness"
    ], randInt(1, 3, rng), rng),
    reputation: pick(["brilliant", "powerful", "dangerous", "mysterious", "isolated"], rng),
    access: pick(["open to scholars", "restricted", "highly secret", "dangerous"], rng)
  };
}

// BANDIT HIDEOUT GENERATION
function generateBanditHideout(rng, region) {
  const memberCount = randInt(5, 100, rng);

  return {
    name: "Hideout of " + pick(["The " + pick(["Black", "Red", "Shadow"], rng) + " " + pick(["Wolves", "Dragons", "Serpents"], rng), genName(rng, "person") + "'s Crew"], rng),
    region: region.name || region,
    leader: generateNPC(rng, "bandit leader"),
    memberCount,
    location: {
      terrain: pick(["forest", "mountain", "cave", "swamp", "ruins"], rng),
      accessibility: pick(["well-hidden", "concealed", "secret entrance", "easily found"], rng),
      distance: randInt(5, 50, rng) + " leagues from civilization"
    },
    facilities: pickN([
      "barracks", "treasury", "horse stables", "weapon cache",
      "commander's tent", "dining hall", "prison", "magical barrier"
    ], randInt(4, 8, rng), rng),
    activities: pickN([
      "robbery", "smuggling", "slave trading", "protection racket",
      "assassination", "artifact theft", "weapon dealing", "piracy"
    ], randInt(2, 4, rng), rng),
    treasury: {
      gold: randInt(5000, 100000, rng) + " gold",
      gems: randInt(0, 50, rng),
      stolen_goods: pick(["none", "some", "considerable", "massive"], rng)
    },
    defenses: {
      guards_on_duty: randInt(5, 30, rng),
      traps: pick(["none", "some", "many", "extensive"], rng),
      magical_wards: pick(["none", "weak", "moderate", "strong"], rng)
    },
    notoriety: pick(["local nuisance", "regional threat", "widely feared", "legendary"], rng),
    successRate: randInt(30, 90, rng) + "%",
    captives: randInt(0, 20, rng),
    hunted_by: pickN(["local militia", "kingdom army", "adventurers", "mercenaries", "paladins"], randInt(1, 3, rng), rng)
  };
}

// NOBLE ESTATE GENERATION
function generateNobleEstate(rng, kingdom) {
  const houseName = genName(rng, "house name");
  const lands = randInt(1000, 100000, rng);

  return {
    name: "House " + houseName + " Estate",
    kingdom: kingdom.name || kingdom,
    head: generateNPC(rng, "noble lord"),
    heir: generateNPC(rng, "noble heir"),
    landArea: lands + " acres",
    population: Math.floor(lands / 10) + " peasants",
    mainSettlement: genName(rng, "place"),
    architecture: pick(["stone castle", "marble palace", "fortified manor", "grand estate"], rng),
    wealth: pick(["meager", "comfortable", "wealthy", "obscenely rich"], rng),
    income: {
      agricultural: randInt(10000, 100000, rng) + " gold/year",
      trade: randInt(5000, 50000, rng) + " gold/year",
      taxes: randInt(10000, 50000, rng) + " gold/year"
    },
    allies: {
      count: randInt(1, 5, rng),
      families: pickN(["Royal House", "Church", "Merchants", "Military"], randInt(1, 3, rng), rng)
    },
    enemies: {
      count: randInt(0, 3, rng),
      families: randInt(0, 3, rng)
    },
    secrets: pickN([
      "hidden bastard", "forbidden magic", "assassination plot", "affair",
      "illegitimate claim", "cursed artifact", "dark pact", "hidden dungeon"
    ], randInt(1, 3, rng), rng),
    military: {
      knights: randInt(5, 50, rng),
      soldiers: randInt(20, 200, rng),
      elite_guard: randInt(2, 20, rng)
    },
    libraries: randInt(0, 5, rng),
    treasures: randInt(5, 20, rng),
    history: {
      age: randInt(50, 1000, rng) + " years",
      major_events: randInt(2, 10, rng),
      famous_ancestors: randInt(1, 5, rng)
    }
  };
}

// MONSTER BREEDING PIT
const BREEDING_MONSTER_TYPES = [
  { species: "giant spiders", yield: 20, maturity: 6 },
  { species: "phase spiders", yield: 15, maturity: 8 },
  { species: "giant scorpions", yield: 15, maturity: 5 },
  { species: "rust monsters", yield: 30, maturity: 3 },
  { species: "hellhounds", yield: 5, maturity: 12 },
  { species: "wyverns", yield: 3, maturity: 24 }
];

function generateMonsterBreedingPit(rng) {
  const monsterType = pick(BREEDING_MONSTER_TYPES, rng);

  return {
    name: monsterType.species + " Breeding Pit",
    monsterType: monsterType.species,
    operator: generateNPC(rng, "monster breeder"),
    capacity: Math.floor(monsterType.yield * (1 + rng())),
    currentPopulation: Math.floor(monsterType.yield * rng()),
    productivity: {
      maturityTime: monsterType.maturity + " months",
      annualYield: monsterType.yield * 12 + " creatures",
      survival_rate: randInt(60, 95, rng) + "%"
    },
    facilities: pickN([
      "breeding chambers", "feeding pens", "incubation pools",
      "isolation cages", "training area", "observation platform"
    ], randInt(3, 6, rng), rng),
    securityLevel: randInt(3, 5, rng),
    breeding_purpose: pick([
      "military weapons", "arena fights", "research", "monster hunting training",
      "dark ritual components", "entertainment", "magical experiments"
    ], rng),
    escapes: randInt(0, 5, rng),
    casualties: randInt(5, 50, rng),
    buyer_network: randInt(2, 10, rng),
    monthly_profit: randInt(5000, 50000, rng) + " gold"
  };
}
// [deduplicated: generateArcaneSchool - defined earlier]

// CRYPT & BURIAL GROUND
function generateCrypt(rng, settlement) {
  return {
    name: settlement.name + " Crypt",
    settlement: settlement.name || settlement,
    burials: randInt(5, 500, rng),
    age: randInt(10, 1000, rng) + " years",
    architecture: pick(["stone chamber", "carved cavern", "catacomb", "pyramid", "mausoleum"], rng),
    keeper: generateNPC(rng, "grave keeper"),
    layout: {
      levels: randInt(1, 5, rng),
      total_tombs: randInt(10, 1000, rng),
      family_vaults: randInt(1, 50, rng)
    },
    notable_burials: randInt(0, 20, rng),
    treasures: {
      burial_goods: pick(["sparse", "moderate", "wealthy", "royal"], rng),
      artifacts_estimated: randInt(0, 10, rng)
    },
    disturbances: pickN([
      "grave robbing", "undead rising", "magical corruption", "collapsed sections",
      "strange lights", "phantom sounds", "curse effects"
    ], randInt(0, 3, rng), rng),
    guardian: pick(["none", "zombie", "skeleton", "ghost", "magical construct", "curse"], rng),
    accessibility: pick(["public", "family access", "restricted", "sealed", "hidden"], rng),
    desecration_risk: randInt(1, 5, rng)
  };
}

// DRAGON LAIR
function generateDragonLair(rng, dragonColor) {
  const color = dragonColor || pick(["red", "blue", "green", "white", "black", "gold", "silver"], rng);

  return {
    name: color.charAt(0).toUpperCase() + color.slice(1) + " Dragon's Lair",
    dragon_color: color,
    dragon_type: pick(["ancient", "adult", "young adult", "young"], rng),
    threat_level: randInt(15, 25, rng),
    location: {
      biome: pick(["mountain", "cave", "swamp", "forest", "castle", "underwater"], rng),
      depth: randInt(0, 1000, rng) + " feet",
      accessibility: pick(["extremely difficult", "dangerous", "moderate", "unknown"], rng)
    },
    hoard: {
      gold_value: randInt(100000, 1000000, rng) + " gold",
      gems: randInt(10, 100, rng),
      magical_items: randInt(5, 20, rng),
      legendary_artifacts: randInt(0, 3, rng)
    },
    lair_features: pickN([
      "throne room", "treasure vault", "dragon eggs", "slave pens",
      "draconic library", "alchemical laboratory", "summoning circle",
      "trapped corridors", "magical wards", "underground lake"
    ], randInt(4, 8, rng), rng),
    servants: {
      humanoid: randInt(0, 50, rng),
      dragon_spawn: randInt(0, 10, rng),
      magical_constructs: randInt(0, 5, rng)
    },
    defenses: randInt(8, 15, rng),
    personality: pick(["proud", "paranoid", "sadistic", "wise", "mad"], rng),
    known_weakness: pick(["none", "paladin magic", "holy artifact", "true name", "loved one"], rng),
    last_rampage: randInt(0, 10, rng) + " years ago",
    hunter_bounty: randInt(50000, 500000, rng) + " gold"
  };
}

// End of expanded feature generation

// ─── SVG RENDERING HELPERS ──────────────────────────────────────────────────

function pointsToSmoothPath(points, cs, closed) {
  if (points.length < 2) return "";
  const pts = points.map(p=>({x:p.x*cs,y:p.y*cs}));
  let d = `M ${pts[0].x} ${pts[0].y}`;
  for (let i=1;i<pts.length;i++) { const prev=pts[i-1],curr=pts[i]; d+=` Q ${prev.x} ${prev.y} ${(prev.x+curr.x)/2} ${(prev.y+curr.y)/2}`; }
  if (closed) { d+=` Q ${pts[pts.length-1].x} ${pts[pts.length-1].y} ${pts[0].x} ${pts[0].y} Z`; }
  else d+=` L ${pts[pts.length-1].x} ${pts[pts.length-1].y}`;
  return d;
}

function hullToSmoothPath(hull, cs) {
  if (hull.length < 3) return "";
  const pts = hull.map(p=>({x:p.x*cs,y:p.y*cs}));
  let d = "";
  for (let i=0;i<pts.length;i++) {
    const p0=pts[(i-1+pts.length)%pts.length],p1=pts[i],p2=pts[(i+1)%pts.length],p3=pts[(i+2)%pts.length];
    if(i===0) d=`M ${p1.x} ${p1.y}`;
    d+=` C ${p1.x+(p2.x-p0.x)/6} ${p1.y+(p2.y-p0.y)/6} ${p2.x-(p3.x-p1.x)/6} ${p2.y-(p3.y-p1.y)/6} ${p2.x} ${p2.y}`;
  }
  return d+" Z";
}

// ─── WORLD GENERATION ORCHESTRATOR ──────────────────────────────────────────

function generateWorld(seed, config) {
  const rng = mulberry32(hashStr(seed));
  const gW = config.gridWidth || 160;
  const gH = config.gridHeight || 120;

  let hmap = generateHeightmap(gW, gH, mulberry32(hashStr(seed+"_h")), config.heightOctaves||6, config.heightPersistence||0.52, config.heightLacunarity||2.1);
  const moisture = generateMoisture(gW, gH, mulberry32(hashStr(seed+"_m")));
  const temperature = generateTemperature(gW, gH, mulberry32(hashStr(seed+"_t")), config.latitudeBias!==false);
  const windMap = generateWindMap(gW, gH, mulberry32(hashStr(seed+"_w")));

  // Apply continent shaping
  if (config.islandMask) {
    const cx=gW/2, cy=gH/2, maxR=Math.min(gW,gH)*0.45;
    for (let y=0;y<gH;y++) for (let x=0;x<gW;x++) { const d=Math.sqrt((x-cx)**2+(y-cy)**2)/maxR; hmap[y][x]*=Math.max(0,1-d*d); }
  }
  if (config.continentShape==="pangaea") {
    const cx=gW*0.45, cy=gH*0.5;
    for (let y=0;y<gH;y++) for (let x=0;x<gW;x++) { const d=Math.sqrt(((x-cx)/(gW*0.4))**2+((y-cy)/(gH*0.4))**2); hmap[y][x]+=Math.max(0,0.3*(1-d)); }
  } else if (config.continentShape==="archipelago") {
    const cRng=mulberry32(hashStr(seed+"_i")),centers=[];
    for(let i=0;i<10;i++) centers.push({x:gW*0.1+cRng()*gW*0.8,y:gH*0.1+cRng()*gH*0.8,r:8+cRng()*22});
    for(let y=0;y<gH;y++) for(let x=0;x<gW;x++) { let b=0; for(const c of centers) b+=Math.max(0,0.2*(1-dist(x,y,c.x,c.y)/c.r)); hmap[y][x]+=b-0.06; }
  } else if (config.continentShape==="two_continents") {
    const cx1=gW*0.28, cx2=gW*0.72, cy=gH*0.5;
    for (let y=0;y<gH;y++) for (let x=0;x<gW;x++) {
      const d1=Math.sqrt(((x-cx1)/(gW*0.25))**2+((y-cy)/(gH*0.35))**2);
      const d2=Math.sqrt(((x-cx2)/(gW*0.25))**2+((y-cy)/(gH*0.35))**2);
      hmap[y][x]+=Math.max(0,0.25*(1-d1))+Math.max(0,0.25*(1-d2));
    }
  }

  // Re-normalize
  let min=Infinity,max=-Infinity;
  for(let y=0;y<gH;y++) for(let x=0;x<gW;x++) { if(hmap[y][x]<min)min=hmap[y][x]; if(hmap[y][x]>max)max=hmap[y][x]; }
  const range=max-min||1;
  for(let y=0;y<gH;y++) for(let x=0;x<gW;x++) hmap[y][x]=(hmap[y][x]-min)/range;

  // Sea level adjustment
  if (config.seaLevel) for(let y=0;y<gH;y++) for(let x=0;x<gW;x++) hmap[y][x]=clamp(hmap[y][x]-config.seaLevel*0.1,0,1);

  // Erosion
  if (config.erosion) hmap = applyErosion(hmap, gW, gH, mulberry32(hashStr(seed+"_e")), config.erosionIterations || 3000);

  // Classify biomes
  const biomeGrid = Array.from({length:gH},(_,y)=>Array.from({length:gW},(_,x)=>classifyBiome(hmap[y][x],moisture[y][x],temperature[y][x])));

  // Generate features
  const rivers = generateRivers(hmap, moisture, gW, gH, mulberry32(hashStr(seed+"_r")), config.riverCount||10);
  const settlements = placeCities(hmap, moisture, rivers, gW, gH, mulberry32(hashStr(seed+"_c")), config);
  const roads = generateRoads(settlements, hmap, gW, gH, mulberry32(hashStr(seed+"_rd")));
  const kingdoms = generateKingdoms(settlements, hmap, gW, gH, mulberry32(hashStr(seed+"_k")), config.kingdomCount||4);
  const pois = generatePOIs(hmap, moisture, settlements, gW, gH, mulberry32(hashStr(seed+"_p")), config);
  const landmarks = generateLandmarks(hmap, moisture, gW, gH, mulberry32(hashStr(seed+"_l")));

  // Sea names
  const seas = [];
  const seaRng = mulberry32(hashStr(seed+"_sea"));
  const waterVisited = Array.from({length:gH},()=>new Uint8Array(gW));
  for(let y=0;y<gH;y++) for(let x=0;x<gW;x++) {
    const b=biomeGrid[y][x];
    if ((b==="deepOcean"||b==="ocean")&&!waterVisited[y][x]) {
      const queue=[{x,y}],cells=[];
      waterVisited[y][x]=1;
      while(queue.length>0) { const{x:cx,y:cy}=queue.shift(); cells.push({x:cx,y:cy}); for(const[dx,dy]of[[1,0],[-1,0],[0,1],[0,-1]]) { const nx=cx+dx,ny=cy+dy; if(nx>=0&&nx<gW&&ny>=0&&ny<gH&&!waterVisited[ny][nx]) { const nb=biomeGrid[ny][nx]; if(nb==="deepOcean"||nb==="ocean"){waterVisited[ny][nx]=1;queue.push({x:nx,y:ny});} } } }
      if (cells.length>40) { const ax=cells.reduce((s,c)=>s+c.x,0)/cells.length, ay=cells.reduce((s,c)=>s+c.y,0)/cells.length; seas.push({x:ax,y:ay,size:cells.length,name:pick(GEN_NAMES.standalone.sea,seaRng)}); }
    }
  }

  // Generate Ley Lines (magical power paths)
  const leyLines = generateLeyLines(mulberry32(hashStr(seed+"_ley")), gW, gH, hmap);

  // Generate Sea Currents
  const seaCurrents = generateSeaCurrents(mulberry32(hashStr(seed+"_curr")), gW, gH, hmap, biomeGrid);

  // Generate Volcanic Zones
  const volcanicZones = generateVolcanicZones(mulberry32(hashStr(seed+"_vol")), gW, gH, hmap);

  // Generate Weather Patterns
  const weatherPatterns = generateWeatherPatterns(mulberry32(hashStr(seed+"_weather")), gW, gH, temperature, moisture, windMap);

  // Generate world-level encounter tables
  const encounterTables = {};
  for (const biome of Object.keys(BIOMES)) {
    if (ENCOUNTER_TABLES[biome]) {
      encounterTables[biome] = generateEncounterTable(mulberry32(hashStr(seed+"_enc_"+biome)), biome, config.partyLevel || 5);
    }
  }

  // World history
  const worldHistory = generateWorldHistory(mulberry32(hashStr(seed+"_hist")), kingdoms, config.worldAge || "ancient");

  return {
    seed, config, gridW:gW, gridH:gH,
    heightmap:hmap, moisture, temperature, windMap, biomeGrid,
    rivers, settlements, roads, kingdoms, pois, landmarks, seas,
    leyLines, seaCurrents, volcanicZones, weatherPatterns,
    encounterTables, worldHistory,
    stats: {
      landCells: biomeGrid.flat().filter(b=>!["deepOcean","ocean","shallows","reef"].includes(b)).length,
      waterCells: biomeGrid.flat().filter(b=>["deepOcean","ocean","shallows","reef"].includes(b)).length,
      totalPop: settlements.reduce((s,st)=>s+st.population,0),
    },
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// SVG MAP ICON COMPONENTS — Hand-drawn cartography style
// ═══════════════════════════════════════════════════════════════════════════

const FMG_Mountain = ({x,y,s=1,color="#706860"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-10,6 L-3,-8 L0,-10 L3,-8 L10,6" fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M0,-10 L-2,-5 L2,-5 Z" fill={color} opacity="0.3"/>
    <path d="M-6,2 L-8,6" stroke={color} strokeWidth="0.6" opacity="0.5"/>
    <path d="M6,2 L8,6" stroke={color} strokeWidth="0.6" opacity="0.5"/>
  </g>
);

const FMG_SnowMountain = ({x,y,s=1,color="#a0a8b0"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-10,6 L-3,-8 L0,-10 L3,-8 L10,6" fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round"/>
    <path d="M-2,-5 L0,-10 L2,-5" fill="white" stroke={color} strokeWidth="0.5"/>
    <path d="M0,-10 L-1,-7 L1,-7 Z" fill="white"/>
    <path d="M-6,2 L-8,6" stroke={color} strokeWidth="0.6" opacity="0.4"/>
    <path d="M6,2 L8,6" stroke={color} strokeWidth="0.6" opacity="0.4"/>
  </g>
);

const FMG_Hill = ({x,y,s=1,color="#7a8a50"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-8,4 Q-4,-2 0,-4 Q4,-2 8,4" fill="none" stroke={color} strokeWidth="0.8" strokeLinecap="round"/>
    <path d="M-5,2 Q-2,-1 1,2" stroke={color} strokeWidth="0.4" opacity="0.4"/>
  </g>
);

const FMG_Tree = ({x,y,s=1,color="#3a6830"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <line x1="0" y1="2" x2="0" y2="6" stroke="#5a4830" strokeWidth="0.8"/>
    <path d="M0,-5 L-4,2 L-2,1 L-5,5 L0,3 L5,5 L2,1 L4,2 Z" fill={color} stroke={color} strokeWidth="0.3" opacity="0.8"/>
  </g>
);

const FMG_PineTree = ({x,y,s=1,color="#2a5038"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <line x1="0" y1="3" x2="0" y2="6" stroke="#4a3820" strokeWidth="0.6"/>
    <path d="M0,-6 L-2,-2 L-1,-2 L-3,1 L-1,1 L-3,4 L3,4 L1,1 L3,1 L1,-2 L2,-2 Z" fill={color} opacity="0.8"/>
  </g>
);

const FMG_PalmTree = ({x,y,s=1,color="#1a6030"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M0,6 Q1,0 0,-3" fill="none" stroke="#6a5020" strokeWidth="0.8"/>
    <path d="M0,-3 Q-5,-1 -7,1" fill="none" stroke={color} strokeWidth="1"/>
    <path d="M0,-3 Q5,-1 7,1" fill="none" stroke={color} strokeWidth="1"/>
    <path d="M0,-3 Q-3,-5 -5,-3" fill="none" stroke={color} strokeWidth="0.8"/>
    <path d="M0,-3 Q3,-5 5,-3" fill="none" stroke={color} strokeWidth="0.8"/>
  </g>
);

const FMG_Cactus = ({x,y,s=1,color="#5a8040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <line x1="0" y1="-5" x2="0" y2="5" stroke={color} strokeWidth="1.5" strokeLinecap="round"/>
    <path d="M0,-1 Q-4,-1 -4,2" fill="none" stroke={color} strokeWidth="1" strokeLinecap="round"/>
    <path d="M0,1 Q3,1 3,-2" fill="none" stroke={color} strokeWidth="1" strokeLinecap="round"/>
  </g>
);

const FMG_City = ({x,y,s=1,color="#d4b870"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-7" y="-4" width="14" height="10" rx="1" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8"/>
    <rect x="-5" y="-6" width="4" height="12" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <rect x="1" y="-3" width="4" height="9" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <line x1="-3" y1="-9" x2="-3" y2="-6" stroke={color} strokeWidth="0.6"/>
    <circle cx="-3" cy="-9.5" r="0.8" fill={color}/>
    <rect x="-1" y="2" width="2" height="4" fill={color} fillOpacity="0.5"/>
  </g>
);

const FMG_Capital = ({x,y,s=1,color="#ffd700"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-9" y="-5" width="18" height="12" rx="1" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="1"/>
    <rect x="-7" y="-8" width="5" height="15" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.5"/>
    <rect x="2" y="-6" width="5" height="13" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.5"/>
    <line x1="-4.5" y1="-12" x2="-4.5" y2="-8" stroke={color} strokeWidth="0.8"/>
    <path d="M-4.5,-12 L-2,-11 L-4.5,-10" fill={color}/>
    <line x1="4.5" y1="-10" x2="4.5" y2="-6" stroke={color} strokeWidth="0.6"/>
    <circle cx="4.5" cy="-10.5" r="0.7" fill={color}/>
    <path d="M-6,-5 L-6,-7 L-3,-5" stroke={color} strokeWidth="0.4" fill="none"/>
    <path d="M6,-5 L6,-7 L3,-5" stroke={color} strokeWidth="0.4" fill="none"/>
  </g>
);

const FMG_Town = ({x,y,s=1,color="#c8b070"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-5" y="-2" width="10" height="7" rx="1" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M-5,-2 L0,-5 L5,-2" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <rect x="-1" y="1" width="2" height="4" fill={color} fillOpacity="0.5"/>
  </g>
);

const FMG_Village = ({x,y,s=1,color="#a89060"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-3,3 L-3,-1 L0,-3 L3,-1 L3,3 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.5"/>
    <rect x="-0.5" y="0" width="1" height="3" fill={color} fillOpacity="0.5"/>
  </g>
);

const FMG_Hamlet = ({x,y,s=1,color="#887860"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <circle cx="0" cy="0" r="2.5" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.4"/>
    <circle cx="0" cy="0" r="1" fill={color} fillOpacity="0.3"/>
  </g>
);

const FMG_Ruins = ({x,y,s=1,color="#8a7a68"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <line x1="-4" y1="4" x2="-4" y2="-2" stroke={color} strokeWidth="0.8" strokeLinecap="round"/>
    <line x1="-2" y1="4" x2="-2" y2="-4" stroke={color} strokeWidth="0.8" strokeLinecap="round"/>
    <line x1="1" y1="4" x2="1" y2="-1" stroke={color} strokeWidth="0.8" strokeLinecap="round"/>
    <line x1="4" y1="4" x2="4" y2="-3" stroke={color} strokeWidth="0.6" strokeDasharray="1,1"/>
    <path d="M-5,-2 L-1,-4 L2,-1 L5,-3" fill="none" stroke={color} strokeWidth="0.4" opacity="0.5"/>
  </g>
);

const FMG_Dungeon = ({x,y,s=1,color="#6a4040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-5,4 L-5,-1 Q-5,-4 -2,-4 L2,-4 Q5,-4 5,-1 L5,4" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8"/>
    <rect x="-2" y="0" width="4" height="4" fill="black" fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <path d="M-3,-2 L0,-4 L3,-2" fill="none" stroke={color} strokeWidth="0.6"/>
    <line x1="0" y1="0" x2="0" y2="4" stroke={color} strokeWidth="0.3"/>
  </g>
);

const FMG_Tower = ({x,y,s=1,color="#7a7a8a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-2.5" y="-4" width="5" height="10" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.7"/>
    <path d="M-3,-4 L-3.5,-6 L-1,-5 L0,-7 L1,-5 L3.5,-6 L3,-4" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <rect x="-1" y="-2" width="2" height="2" fill={color} fillOpacity="0.4"/>
    <rect x="-1" y="2" width="2" height="4" fill={color} fillOpacity="0.5"/>
  </g>
);

const FMG_Shrine = ({x,y,s=1,color="#6a8a6a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <circle cx="0" cy="0" r="5" fill="none" stroke={color} strokeWidth="0.5" strokeDasharray="2,2" opacity="0.5"/>
    <line x1="0" y1="-3" x2="0" y2="3" stroke={color} strokeWidth="0.8"/>
    <line x1="-3" y1="0" x2="3" y2="0" stroke={color} strokeWidth="0.8"/>
    <circle cx="0" cy="0" r="1.5" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.4"/>
  </g>
);

const FMG_Cave = ({x,y,s=1,color="#4a3e30"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-5,3 Q-4,-2 -2,-3 Q0,-4 2,-3 Q4,-2 5,3" fill="black" fillOpacity="0.3" stroke={color} strokeWidth="0.8"/>
    <path d="M-3,3 Q-2,0 0,-1 Q2,0 3,3" fill="black" fillOpacity="0.4"/>
  </g>
);

const FMG_Grove = ({x,y,s=1,color="#3a7a2a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <circle cx="-3" cy="-1" r="3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <circle cx="3" cy="-1" r="3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <circle cx="0" cy="-3" r="3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <circle cx="0" cy="0" r="1" fill={color} fillOpacity="0.5"/>
  </g>
);

const FMG_Monolith = ({x,y,s=1,color="#5a5a6a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-1.5,5 L-2,-6 L0,-8 L2,-6 L1.5,5 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.7"/>
    <line x1="-1" y1="-3" x2="1" y2="-3" stroke={color} strokeWidth="0.3" opacity="0.5"/>
    <line x1="-0.8" y1="-1" x2="0.8" y2="-1" stroke={color} strokeWidth="0.3" opacity="0.5"/>
    <line x1="-0.5" y1="1" x2="0.5" y2="1" stroke={color} strokeWidth="0.3" opacity="0.5"/>
  </g>
);

const FMG_Mine = ({x,y,s=1,color="#7a6040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-4,2 L-3,-3 L3,-3 L4,2" fill="black" fillOpacity="0.25" stroke={color} strokeWidth="0.7"/>
    <line x1="-2" y1="-3" x2="-1" y2="2" stroke={color} strokeWidth="0.4"/>
    <line x1="2" y1="-3" x2="1" y2="2" stroke={color} strokeWidth="0.4"/>
    <path d="M-2,3 L-3,2 L-1,1 L1,1 L3,2 L2,3" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.3"/>
  </g>
);

const FMG_Fortress = ({x,y,s=1,color="#6a6a7a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-7" y="-3" width="14" height="8" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.7"/>
    <rect x="-8" y="-5" width="3" height="10" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.5"/>
    <rect x="5" y="-5" width="3" height="10" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.5"/>
    <path d="M-8,-5 L-8,-6 L-7,-5 L-6,-6 L-5,-5" fill="none" stroke={color} strokeWidth="0.4"/>
    <path d="M5,-5 L5,-6 L6,-5 L7,-6 L8,-5" fill="none" stroke={color} strokeWidth="0.4"/>
    <rect x="-1" y="1" width="2" height="4" fill={color} fillOpacity="0.4"/>
  </g>
);

const FMG_Temple = ({x,y,s=1,color="#8a7a6a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-6" y="-1" width="12" height="7" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.6"/>
    <path d="M-7,-1 L0,-6 L7,-1" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <line x1="-4" y1="-1" x2="-4" y2="6" stroke={color} strokeWidth="0.5"/>
    <line x1="0" y1="-1" x2="0" y2="6" stroke={color} strokeWidth="0.5"/>
    <line x1="4" y1="-1" x2="4" y2="6" stroke={color} strokeWidth="0.5"/>
    <circle cx="0" cy="-4" r="1" fill={color} fillOpacity="0.4" stroke={color} strokeWidth="0.3"/>
  </g>
);

const FMG_Lighthouse = ({x,y,s=1,color="#8a8898"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-2,6 L-1.5,-4 L1.5,-4 L2,6 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M-2,-4 L-3,-6 L3,-6 L2,-4" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <line x1="0" y1="-6" x2="0" y2="-8" stroke={color} strokeWidth="0.5"/>
    <circle cx="0" cy="-5" r="1" fill="#ffd700" fillOpacity="0.6" stroke={color} strokeWidth="0.3"/>
    <path d="M-4,-5 L-1.5,-5" stroke="#ffd700" strokeWidth="0.3" opacity="0.5"/>
    <path d="M1.5,-5 L4,-5" stroke="#ffd700" strokeWidth="0.3" opacity="0.5"/>
  </g>
);

const FMG_Camp = ({x,y,s=1,color="#8a6a50"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-4,3 L0,-4 L4,3 Z" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.6"/>
    <line x1="0" y1="-4" x2="0" y2="3" stroke={color} strokeWidth="0.3" opacity="0.3"/>
    <circle cx="5" cy="2" r="1.5" fill="#c06030" fillOpacity="0.3" stroke="#c06030" strokeWidth="0.4"/>
  </g>
);

const FMG_Portal = ({x,y,s=1,color="#7a50a0"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx="0" cy="0" rx="4" ry="6" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8"/>
    <ellipse cx="0" cy="0" rx="2.5" ry="4" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.5"/>
    <ellipse cx="0" cy="0" rx="1" ry="2" fill={color} fillOpacity="0.3"/>
    <circle cx="0" cy="-2" r="0.5" fill="white" fillOpacity="0.5"/>
  </g>
);

const FMG_Battlefield = ({x,y,s=1,color="#7a4040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <line x1="-5" y1="3" x2="-2" y2="-4" stroke={color} strokeWidth="0.8" strokeLinecap="round"/>
    <line x1="-3" y1="-4" x2="-1" y2="-3" stroke={color} strokeWidth="0.6"/>
    <line x1="2" y1="3" x2="4" y2="-3" stroke={color} strokeWidth="0.8" strokeLinecap="round"/>
    <line x1="3" y1="-3" x2="5" y2="-2" stroke={color} strokeWidth="0.6"/>
    <circle cx="-1" cy="2" r="1" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.3"/>
    <circle cx="1" cy="0" r="0.5" fill={color} fillOpacity="0.3"/>
  </g>
);

const FMG_Waterfall = ({x,y,s=1,color="#4a88b0"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-2,-4 L-2,0 Q0,2 2,0 L2,-4" fill="none" stroke={color} strokeWidth="0.8"/>
    <line x1="-1" y1="0" x2="-1" y2="4" stroke={color} strokeWidth="0.5" strokeDasharray="1,1"/>
    <line x1="1" y1="0" x2="1" y2="4" stroke={color} strokeWidth="0.5" strokeDasharray="1,1"/>
    <ellipse cx="0" cy="4" rx="3" ry="1" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.3"/>
  </g>
);

const FMG_Ship = ({x,y,s=1,color="#6a5a40"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-5,2 Q-4,-1 0,-2 Q4,-1 5,2 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <line x1="0" y1="-2" x2="0" y2="-7" stroke={color} strokeWidth="0.5"/>
    <path d="M0,-7 L3,-5 L0,-4" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.3"/>
  </g>
);

const FMG_Compass = ({x,y,s=1,color}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <circle cx="0" cy="0" r="20" fill="none" stroke={color} strokeWidth="0.5" opacity="0.3"/>
    <circle cx="0" cy="0" r="18" fill="none" stroke={color} strokeWidth="0.3" opacity="0.2"/>
    <line x1="0" y1="-22" x2="0" y2="22" stroke={color} strokeWidth="0.6" opacity="0.3"/>
    <line x1="-22" y1="0" x2="22" y2="0" stroke={color} strokeWidth="0.6" opacity="0.3"/>
    <line x1="-15" y1="-15" x2="15" y2="15" stroke={color} strokeWidth="0.3" opacity="0.2"/>
    <line x1="15" y1="-15" x2="-15" y2="15" stroke={color} strokeWidth="0.3" opacity="0.2"/>
    <path d="M0,-16 L3,-3 L0,0 L-3,-3 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <path d="M0,16 L3,3 L0,0 L-3,3 Z" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.3"/>
    <text x="0" y="-24" textAnchor="middle" fill={color} fontSize="6" fontFamily="'Cinzel', serif" fontWeight="700" opacity="0.5">N</text>
    <text x="0" y="28" textAnchor="middle" fill={color} fontSize="5" fontFamily="'Cinzel', serif" opacity="0.3">S</text>
    <text x="26" y="2" textAnchor="middle" fill={color} fontSize="5" fontFamily="'Cinzel', serif" opacity="0.3">E</text>
    <text x="-26" y="2" textAnchor="middle" fill={color} fontSize="5" fontFamily="'Cinzel', serif" opacity="0.3">W</text>
  </g>
);

const FMG_ScaleBar = ({x,y,s=1,color,label="100 leagues"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <line x1="0" y1="0" x2="80" y2="0" stroke={color} strokeWidth="1" opacity="0.4"/>
    <line x1="0" y1="-3" x2="0" y2="3" stroke={color} strokeWidth="0.8" opacity="0.4"/>
    <line x1="40" y1="-2" x2="40" y2="2" stroke={color} strokeWidth="0.5" opacity="0.3"/>
    <line x1="80" y1="-3" x2="80" y2="3" stroke={color} strokeWidth="0.8" opacity="0.4"/>
    <text x="40" y="10" textAnchor="middle" fill={color} fontSize="5" fontFamily="'Spectral', serif" opacity="0.4">{label}</text>
  </g>
);

// ═══════════════════════════════════════════════════════════════════════════
// NEW ICON COMPONENTS (30+ NEW) — Hand-drawn cartographic style
// ═══════════════════════════════════════════════════════════════════════════

const FMG_Volcano = ({x,y,s=1,color="#8a5040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-10,8 L-6,-6 L0,-8 L6,-6 L10,8 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="1"/>
    <path d="M-4,-6 L0,-8 L4,-6" fill="none" stroke={color} strokeWidth="0.8"/>
    <circle cx="0" cy="-8" r="1.5" fill="#ff6030" fillOpacity="0.4" stroke="#ff6030" strokeWidth="0.6"/>
    <path d="M-1,-9 Q-2,-12 -1,-15" fill="none" stroke="#8a8070" strokeWidth="0.8" opacity="0.6"/>
    <path d="M0,-10 Q0.5,-14 1,-18" fill="none" stroke="#8a8070" strokeWidth="0.8" opacity="0.6"/>
    <path d="M1.5,-9 Q3,-13 2.5,-16" fill="none" stroke="#8a8070" strokeWidth="0.7" opacity="0.5"/>
    <path d="M-6,2 L-5,-2" stroke={color} strokeWidth="0.4" opacity="0.5"/>
    <path d="M6,2 L5,-2" stroke={color} strokeWidth="0.4" opacity="0.5"/>
    <circle cx="0" cy="-1" r="0.8" fill="#ff4000" fillOpacity="0.3"/>
  </g>
);

const FMG_Oasis = ({x,y,s=1,color="#5aa060"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx="0" cy="2" rx="6" ry="4" fill="#4a9ac0" fillOpacity="0.3" stroke="#4a9ac0" strokeWidth="0.8"/>
    <path d="M-8,-2 Q-6,-4 -4,-2" fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round"/>
    <path d="M-4,-2 Q-2,-6 0,-4" fill="none" stroke={color} strokeWidth="1" strokeLinecap="round"/>
    <path d="M0,-4 Q2,-6 4,-2" fill="none" stroke={color} strokeWidth="1" strokeLinecap="round"/>
    <path d="M4,-2 Q6,-4 8,-2" fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round"/>
    <path d="M-5,1 L-5,5 L-4,6" fill="none" stroke={color} strokeWidth="0.6"/>
    <path d="M5,1 L5,5 L6,6" fill="none" stroke={color} strokeWidth="0.6"/>
    <circle cx="-2" cy="4" r="0.5" fill={color} opacity="0.4"/>
    <circle cx="2" cy="4" r="0.5" fill={color} opacity="0.4"/>
  </g>
);

const FMG_Swamp = ({x,y,s=1,color="#4a6a40"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx="0" cy="0" rx="8" ry="6" fill="#5a6a40" fillOpacity="0.2" stroke="#5a6a40" strokeWidth="0.8" strokeDasharray="2,2"/>
    <path d="M-2,-6 Q-1,-3 -2,2 Q-1,4 0,4 Q1,4 0,2 Q0,-2 1,-4 Q2,-2 2,2" fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round"/>
    <path d="M-3,5 L-2,8" stroke={color} strokeWidth="0.5"/>
    <path d="M3,5 L4,8" stroke={color} strokeWidth="0.5"/>
    <path d="M-6,2 Q-4,3 -2,2" fill="none" stroke="#5a7050" strokeWidth="0.6"/>
    <path d="M2,2 Q4,3 6,2" fill="none" stroke="#5a7050" strokeWidth="0.6"/>
    <path d="M-5,4 Q-4,5 -3,4" fill="none" stroke="#5a7050" strokeWidth="0.5"/>
    <path d="M4,4 Q5,5 6,4" fill="none" stroke="#5a7050" strokeWidth="0.5"/>
  </g>
);

const FMG_Bridge = ({x,y,s=1,color="#7a6a50"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-8,0 Q-6,-3 0,-4 Q6,-3 8,0" fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round"/>
    <line x1="-8" y1="0" x2="8" y2="0" stroke={color} strokeWidth="2" opacity="0.3"/>
    <path d="M-7,0 L-7,3" stroke={color} strokeWidth="0.6"/>
    <path d="M-3,0 L-3,3" stroke={color} strokeWidth="0.6"/>
    <path d="M3,0 L3,3" stroke={color} strokeWidth="0.6"/>
    <path d="M7,0 L7,3" stroke={color} strokeWidth="0.6"/>
    <line x1="-8.5" y1="-0.5" x2="-6" y2="1" stroke={color} strokeWidth="0.5"/>
    <line x1="8.5" y1="-0.5" x2="6" y2="1" stroke={color} strokeWidth="0.5"/>
  </g>
);

const FMG_Port = ({x,y,s=1,color="#6a7a80"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-8,0 L-8,4 L8,4 L8,0" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8"/>
    <line x1="-6" y1="0" x2="-6" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="-2" y1="0" x2="-2" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="2" y1="0" x2="2" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="6" y1="0" x2="6" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="-8" y1="2" x2="8" y2="2" stroke={color} strokeWidth="0.4" opacity="0.5"/>
    <path d="M8,0 L12,-3 L12,3" fill="none" stroke={color} strokeWidth="0.6"/>
    <circle cx="10" cy="0" r="1" fill={color} fillOpacity="0.3"/>
  </g>
);

const FMG_Shipwreck = ({x,y,s=1,color="#5a4a30"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-6,4 Q-4,2 -2,3 Q2,1 4,2 Q6,3 6,5" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8"/>
    <path d="M-3,0 L-1,-5 L2,-4 L0,0 Z" fill="none" stroke={color} strokeWidth="1" strokeDasharray="2,1"/>
    <path d="M-1,-4 Q0,-6 1,-4" fill="none" stroke={color} strokeWidth="0.6" opacity="0.5"/>
    <path d="M5,1 L6,-1" stroke={color} strokeWidth="0.8"/>
    <path d="M-5,3 L-6,-1" stroke={color} strokeWidth="0.8"/>
    <circle cx="-4" cy="5" r="1.2" fill="#4a3a20" stroke={color} strokeWidth="0.5"/>
    <circle cx="3" cy="5" r="1" fill="#4a3a20" stroke={color} strokeWidth="0.5"/>
    <path d="M-2,4 L-2,6" stroke={color} strokeWidth="0.4"/>
  </g>
);

const FMG_Dragon = ({x,y,s=1,color="#6a4a80"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx="0" cy="0" rx="4" ry="3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.8"/>
    <path d="M4,0 L6,1 L6,-1 Z" fill={color} stroke={color} strokeWidth="0.6"/>
    <circle cx="5" cy="0" r="0.6" fill={color}/>
    <path d="M-4,0 L-6,-2 L-7,-3 L-7,-1 L-6,1 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.6"/>
    <path d="M-6,-2 L-7,-4" stroke={color} strokeWidth="0.5"/>
    <path d="M-6,1 L-7,4" stroke={color} strokeWidth="0.5"/>
    <path d="M2,-3 Q3,-5 4,-4 Q5,-3 4,-2" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M2,3 Q3,5 4,4 Q5,3 4,2" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M-2,-2 Q-2,-4 0,-5" fill="none" stroke={color} strokeWidth="0.5" opacity="0.6"/>
  </g>
);

const FMG_SeaSerpent = ({x,y,s=1,color="#3a6a90"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-8,0 Q-4,-2 0,-2 Q4,-2 6,-1 Q8,0 8,2" fill="none" stroke={color} strokeWidth="1.2" strokeLinecap="round"/>
    <path d="M6,-1 L8,-2 L7,0 Z" fill={color} stroke={color} strokeWidth="0.6"/>
    <circle cx="8" cy="0" r="0.7" fill={color}/>
    <path d="M-7,-1 Q-5,-3 -3,-3 Q-1,-3 1,-2" fill="none" stroke={color} strokeWidth="0.8" opacity="0.6"/>
    <path d="M0,2 Q2,4 4,3" fill="none" stroke={color} strokeWidth="0.8" opacity="0.5"/>
    <path d="M-4,1 L-3,-1 L-2,1" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <path d="M2,0 L3,-2 L4,0" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
  </g>
);

const FMG_Treasure = ({x,y,s=1,color="#d4a040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-6" y="-2" width="12" height="8" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8" rx="0.5"/>
    <path d="M-6,-2 L0,-4 L6,-2" fill={color} fillOpacity="0.25" stroke={color} strokeWidth="0.6"/>
    <path d="M-2,0 L0,-2 L2,0" fill="#ffd700" fillOpacity="0.5" stroke="#ffd700" strokeWidth="0.4"/>
    <circle cx="-3" cy="3" r="0.8" fill="#ffd700" fillOpacity="0.6"/>
    <circle cx="0" cy="4" r="0.7" fill="#ffd700" fillOpacity="0.5"/>
    <circle cx="3" cy="3" r="0.8" fill="#ffd700" fillOpacity="0.6"/>
    <circle cx="-4" cy="5" r="0.6" fill="#c0a000" fillOpacity="0.4"/>
    <circle cx="4" cy="5" r="0.6" fill="#c0a000" fillOpacity="0.4"/>
  </g>
);

const FMG_Skull = ({x,y,s=1,color="#a0a0a0"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx="0" cy="-2" rx="4" ry="5" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.8"/>
    <circle cx="-2" cy="-3" r="1.5" fill="black" fillOpacity="0.4" stroke={color} strokeWidth="0.4"/>
    <circle cx="2" cy="-3" r="1.5" fill="black" fillOpacity="0.4" stroke={color} strokeWidth="0.4"/>
    <path d="M-1,-1 L1,-1" stroke={color} strokeWidth="0.5"/>
    <path d="M-3,1 L-1,2 L1,2 L3,1" fill="none" stroke={color} strokeWidth="0.6"/>
    <circle cx="-1.5" cy="2" r="0.4" fill={color} opacity="0.5"/>
    <circle cx="1.5" cy="2" r="0.4" fill={color} opacity="0.5"/>
    <path d="M-4,3 L4,3" stroke={color} strokeWidth="0.5" opacity="0.5"/>
  </g>
);

const FMG_Crown = ({x,y,s=1,color="#ffd700"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-7,3 L-5,-2 L-2,1 L0,-4 L2,1 L5,-2 L7,3" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8" strokeLinejoin="round"/>
    <line x1="-7" y1="3" x2="7" y2="3" stroke={color} strokeWidth="1.2"/>
    <circle cx="-5" cy="-2" r="1" fill={color} fillOpacity="0.5" stroke={color} strokeWidth="0.4"/>
    <circle cx="0" cy="-4" r="1.2" fill={color} fillOpacity="0.6" stroke={color} strokeWidth="0.4"/>
    <circle cx="5" cy="-2" r="1" fill={color} fillOpacity="0.5" stroke={color} strokeWidth="0.4"/>
    <path d="M-2,2 L-2,4" stroke={color} strokeWidth="0.5"/>
    <path d="M2,2 L2,4" stroke={color} strokeWidth="0.5"/>
  </g>
);

const FMG_Shield = ({x,y,s=1,color="#8a6a50"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-5,-4 L-5,2 Q0,5 5,2 L5,-4 Z" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8"/>
    <path d="M0,-4 L-3,0 L0,3 L3,0 Z" fill="none" stroke={color} strokeWidth="0.7" strokeLinejoin="round"/>
    <path d="M-2,-2 L2,-2" stroke={color} strokeWidth="0.5"/>
    <path d="M-2,0 L2,0" stroke={color} strokeWidth="0.5"/>
  </g>
);

const FMG_Sword = ({x,y,s=1,color="#a0a0b0"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-1,-6 L0,4 L1,-6" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.8"/>
    <path d="M-2,3 L2,3 L2,4 Q0,5 -2,4 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M-1.5,3 L1.5,3" stroke={color} strokeWidth="0.4"/>
    <path d="M1,-6 L4,-8 L3,-7 Z" fill={color} stroke={color} strokeWidth="0.5"/>
    <path d="M-1,-6 L-4,-8 L-3,-7 Z" fill={color} stroke={color} strokeWidth="0.5"/>
    <circle cx="0" cy="4.5" r="0.6" fill={color} fillOpacity="0.4"/>
  </g>
);

const FMG_Scroll = ({x,y,s=1,color="#d4c080"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-6,-3 Q-4,-5 0,-5 Q4,-5 6,-3 L6,0 Q4,2 0,2 Q-4,2 -6,0 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8" strokeLinecap="round"/>
    <path d="M-6,-3 L6,-3" stroke={color} strokeWidth="1" opacity="0.5"/>
    <path d="M-6,0 L6,0" stroke={color} strokeWidth="1" opacity="0.5"/>
    <circle cx="-5" cy="-1.5" r="0.6" fill={color} fillOpacity="0.4"/>
    <circle cx="5" cy="-1.5" r="0.6" fill={color} fillOpacity="0.4"/>
    <path d="M-2,-1.5 L2,-1.5" stroke={color} strokeWidth="0.4" opacity="0.6"/>
  </g>
);

const FMG_Wagon = ({x,y,s=1,color="#7a6a50"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-5" y="-2" width="10" height="4" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8" rx="0.5"/>
    <circle cx="-4" cy="3" r="2" fill="none" stroke={color} strokeWidth="0.6"/>
    <circle cx="4" cy="3" r="2" fill="none" stroke={color} strokeWidth="0.6"/>
    <line x1="-4" y1="3" x2="4" y2="3" stroke={color} strokeWidth="0.5"/>
    <path d="M6,-1 L8,-2 L8,0" fill="none" stroke={color} strokeWidth="0.6"/>
    <circle cx="6" cy="2" r="0.5" fill={color} fillOpacity="0.4"/>
  </g>
);

const FMG_Horse = ({x,y,s=1,color="#6a5040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx="0" cy="0" rx="5" ry="3" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8"/>
    <path d="M4,-2 L5,-4 L4,-3 Z" fill={color} stroke={color} strokeWidth="0.6"/>
    <circle cx="4.5" cy="-2.5" r="0.7" fill={color}/>
    <path d="M-4,-3 Q-3,-1 -2,-3" fill="none" stroke={color} strokeWidth="0.7" opacity="0.6"/>
    <path d="M0,-3 L0,-5 L1,-4 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <line x1="-3" y1="2" x2="-3" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="-1" y1="2" x2="-1" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="1" y1="2" x2="1" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="3" y1="2" x2="3" y2="4" stroke={color} strokeWidth="0.6"/>
  </g>
);

const FMG_Wolf = ({x,y,s=1,color="#5a4a40"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <ellipse cx="0" cy="0" rx="4" ry="3" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8"/>
    <path d="M4,-1 L6,-3 L5,-1 Z" fill={color} stroke={color} strokeWidth="0.6"/>
    <circle cx="5" cy="-1" r="0.6" fill={color}/>
    <path d="M-3,-2 L-5,-4 L-4,-2 Z" fill={color} stroke={color} strokeWidth="0.5"/>
    <path d="M-2,-2 L-4,-4 L-3,-2 Z" fill={color} stroke={color} strokeWidth="0.5"/>
    <path d="M2,-2 Q3,-3 4,-2" fill="none" stroke={color} strokeWidth="0.5"/>
    <line x1="-2" y1="2" x2="-2" y2="4" stroke={color} strokeWidth="0.5"/>
    <line x1="0" y1="2" x2="0" y2="4" stroke={color} strokeWidth="0.5"/>
    <line x1="2" y1="2" x2="2" y2="4" stroke={color} strokeWidth="0.5"/>
    <path d="M-4,1 Q-5,0.5 -6,1" fill="none" stroke={color} strokeWidth="0.5"/>
  </g>
);

const FMG_Castle = ({x,y,s=1,color="#8a7a68"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-8" y="-2" width="16" height="8" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8" rx="0.5"/>
    <rect x="-10" y="-5" width="3" height="12" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <rect x="-4" y="-6" width="3" height="13" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <rect x="1" y="-5" width="3" height="12" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <rect x="7" y="-5" width="3" height="12" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M-10,-5 L-10,-6 L-9,-5 L-8,-6 L-7,-5" fill="none" stroke={color} strokeWidth="0.4"/>
    <path d="M7,-5 L7,-6 L8,-5 L9,-6 L10,-5" fill="none" stroke={color} strokeWidth="0.4"/>
    <rect x="-2" y="1" width="4" height="4" fill={color} fillOpacity="0.4"/>
  </g>
);

const FMG_Cathedral = ({x,y,s=1,color="#8a8a7a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-6,4 L-6,-2 L0,-6 L6,-2 L6,4" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8"/>
    <path d="M-2,-2 L0,-5 L2,-2" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M0,-6 L0,-8" stroke={color} strokeWidth="0.6"/>
    <circle cx="0" cy="-8" r="0.5" fill={color}/>
    <circle cx="0" cy="-1" r="1.5" fill="none" stroke={color} strokeWidth="0.4"/>
    <line x1="-4" y1="0" x2="-4" y2="4" stroke={color} strokeWidth="0.5"/>
    <line x1="0" y1="0" x2="0" y2="4" stroke={color} strokeWidth="0.5"/>
    <line x1="4" y1="0" x2="4" y2="4" stroke={color} strokeWidth="0.5"/>
  </g>
);

const FMG_Windmill = ({x,y,s=1,color="#8a7a60"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-2" y="-1" width="4" height="6" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.7"/>
    <circle cx="0" cy="-1" r="2.5" fill="none" stroke={color} strokeWidth="0.6"/>
    <path d="M0,-1 L1.5,-3 L1,-0.5 L2.5,1 L1,0.5 L1.5,3 L0,1.5 L-1.5,3 L-1,0.5 L-2.5,1 L-1,-0.5 L-1.5,-3 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <path d="M0,-1 L0,5" stroke={color} strokeWidth="0.5" opacity="0.5"/>
    <circle cx="0" cy="5" r="0.5" fill={color} opacity="0.4"/>
  </g>
);

const FMG_Farm = ({x,y,s=1,color="#8a7a50"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <rect x="-4" y="-2" width="8" height="6" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.7" rx="0.5"/>
    <path d="M-4,2 L0,-1 L4,2" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <line x1="-6" y1="0" x2="-6" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="-6" y1="0" x2="-8" y2="0" stroke={color} strokeWidth="0.6"/>
    <line x1="-6" y1="4" x2="-8" y2="4" stroke={color} strokeWidth="0.6"/>
    <line x1="-8" y1="0" x2="-8" y2="4" stroke={color} strokeWidth="0.6"/>
    <path d="M6,1 L6,3 L7,3 L7,1" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <path d="M-2,3 L-2,5 L0,5 L0,3" stroke={color} strokeWidth="0.4" opacity="0.5"/>
    <path d="M2,3 L2,5 L4,5 L4,3" stroke={color} strokeWidth="0.4" opacity="0.5"/>
  </g>
);

const FMG_Graveyard = ({x,y,s=1,color="#6a6a70"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-6,4 L-6,1 L-4,0 L-4,4" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.6"/>
    <path d="M-4,2 L-2,1 L0,2" fill="none" stroke={color} strokeWidth="0.6"/>
    <path d="M-1,4 L-1,0 L1,0 L1,4" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.6"/>
    <path d="M0,2 L2,1 L4,2" fill="none" stroke={color} strokeWidth="0.6"/>
    <path d="M4,4 L4,0 L6,-1 L6,4" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.6"/>
    <path d="M5,2 L6.5,1 L7.5,2" fill="none" stroke={color} strokeWidth="0.5"/>
  </g>
);

const FMG_Well = ({x,y,s=1,color="#8a8078"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-5,2 L-5,-1 Q-5,-3 -2,-3 L2,-3 Q5,-3 5,-1 L5,2" fill="none" stroke={color} strokeWidth="0.8"/>
    <ellipse cx="0" cy="2" rx="5" ry="2" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M-6,-1 L-8,-4 L-6,-3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <path d="M6,-1 L8,-4 L6,-3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.5"/>
    <line x1="-8" y1="-4" x2="8" y2="-4" stroke={color} strokeWidth="0.5"/>
    <path d="M0,-4 Q-1,-5 0,-6" fill="none" stroke={color} strokeWidth="0.5"/>
    <circle cx="0" cy="-5.5" r="0.4" fill={color} opacity="0.4"/>
  </g>
);

const FMG_Totem = ({x,y,s=1,color="#8a6a50"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-2,-6 L-2,-8 L0,-8 L0,-6 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.6"/>
    <path d="M-0.5,-6 L-1.5,-6 L-1,-5 L0.5,-5 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.6"/>
    <path d="M-1,-5 L-2,-3 L2,-3 L1,-5" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6"/>
    <path d="M-1.5,-3 L-2,-1 L2,-1 L1.5,-3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.6"/>
    <path d="M-1,-1 L-1.5,2 L1.5,2 L1,-1" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.6"/>
    <circle cx="-1" cy="-6.5" r="0.5" fill={color} opacity="0.5"/>
    <circle cx="0.5" cy="-4.5" r="0.4" fill={color} opacity="0.4"/>
    <circle cx="-0.5" cy="-1" r="0.4" fill={color} opacity="0.4"/>
  </g>
);

const FMG_Crystal = ({x,y,s=1,color="#7a7aa0"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-1,-6 L-3,-1 L-1,3 L1,3 L3,-1 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.8"/>
    <path d="M1,-6 L-1,-6 L1,3" fill={color} fillOpacity="0.1" stroke={color} strokeWidth="0.6"/>
    <path d="M-1,-6 L3,-1 L1,3" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.6"/>
    <line x1="-1" y1="-6" x2="1" y2="3" stroke={color} strokeWidth="0.4" opacity="0.4"/>
    <path d="M-2,0 L2,0" stroke={color} strokeWidth="0.5" opacity="0.5"/>
  </g>
);

const FMG_Geyser = ({x,y,s=1,color="#a0a080"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-4,4 L-3,-1 L3,-1 L4,4 Z" fill={color} fillOpacity="0.15" stroke={color} strokeWidth="0.8"/>
    <path d="M-2,-1 Q-2,-4 -1,-6" fill="none" stroke="#4a88b0" strokeWidth="1" opacity="0.5"/>
    <path d="M0,-1 Q0,-5 1,-8" fill="none" stroke="#4a88b0" strokeWidth="1.2" opacity="0.6"/>
    <path d="M2,-1 Q2,-4 3,-6" fill="none" stroke="#4a88b0" strokeWidth="1" opacity="0.5"/>
    <path d="M-1,-8 L0,-10 L1,-8" fill="#4a88b0" fillOpacity="0.3"/>
    <path d="M-4,4 L4,4" stroke={color} strokeWidth="0.5" opacity="0.5"/>
  </g>
);

const FMG_Coral = ({x,y,s=1,color="#c0805a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-1,-6 L-2,-3 L-1,0 L0,-2" fill="none" stroke={color} strokeWidth="1" strokeLinecap="round"/>
    <path d="M0,-6 L1,-3 L0,0 L1,-2" fill="none" stroke={color} strokeWidth="1" strokeLinecap="round"/>
    <path d="M1,-6 L3,-2 L2,2 L3,0" fill="none" stroke={color} strokeWidth="1" strokeLinecap="round"/>
    <path d="M-3,-4 L-4,-2 L-3,1" fill="none" stroke={color} strokeWidth="0.8" strokeLinecap="round" opacity="0.7"/>
    <path d="M2,-4 L4,-2 L3,1" fill="none" stroke={color} strokeWidth="0.8" strokeLinecap="round" opacity="0.7"/>
    <circle cx="0" cy="-6" r="0.5" fill={color} opacity="0.5"/>
    <circle cx="-1" cy="0" r="0.4" fill={color} opacity="0.4"/>
    <circle cx="1" cy="0" r="0.4" fill={color} opacity="0.4"/>
  </g>
);

const FMG_Anchor = ({x,y,s=1,color="#7a7a8a"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-1,-6 L-1,2" stroke={color} strokeWidth="1"/>
    <path d="M-3,2 L3,2" stroke={color} strokeWidth="1.2"/>
    <path d="M-3,2 L-2,-2 L0,-3" fill="none" stroke={color} strokeWidth="0.8"/>
    <path d="M3,2 L2,-2 L0,-3" fill="none" stroke={color} strokeWidth="0.8"/>
    <path d="M-1,0 L-3,0" stroke={color} strokeWidth="0.5"/>
    <path d="M-1,0 L1,0" stroke={color} strokeWidth="0.5"/>
    <circle cx="-1" cy="-6" r="0.6" fill={color} opacity="0.5"/>
    <path d="M-2,3 L-1,4 L0,3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
    <path d="M1,3 L2,4 L3,3" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.4"/>
  </g>
);

const FMG_Flag = ({x,y,s=1,color="#d04040"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <line x1="0" y1="-6" x2="0" y2="4" stroke="#5a4a30" strokeWidth="0.8"/>
    <path d="M0,-5 Q3,-6 4,-4 Q3,-2 0,-3 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.7" strokeLinecap="round"/>
    <path d="M0,-2 Q3,-1 4,1 Q3,2 0,1 Z" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.6" strokeLinecap="round"/>
    <circle cx="0" cy="4" r="0.5" fill="#5a4a30" opacity="0.6"/>
  </g>
);

const FMG_Fire = ({x,y,s=1,color="#ff6030"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-1,3 L-2,0 L-1,-2 L0,-3 L1,-2 L2,0 L1,3 Z" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.7"/>
    <path d="M-1,2 Q-0.5,0 0,-1 Q0.5,0 1,2" fill={color} fillOpacity="0.5" stroke={color} strokeWidth="0.5"/>
    <path d="M-1,1 L0,-1 L1,1" fill="#ffb030" fillOpacity="0.4"/>
    <path d="M-2,3 L2,3" stroke="#5a4030" strokeWidth="0.8"/>
    <path d="M-1.5,3.5 L-1,3.5 L-0.5,4" fill="#8a6030" fillOpacity="0.4"/>
    <path d="M0.5,3.5 L1,3.5 L1.5,4" fill="#8a6030" fillOpacity="0.4"/>
  </g>
);

const FMG_Mushroom = ({x,y,s=1,color="#c06050"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M-4,-2 Q-5,-5 -2,-6 Q2,-6 5,-3 Q4,-1 0,-1 Q-3,-1 -4,-2" fill={color} fillOpacity="0.3" stroke={color} strokeWidth="0.8"/>
    <path d="M0,0 L0,4" stroke="#8a6a40" strokeWidth="1"/>
    <circle cx="-2.5" cy="-3" r="0.6" fill="#ffb030" fillOpacity="0.4"/>
    <circle cx="0" cy="-5" r="0.6" fill="#ffb030" fillOpacity="0.4"/>
    <circle cx="2.5" cy="-3" r="0.6" fill="#ffb030" fillOpacity="0.4"/>
    <ellipse cx="0" cy="4" rx="3" ry="1" fill={color} fillOpacity="0.2" stroke={color} strokeWidth="0.5"/>
  </g>
);

const FMG_Web = ({x,y,s=1,color="#a0a0a0"}) => (
  <g transform={`translate(${x},${y}) scale(${s})`}>
    <path d="M0,-6 L6,6" stroke={color} strokeWidth="0.5" opacity="0.6"/>
    <path d="M0,-6 L-6,6" stroke={color} strokeWidth="0.5" opacity="0.6"/>
    <path d="M0,-6 L0,6" stroke={color} strokeWidth="0.5" opacity="0.6"/>
    <path d="M-6,0 L6,0" stroke={color} strokeWidth="0.5" opacity="0.6"/>
    <path d="M-4,-4 L4,4" stroke={color} strokeWidth="0.5" opacity="0.5"/>
    <path d="M4,-4 L-4,4" stroke={color} strokeWidth="0.5" opacity="0.5"/>
    <circle cx="0" cy="-4" r="3" fill="none" stroke={color} strokeWidth="0.4" opacity="0.5"/>
    <circle cx="0" cy="-4" r="5" fill="none" stroke={color} strokeWidth="0.3" opacity="0.4"/>
    <circle cx="0" cy="0" r="0.8" fill={color} fillOpacity="0.5"/>
  </g>
);

// ═══════════════════════════════════════════════════════════════════════════
// TERRAIN PATTERN GENERATORS
// ═══════════════════════════════════════════════════════════════════════════

function generateTerrainPatterns() {
  return [
    {id: "pattern_ocean", pattern: (
      <pattern id="pattern_ocean" patternUnits="userSpaceOnUse" width="20" height="20" key="ocean">
        <rect width="20" height="20" fill="#3a7ab0"/>
        <path d="M0,5 Q5,3 10,5 T20,5" stroke="#5a9ac0" strokeWidth="0.5" fill="none" opacity="0.6"/>
        <path d="M0,12 Q5,10 10,12 T20,12" stroke="#5a9ac0" strokeWidth="0.5" fill="none" opacity="0.5"/>
      </pattern>
    )},
    {id: "pattern_deepocean", pattern: (
      <pattern id="pattern_deepocean" patternUnits="userSpaceOnUse" width="20" height="20" key="deepocean">
        <rect width="20" height="20" fill="#1a5a8a"/>
        <circle cx="5" cy="5" r="1" fill="#3a7ab0" opacity="0.5"/>
        <circle cx="15" cy="15" r="1" fill="#3a7ab0" opacity="0.5"/>
      </pattern>
    )},
    {id: "pattern_forest", pattern: (
      <pattern id="pattern_forest" patternUnits="userSpaceOnUse" width="16" height="16" key="forest">
        <rect width="16" height="16" fill="#4a7a40"/>
        <circle cx="4" cy="4" r="3" fill="#3a6a30" opacity="0.7"/>
        <circle cx="12" cy="8" r="2.5" fill="#3a6a30" opacity="0.6"/>
        <circle cx="8" cy="12" r="2.5" fill="#2a5a20" opacity="0.6"/>
      </pattern>
    )},
    {id: "pattern_desert", pattern: (
      <pattern id="pattern_desert" patternUnits="userSpaceOnUse" width="24" height="24" key="desert">
        <rect width="24" height="24" fill="#d4a860"/>
        <circle cx="3" cy="3" r="1" fill="#c09850" opacity="0.5"/>
        <circle cx="15" cy="8" r="0.8" fill="#c09850" opacity="0.4"/>
        <circle cx="20" cy="18" r="0.9" fill="#c09850" opacity="0.5"/>
      </pattern>
    )},
    {id: "pattern_mountain", pattern: (
      <pattern id="pattern_mountain" patternUnits="userSpaceOnUse" width="16" height="16" key="mountain">
        <rect width="16" height="16" fill="#8a8a80"/>
        <line x1="0" y1="8" x2="16" y2="8" stroke="#6a6a60" strokeWidth="0.4" opacity="0.5"/>
        <line x1="0" y1="4" x2="16" y2="4" stroke="#6a6a60" strokeWidth="0.3" opacity="0.4"/>
      </pattern>
    )},
    {id: "pattern_tundra", pattern: (
      <pattern id="pattern_tundra" patternUnits="userSpaceOnUse" width="20" height="20" key="tundra">
        <rect width="20" height="20" fill="#c0c0c0"/>
        <path d="M2,10 L3,8 L4,10" stroke="#a0a0a0" strokeWidth="0.5" fill="none" opacity="0.6"/>
        <path d="M12,10 L13,8 L14,10" stroke="#a0a0a0" strokeWidth="0.5" fill="none" opacity="0.6"/>
      </pattern>
    )},
    {id: "pattern_swamp", pattern: (
      <pattern id="pattern_swamp" patternUnits="userSpaceOnUse" width="16" height="16" key="swamp">
        <rect width="16" height="16" fill="#6a7a60"/>
        <path d="M2,8 Q4,10 6,8" stroke="#8a9a70" strokeWidth="0.5" fill="none" opacity="0.5"/>
        <path d="M10,8 Q12,10 14,8" stroke="#8a9a70" strokeWidth="0.5" fill="none" opacity="0.5"/>
      </pattern>
    )},
    {id: "pattern_grassland", pattern: (
      <pattern id="pattern_grassland" patternUnits="userSpaceOnUse" width="12" height="12" key="grassland">
        <rect width="12" height="12" fill="#7a9a50"/>
        <line x1="0" y1="6" x2="3" y2="3" stroke="#6a8a40" strokeWidth="0.4" opacity="0.6"/>
        <line x1="4" y1="6" x2="7" y2="3" stroke="#6a8a40" strokeWidth="0.4" opacity="0.6"/>
        <line x1="8" y1="6" x2="11" y2="3" stroke="#6a8a40" strokeWidth="0.4" opacity="0.6"/>
      </pattern>
    )},
  ];
}

// ═══════════════════════════════════════════════════════════════════════════
// MAP DECORATIVE ELEMENTS
// ═══════════════════════════════════════════════════════════════════════════

const FMG_CartoucheFrame = ({x, y, width, height, title, subtitle}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x="0" y="0" width={width} height={height} fill="none" stroke="#5a5050" strokeWidth="1.5" opacity="0.6"/>
    <rect x="2" y="2" width={width-4} height={height-4} fill="none" stroke="#5a5050" strokeWidth="0.5" opacity="0.4"/>
    <path d={`M5,5 L15,0 L25,5`} fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.5"/>
    <path d={`M${width-25},5 L${width-15},0 L${width-5},5`} fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.5"/>
    <path d={`M5,${height-5} L15,${height} L25,${height-5}`} fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.5"/>
    <path d={`M${width-25},${height-5} L${width-15},${height} L${width-5},${height-5}`} fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.5"/>
    <text x={width/2} y={height/2-8} textAnchor="middle" fill="#5a5050" fontSize="20" fontFamily="'Cinzel', serif" fontWeight="bold" opacity="0.8">{title}</text>
    {subtitle && <text x={width/2} y={height/2+8} textAnchor="middle" fill="#5a5050" fontSize="12" fontFamily="'Spectral', serif" opacity="0.6">{subtitle}</text>}
  </g>
);

const FMG_CompassRose_Detailed = ({x, y, size}) => (
  <g transform={`translate(${x},${y}) scale(${size/100})`}>
    <circle cx="0" cy="0" r="45" fill="none" stroke="#5a5050" strokeWidth="1" opacity="0.5"/>
    <circle cx="0" cy="0" r="38" fill="none" stroke="#5a5050" strokeWidth="0.5" opacity="0.3"/>
    <path d="M0,-50 L5,-15 L0,0 L-5,-15 Z" fill="#5a5050" fillOpacity="0.4" stroke="#5a5050" strokeWidth="0.6"/>
    <path d="M0,50 L5,15 L0,0 L-5,15 Z" fill="#5a5050" fillOpacity="0.2" stroke="#5a5050" strokeWidth="0.4"/>
    <path d="M50,0 L15,5 L0,0 L15,-5 Z" fill="#5a5050" fillOpacity="0.2" stroke="#5a5050" strokeWidth="0.4"/>
    <path d="M-50,0 L-15,5 L0,0 L-15,-5 Z" fill="#5a5050" fillOpacity="0.2" stroke="#5a5050" strokeWidth="0.4"/>
    <path d="M35,-35 L10,-10 L0,0 L-10,-10 Z" fill="#5a5050" fillOpacity="0.15" stroke="#5a5050" strokeWidth="0.3"/>
    <path d="M35,35 L10,10 L0,0 L-10,10 Z" fill="#5a5050" fillOpacity="0.15" stroke="#5a5050" strokeWidth="0.3"/>
    <path d="M-35,35 L-10,10 L0,0 L10,10 Z" fill="#5a5050" fillOpacity="0.15" stroke="#5a5050" strokeWidth="0.3"/>
    <path d="M-35,-35 L-10,-10 L0,0 L10,-10 Z" fill="#5a5050" fillOpacity="0.15" stroke="#5a5050" strokeWidth="0.3"/>
    <circle cx="0" cy="0" r="8" fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.6"/>
    <circle cx="0" cy="0" r="3" fill="#5a5050" fillOpacity="0.4"/>
    <text x="0" y="-55" textAnchor="middle" fill="#5a5050" fontSize="18" fontFamily="'Cinzel', serif" fontWeight="700" opacity="0.7">N</text>
    <text x="0" y="65" textAnchor="middle" fill="#5a5050" fontSize="14" fontFamily="'Cinzel', serif" opacity="0.4">S</text>
    <text x="65" y="5" textAnchor="middle" fill="#5a5050" fontSize="14" fontFamily="'Cinzel', serif" opacity="0.4">E</text>
    <text x="-65" y="5" textAnchor="middle" fill="#5a5050" fontSize="14" fontFamily="'Cinzel', serif" opacity="0.4">W</text>
  </g>
);

const FMG_ScaleBar_Detailed = ({x, y, width}) => (
  <g transform={`translate(${x},${y})`}>
    <line x1="0" y1="0" x2={width} y2="0" stroke="#5a5050" strokeWidth="2" opacity="0.6"/>
    <line x1="0" y1="-6" x2="0" y2="6" stroke="#5a5050" strokeWidth="1.2" opacity="0.6"/>
    <line x1={width/4} y1="-3" x2={width/4} y2="3" stroke="#5a5050" strokeWidth="0.8" opacity="0.5"/>
    <line x1={width/2} y1="-4" x2={width/2} y2="4" stroke="#5a5050" strokeWidth="1" opacity="0.5"/>
    <line x1={3*width/4} y1="-3" x2={3*width/4} y2="3" stroke="#5a5050" strokeWidth="0.8" opacity="0.5"/>
    <line x1={width} y1="-6" x2={width} y2="6" stroke="#5a5050" strokeWidth="1.2" opacity="0.6"/>
    <text x={width/2} y="20" textAnchor="middle" fill="#5a5050" fontSize="11" fontFamily="'Spectral', serif" opacity="0.6">50 leagues</text>
  </g>
);

const FMG_MapBorder = ({width, height}) => (
  <g>
    <rect x="10" y="10" width={width-20} height={height-20} fill="none" stroke="#5a5050" strokeWidth="2" opacity="0.5"/>
    <rect x="8" y="8" width={width-16} height={height-16} fill="none" stroke="#5a5050" strokeWidth="0.5" opacity="0.3"/>
    <path d="M15,15 L25,10 L35,15" fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.4"/>
    <path d={`M${width-35},15 L${width-25},10 L${width-15},15`} fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.4"/>
    <path d={`M15,${height-15} L25,${height-10} L35,${height-15}`} fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.4"/>
    <path d={`M${width-35},${height-15} L${width-25},${height-10} L${width-15},${height-15}`} fill="none" stroke="#5a5050" strokeWidth="0.8" opacity="0.4"/>
  </g>
);

const FMG_LegendBox = ({x, y, items}) => (
  <g transform={`translate(${x},${y})`}>
    <rect x="0" y="0" width="200" height={Math.min(items.length * 24 + 20, 400)} fill="white" fillOpacity="0.85" stroke="#5a5050" strokeWidth="1" rx="2"/>
    <text x="10" y="18" fill="#5a5050" fontSize="14" fontFamily="'Cinzel', serif" fontWeight="bold">Legend</text>
    {items.map((item, idx) => (
      <g key={idx} transform={`translate(0, ${30 + idx * 24})`}>
        <rect x="10" y="0" width="16" height="16" fill={item.color} fillOpacity="0.3" stroke={item.color} strokeWidth="0.5"/>
        <text x="35" y="13" fill="#5a5050" fontSize="12" fontFamily="'Spectral', serif">{item.label}</text>
      </g>
    ))}
  </g>
);

// ═══════════════════════════════════════════════════════════════════════════
// LABEL PLACEMENT SYSTEM
// ═══════════════════════════════════════════════════════════════════════════

const LABEL_STYLES = {
  capital: { fontSize: 16, fontWeight: "bold", fontFamily: "'Cinzel', serif", fill: "#2a2a20", opacity: 0.9 },
  city: { fontSize: 13, fontWeight: "600", fontFamily: "'Spectral', serif", fill: "#3a3a30", opacity: 0.85 },
  town: { fontSize: 11, fontWeight: "500", fontFamily: "'Spectral', serif", fill: "#4a4a40", opacity: 0.8 },
  village: { fontSize: 9, fontWeight: "400", fontFamily: "'Spectral', serif", fill: "#5a5a50", opacity: 0.75 },
  settlement: { fontSize: 8, fontFamily: "'Spectral', serif", fill: "#6a6a60", opacity: 0.7 },
  sea: { fontSize: 14, fontStyle: "italic", fontFamily: "'Spectral', serif", fill: "#3a6a9a", opacity: 0.6 },
  mountain: { fontSize: 11, fontWeight: "bold", fontFamily: "'Spectral', serif", fill: "#5a4a40", opacity: 0.7 },
  region: { fontSize: 18, fontWeight: "bold", fontFamily: "'Cinzel', serif", fill: "#4a4a3a", opacity: 0.5 },
};

function calculateLabelPositions(entities, viewport, zoom) {
  const labels = [];
  const placedBounds = [];

  function checkOverlap(x, y, width, height) {
    const buffer = 5;
    return placedBounds.some(b =>
      x < b.x2 + buffer && x + width > b.x1 - buffer &&
      y < b.y2 + buffer && y + height > b.y1 - buffer
    );
  }

  function addLabel(text, x, y, style, rotation = 0) {
    const estWidth = text.length * (style.fontSize * 0.5);
    const estHeight = style.fontSize * 1.2;
    if (!checkOverlap(x - estWidth/2, y - estHeight/2, estWidth, estHeight)) {
      labels.push({text, x, y, ...style, rotation});
      placedBounds.push({
        x1: x - estWidth/2, x2: x + estWidth/2,
        y1: y - estHeight/2, y2: y + estHeight/2,
      });
      return true;
    }
    return false;
  }

  for (const entity of entities) {
    if (!entity.name) continue;
    const px = entity.x * viewport.width;
    const py = entity.y * viewport.height;
    if (px < viewport.x || px > viewport.x + viewport.width) continue;
    if (py < viewport.y || py > viewport.y + viewport.height) continue;

    const style = LABEL_STYLES[entity.type] || LABEL_STYLES.settlement;
    const offsets = [[0, -20], [20, -10], [-20, -10], [0, 20], [25, 0], [-25, 0]];

    for (const [ox, oy] of offsets) {
      if (addLabel(entity.name, px + ox, py + oy, style)) break;
    }
  }

  return labels;
}

function renderCurvedText(text, pathPoints, fontSize) {
  if (pathPoints.length < 2) return null;
  const pathId = `path_${Math.random().toString(36).substr(2, 9)}`;
  let pathD = `M ${pathPoints[0].x} ${pathPoints[0].y}`;
  for (let i = 1; i < pathPoints.length; i++) {
    const p = pathPoints[i];
    pathD += ` L ${p.x} ${p.y}`;
  }
  return (
    <g key={pathId}>
      <defs><path id={pathId} d={pathD} fill="none"/></defs>
      <text fontSize={fontSize} fontFamily="'Spectral', serif" fill="#3a6a9a" opacity="0.7">
        <textPath href={`#${pathId}`} startOffset="50%" textAnchor="middle">
          {text}
        </textPath>
      </text>
    </g>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// RELIEF SHADING & CONTOURS
// ═══════════════════════════════════════════════════════════════════════════

function generateHillshading(heightmap, gW, gH, cs) {
  const elements = [];
  const lightAngle = Math.PI * 0.75; // Northwest light
  const lightX = Math.cos(lightAngle);
  const lightY = Math.sin(lightAngle);

  for (let y = 0; y < gH; y++) {
    for (let x = 0; x < gW; x++) {
      const h = heightmap[y][x];
      let shade = 0.5;

      if (x > 0 && x < gW - 1 && y > 0 && y < gH - 1) {
        const dhdx = (heightmap[y][x+1] - heightmap[y][x-1]) / 2;
        const dhdy = (heightmap[y+1][x] - heightmap[y-1][x]) / 2;
        const nx = -dhdx;
        const ny = -dhdy;
        const nz = 1;
        const len = Math.sqrt(nx*nx + ny*ny + nz*nz);
        shade = 0.5 + 0.3 * (lightX * (nx/len) + lightY * (ny/len) + 0.2 * (nz/len));
      }

      const opacity = Math.max(0, Math.min(0.3, (shade - 0.5) * 0.6));
      elements.push(
        <rect key={`shade_${x}_${y}`} x={x*cs} y={y*cs} width={cs} height={cs}
              fill={shade > 0.5 ? "white" : "black"} fillOpacity={opacity}/>
      );
    }
  }

  return elements;
}

function generateContourLines(heightmap, gW, gH, cs, interval = 0.1) {
  const contours = [];
  const visited = Array.from({length: gH}, () => new Uint8Array(gW));

  for (let level = 0; level <= 1; level += interval) {
    for (let y = 0; y < gH; y++) {
      for (let x = 0; x < gW; x++) {
        if (visited[y][x] || Math.abs(heightmap[y][x] - level) > interval * 0.5) continue;
        visited[y][x] = 1;

        const path = [];
        const queue = [{x, y}];
        const qVisited = new Set();

        while (queue.length > 0) {
          const {x: cx, y: cy} = queue.shift();
          const key = `${cx},${cy}`;
          if (qVisited.has(key)) continue;
          qVisited.add(key);

          path.push({x: cx * cs + cs/2, y: cy * cs + cs/2});

          for (const [dx, dy] of [[1,0],[-1,0],[0,1],[0,-1]]) {
            const nx = cx + dx, ny = cy + dy;
            if (nx >= 0 && nx < gW && ny >= 0 && ny < gH &&
                Math.abs(heightmap[ny][nx] - level) < interval * 0.5) {
              queue.push({x: nx, y: ny});
            }
          }
        }

        if (path.length > 3) {
          const d = path.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
          contours.push(
            <path key={`contour_${level}_${x}_${y}`} d={d} fill="none" stroke="#a0a090"
                  strokeWidth="0.3" opacity={0.3 * (level % 0.5 === 0 ? 1 : 0.5)}/>
          );
        }
      }
    }
  }

  return contours;
}

// ═══════════════════════════════════════════════════════════════════════════
// EXPANDED WORLD GENERATION
// ═══════════════════════════════════════════════════════════════════════════

function generateLeyLines(rng, gW, gH, hmap) {
  const leyLines = [];
  const lineCount = randInt(3, 7, rng);

  for (let i = 0; i < lineCount; i++) {
    const startX = rng() * gW;
    const startY = rng() * gH;
    const angle = rng() * Math.PI * 2;
    const length = 30 + rng() * 40;
    const points = [];

    for (let t = 0; t <= length; t += 1) {
      let x = startX + Math.cos(angle) * t;
      let y = startY + Math.sin(angle) * t;

      // Avoid water
      if (x >= 0 && x < gW && y >= 0 && y < gH) {
        if (hmap[Math.floor(y)][Math.floor(x)] > 0.3) {
          points.push({x, y});
        }
      }
    }

    if (points.length > 5) {
      leyLines.push({
        id: `ley_${i}`,
        points,
        power: 50 + rng() * 100,
        type: pick(["celestial", "elemental", "life"], rng),
      });
    }
  }

  return leyLines;
}

function generateSeaCurrents(rng, gW, gH, hmap, biomeGrid) {
  const currents = [];
  const waterCells = [];

  for (let y = 0; y < gH; y++) {
    for (let x = 0; x < gW; x++) {
      const b = biomeGrid[y][x];
      if (b === "deepOcean" || b === "ocean" || b === "shallows") {
        waterCells.push({x, y});
      }
    }
  }

  if (waterCells.length > 20) {
    const currentCount = randInt(3, 6, rng);
    for (let i = 0; i < currentCount; i++) {
      const start = pick(waterCells, rng);
      let angle = rng() * Math.PI * 2;
      const strength = 0.3 + rng() * 0.7;
      const path = [];

      let x = start.x, y = start.y;
      for (let step = 0; step < 50; step++) {
        if (x < 0 || x >= gW || y < 0 || y >= gH) break;
        path.push({x, y});
        x += Math.cos(angle) * strength;
        y += Math.sin(angle) * strength;
        angle += (rng() - 0.5) * 0.3;
      }

      if (path.length > 5) {
        currents.push({
          id: `current_${i}`,
          path,
          strength,
          warm: rng() > 0.5,
        });
      }
    }
  }

  return currents;
}

function generateVolcanicZones(rng, gW, gH, hmap) {
  const zones = [];
  const zoneCount = randInt(0, 3, rng);

  for (let i = 0; i < zoneCount; i++) {
    const cx = rng() * gW;
    const cy = rng() * gH;
    const radius = 3 + rng() * 8;
    const intensity = 0.5 + rng() * 0.5;

    const vents = [];
    const ventCount = randInt(1, 4, rng);
    for (let v = 0; v < ventCount; v++) {
      const vx = cx + (rng() - 0.5) * radius * 2;
      const vy = cy + (rng() - 0.5) * radius * 2;
      if (vx >= 0 && vx < gW && vy >= 0 && vy < gH && hmap[Math.floor(vy)][Math.floor(vx)] > 0.4) {
        vents.push({x: vx, y: vy});
      }
    }

    if (vents.length > 0) {
      zones.push({
        id: `volcano_${i}`,
        centerX: cx,
        centerY: cy,
        radius,
        intensity,
        vents,
        lastEruption: randInt(-10000, 0, rng),
      });
    }
  }

  return zones;
}

function generateWeatherPatterns(rng, gW, gH, temperature, moisture, windMap) {
  const patterns = [];

  // Jet stream
  const jetStreamY = gH * (0.25 + rng() * 0.2);
  patterns.push({
    id: "jetstream",
    type: "jetstream",
    latitude: jetStreamY,
    strength: 0.6 + rng() * 0.4,
  });

  // Storm systems
  const stormCount = randInt(2, 5, rng);
  for (let i = 0; i < stormCount; i++) {
    const x = rng() * gW;
    const y = rng() * gH;
    const size = 15 + rng() * 20;
    const power = 0.5 + rng() * 0.5;

    patterns.push({
      id: `storm_${i}`,
      type: "storm",
      centerX: x,
      centerY: y,
      size,
      power,
      rotation: rng() * Math.PI * 2,
    });
  }

  // Climate zones
  patterns.push({
    id: "tropical",
    type: "climate",
    band: "equatorial",
    startY: 0,
    endY: gH * 0.25,
  });

  patterns.push({
    id: "temperate",
    type: "climate",
    band: "temperate",
    startY: gH * 0.25,
    endY: gH * 0.75,
  });

  patterns.push({
    id: "polar",
    type: "climate",
    band: "polar",
    startY: gH * 0.75,
    endY: gH,
  });

  return patterns;
}
// [deduplicated: generateWorldHistory - defined earlier]

// ═══════════════════════════════════════════════════════════════════════════
// ICON LOOKUP MAP (COMPREHENSIVE)
// ═══════════════════════════════════════════════════════════════════════════

const FMG_ICON_MAP = {
  capital: FMG_Capital, city: FMG_City, town: FMG_Town, village: FMG_Village, hamlet: FMG_Hamlet,
  dungeon: FMG_Dungeon, ruins: FMG_Ruins, tower: FMG_Tower, shrine: FMG_Shrine, cave: FMG_Cave,
  grove: FMG_Grove, monolith: FMG_Monolith, mine: FMG_Mine, fortress: FMG_Fortress, temple: FMG_Temple,
  lighthouse: FMG_Lighthouse, camp: FMG_Camp, portal: FMG_Portal, battlefield: FMG_Battlefield,
  mountain: FMG_Mountain, snowMountain: FMG_SnowMountain, hill: FMG_Hill,
  tree: FMG_Tree, pineTree: FMG_PineTree, palmTree: FMG_PalmTree, cactus: FMG_Cactus,
  waterfall: FMG_Waterfall, ship: FMG_Ship, compass: FMG_Compass, scaleBar: FMG_ScaleBar,
  volcano: FMG_Volcano, oasis: FMG_Oasis, swamp: FMG_Swamp, bridge: FMG_Bridge, port: FMG_Port,
  shipwreck: FMG_Shipwreck, dragon: FMG_Dragon, seaSerpent: FMG_SeaSerpent, treasure: FMG_Treasure,
  skull: FMG_Skull, crown: FMG_Crown, shield: FMG_Shield, sword: FMG_Sword, scroll: FMG_Scroll,
  wagon: FMG_Wagon, horse: FMG_Horse, wolf: FMG_Wolf, castle: FMG_Castle, cathedral: FMG_Cathedral,
  windmill: FMG_Windmill, farm: FMG_Farm, graveyard: FMG_Graveyard, well: FMG_Well, totem: FMG_Totem,
  crystal: FMG_Crystal, geyser: FMG_Geyser, coral: FMG_Coral, anchor: FMG_Anchor, flag: FMG_Flag,
  fire: FMG_Fire, mushroom: FMG_Mushroom, web: FMG_Web,
};

// (No export block - this file is concatenated into the app)

// ═══════════════════════════════════════════════════════════════════════════
// FANTASY MAP GENERATOR — MAIN REACT COMPONENT
// ═══════════════════════════════════════════════════════════════════════════

function FantasyMapGenerator() {
  const [seed, setSeed] = useState("DragonRealm");
  const [seedInput, setSeedInput] = useState("DragonRealm");
  const [world, setWorld] = useState(null);
  const [generating, setGenerating] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [selectedEntity, setSelectedEntity] = useState(null);
  const [hoveredEntity, setHoveredEntity] = useState(null);
  const [zoom, setZoom] = useState(0.5);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const panStart = useRef({ x:0, y:0, px:0, py:0 });
  const svgRef = useRef(null);
  const [sideTab, setSideTab] = useState("overview");
  const [searchQuery, setSearchQuery] = useState("");
  const [mapStyle, setMapStyle] = useState("terrain"); // terrain, political, physical, parchment
  const [detailTab, setDetailTab] = useState("info");
  const [showHistory, setShowHistory] = useState(false);
  const [showEncounters, setShowEncounters] = useState(false);

  const [layers, setLayers] = useState({
    terrain:true, rivers:true, roads:true, settlements:true, pois:true,
    kingdoms:true, labels:true, grid:false, icons:true, compass:true,
    heightmap:false, moisture:false, temperature:false, wind:false,
    tributaries:true, tradeRoutes:true, seaNames:true, landmarks:true,
    waterfall:true, decorations:true,
  });

  const [config, setConfig] = useState({
    gridWidth:160, gridHeight:120, continentShape:"natural", islandMask:false,
    seaLevel:0, heightOctaves:6, heightPersistence:0.52, heightLacunarity:2.1,
    latitudeBias:true, erosion:false, erosionIterations:3000,
    riverCount:10, capitals:3, cities:8, towns:15, villages:25, hamlets:35,
    kingdomCount:4, dungeons:12, ruins:10, towers:8, shrines:10, caves:10,
    groves:6, monoliths:5, mines:8, fortresses:6, temples:5, lighthouses:4,
    camps:8, portals:3, battlefields:4, partyLevel:5,
  });

  const CELL = 6;
  const mapW = config.gridWidth * CELL;
  const mapH = config.gridHeight * CELL;

  const doGenerate = useCallback((s, c) => {
    setGenerating(true);
    setTimeout(() => {
      try {
        const w = generateWorld(s||seed, c||config);
        setWorld(w);
        setSelectedEntity(null);
        setHoveredEntity(null);
        setPan({x:0,y:0});
        setZoom(0.5);
      } catch(e) { console.error("Gen error:", e); }
      setGenerating(false);
    }, 50);
  }, [seed, config]);

  useEffect(() => { doGenerate(seed, config); }, []);

  const randomSeed = () => {
    const words = ["Dragon","Storm","Shadow","Crystal","Iron","Thunder","Moon","Star","Frost","Fire","Blood","Ghost","Elder","Arcane","Mystic","Void","Dawn","Dusk","Wild","Bone","Rune","Ether","Cosmos","Nexus","Primal"];
    const s = words[Math.floor(Math.random()*words.length)] + words[Math.floor(Math.random()*words.length)] + Math.floor(Math.random()*999);
    setSeedInput(s); setSeed(s); doGenerate(s, config);
  };

  // Map interaction
  const handleWheel = useCallback((e) => { e.preventDefault(); setZoom(z=>clamp(z*(e.deltaY>0?0.9:1.1),0.12,10)); }, []);
  const handleMouseDown = useCallback((e) => { if(e.button===0){setIsPanning(true);panStart.current={x:e.clientX,y:e.clientY,px:pan.x,py:pan.y};} }, [pan]);
  const handleMouseMove = useCallback((e) => { if(isPanning) setPan({x:panStart.current.px+(e.clientX-panStart.current.x)/zoom,y:panStart.current.py+(e.clientY-panStart.current.y)/zoom}); }, [isPanning,zoom]);
  const handleMouseUp = useCallback(() => setIsPanning(false), []);

  const handleEntityClick = useCallback((entity) => { setSelectedEntity(entity); setSideTab("details"); setDetailTab("info"); }, []);
  const centerOn = useCallback((x,y) => { setPan({x:-x*CELL+mapW/2/zoom,y:-y*CELL+mapH/2/zoom}); setZoom(z=>Math.max(z,1.5)); }, [zoom,mapW,mapH]);

  // Search
  const searchResults = useCallback(() => {
    if (!world||!searchQuery.trim()) return [];
    const q = searchQuery.toLowerCase();
    const r = [];
    for (const s of world.settlements) if(s.name.toLowerCase().includes(q)) r.push({...s,category:"settlement"});
    for (const p of world.pois) if(p.name.toLowerCase().includes(q)) r.push({...p,category:"poi"});
    for (const k of world.kingdoms) if(k.name.toLowerCase().includes(q)) r.push({...k,category:"kingdom"});
    for (const rv of world.rivers) if(rv.name.toLowerCase().includes(q)) r.push({...rv,category:"river"});
    for (const l of world.landmarks) if(l.name.toLowerCase().includes(q)) r.push({...l,category:"landmark"});
    return r.slice(0,25);
  }, [world, searchQuery]);

  // Export
  const exportSVG = useCallback(() => { if(!svgRef.current) return; const b=new Blob([svgRef.current.outerHTML],{type:"image/svg+xml"}); const u=URL.createObjectURL(b); const a=document.createElement("a"); a.href=u; a.download=`${seed}-map.svg`; a.click(); URL.revokeObjectURL(u); }, [seed]);
  const exportJSON = useCallback(() => { if(!world) return; const d={seed:world.seed,settlements:world.settlements,kingdoms:world.kingdoms,rivers:world.rivers.map(r=>({name:r.name,length:r.path.length,waterfalls:r.waterfalls})),pois:world.pois,landmarks:world.landmarks,seas:world.seas,worldHistory:world.worldHistory,stats:world.stats}; const b=new Blob([JSON.stringify(d,null,2)],{type:"application/json"}); const u=URL.createObjectURL(b); const a=document.createElement("a"); a.href=u; a.download=`${seed}-world.json`; a.click(); URL.revokeObjectURL(u); }, [world,seed]);

  // Zoom-dependent rendering
  const showLabels = zoom > 0.55;
  const showDetails = zoom > 1.2;
  const showPOILabels = zoom > 1.8;
  const showSmall = zoom > 0.8;
  const showHamlets = zoom > 2;
  const showDecoIcons = zoom > 0.7;
  const renderStep = zoom < 0.35 ? 4 : zoom < 0.7 ? 2 : 1;

  // Biome color for map style
  const getBiomeColor = useCallback((biome) => {
    if (mapStyle === "parchment") {
      const h = {"deepOcean":"#c8b898","ocean":"#c0b090","shallows":"#b8a888","beach":"#e8d8b8","tundra":"#d8d0c0","snowfield":"#e8e0d0","grassland":"#c8c0a0","plains":"#d0c8a8","savanna":"#d8c898","desert":"#e0d0a0","forest":"#b0a880","denseForest":"#a09870","jungle":"#98906a","swamp":"#a8a078","hills":"#c0b890","highlands":"#b8b088","mountain":"#a8a090","snowMountain":"#d0c8b8","volcanic":"#908070","taiga":"#a0a078","steppe":"#c8c098","mesa":"#c8a880","oasis":"#b0b888","reef":"#b0b8a8","glacier":"#c8d0c0","marshland":"#a8a870","badlands":"#b89870"};
      return h[biome] || "#c0b898";
    }
    if (mapStyle === "political") return "rgba(200,195,185,0.3)";
    return BIOMES[biome]?.color || "#888";
  }, [mapStyle]);

  // ─── RENDER ────────────────────────────────────────────────────────────

  return (
    <div style={{ display:"flex", height:"calc(100vh - 56px)", overflow:"hidden", background:T.bg }}>

      {/* ═══ LEFT SIDEBAR ═══ */}
      <div style={{ width:340, flexShrink:0, borderRight:`1px solid ${T.border}`, display:"flex", flexDirection:"column", background:T.bgNav, overflow:"hidden" }}>

        {/* Seed Controls */}
        <div style={{ padding:14, borderBottom:`1px solid ${T.border}` }}>
          <div style={{ fontFamily:T.ui, fontSize:9, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase", fontWeight:500, marginBottom:8, display:"flex", alignItems:"center", gap:6 }}>
            <Wand2 size={12}/> Map Forge
          </div>
          <div style={{ display:"flex", gap:5, marginBottom:6 }}>
            <Input value={seedInput} onChange={setSeedInput} placeholder="World seed..." style={{ flex:1, fontSize:11, padding:"5px 9px" }} />
            <button onClick={randomSeed} title="Random seed" style={{ background:T.bgCard, border:`1px solid ${T.border}`, borderRadius:2, cursor:"pointer", padding:"5px 9px", color:T.textMuted, display:"flex", alignItems:"center" }}><RefreshCw size={11}/></button>
          </div>
          <div style={{ display:"flex", gap:5, marginBottom:8 }}>
            <CrimsonBtn small onClick={()=>{setSeed(seedInput);doGenerate(seedInput,config);}} style={{ flex:1, justifyContent:"center" }}>
              {generating ? <><RefreshCw size={10} style={{animation:"spin 1s linear infinite"}}/> Forging...</> : <><Wand2 size={10}/> Generate</>}
            </CrimsonBtn>
            <CrimsonBtn small secondary onClick={()=>setShowConfig(!showConfig)}><Settings size={10}/></CrimsonBtn>
          </div>
          {/* Map Style */}
          <div style={{ display:"flex", gap:4 }}>
            {["terrain","political","parchment"].map(s => (
              <button key={s} onClick={()=>setMapStyle(s)} style={{
                flex:1, padding:"4px 0", background:mapStyle===s?T.crimsonSoft:"transparent",
                border:`1px solid ${mapStyle===s?T.crimsonBorder:T.borderMid}`, borderRadius:2, cursor:"pointer",
                fontFamily:T.ui, fontSize:6, letterSpacing:"1px", textTransform:"uppercase",
                color:mapStyle===s?T.crimson:T.textFaint,
              }}>{s}</button>
            ))}
          </div>
        </div>

        {/* Config Panel */}
        {showConfig && (
          <div style={{ padding:14, borderBottom:`1px solid ${T.border}`, maxHeight:420, overflowY:"auto" }}>
            <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", marginBottom:8 }}>World Configuration</div>
            <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
              <div>
                <label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>Continent Shape</label>
                <Select value={config.continentShape} onChange={v=>setConfig(c=>({...c,continentShape:v}))} style={{ width:"100%", fontSize:10, padding:"4px 7px" }}>
                  <option value="natural">Natural</option>
                  <option value="pangaea">Pangaea</option>
                  <option value="archipelago">Archipelago</option>
                  <option value="two_continents">Two Continents</option>
                </Select>
              </div>
              <div style={{ display:"flex", gap:6 }}>
                <div style={{ flex:1 }}><label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>Width</label><Input type="number" value={config.gridWidth} onChange={v=>setConfig(c=>({...c,gridWidth:parseInt(v)||120}))} style={{ fontSize:10, padding:"4px 7px" }} /></div>
                <div style={{ flex:1 }}><label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>Height</label><Input type="number" value={config.gridHeight} onChange={v=>setConfig(c=>({...c,gridHeight:parseInt(v)||90}))} style={{ fontSize:10, padding:"4px 7px" }} /></div>
              </div>
              {[["seaLevel","Sea Level",-3,3],["heightOctaves","Terrain Detail",2,8],["heightPersistence","Roughness",0.3,0.7,0.02]].map(([k,l,mn,mx,step])=>(
                <div key={k}><label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>{l}: {typeof config[k]==="number"&&config[k]%1?config[k].toFixed(2):config[k]}</label><input type="range" min={mn} max={mx} step={step||1} value={config[k]} onChange={e=>setConfig(c=>({...c,[k]:step?parseFloat(e.target.value):parseInt(e.target.value)}))} style={{ width:"100%" }}/></div>
              ))}
              <ToggleSwitch on={config.islandMask} onToggle={()=>setConfig(c=>({...c,islandMask:!c.islandMask}))} label="Island Mask" />
              <ToggleSwitch on={config.latitudeBias} onToggle={()=>setConfig(c=>({...c,latitudeBias:!c.latitudeBias}))} label="Latitude Temperature" />
              <ToggleSwitch on={config.erosion} onToggle={()=>setConfig(c=>({...c,erosion:!c.erosion}))} label="Hydraulic Erosion" />
              {config.erosion && <div><label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>Erosion Iterations: {config.erosionIterations}</label><input type="range" min={500} max={10000} step={500} value={config.erosionIterations} onChange={e=>setConfig(c=>({...c,erosionIterations:parseInt(e.target.value)}))} style={{ width:"100%" }}/></div>}

              <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", marginTop:6 }}>Party Level (for encounters)</div>
              <div><label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>Level: {config.partyLevel}</label><input type="range" min={1} max={20} step={1} value={config.partyLevel} onChange={e=>setConfig(c=>({...c,partyLevel:parseInt(e.target.value)}))} style={{ width:"100%" }}/></div>

              <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", marginTop:6 }}>Settlements</div>
              {[["capitals","Capitals",1,6],["cities","Cities",2,20],["towns","Towns",5,40],["villages","Villages",0,60],["hamlets","Hamlets",0,80]].map(([k,l,mn,mx])=>(
                <div key={k}><label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>{l}: {config[k]}</label><input type="range" min={mn} max={mx} step={1} value={config[k]} onChange={e=>setConfig(c=>({...c,[k]:parseInt(e.target.value)}))} style={{ width:"100%" }}/></div>
              ))}
              <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", marginTop:6 }}>Features</div>
              {[["riverCount","Rivers",0,20],["kingdomCount","Kingdoms",1,10],["dungeons","Dungeons",0,25],["ruins","Ruins",0,25],["towers","Towers",0,20],["caves","Caves",0,20],["shrines","Shrines",0,20],["mines","Mines",0,15],["fortresses","Fortresses",0,15],["temples","Temples",0,12],["portals","Portals",0,8],["battlefields","Battlefields",0,10]].map(([k,l,mn,mx])=>(
                <div key={k}><label style={{ fontSize:10, color:T.textDim, display:"block", marginBottom:3 }}>{l}: {config[k]}</label><input type="range" min={mn} max={mx} step={1} value={config[k]} onChange={e=>setConfig(c=>({...c,[k]:parseInt(e.target.value)}))} style={{ width:"100%" }}/></div>
              ))}
            </div>
          </div>
        )}

        {/* Sidebar Tabs */}
        <div style={{ display:"flex", borderBottom:`1px solid ${T.border}` }}>
          {[{id:"overview",label:"Overview",icon:Globe},{id:"search",label:"Search",icon:Search},{id:"layers",label:"Layers",icon:Layers},{id:"details",label:"Details",icon:Eye},{id:"lore",label:"Lore",icon:BookOpen}].map(t=>(
            <button key={t.id} onClick={()=>setSideTab(t.id)} style={{ flex:1, padding:"8px 0", background:"transparent", border:"none", cursor:"pointer", borderBottom:sideTab===t.id?`2px solid ${T.crimson}`:"2px solid transparent", color:sideTab===t.id?T.crimson:T.textMuted, display:"flex", alignItems:"center", justifyContent:"center", gap:3, fontFamily:T.ui, fontSize:6, letterSpacing:"1px", textTransform:"uppercase" }}><t.icon size={9}/> {t.label}</button>
          ))}
        </div>

        {/* Sidebar Content */}
        <div style={{ flex:1, overflowY:"auto", padding:14 }}>

          {/* Overview Tab */}
          {sideTab==="overview" && world && (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              <div style={{ fontSize:15, fontWeight:300, color:T.text }}>{world.seed}</div>
              <div style={{ fontSize:10, color:T.textDim, fontWeight:300 }}>{world.gridW}x{world.gridH} grid | {world.stats.totalPop.toLocaleString()} total population</div>
              <div style={{ fontSize:10, color:T.textDim }}>{Math.round(world.stats.landCells/(world.stats.landCells+world.stats.waterCells)*100)}% land / {Math.round(world.stats.waterCells/(world.stats.landCells+world.stats.waterCells)*100)}% water</div>

              <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:6 }}>
                {[{l:"Kingdoms",v:world.kingdoms.length,i:Crown},{l:"Settlements",v:world.settlements.length,i:MapPin},{l:"Rivers",v:world.rivers.length,i:Activity},{l:"POIs",v:world.pois.length,i:Target},{l:"Landmarks",v:world.landmarks.length,i:Mountain},{l:"Seas",v:world.seas.length,i:Globe}].map(s=>(
                  <div key={s.l} style={{ padding:8, background:T.bgCard, border:`1px solid ${T.borderMid}`, borderRadius:2, textAlign:"center" }}>
                    <s.i size={10} color={T.crimson} style={{ display:"block", margin:"0 auto 3px" }}/>
                    <div style={{ fontSize:16, fontWeight:300, color:T.text }}>{s.v}</div>
                    <div style={{ fontFamily:T.ui, fontSize:6, letterSpacing:"1px", color:T.textFaint, textTransform:"uppercase" }}>{s.l}</div>
                  </div>
                ))}
              </div>

              {/* Kingdoms */}
              <div>
                <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.crimson, textTransform:"uppercase", marginBottom:6 }}>Kingdoms</div>
                {world.kingdoms.map((k,i)=>(
                  <div key={i} onClick={()=>{setSelectedEntity({...k,entityType:"kingdom"});setSideTab("details");}} style={{ padding:"6px 8px", cursor:"pointer", borderBottom:`1px solid ${T.borderMid}`, display:"flex", justifyContent:"space-between", alignItems:"center", transition:"background 0.15s" }}>
                    <div>
                      <div style={{ fontSize:11, color:T.text, fontWeight:300 }}>{k.name}</div>
                      <div style={{ fontSize:9, color:T.textFaint }}>{k.capital} | {k.government}</div>
                    </div>
                    <div style={{ textAlign:"right" }}>
                      <Tag>{k.settlements.length}</Tag>
                      <div style={{ fontSize:8, color:T.textFaint, marginTop:2 }}>{k.population.toLocaleString()}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Biome Distribution */}
              <div>
                <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.crimson, textTransform:"uppercase", marginBottom:6 }}>Biomes</div>
                {(()=>{
                  if(!world) return null;
                  const counts={};
                  for(let y=0;y<world.gridH;y++) for(let x=0;x<world.gridW;x++) { const b=world.biomeGrid[y][x]; counts[b]=(counts[b]||0)+1; }
                  const total=world.gridW*world.gridH;
                  return Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,12).map(([biome,count])=>(
                    <div key={biome} style={{ marginBottom:3 }}>
                      <div style={{ display:"flex", justifyContent:"space-between", fontSize:9, color:T.textDim, marginBottom:1 }}>
                        <span style={{ display:"flex", alignItems:"center", gap:3 }}><span style={{ width:7, height:7, background:BIOMES[biome]?.color||"#888", borderRadius:1, display:"inline-block" }}/>{BIOMES[biome]?.label||biome}</span>
                        <span>{(count/total*100).toFixed(1)}%</span>
                      </div>
                      <div style={{ height:2, background:T.bgInput, borderRadius:1 }}><div style={{ width:`${count/total*100}%`, height:"100%", background:BIOMES[biome]?.color||T.crimson, borderRadius:1 }}/></div>
                    </div>
                  ));
                })()}
              </div>

              <div style={{ display:"flex", gap:6, marginTop:6 }}>
                <CrimsonBtn small onClick={exportSVG} style={{ flex:1, justifyContent:"center" }}><Download size={9}/> SVG</CrimsonBtn>
                <CrimsonBtn small secondary onClick={exportJSON} style={{ flex:1, justifyContent:"center" }}><FileText size={9}/> JSON</CrimsonBtn>
              </div>
            </div>
          )}

          {/* Search Tab */}
          {sideTab==="search" && (
            <div>
              <Input value={searchQuery} onChange={setSearchQuery} placeholder="Search everything..." style={{ fontSize:11, marginBottom:10 }} />
              {searchResults().map((r,i)=>(
                <div key={i} onClick={()=>{setSelectedEntity({...r,entityType:r.category});setSideTab("details");if(r.x!=null)centerOn(r.x,r.y);}} style={{ padding:"6px 8px", cursor:"pointer", borderBottom:`1px solid ${T.borderMid}` }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                    <span style={{ fontSize:11, color:T.text, fontWeight:300 }}>{r.name}</span>
                    <Tag variant="muted">{r.category}</Tag>
                  </div>
                  {r.type && <div style={{ fontSize:9, color:T.textFaint, marginTop:1, textTransform:"capitalize" }}>{r.type}</div>}
                </div>
              ))}
              {searchQuery&&searchResults().length===0 && <p style={{ fontSize:11, color:T.textFaint, textAlign:"center", padding:16, fontStyle:"italic" }}>No results</p>}
            </div>
          )}

          {/* Layers Tab */}
          {sideTab==="layers" && (
            <div style={{ display:"flex", flexDirection:"column", gap:3 }}>
              <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", marginBottom:6 }}>Map Layers</div>
              {[{k:"terrain",l:"Terrain"},{k:"rivers",l:"Rivers"},{k:"tributaries",l:"Tributaries"},{k:"roads",l:"Roads"},{k:"tradeRoutes",l:"Trade Routes"},{k:"settlements",l:"Settlements"},{k:"pois",l:"Points of Interest"},{k:"kingdoms",l:"Kingdom Borders"},{k:"labels",l:"Labels"},{k:"icons",l:"Map Icons"},{k:"compass",l:"Compass Rose"},{k:"landmarks",l:"Landmark Names"},{k:"seaNames",l:"Sea Names"},{k:"waterfall",l:"Waterfall Markers"},{k:"decorations",l:"Decorative Elements"},{k:"grid",l:"Grid"}].map(l=>(
                <ToggleSwitch key={l.k} on={layers[l.k]} onToggle={()=>setLayers(p=>({...p,[l.k]:!p[l.k]}))} label={l.l} />
              ))}
              <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", marginTop:12, marginBottom:6 }}>Debug Overlays</div>
              {[{k:"heightmap",l:"Heightmap"},{k:"moisture",l:"Moisture"},{k:"temperature",l:"Temperature"},{k:"wind",l:"Wind"}].map(l=>(
                <ToggleSwitch key={l.k} on={layers[l.k]} onToggle={()=>setLayers(p=>({...p,[l.k]:!p[l.k]}))} label={l.l} />
              ))}
            </div>
          )}

          {/* Details Tab */}
          {sideTab==="details" && (
            <div>
              {selectedEntity ? (
                <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", alignItems:"start" }}>
                    <div>
                      <div style={{ fontSize:15, fontWeight:300, color:T.text, marginBottom:4 }}>{selectedEntity.name}</div>
                      <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
                        <Tag variant={selectedEntity.entityType==="kingdom"?"info":selectedEntity.entityType==="settlement"?"success":selectedEntity.entityType==="poi"?"warning":"muted"}>{selectedEntity.entityType}</Tag>
                        {selectedEntity.type && <Tag variant="muted">{selectedEntity.type}</Tag>}
                      </div>
                    </div>
                    <button onClick={()=>setSelectedEntity(null)} style={{ background:"none", border:"none", cursor:"pointer", color:T.textFaint }}><X size={13}/></button>
                  </div>

                  {/* Detail sub-tabs for settlements */}
                  {selectedEntity.entityType==="settlement" && (
                    <div style={{ display:"flex", gap:2, borderBottom:`1px solid ${T.borderMid}`, paddingBottom:6 }}>
                      {["info","npcs","tavern","lore","encounters"].map(t=>(
                        <button key={t} onClick={()=>setDetailTab(t)} style={{ padding:"3px 8px", background:detailTab===t?T.crimsonSoft:"transparent", border:`1px solid ${detailTab===t?T.crimsonBorder:"transparent"}`, borderRadius:2, cursor:"pointer", fontFamily:T.ui, fontSize:6, letterSpacing:"1px", color:detailTab===t?T.crimson:T.textFaint, textTransform:"uppercase" }}>{t}</button>
                      ))}
                    </div>
                  )}

                  {/* Info sub-tab */}
                  {(detailTab==="info"||selectedEntity.entityType!=="settlement") && (
                    <>
                      {selectedEntity.population!=null && <div style={{ fontSize:11, color:T.textDim }}><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Population</span>{selectedEntity.population.toLocaleString()}</div>}
                      {selectedEntity.government && <div style={{ fontSize:11, color:T.textDim }}><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Government</span>{selectedEntity.government}</div>}
                      {selectedEntity.defenses && selectedEntity.defenses!=="Minimal" && <div style={{ fontSize:11, color:T.textDim }}><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Defenses</span>{selectedEntity.defenses}</div>}
                      {selectedEntity.isCoastal!=null && <div style={{ display:"flex", gap:4, flexWrap:"wrap" }}>{selectedEntity.isCoastal&&<Tag variant="info">Coastal</Tag>}{selectedEntity.isRiverside&&<Tag variant="info">Riverside</Tag>}<Tag variant="muted">{selectedEntity.wealth}</Tag><Tag variant="muted">{selectedEntity.mood}</Tag></div>}
                      {selectedEntity.features && <div><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Notable Features</span>{selectedEntity.features.map((f,i)=><div key={i} style={{ fontSize:10, color:T.textDim, padding:"1px 0" }}>{f}</div>)}</div>}
                      {selectedEntity.exports && <div><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Exports</span><div style={{ display:"flex", gap:3, flexWrap:"wrap" }}>{selectedEntity.exports.map((e,i)=><Tag key={i} variant="muted">{e}</Tag>)}</div></div>}
                      {selectedEntity.description && <div style={{ fontSize:11, color:T.textDim, fontStyle:"italic", lineHeight:1.6 }}>{selectedEntity.description}</div>}
                      {selectedEntity.threat && <div style={{ fontSize:11 }}><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Threat</span><Tag variant={selectedEntity.threat==="deadly"||selectedEntity.threat==="extreme"?"critical":selectedEntity.threat==="high"?"danger":selectedEntity.threat==="moderate"?"warning":"success"}>{selectedEntity.threat} (CR {selectedEntity.cr})</Tag></div>}
                      {selectedEntity.occupants && <div style={{ fontSize:11, color:T.textDim }}><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Occupants</span>{selectedEntity.occupants}</div>}
                      {selectedEntity.floors && selectedEntity.floors>1 && <div style={{ fontSize:11, color:T.textDim }}>{selectedEntity.floors} floors/levels | {selectedEntity.condition}</div>}
                      {selectedEntity.treasure && selectedEntity.treasure.items?.length>0 && <div><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Treasure</span>{selectedEntity.treasure.items.map((it,i)=><div key={i} style={{ fontSize:10, color:T.textDim }}><Tag variant={it.rarity==="legendary"?"critical":it.rarity==="veryRare"?"danger":it.rarity==="rare"?"warning":"muted"}>{it.rarity}</Tag> {it.name}</div>)}<div style={{ fontSize:9, color:T.textFaint, marginTop:3 }}>{selectedEntity.treasure.coins.gold} gp | {selectedEntity.treasure.gems.length} gems</div></div>}
                      {selectedEntity.ruler && <div style={{ fontSize:11, color:T.textDim }}><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Ruler</span>{selectedEntity.ruler.title} {selectedEntity.ruler.name} ({selectedEntity.ruler.trait})</div>}
                      {selectedEntity.militaryStrength && <div style={{ fontSize:11, color:T.textDim }}>Military: {selectedEntity.militaryStrength}</div>}
                      {selectedEntity.relations && Object.keys(selectedEntity.relations).length>0 && <div><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Relations</span>{Object.entries(selectedEntity.relations).map(([name,rel],i)=><div key={i} style={{ fontSize:10, color:T.textDim, display:"flex", justifyContent:"space-between" }}><span>{name}</span><Tag variant={rel.includes("war")||rel==="hostile"?"danger":rel==="allied"||rel==="friendly"?"success":rel==="tense"||rel==="rivals"?"warning":"muted"}>{rel}</Tag></div>)}</div>}
                      {selectedEntity.settlements && <div><span style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", display:"block", marginBottom:3 }}>Settlements ({selectedEntity.settlements.length})</span>{selectedEntity.settlements.slice(0,10).map((s,i)=><div key={i} style={{ fontSize:10, color:T.textDim, padding:"1px 0" }}>{s}</div>)}{selectedEntity.settlements.length>10 && <div style={{ fontSize:9, color:T.textFaint }}>...and {selectedEntity.settlements.length-10} more</div>}</div>}
                    </>
                  )}

                  {/* NPCs sub-tab */}
                  {detailTab==="npcs" && selectedEntity.npcs && (
                    <div>{selectedEntity.npcs.map((npc,i)=>(
                      <div key={i} style={{ padding:"8px 0", borderBottom:`1px solid ${T.borderMid}` }}>
                        <div style={{ fontSize:12, color:T.text, fontWeight:300 }}>{npc.name}</div>
                        <div style={{ fontSize:10, color:T.textDim }}>{npc.race} {npc.class||""} {npc.level?`Lv.${npc.level}`:""} | {npc.role}</div>
                        <div style={{ display:"flex", gap:3, marginTop:3, flexWrap:"wrap" }}>
                          <Tag variant={npc.attitude==="friendly"||npc.attitude==="helpful"?"success":npc.attitude==="hostile"?"danger":"muted"}>{npc.attitude}</Tag>
                          {npc.traits.map((t,j)=><Tag key={j} variant="muted">{t}</Tag>)}
                        </div>
                        <div style={{ fontSize:9, color:T.textFaint, marginTop:3, fontStyle:"italic" }}>Quirk: {npc.quirk}</div>
                        <div style={{ fontSize:9, color:T.textFaint }}>Motivated by: {npc.motivation}</div>
                      </div>
                    ))}</div>
                  )}

                  {/* Tavern sub-tab */}
                  {detailTab==="tavern" && selectedEntity.tavern && (
                    <div style={{ display:"flex", flexDirection:"column", gap:8 }}>
                      <div style={{ fontSize:14, fontWeight:300, color:T.text }}>{selectedEntity.tavern.name}</div>
                      <div style={{ fontSize:11, color:T.textDim }}>Specialty: {selectedEntity.tavern.specialty}</div>
                      <div style={{ fontSize:11, color:T.textDim }}>{selectedEntity.tavern.rooms} rooms | {selectedEntity.tavern.pricePerNight} gp/night</div>
                      <div style={{ padding:10, background:T.bgInput, borderRadius:2, border:`1px solid ${T.borderMid}` }}>
                        <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.crimson, textTransform:"uppercase", marginBottom:4 }}>Rumor</div>
                        <div style={{ fontSize:11, color:T.textDim, fontStyle:"italic", lineHeight:1.6 }}>{selectedEntity.tavern.rumor}</div>
                      </div>
                    </div>
                  )}
                  {detailTab==="tavern" && !selectedEntity.tavern && <p style={{ fontSize:11, color:T.textFaint, fontStyle:"italic" }}>No tavern in this settlement.</p>}

                  {/* Lore sub-tab */}
                  {detailTab==="lore" && (
                    <div style={{ fontSize:11, color:T.textDim, lineHeight:1.7, fontStyle:"italic" }}>
                      {selectedEntity.lore || "No recorded lore for this location."}
                    </div>
                  )}

                  {/* Encounters sub-tab */}
                  {detailTab==="encounters" && world && selectedEntity.biome && (
                    <div>
                      <div style={{ fontFamily:T.ui, fontSize:7, letterSpacing:"1px", color:T.textMuted, textTransform:"uppercase", marginBottom:6 }}>{BIOMES[selectedEntity.biome]?.label||selectedEntity.biome} encounters</div>
                      {(world.encounterTables[selectedEntity.biome]||[]).map((enc,i)=>(
                        <div key={i} style={{ padding:"5px 0", borderBottom:`1px solid ${T.borderMid}`, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
                          <div>
                            <div style={{ fontSize:11, color:T.text, fontWeight:300 }}>{enc.count}x {enc.monster}</div>
                            <div style={{ fontSize:9, color:T.textFaint }}>{enc.notes}</div>
                          </div>
                          <div style={{ textAlign:"right" }}>
                            <Tag variant={enc.difficulty==="deadly"?"critical":enc.difficulty==="hard"?"danger":enc.difficulty==="medium"?"warning":"success"}>CR {enc.cr}</Tag>
                            <div style={{ fontSize:8, color:T.textFaint, marginTop:1 }}>{enc.treasure}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {selectedEntity.x!=null && <CrimsonBtn small onClick={()=>centerOn(selectedEntity.x,selectedEntity.y)} style={{ marginTop:6 }}><Compass size={9}/> Center on Map</CrimsonBtn>}
                </div>
              ) : (
                <div style={{ textAlign:"center", padding:28, color:T.textFaint }}>
                  <Eye size={22} style={{ marginBottom:6, opacity:0.3 }}/>
                  <p style={{ fontSize:11, fontWeight:300 }}>Click any map element to view details</p>
                </div>
              )}
            </div>
          )}

          {/* Lore Tab */}
          {sideTab==="lore" && world && (
            <div style={{ display:"flex", flexDirection:"column", gap:12 }}>
              <div style={{ fontFamily:T.ui, fontSize:8, letterSpacing:"1px", color:T.crimson, textTransform:"uppercase" }}>World History</div>
              {world.worldHistory.map((era,i)=>(
                <div key={i}>
                  <div style={{ fontSize:12, fontWeight:400, color:T.text, marginBottom:4, fontFamily:T.ui, letterSpacing:"1px" }}>{era.era}</div>
                  {era.events.map((ev,j)=>(
                    <div key={j} style={{ padding:"4px 0 4px 12px", borderLeft:`2px solid ${T.crimsonBorder}`, marginBottom:4 }}>
                      <div style={{ fontSize:9, color:T.crimsonDim, fontFamily:T.ui }}>{ev.year} AL</div>
                      <div style={{ fontSize:10, color:T.textDim, lineHeight:1.5 }}>{ev.event}</div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ═══ MAP VIEWPORT ═══ */}
      <div style={{ flex:1, position:"relative", overflow:"hidden", cursor:isPanning?"grabbing":"grab" }}
        onWheel={handleWheel} onMouseDown={handleMouseDown} onMouseMove={handleMouseMove} onMouseUp={handleMouseUp} onMouseLeave={handleMouseUp}>

        {generating && (
          <div style={{ position:"absolute", inset:0, zIndex:100, background:"rgba(0,0,6,0.70)", display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:14 }}>
            <RefreshCw size={28} color={T.crimson} style={{ animation:"spin 1s linear infinite" }}/>
            <span style={{ fontFamily:T.ui, fontSize:10, letterSpacing:"2px", color:T.crimson, textTransform:"uppercase" }}>Forging World...</span>
          </div>
        )}

        {world && (
          <svg ref={svgRef} width="100%" height="100%"
            viewBox={`${-pan.x*zoom} ${-pan.y*zoom} ${mapW/zoom*1.5} ${mapH/zoom*1.5}`}
            style={{ background: mapStyle==="parchment"?"#d4c4a0":BIOMES.deepOcean.color }}>

            <defs>
              <filter id="fmgParchment"><feTurbulence type="fractalNoise" baseFrequency="0.03" numOctaves="4" result="n"/><feDiffuseLighting in="n" lightingColor="#f5e6c8" surfaceScale="1" result="l"><feDistantLight azimuth="225" elevation="45"/></feDiffuseLighting><feComposite in="SourceGraphic" in2="l" operator="multiply"/></filter>
              <filter id="fmgShadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="1" stdDeviation="1" floodColor="#000" floodOpacity="0.5"/></filter>
              <filter id="fmgGlow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
              <pattern id="fmgWater" width="12" height="12" patternUnits="userSpaceOnUse"><rect width="12" height="12" fill={mapStyle==="parchment"?"#c0b090":"#1a4570"}/><path d="M0 6 Q3 4 6 6 Q9 8 12 6" stroke={mapStyle==="parchment"?"rgba(0,0,0,0.06)":"rgba(255,255,255,0.06)"} strokeWidth="0.5" fill="none"/></pattern>
              <pattern id="fmgForestPat" width="8" height="8" patternUnits="userSpaceOnUse"><circle cx="2" cy="2" r="0.8" fill="rgba(0,60,0,0.1)"/><circle cx="6" cy="6" r="1" fill="rgba(0,60,0,0.08)"/></pattern>
            </defs>

            {/* Terrain */}
            {layers.terrain && <g>{(()=>{
              const rects=[];
              for(let y=0;y<world.gridH;y+=renderStep) for(let x=0;x<world.gridW;x+=renderStep)
                rects.push(<rect key={`${x},${y}`} x={x*CELL} y={y*CELL} width={CELL*renderStep+0.5} height={CELL*renderStep+0.5} fill={getBiomeColor(world.biomeGrid[y][x])}/>);
              return rects;
            })()}</g>}

            {/* Debug overlays */}
            {layers.heightmap && <g opacity={0.6}>{(()=>{const r=[];for(let y=0;y<world.gridH;y+=renderStep) for(let x=0;x<world.gridW;x+=renderStep){const v=Math.floor(world.heightmap[y][x]*255);r.push(<rect key={`h${x},${y}`} x={x*CELL} y={y*CELL} width={CELL*renderStep+0.5} height={CELL*renderStep+0.5} fill={`rgb(${v},${v},${v})`}/>);}return r;})()}</g>}
            {layers.moisture && <g opacity={0.6}>{(()=>{const r=[];for(let y=0;y<world.gridH;y+=renderStep) for(let x=0;x<world.gridW;x+=renderStep){const m=world.moisture[y][x];r.push(<rect key={`m${x},${y}`} x={x*CELL} y={y*CELL} width={CELL*renderStep+0.5} height={CELL*renderStep+0.5} fill={`rgb(0,${Math.floor(m*200)},${Math.floor(m*255)})`}/>);}return r;})()}</g>}
            {layers.temperature && <g opacity={0.6}>{(()=>{const r=[];for(let y=0;y<world.gridH;y+=renderStep) for(let x=0;x<world.gridW;x+=renderStep){const t=world.temperature[y][x];r.push(<rect key={`t${x},${y}`} x={x*CELL} y={y*CELL} width={CELL*renderStep+0.5} height={CELL*renderStep+0.5} fill={`rgb(${Math.floor(t*255)},${Math.floor((1-Math.abs(t-0.5)*2)*100)},${Math.floor((1-t)*255)})`}/>);}return r;})()}</g>}

            {/* Grid */}
            {layers.grid && <g opacity={0.12} stroke={mapStyle==="parchment"?"#5a4a30":"#c0c0c0"} strokeWidth={0.3}>
              {Array.from({length:Math.ceil(world.gridW/10)+1},(_,i)=><line key={`gv${i}`} x1={i*10*CELL} y1={0} x2={i*10*CELL} y2={world.gridH*CELL}/>)}
              {Array.from({length:Math.ceil(world.gridH/10)+1},(_,i)=><line key={`gh${i}`} x1={0} y1={i*10*CELL} x2={world.gridW*CELL} y2={i*10*CELL}/>)}
            </g>}

            {/* Kingdom territories */}
            {layers.kingdoms && world.kingdoms.map((k,i)=>(
              <g key={`k${i}`}>
                <path d={hullToSmoothPath(k.hull,CELL)} fill={mapStyle==="political"?k.color.replace("0.12","0.25"):k.color} stroke={k.borderColor} strokeWidth={mapStyle==="political"?3:2} strokeDasharray={mapStyle==="political"?"none":"8,4"}/>
                {showLabels&&layers.labels&&<text x={k.hull.reduce((s,p)=>s+p.x,0)/k.hull.length*CELL} y={k.hull.reduce((s,p)=>s+p.y,0)/k.hull.length*CELL} textAnchor="middle" fill={k.borderColor.replace("0.45","0.8")} fontFamily="'Cinzel', serif" fontSize={zoom>1?10:14} fontWeight={500} letterSpacing="3px" style={{textTransform:"uppercase"}} filter="url(#fmgShadow)">{k.name}</text>}
              </g>
            ))}

            {/* Rivers */}
            {layers.rivers && world.rivers.map((r,i)=>(
              <g key={`r${i}`}>
                <path d={pointsToSmoothPath(r.path,CELL)} fill="none" stroke={mapStyle==="parchment"?"#8090a0":"#3a7ab0"} strokeWidth={r.width} strokeLinecap="round" strokeLinejoin="round" opacity={0.75}/>
                {layers.tributaries && r.tributaries.map((t,j)=><path key={`rt${j}`} d={pointsToSmoothPath(t.path,CELL)} fill="none" stroke={mapStyle==="parchment"?"#8090a0":"#3a7ab0"} strokeWidth={t.width*0.7} strokeLinecap="round" opacity={0.5}/>)}
                {showLabels&&layers.labels&&r.path.length>10&&<text x={r.path[Math.floor(r.path.length/3)].x*CELL} y={r.path[Math.floor(r.path.length/3)].y*CELL-4} fill={mapStyle==="parchment"?"#607080":"#5a9ac8"} fontSize={8} fontFamily="'Spectral', serif" fontStyle="italic" filter="url(#fmgShadow)">{r.name}</text>}
                {layers.waterfall && r.waterfalls.map((wf,j)=><FMG_Waterfall key={`wf${j}`} x={wf.x*CELL} y={wf.y*CELL} s={0.8}/>)}
              </g>
            ))}

            {/* Roads */}
            {layers.roads && world.roads.filter(r=>r.type!=="trade"||layers.tradeRoutes).map((r,i)=>(
              <path key={`rd${i}`} d={pointsToSmoothPath(r.path,CELL)} fill="none"
                stroke={r.type==="major"?"rgba(180,140,80,0.5)":r.type==="trade"?"rgba(200,100,60,0.3)":"rgba(150,130,90,0.3)"}
                strokeWidth={r.type==="major"?2:r.type==="trade"?1.5:1}
                strokeDasharray={r.type==="major"?"none":r.type==="trade"?"6,4":"4,3"}
                strokeLinecap="round"/>
            ))}

            {/* Decorative terrain icons */}
            {layers.icons && showDecoIcons && layers.decorations && world && (()=>{
              const icons = [];
              const step = zoom < 0.6 ? 12 : zoom < 1.2 ? 8 : 5;
              for (let y = 0; y < world.gridH; y += step) {
                for (let x = 0; x < world.gridW; x += step) {
                  const b = world.biomeGrid[y]?.[x];
                  const px = x*CELL, py = y*CELL;
                  if (b==="mountain"||b==="snowMountain") icons.push(b==="snowMountain" ? <FMG_SnowMountain key={`di${x},${y}`} x={px} y={py} s={0.7}/> : <FMG_Mountain key={`di${x},${y}`} x={px} y={py} s={0.6}/>);
                  else if (b==="hills"||b==="highlands") icons.push(<FMG_Hill key={`di${x},${y}`} x={px} y={py} s={0.5}/>);
                  else if (b==="forest"||b==="denseForest") icons.push(<FMG_Tree key={`di${x},${y}`} x={px} y={py} s={0.5} color={b==="denseForest"?"#1d4818":"#3a6830"}/>);
                  else if (b==="taiga") icons.push(<FMG_PineTree key={`di${x},${y}`} x={px} y={py} s={0.5}/>);
                  else if (b==="jungle") icons.push(<FMG_PalmTree key={`di${x},${y}`} x={px} y={py} s={0.5}/>);
                  else if (b==="desert"&&(x+y)%24===0) icons.push(<FMG_Cactus key={`di${x},${y}`} x={px} y={py} s={0.4}/>);
                }
              }
              return <g opacity={0.5}>{icons}</g>;
            })()}

            {/* Landmark labels */}
            {layers.landmarks && showLabels && world.landmarks.map((l,i)=>(
              <text key={`lm${i}`} x={l.x*CELL} y={l.y*CELL} textAnchor="middle" fill={mapStyle==="parchment"?"rgba(80,60,30,0.5)":"rgba(255,255,255,0.5)"} fontFamily="'Cinzel', serif" fontSize={l.type==="mountain_range"?11:l.type==="desert"?10:9} fontStyle={l.type==="forest"||l.type==="swamp"?"italic":"normal"} letterSpacing="2px" style={{textTransform:"uppercase"}} filter="url(#fmgShadow)">{l.name}</text>
            ))}

            {/* Sea names */}
            {layers.seaNames && world.seas.map((s,i)=>(
              <text key={`sea${i}`} x={s.x*CELL} y={s.y*CELL} textAnchor="middle" fill={mapStyle==="parchment"?"rgba(80,90,100,0.35)":"rgba(100,160,220,0.35)"} fontFamily="'Cinzel', serif" fontSize={s.size>400?16:s.size>200?12:9} letterSpacing="5px" fontStyle="italic" style={{textTransform:"uppercase"}} filter="url(#fmgShadow)">{s.name}</text>
            ))}

            {/* Settlements */}
            {layers.settlements && world.settlements.map((s,i)=>{
              if(s.type==="hamlet"&&!showHamlets) return null;
              if((s.type==="village"||s.type==="hamlet")&&!showSmall) return null;
              const Icon = FMG_ICON_MAP[s.type];
              const isSelected = selectedEntity?.name===s.name&&selectedEntity?.entityType==="settlement";
              const sc = s.type==="capital"?1.2:s.type==="city"?1:s.type==="town"?0.8:0.6;
              return (
                <g key={`s${i}`} onClick={(e)=>{e.stopPropagation();handleEntityClick({...s,entityType:"settlement"});}} onMouseEnter={()=>setHoveredEntity(s)} onMouseLeave={()=>setHoveredEntity(null)} style={{cursor:"pointer"}}>
                  {isSelected && <circle cx={s.x*CELL} cy={s.y*CELL} r={12*sc} fill="none" stroke={T.crimson} strokeWidth={1.5} filter="url(#fmgGlow)"/>}
                  {layers.icons && Icon ? <Icon x={s.x*CELL} y={s.y*CELL} s={sc}/> : <circle cx={s.x*CELL} cy={s.y*CELL} r={4*sc} fill={s.type==="capital"?"#ffd700":"#c8b070"} stroke="#6a5a30" strokeWidth={0.5}/>}
                  {showLabels&&layers.labels&&(s.type==="capital"||s.type==="city"||(showDetails&&s.type==="town"))&&(
                    <text x={s.x*CELL} y={s.y*CELL-10*sc} textAnchor="middle" fill={mapStyle==="parchment"?"#3a2a10":"#f0e8d0"} fontFamily="'Cinzel', serif" fontSize={s.type==="capital"?9:7} fontWeight={s.type==="capital"?700:400} letterSpacing={s.type==="capital"?"1.5px":"0.5px"} filter="url(#fmgShadow)">{s.name}</text>
                  )}
                </g>
              );
            })}

            {/* POIs */}
            {layers.pois && world.pois.map((p,i)=>{
              if(!showSmall&&!p.discovered) return null;
              const Icon = FMG_ICON_MAP[p.type];
              const isSelected = selectedEntity?.name===p.name&&selectedEntity?.entityType==="poi";
              return (
                <g key={`p${i}`} onClick={(e)=>{e.stopPropagation();handleEntityClick({...p,entityType:"poi"});}} onMouseEnter={()=>setHoveredEntity(p)} onMouseLeave={()=>setHoveredEntity(null)} style={{cursor:"pointer"}}>
                  {isSelected && <circle cx={p.x*CELL} cy={p.y*CELL} r={10} fill="none" stroke={T.crimson} strokeWidth={1.5} filter="url(#fmgGlow)"/>}
                  {layers.icons && Icon ? <Icon x={p.x*CELL} y={p.y*CELL} s={0.7}/> : <circle cx={p.x*CELL} cy={p.y*CELL} r={3} fill="#8a7060" stroke="rgba(0,0,6,0.35)" strokeWidth={0.5}/>}
                  {showPOILabels&&layers.labels&&<text x={p.x*CELL} y={p.y*CELL-8} textAnchor="middle" fill={mapStyle==="parchment"?"rgba(60,40,20,0.6)":"rgba(220,200,180,0.6)"} fontFamily="'Spectral', serif" fontSize={6} fontStyle="italic" filter="url(#fmgShadow)">{p.name}</text>}
                </g>
              );
            })}

            {/* Compass Rose */}
            {layers.compass && <FMG_Compass x={mapW-60} y={mapH-60} s={1.5} color={mapStyle==="parchment"?"#6a5a40":"#a0a0a0"}/>}

            {/* Scale Bar */}
            {layers.compass && <FMG_ScaleBar x={60} y={mapH-30} s={1} color={mapStyle==="parchment"?"#6a5a40":"#a0a0a0"}/>}

            {/* Hover Tooltip */}
            {hoveredEntity&&!isPanning&&(
              <g>
                <rect x={hoveredEntity.x*CELL+10} y={hoveredEntity.y*CELL-35} width={Math.max(120,hoveredEntity.name.length*7+24)} height={44} rx={2} fill="rgba(15,15,20,0.92)" stroke="rgba(150,80,80,0.4)" strokeWidth={0.5}/>
                <text x={hoveredEntity.x*CELL+18} y={hoveredEntity.y*CELL-20} fill="#f0e0c0" fontFamily="'Cinzel', serif" fontSize={9} fontWeight={500}>{hoveredEntity.name}</text>
                <text x={hoveredEntity.x*CELL+18} y={hoveredEntity.y*CELL-8} fill="rgba(200,180,150,0.6)" fontFamily="'Spectral', serif" fontSize={7} style={{textTransform:"capitalize"}}>{hoveredEntity.type}{hoveredEntity.population?` | Pop. ${hoveredEntity.population.toLocaleString()}`:""}</text>
                {hoveredEntity.threat&&<text x={hoveredEntity.x*CELL+18} y={hoveredEntity.y*CELL+3} fill={hoveredEntity.threat==="deadly"||hoveredEntity.threat==="extreme"?"#ff7070":hoveredEntity.threat==="high"?"#f5c45c":"#5ee09a"} fontFamily="'Spectral', serif" fontSize={7}>Threat: {hoveredEntity.threat}</text>}
              </g>
            )}
          </svg>
        )}

        {/* Map Controls */}
        <div style={{ position:"absolute", bottom:14, left:14, display:"flex", gap:6, zIndex:50 }}>
          <div style={{ background:"rgba(15,15,20,0.88)", border:`1px solid ${T.border}`, borderRadius:2, padding:"5px 7px", display:"flex", alignItems:"center", gap:6 }}>
            <button onClick={()=>setZoom(z=>clamp(z*0.7,0.12,10))} style={{ background:"none", border:"none", cursor:"pointer", color:T.textMuted, padding:1 }}><Minus size={11}/></button>
            <span style={{ fontFamily:T.ui, fontSize:7, color:T.textDim, letterSpacing:"1px", minWidth:36, textAlign:"center" }}>{(zoom*100).toFixed(0)}%</span>
            <button onClick={()=>setZoom(z=>clamp(z*1.3,0.12,10))} style={{ background:"none", border:"none", cursor:"pointer", color:T.textMuted, padding:1 }}><Plus size={11}/></button>
          </div>
          <div style={{ background:"rgba(15,15,20,0.88)", border:`1px solid ${T.border}`, borderRadius:2, padding:"5px 7px", display:"flex", gap:4 }}>
            {[{l:"Fit",z:0.5},{l:"Region",z:1.5},{l:"Local",z:3},{l:"Detail",z:5}].map(p=>(
              <button key={p.l} onClick={()=>setZoom(p.z)} style={{ background:Math.abs(zoom-p.z)<0.15?T.crimsonSoft:"transparent", border:"none", cursor:"pointer", padding:"2px 6px", borderRadius:2, fontFamily:T.ui, fontSize:6, letterSpacing:"1px", color:Math.abs(zoom-p.z)<0.15?T.crimson:T.textMuted, textTransform:"uppercase" }}>{p.l}</button>
            ))}
          </div>
        </div>

        {/* Info bar */}
        <div style={{ position:"absolute", bottom:14, right:14, background:"rgba(15,15,20,0.88)", border:`1px solid ${T.border}`, borderRadius:2, padding:"5px 9px", zIndex:50 }}>
          <span style={{ fontFamily:T.ui, fontSize:6, letterSpacing:"1px", color:T.textFaint }}>{world?`${world.gridW}x${world.gridH} | Seed: ${world.seed} | ${mapStyle}`:"No world"}</span>
        </div>

        {/* Minimap */}
        {world && (
          <div style={{ position:"absolute", top:14, right:14, width:180, height:135, background:"rgba(15,15,20,0.92)", border:`1px solid ${T.border}`, borderRadius:2, overflow:"hidden", zIndex:50 }}>
            <svg width="180" height="135" viewBox={`0 0 ${world.gridW} ${world.gridH}`}>
              {(()=>{const r=[],st=4;for(let y=0;y<world.gridH;y+=st) for(let x=0;x<world.gridW;x+=st) r.push(<rect key={`mm${x},${y}`} x={x} y={y} width={st} height={st} fill={getBiomeColor(world.biomeGrid[y][x])}/>);return r;})()}
              {world.kingdoms.map((k,i)=><path key={`mmk${i}`} d={hullToSmoothPath(k.hull,1)} fill={k.color} stroke={k.borderColor} strokeWidth={0.5}/>)}
              {world.settlements.filter(s=>s.type==="capital"||s.type==="city").map((s,i)=><circle key={`mms${i}`} cx={s.x} cy={s.y} r={s.type==="capital"?1.5:1} fill="#ffd700"/>)}
              <rect x={(-pan.x)/CELL} y={(-pan.y)/CELL} width={world.gridW/zoom*0.5} height={world.gridH/zoom*0.5} fill="none" stroke={T.crimson} strokeWidth={1} opacity={0.8}/>
            </svg>
          </div>
        )}

        {!world&&!generating&&(
          <div style={{ position:"absolute", inset:0, display:"flex", alignItems:"center", justifyContent:"center", flexDirection:"column", gap:14 }}>
            <MapIcon size={44} color={T.textFaint}/>
            <span style={{ fontFamily:T.ui, fontSize:10, letterSpacing:"2px", color:T.textMuted, textTransform:"uppercase" }}>Enter a seed and click Generate</span>
          </div>
        )}
      </div>

      <style>{`@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}

export default function CampaignManager() {
  const [campaigns, setCampaigns] = useState([
    { id: "example", data: JSON.parse(JSON.stringify(EXAMPLE_CAMPAIGN)), isExample: true },
  ]);
  const [activeCampaignId, setActiveCampaignId] = useState("example");
  const [tab, setTab] = useState("dashboard");

  const data = campaigns.find(c=>c.id===activeCampaignId)?.data || NEW_CAMPAIGN();
  const setData = (updater) => {
    setCampaigns(prev => prev.map(c => {
      if (c.id !== activeCampaignId) return c;
      const newData = typeof updater === "function" ? updater(c.data) : updater;
      return { ...c, data: newData };
    }));
  };

  const createCampaign = () => {
    const newId = `campaign-${Date.now()}`;
    setCampaigns(prev => [...prev, { id: newId, data: NEW_CAMPAIGN(), isExample: false }]);
    setActiveCampaignId(newId);
    setTab("dashboard");
  };
  const deleteCampaign = (id) => {
    setCampaigns(prev => prev.filter(c => c.id !== id));
    if (activeCampaignId === id) {
      const remaining = campaigns.filter(c => c.id !== id);
      setActiveCampaignId(remaining[0]?.id || "");
    }
  };

  const allTabs = [
    { id:"dashboard", label:"Campaign Hub", icon:Compass, always:true },
    { id:"timeline",  label:"Timeline",     icon:Clock,   module:"timeline" },
    { id:"world",     label:"World",        icon:Globe,   module:"worldState" },
    { id:"play",      label:"Play Mode",    icon:Swords,  module:"playMode" },
    { id:"generator", label:"Map Forge",    icon:MapIcon, always:true },
    { id:"notes",     label:"Notes",        icon:BookOpen, module:"notesEditor" },
    { id:"settings",  label:"Settings",     icon:Settings, always:true },
  ];

  const tabs = allTabs.filter(t => t.always || data.modules[t.module]);

  return (
    <div style={{ width:"100%", height:"100vh", display:"flex", flexDirection:"column", background:T.bg, color:T.text, fontFamily:T.body, overflow:"hidden" }}>
      <nav style={{ display:"flex", alignItems:"center", gap:0, padding:"0 56px", height:56, flexShrink:0, borderBottom:`1px solid ${T.border}`, background:T.bgNav, position:"sticky", top:0, zIndex:200 }}>
        <div style={{ display:"flex", alignItems:"center", gap:10, marginRight:36 }}>
          <Crown size={16} color={T.crimson} />
          <span style={{ fontFamily:T.ui, fontSize:10, fontWeight:500, color:T.text, letterSpacing:"3px", textTransform:"uppercase" }}>Campaign Manager</span>
        </div>
        <div style={{ flex:1, display:"flex", gap:24, overflowX:"auto" }}>
          {tabs.map(t => (
            <button key={t.id} onClick={()=>setTab(t.id)} style={{
              background:"transparent", border:"none", cursor:"pointer", padding:"18px 0",
              fontFamily:T.ui, fontSize:10, letterSpacing:"3px", textTransform:"uppercase",
              color:tab===t.id?T.text:T.textMuted, fontWeight:500, position:"relative",
              display:"flex", alignItems:"center", gap:6, transition:"color 0.2s", whiteSpace:"nowrap",
              borderBottom:tab===t.id?`2px solid ${T.crimson}`:"2px solid transparent",
            }}><t.icon size={13}/> {t.label}</button>
          ))}
        </div>
        <div style={{ display:"flex", alignItems:"center", gap:16 }}>
          <CampaignSelector
            campaigns={campaigns}
            activeCampaignId={activeCampaignId}
            onSelect={setActiveCampaignId}
            onCreate={createCampaign}
            onDelete={deleteCampaign}
          />
          <Bell size={14} color={T.textFaint} style={{cursor:"pointer"}} />
        </div>
      </nav>

      <div style={{ flex:1, overflow:"hidden" }}>
        <div style={{ height:"100%", overflowY:"auto" }}>
          {tab==="dashboard" && <DashboardView data={data} setData={setData} onNav={setTab}/>}
          {tab==="timeline"  && <TimelineView data={data} setData={setData}/>}
          {tab==="world"     && <WorldView data={data} setData={setData}/>}
          {tab==="play"      && <PlayView data={data} setData={setData}/>}
          {tab==="generator" && <FantasyMapGenerator />}
          {tab==="notes"     && <NotesView data={data} setData={setData}/>}
          {tab==="settings"  && <SettingsView data={data} setData={setData}/>}
        </div>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;700&family=Spectral:ital,wght@0,300;0,400;0,500;1,300;1,400&display=swap');
        @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.3} }
        @keyframes fadeIn { from{opacity:0} to{opacity:1} }
        *{box-sizing:border-box;}
        ::selection{background:${T.crimson};color:${T.text};}
        ::-webkit-scrollbar{width:4px;}
        ::-webkit-scrollbar-track{background:transparent;}
        ::-webkit-scrollbar-thumb{background:${T.textFaint};border-radius:2px;}
        ::-webkit-scrollbar-thumb:hover{background:${T.textMuted};}
        input::placeholder{color:${T.textFaint};}
        textarea::placeholder{color:${T.textFaint};}
        input:focus, textarea:focus{outline:none;border-color:${T.crimson}!important;box-shadow:0 0 0 3px ${T.crimsonSoft};}
        select:focus{outline:none;border-color:${T.crimson}!important;}
        button:hover{filter:brightness(1.1);}
        input[type="range"]{-webkit-appearance:none;height:4px;background:${T.bgInput};border-radius:2px;outline:none;}
        input[type="range"]::-webkit-slider-thumb{-webkit-appearance:none;width:14px;height:14px;background:${T.crimson};border-radius:50%;cursor:pointer;}
      `}</style>
    </div>
  );
}

